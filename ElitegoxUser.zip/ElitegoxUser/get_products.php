<?php  
include 'config.php';  

header('Content-Type: application/json');

$data = [];

$sql = $conn->query("SELECT * FROM products ORDER BY id DESC");

while($row = $sql->fetch_assoc()){

    $stock = intval($row['stock']);
    $sold = intval($row['sold']);

    $left = $stock - $sold;

    if ($left > 0) {
        $stock_status = "Stock Available";
    } else {
        $stock_status = "Stock Out";
        $left = 0;
    }

    $data[] = [
        "id" => $row['id'],
        "title" => $row['title'],
        "amount" => $row['amount'],
        "discount" => $row['discount'],
        "description" => $row['description'],
        "stock" => $stock,
        "sold" => $sold,
        "left" => $left,
        "stock_status" => $stock_status,
        "image_link" => $row['image_link'] // ONLY THUMBNAIL
    ];
}

echo json_encode([
    "status" => "success",
    "products" => $data
]);
?>