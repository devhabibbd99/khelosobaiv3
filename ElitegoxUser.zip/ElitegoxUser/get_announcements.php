<?php
include 'config.php';

header('Content-Type: application/json');

$result = $conn->query("
    SELECT *
    FROM announcements
    ORDER BY id DESC
");

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = [
        "id" => $row['id'],
        "title" => $row['title'],
        "image_link" => $row['image_link'],
        "message" => $row['message'],
        "date" => $row['announce_date'],
        "time" => $row['announce_time']
    ];
}

echo json_encode([
    "status" => "success",
    "data" => $data
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>