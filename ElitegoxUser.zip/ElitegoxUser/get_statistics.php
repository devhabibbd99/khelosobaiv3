<?php
header('Content-Type: application/json');
include 'config.php';

$email = $_POST['email'] ?? '';
$type  = $_POST['type']  ?? '';

if (empty($email)) {
    echo json_encode([
        'success' => false,
        'message' => 'Email parameter missing'
    ]);
    exit;
}

if (empty($type)) {
    echo json_encode([
        'success' => false,
        'message' => 'Type parameter missing'
    ]);
    exit;
}

if ($type === 'winnings') {
    $stmt = $conn->prepare("
        SELECT match_id, match_title, type, played_on, winnings, winaddmsg
        FROM statistics
        WHERE email = ?
          AND winnings > 0
    ");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    echo json_encode([
        'success' => true,
        'type'    => 'winnings',
        'data'    => $rows
    ]);
} elseif ($type === 'participate') {
    $stmt = $conn->prepare("
        SELECT match_id, match_title, type, played_on, paid
        FROM statistics
        WHERE email = ?
          AND (winnings = 0 OR winnings IS NULL)
          AND (refund_amount = 0 OR refund_amount IS NULL)
    ");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    echo json_encode([
        'success' => true,
        'type'    => 'participate',
        'data'    => $rows
    ]);
} elseif ($type === 'refund') {
    $stmt = $conn->prepare("
        SELECT match_id, match_title, type, played_on, 
               COALESCE(refund_amount, 0) AS refund_amount, 
               refund_reason
        FROM statistics
        WHERE email = ?
          AND refund_amount > 0
    ");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    foreach ($rows as &$row) {
        $row['refund_amount'] = $row['refund_amount'] ?? 0;
    }

    echo json_encode([
        'success' => true,
        'type'    => 'refund',
        'data'    => $rows
    ]);
} elseif ($type === 'all') {
    $stmt = $conn->prepare("SELECT * FROM statistics WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $all = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $winnings    = [];
    $refund      = [];
    $participate = [];

    foreach ($all as $row) {
        $row['refund_amount'] = $row['refund_amount'] ?? 0;
        
        if (!empty($row['winnings']) && $row['winnings'] > 0) {
            $winnings[] = $row;
        } elseif (!empty($row['refund_amount']) && $row['refund_amount'] > 0) {
            $refund[] = $row;
        } else {
            $participate[] = $row;
        }
    }

    echo json_encode([
        'success'     => true,
        'type'        => 'all',
        'winnings'    => $winnings,
        'refund'      => $refund,
        'participate' => $participate
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid type. Use: winnings | participate | refund | all'
    ]);
}

$conn->close();
?>