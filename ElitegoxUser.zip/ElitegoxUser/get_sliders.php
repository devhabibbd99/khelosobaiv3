<?php
header('Content-Type: application/json');
include 'config.php';

// Check table exists or not (optional safe guard)
$conn->query("
CREATE TABLE IF NOT EXISTS imagesliders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_url TEXT NOT NULL,
    activity_link TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

$result = $conn->query("SELECT * FROM imagesliders ORDER BY id DESC");
$sliders = [];

while ($row = $result->fetch_assoc()) {
    $sliders[] = $row;
}

echo json_encode(["success" => true, "data" => $sliders]);

$conn->close();
?>