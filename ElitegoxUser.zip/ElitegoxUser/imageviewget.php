<?php
include 'config.php';
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $result = $conn->query("SELECT * FROM sliders ORDER BY id DESC LIMIT 1");

    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();

        $response = [
            "success" => true,
            "image1" => $data['image1'],
            "image2" => $data['image2'],
            "image3" => $data['image3'],
            "image4" => $data['image4'],
            "image5" => $data['image5'],
            "image6" => $data['image6']
        ];
    } else {
        $response = [
            "success" => false,
            "message" => "No images found"
        ];
    }

    echo json_encode($response);
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
}
?>