<?php
// Prevent double inclusion
if (!defined('CRAZYTOUR_CONFIG_INCLUDED')) {
    define('CRAZYTOUR_CONFIG_INCLUDED', true);

    header('Content-Type: application/json');
    date_default_timezone_set("Asia/Dhaka");

    // Database Config
    $hostname = "localhost";
    $username = "skmespor_SKmSHUVONEwDBoKHAHACkKOr";
    $password = "SKmSHUVONEwDBoKHAHACkKOr";
    $database = "skmespor_SKmSHUVONEwDBoKHAHACkKOr";

    $conn = new mysqli($hostname, $username, $password, $database);
    $conn->set_charset("utf8mb4");

    if ($conn->connect_error) {
        die(json_encode(["error" => "Connection Failed: " . $conn->connect_error]));
    }

    // Suspicious User-Agent Detection
    $user_agent = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    $suspicious_agents = ['sqlmap', 'curl', 'wget', 'hackbar', 'python', 'httpclient', 'libwww', 'nmap'];
    foreach ($suspicious_agents as $agent) {
        if (strpos($user_agent, $agent) !== false) {
            http_response_code(403);
            echo json_encode(["error" => "Blocked: Suspicious User Agent"]);
            exit;
        }
    }

    // Suspicious Header Detection
    $headers = getallheaders();
    foreach ($headers as $key => $value) {
        $key = strtolower($key);
        $value = strtolower($value);
        if (strpos($key, 'x-requested-with') !== false && strpos($value, 'darknethaxor') !== false) {
            http_response_code(403);
            echo json_encode(["error" => "Blocked: Suspicious Header"]);
            exit;
        }
    }

    // Method Whitelist
    $allowed_methods = ['POST', 'GET'];
    if (!in_array($_SERVER['REQUEST_METHOD'], $allowed_methods)) {
        http_response_code(405);
        echo json_encode(["error" => "Method Not Allowed"]);
        exit;
    }

    // Deep pattern detector (SQLi + XSS)
    if (!function_exists('is_malicious_input')) {
        function is_malicious_input($input) {
            $patterns = [
                // SQL Injection
                'union select', 'information_schema', 'sleep(', 'benchmark(', 'load_file', 'outfile', 'or 1=1', '--', ';--',
                // XSS
                '<script', 'javascript:', 'onerror', 'onload', 'alert(', 'prompt(', 'confirm(', 'document.cookie', '<img', '<svg', '<iframe', '<object'
            ];

            $decoded_inputs = [
                strtolower($input),
                strtolower(urldecode($input)),
                strtolower(htmlspecialchars_decode($input)),
                strtolower(base64_decode($input))
            ];

            foreach ($patterns as $pattern) {
                foreach ($decoded_inputs as $decoded) {
                    if (strpos($decoded, $pattern) !== false) {
                        return true;
                    }
                }
            }

            return false;
        }
    }

    // Check all GET, POST, COOKIE data
    $all_inputs = array_merge($_GET, $_POST, $_COOKIE);
    foreach ($all_inputs as $key => $value) {
        if (is_array($value)) {
            $value = implode(' ', $value);
        }
        if (is_malicious_input($value)) {
            http_response_code(403);
            echo json_encode(["error" => "Blocked: Malicious input detected"]);
            exit;
        }
    }
}
?>