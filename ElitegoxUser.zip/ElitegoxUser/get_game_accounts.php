<?php
include 'config.php';

header('Content-Type: application/json');

$token = trim($_POST['token'] ?? '');

if (empty($token)) {
    echo json_encode([
        "status" => "failed",
        "message" => "Token Required"
    ]);
    exit;
}

$stmt = $conn->prepare("
    SELECT id,
           ingame_name,
           game_uid,
           level,
           is_default,
           created_at
    FROM game_accounts
    WHERE token=?
    ORDER BY id DESC
");

$stmt->bind_param("s", $token);
$stmt->execute();

$result = $stmt->get_result();

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode([
    "status" => "success",
    "total" => count($data),
    "data" => $data
], JSON_UNESCAPED_UNICODE);
?>