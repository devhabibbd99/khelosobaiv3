<?php
include 'config.php';

header('Content-Type: application/json');

$type = trim($_POST['type'] ?? 'save'); // save | edit | delete

/* ============================================================
   TYPE = SAVE  (Original logic — untouched)
   ============================================================ */
if ($type == "save") {

    $token = trim($_POST['token'] ?? '');
    $ingame_name = trim($_POST['ingame_name'] ?? '');
    $game_uid = trim($_POST['game_uid'] ?? '');
    $level = trim($_POST['level'] ?? '');
    $is_default = trim($_POST['is_default'] ?? 'false');

    if (
        empty($token) ||
        empty($ingame_name) ||
        empty($game_uid) ||
        empty($level)
    ) {
        echo json_encode([
            "status" => "failed",
            "message" => "All fields required"
        ]);
        exit;
    }

    if ($is_default != "true") {
        $is_default = "false";
    }

    if ($is_default == "true") {
        $stmt = $conn->prepare("UPDATE game_accounts SET is_default='false' WHERE token=?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
    }

    $stmt = $conn->prepare("
        INSERT INTO game_accounts
        (token, ingame_name, game_uid, level, is_default)
        VALUES (?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "sssss",
        $token,
        $ingame_name,
        $game_uid,
        $level,
        $is_default
    );

    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "Account Saved"
        ]);
    } else {
        echo json_encode([
            "status" => "failed",
            "message" => "Save Failed"
        ]);
    }
    exit;
}

/* ============================================================
   TYPE = EDIT  (Same params as save + id)
   ============================================================ */
if ($type == "edit") {

    $token = trim($_POST['token'] ?? '');
    $id = trim($_POST['id'] ?? '');
    $ingame_name = trim($_POST['ingame_name'] ?? '');
    $game_uid = trim($_POST['game_uid'] ?? '');
    $level = trim($_POST['level'] ?? '');
    $is_default = trim($_POST['is_default'] ?? 'false');

    if (
        empty($token) ||
        empty($id) ||
        empty($ingame_name) ||
        empty($game_uid) ||
        empty($level)
    ) {
        echo json_encode([
            "status" => "failed",
            "message" => "All fields required"
        ]);
        exit;
    }

    if ($is_default != "true") {
        $is_default = "false";
    }

    if ($is_default == "true") {
        $stmt = $conn->prepare("UPDATE game_accounts SET is_default='false' WHERE token=?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
    }

    $stmt = $conn->prepare("
        UPDATE game_accounts
        SET ingame_name=?, game_uid=?, level=?, is_default=?
        WHERE id=? AND token=?
    ");

    $stmt->bind_param(
        "ssssis",
        $ingame_name,
        $game_uid,
        $level,
        $is_default,
        $id,
        $token
    );

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode([
                "status" => "success",
                "message" => "Account Updated"
            ]);
        } else {
            echo json_encode([
                "status" => "failed",
                "message" => "No Account Found / Nothing Changed"
            ]);
        }
    } else {
        echo json_encode([
            "status" => "failed",
            "message" => "Update Failed"
        ]);
    }
    exit;
}

/* ============================================================
   TYPE = DELETE  (Only id + token)
   ============================================================ */
if ($type == "delete") {

    $token = trim($_POST['token'] ?? '');
    $id = trim($_POST['id'] ?? '');

    if (empty($token) || empty($id)) {
        echo json_encode([
            "status" => "failed",
            "message" => "All fields required"
        ]);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM game_accounts WHERE id=? AND token=?");
    $stmt->bind_param("is", $id, $token);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode([
                "status" => "success",
                "message" => "Account Deleted"
            ]);
        } else {
            echo json_encode([
                "status" => "failed",
                "message" => "No Account Found"
            ]);
        }
    } else {
        echo json_encode([
            "status" => "failed",
            "message" => "Delete Failed"
        ]);
    }
    exit;
}

/* ============================================================
   INVALID TYPE
   ============================================================ */
echo json_encode([
    "status" => "failed",
    "message" => "Invalid type"
]);
?>