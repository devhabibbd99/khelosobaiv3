<?php
include 'config.php';

header('Content-Type: application/json; charset=utf-8');

$conn->set_charset("utf8mb4");

$result = mysqli_query($conn, "SELECT * FROM appinfo LIMIT 1");

if ($result && mysqli_num_rows($result) > 0) {
    $data = mysqli_fetch_assoc($result);

    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
} else {
    echo json_encode([
        "status" => false,
        "message" => "No App Info Found"
    ]);
}

mysqli_close($conn);
?>