<?php
// config.php ফাইল ইনক্লুড করা হলো
include 'config.php'; 

header('Content-Type: application/json');
date_default_timezone_set("Asia/Dhaka"); // আপনার টাইমজোন অনুযায়ী

// আপনার টেবিল থেকে ডেটা আনা
$sql = "SELECT withdraw_block_time FROM appinfo LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $db_time = $row['withdraw_block_time']; // ডাটাবেস ভ্যালু: 25/03/2026 At 10:00 PM

    // " At " লেখাটি সরিয়ে স্ট্যান্ডার্ড ফরম্যাটে আনা (যেমন: 25/03/2026 10:00 PM)
    $clean_time = str_replace(" At ", " ", $db_time);

    // d/m/Y ফরম্যাটকে PHP এর বোঝার সুবিধার্থে Y-m-d এ রূপান্তর
    $temp_date = DateTime::createFromFormat('d/m/Y h:i A', $clean_time);
    
    if ($temp_date) {
        $block_timestamp = $temp_date->getTimestamp();
        $current_timestamp = time();

        if ($current_timestamp < $block_timestamp) {
            // এখনো ব্লক টাইম শেষ হয়নি (সেকেন্ড যাই হোক না কেন)
            $diff_seconds = $block_timestamp - $current_timestamp;
            
            echo json_encode([
                "status" => "suspended",
                "remaining_seconds" => $diff_seconds,
                "target_time" => $db_time // ডায়ালগে দেখানোর জন্য অরিজিনাল টাইম
            ]);
        } else {
            // ব্লক টাইম পার হয়ে গেছে
            echo json_encode(["status" => "ok"]);
        }
    } else {
        // যদি টাইম ফরম্যাটে ভুল থাকে তবে নরমাল স্ট্যাটাস দেবে
        echo json_encode(["status" => "ok"]);
    }
} else {
    echo json_encode(["status" => "ok"]);
}

$conn->close();
?>
