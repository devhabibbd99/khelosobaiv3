<?php
include 'config.php';
$conn->set_charset("utf8mb4");

$type = $_POST["type"];

if ($type == "AllRulse") {
    $sql = "SELECT * FROM match_types";
    $result = $conn->query($sql);

    $data = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
    } else {
        echo "No Data Found";
    }
}
$conn->close();
?>