<?php
include 'config.php';

header('Content-Type: application/json');

$email = trim($_POST['email'] ?? '');

if (empty($email)) {
    echo json_encode([
        "status" => "failed",
        "message" => "Email Required"
    ]);
    exit;
}

$stmt = $conn->prepare("
    SELECT *
    FROM user_announcements
    WHERE email=?
    ORDER BY id DESC
");

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

$data = [];

while ($row = $result->fetch_assoc()) {

    $data[] = [
        "id" => $row['id'],
        "title" => $row['title'],
        "image_link" => $row['image_link'],
        "message" => $row['message'],
        "date" => $row['announce_date'],
        "time" => $row['announce_time']
    ];
}

echo json_encode([
    "status" => "success",
    "data" => $data
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>