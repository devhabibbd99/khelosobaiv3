<?php
include 'config.php';
header('Content-Type: application/json');

$match_type = trim($_REQUEST['match_type'] ?? '');

if (empty($match_type)) {
    echo json_encode([
        "status" => false,
        "message" => "match_type required"
    ]);
    exit;
}

$stmt = $conn->prepare("SELECT rules FROM match_rules WHERE match_type = ? LIMIT 1");
$stmt->bind_param("s", $match_type);
$stmt->execute();

$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode([
        "status" => true,
        "match_type" => $match_type,
        "rules" => $row['rules']
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Rule not found"
    ]);
}
?>