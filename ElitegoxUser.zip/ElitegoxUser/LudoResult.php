<?php
header('Content-Type: application/json');
include 'config.php'; // এখানে তোমার ডাটাবেস কানেকশন থাকবে

try {
    // Prepared statement তৈরি করা হলো
    $stmt = $conn->prepare("SELECT * FROM ludoking WHERE match_result = 'YES'");
    $stmt->execute();
    $result = $stmt->get_result();

    $matches = [];

    while ($row = $result->fetch_assoc()) {
        $matches[] = $row;
    }

    if (count($matches) > 0) {
        echo json_encode($matches, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    } else {
        echo json_encode(["message" => "No matches found"], JSON_PRETTY_PRINT);
    }

} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>