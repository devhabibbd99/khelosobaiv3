<?php

header("Content-Type: application/json");
include "config.php";

$id         = $_POST['id'];
$match_type = $_POST['match_type'];
$type       = $_POST['type'];

/* =========================
   TYPE 1: WINNER TEAM
========================= */
if ($type == "winner") {

    // সবচেয়ে বেশি winning যে team — সেটা winner
    $winner = mysqli_query($conn, "
        SELECT team_name
        FROM joiners
        WHERE match_id = '$id'
        AND type = '$match_type'
        ORDER BY CAST(winning AS UNSIGNED) DESC
        LIMIT 1
    ");

    if (mysqli_num_rows($winner) == 0) {
        echo json_encode(["status" => false, "message" => "No Data"]);
        exit;
    }

    $w    = mysqli_fetch_assoc($winner);
    $team = $w['team_name'];

    // Winner team এর সব members — limit নেই, যত জন আছে সব আসবে
    $result = mysqli_query($conn, "
        SELECT id, name, winning, total_kill, team_name, team_color, mode, is_leader
        FROM joiners
        WHERE match_id = '$id'
        AND type = '$match_type'
        AND team_name = '$team'
        ORDER BY is_leader DESC
    ");

    $players    = [];
    $total_kill = 0;
    $team_color = "";
    $team_mode  = "";

    while ($row = mysqli_fetch_assoc($result)) {
        if (empty($team_color)) $team_color = $row['team_color'];
        if (empty($team_mode))  $team_mode  = $row['mode'];

        $players[]   = [
            "id"         => $row['id'],
            "name"       => $row['name'],
            "winning"    => $row['winning'],
            "total_kill" => $row['total_kill'],
            "is_leader"  => (int)$row['is_leader']
        ];
        $total_kill += (int)$row['total_kill'];
    }

    echo json_encode([
        "status"      => true,
        "type"        => "winner",
        "mode"        => $team_mode,
        "winner_team" => $team,
        "team_color"  => $team_color,
        "total_kill"  => $total_kill,
        "players"     => $players
    ], JSON_UNESCAPED_UNICODE);

}

/* =========================
   TYPE 2: ALL PLAYERS (Team Group করা)
========================= */
else if ($type == "all") {

    $result = mysqli_query($conn, "
        SELECT id, name, team_name, team_color, mode, total_kill, winning, is_leader
        FROM joiners
        WHERE match_id = '$id'
        AND type = '$match_type'
        ORDER BY team_name ASC, is_leader DESC
    ");

    if (mysqli_num_rows($result) == 0) {
        echo json_encode(["status" => false, "message" => "No Data"]);
        exit;
    }

    $teams = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $team_name = $row['team_name'];

        if (!isset($teams[$team_name])) {
            $teams[$team_name] = [
                "team_name"  => $team_name,
                "team_color" => $row['team_color'],
                "mode"       => $row['mode'],
                "players"    => []
            ];
        }

        $teams[$team_name]['players'][] = [
            "id"         => $row['id'],
            "name"       => $row['name'],
            "winning"    => $row['winning'],
            "total_kill" => $row['total_kill'],
            "is_leader"  => (int)$row['is_leader']
        ];
    }

    echo json_encode([
        "status" => true,
        "type"   => "all",
        "teams"  => array_values($teams)
    ], JSON_UNESCAPED_UNICODE);

}

/* =========================
   INVALID TYPE
========================= */
else {
    echo json_encode(["status" => false, "message" => "Invalid type"]);
}

?>