<?php
if (!defined('CRAZYTOUR_CONFIG_INCLUDED')) {
    define('CRAZYTOUR_CONFIG_INCLUDED', true);

    date_default_timezone_set("Asia/Dhaka");

    $hostname = "localhost";
    $username = "skmespor_SKmSHUVONEwDBoKHAHACkKOr";
    $password = "SKmSHUVONEwDBoKHAHACkKOr";
    $database = "skmespor_SKmSHUVONEwDBoKHAHACkKOr";

    $conn = new mysqli($hostname, $username, $password, $database);
    $conn->set_charset("utf8mb4");

    if ($conn->connect_error) {
        die("Connection Failed: " . $conn->connect_error);
    }
}
?>