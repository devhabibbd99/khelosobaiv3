<?php
require_once "db.php";

$type = $_GET['type'] ?? 'check';

/* =======================
   TYPE : LIST (All Banned)
   ======================= */
if ($type === "list") {

    $result = $conn->query(
        "SELECT device_id, ban_status, created_at 
         FROM device_ban 
         WHERE ban_status = 1 
         ORDER BY id DESC"
    );

    $banned_devices = [];

    while ($row = $result->fetch_assoc()) {
        $banned_devices[] = [
            "device_id" => $row['device_id'],
            "ban_status" => (int)$row['ban_status'],
            "date" => $row['created_at']
        ];
    }

    echo json_encode([
        "total_banned" => count($banned_devices),
        "list" => $banned_devices
    ]);
    exit;
}

/* =======================
   TYPE : CHECK (Single)
   ======================= */

$device_id = $_REQUEST['device_id'] ?? null;

if (!$device_id) {
    echo "Device ID Missing";
    exit;
}

$stmt = $conn->prepare(
    "SELECT ban_status FROM device_ban WHERE device_id = ?"
);
$stmt->bind_param("s", $device_id);
$stmt->execute();

$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {

    if ((int)$row['ban_status'] === 1) {
        echo "Your device is banned";
    } else {
        echo "Device allowed";
    }

} else {
    echo "Device not found, allowed";
}

$conn->close();