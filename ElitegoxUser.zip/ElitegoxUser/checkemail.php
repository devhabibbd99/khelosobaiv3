<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];

    $query = "SELECT username, password FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo json_encode([
            "status" => "success",
            "username" => $row["username"],
            "password" => $row["password"]  // ⚠️ সতর্কতা: শুধুমাত্র হ্যাশ থাকলে পাঠাও
        ]);
    } else {
        echo json_encode([
            "status" => "fail",
            "message" => "Email not found"
        ]);
    }
}
?>