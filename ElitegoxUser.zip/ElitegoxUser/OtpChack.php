<?php
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["php_session_id"])) {
        session_id($_POST["php_session_id"]);
    }
    session_start();

    $otp = $_POST["otp"];
    $session_id = $_POST["session_id"];

    if (!isset($_SESSION["session_id"]) || $session_id !== $_SESSION["session_id"]) {
        echo json_encode([
            "status" => "fail",
            "message" => "Invalid session"
        ]);
        exit();
    }

    if (isset($_SESSION["otp"]) && $_SESSION["otp"] == $otp) {
        echo json_encode([
            "status" => "success",
            "message" => "OTP verified"
        ]);
    } else {
        echo json_encode([
            "status" => "fail",
            "message" => "Incorrect OTP"
        ]);
    }
}
?>