<?php  
include 'config.php';  
header('Content-Type: application/json');  
  
$token = $_POST['token'] ?? '';  
  
$user = $conn->query("SELECT * FROM users WHERE token='$token'");  
if ($user->num_rows == 0) {  
    echo json_encode(["status"=>"error"]);  
    exit;  
}  
  
$u = $user->fetch_assoc();  
$uid = $u['uid'];  
  
$res = $conn->query("  
SELECT * FROM gift_requests   
WHERE sender_uid='$uid' OR receiver_uid='$uid'  
ORDER BY id DESC  
");  
  
$data = [];  
while($row = $res->fetch_assoc()){  
    $data[] = $row;  
}  
  
echo json_encode([  
    "status"=>"success",  
    "data"=>$data  
]);  
  
  
  
Ater response kmn hbe