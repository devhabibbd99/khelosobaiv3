<?php  
header("Content-Type: application/json");  
include("config.php");  

$type = $_GET['type'] ?? null;  

if ($type !== "getdata") {  
    echo json_encode([
        "status" => "error",
        "message" => "Invalid or missing 'type'."
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);  
    exit;  
}  

// শুধুমাত্র প্রয়োজনীয় ফিল্ডগুলো
$sql = "SELECT home_notice, update_notice, version_code, updated_on, application_status, closed_reason FROM appinfo WHERE id = 1";  
$result = $conn->query($sql);  

if ($result && $result->num_rows > 0) {  
    $row = $result->fetch_assoc();  
    $response = ["status" => "success"] + $row;  
    echo json_encode($response, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);  
} else {  
    echo json_encode([
        "status" => "error",
        "message" => "No data found."
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);  
}
?>