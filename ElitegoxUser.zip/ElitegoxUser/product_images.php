<?php

include 'config.php';

header('Content-Type: application/json');

$product_id = intval($_POST['product_id'] ?? 0);

if ($product_id <= 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid Product ID"
    ]);
    exit;
}

$images = [];
$deliveryFree = "";
$homeDelivery = "";

$product_stmt = $conn->prepare("SELECT DeliveryFree, home_delivery FROM products WHERE id = ? LIMIT 1");
$product_stmt->bind_param("i", $product_id);
$product_stmt->execute();
$product_result = $product_stmt->get_result();

if ($product_row = $product_result->fetch_assoc()) {
    $deliveryFree = $product_row['DeliveryFree'] ?? "";
    $homeDelivery = $product_row['home_delivery'] ?? "";
}
$product_stmt->close();

$image_stmt = $conn->prepare("SELECT image_link FROM product_images WHERE product_id = ? ORDER BY id ASC");
$image_stmt->bind_param("i", $product_id);
$image_stmt->execute();
$image_result = $image_stmt->get_result();

while ($row = $image_result->fetch_assoc()) {
    $images[] = $row['image_link'];
}
$image_stmt->close();

echo json_encode([
    "status" => "success",
    "product_id" => $product_id,
    "DeliveryFree" => $deliveryFree,
    "home_delivery" => $homeDelivery,
    "images" => $images
]);