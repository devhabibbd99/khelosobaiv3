<?php

header('Content-Type: application/json');

include 'config.php';

$data = [];

$result = $conn->query("SELECT * FROM topup_list ORDER BY id DESC");

while ($row = $result->fetch_assoc()) {

    $data[] = [
        "id" => $row["id"],
        "title" => $row["title"],
        "real_price" => $row["real_price"],
        "discount_price" => $row["discount_price"],
        "image_link" => $row["image_link"],
        "stock_message" => $row["stock_message"]
    ];

}

echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

$conn->close();

?>