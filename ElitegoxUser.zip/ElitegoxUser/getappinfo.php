<?php
header("Content-Type: application/json");
include("config.php");

$types = [
    "basic" => ["version_code", "update_notice", "updated_on", "update_link"],
    "status" => ["application_status", "closed_reason", "autopay_status"],
    "number" => ["bkash_number", "nagad_number", "rocket_number"],
    "notice" => ["bkash_notice", "nagad_notice", "rocket_notice"],
    "limits" => ["min_deposit", "min_withdraw"],
    "limits_promo" => ["min_refer_bonus", "min_first_refer_dp"],
    "link" => ["admin_support_link", "add_money_link", "collect_room_link", "join_match_link", "telegram_link", "share_app_link"],
    "dialog_notice" => ["home_notice", "dialog_notice"]
];

$type = $_GET['type'] ?? null;
if (!$type || !isset($types[$type])) {
    echo json_encode(["status" => "error", "message" => "Invalid or missing 'type'."]);
    exit;
}

$fields = implode(",", $types[$type]);
$sql = "SELECT $fields FROM appinfo WHERE id = 1";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo json_encode(["status" => "success", "data" => $result->fetch_assoc()]);
} else {
    echo json_encode(["status" => "error", "message" => "No data found."]);
}
?>