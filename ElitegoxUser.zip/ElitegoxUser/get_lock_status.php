<?php
header('Content-Type: application/json');
include 'config.php';

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;

if ($id <= 0) {
    echo json_encode([
        "status" => false,
        "message" => "Invalid ID"
    ]);
    exit;
}

$stmt = $conn->prepare("SELECT locked, locked_type FROM freefire WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc();

    if ($row['locked'] === 'true') {

        echo json_encode([
            "status" => true,
            "locked" => $row['locked'],
            "locked_type" => $row['locked_type']
        ]);

    } else {

        echo json_encode([
            "status" => false,
            "message" => "Locked False"
        ]);

    }

} else {

    echo json_encode([
        "status" => false,
        "message" => "Match Not Found"
    ]);

}

$stmt->close();
$conn->close();
?>