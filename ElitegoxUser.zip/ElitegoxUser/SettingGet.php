<?php
include 'db.php';

// Input নিরাপদভাবে পড়া
$type = isset($_POST["ShuvoAction"]) ? $_POST["ShuvoAction"] : '';

if ($type === "Data") {
    // Prepared statement তৈরি
    $stmt = $conn->prepare("SELECT * FROM appinfo");

    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();

        $data = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            echo json_encode($data, JSON_UNESCAPED_UNICODE);
        } else {
            echo "No Data Found";
        }

        $stmt->close();
    } else {
        echo "Query Prepare Failed!";
    }
}

$conn->close();
?>