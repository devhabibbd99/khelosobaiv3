<?php
include "config.php";

// Match types
$match_types = [
    "Lone Wolf",
    "Clash Squad",
    "BRMatch",
    "Cs 2VS2",
    "Free Match",
    "Free Match1",
    "Cs 4VS4",
    "Special Mode",
    "ludoking"   // key now matches table name
];

$response = [
    "status" => "success"
];

// প্রথমে সব 0 করে দিচ্ছি
foreach ($match_types as $type) {
    $response[$type] = 0;
}

// freefire table থেকে count (except 'ludoking')
$sql = "SELECT match_type, COUNT(*) AS total 
        FROM freefire
        WHERE match_result = 'NO'
        GROUP BY match_type";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $type = $row['match_type'];
        if (isset($response[$type]) && $type !== 'ludoking') {
            $response[$type] = (int)$row['total'];
        }
    }
}

// ludoking table থেকে count
$sql_ludo = "SELECT COUNT(*) AS total FROM ludoking WHERE match_result = 'NO'";
$result_ludo = $conn->query($sql_ludo);

if ($result_ludo && $row_ludo = $result_ludo->fetch_assoc()) {
    $response['ludoking'] = (int)$row_ludo['total'];
}

// Final JSON output
echo json_encode($response, JSON_PRETTY_PRINT);
?>