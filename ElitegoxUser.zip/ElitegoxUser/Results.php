<?php
include "db.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([]);
    exit;
}

$type = $_POST['type'] ?? '';

if ($type == '') {
    echo json_encode([]);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM freefire WHERE match_type = ? AND match_result = 'YES'");
$stmt->bind_param("s", $type);
$stmt->execute();
$result = $stmt->get_result();

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Return only pure array (no status, no object)
echo json_encode($data, JSON_PRETTY_PRINT);

?>