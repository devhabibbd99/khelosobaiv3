<?php

header('Content-Type: application/json');
include 'config.php';

$token = trim($_GET['token'] ?? '');

if (empty($token)) {
    echo json_encode([
        "status" => "error",
        "message" => "Token required"
    ]);
    exit();
}

/* =========================
   GET USER ORDERS
========================= */

$stmt = $conn->prepare("
    SELECT * 
    FROM topup_orders 
    WHERE user_token = ? 
    ORDER BY id DESC
");

$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];

if ($result && $result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }

    echo json_encode([
        "status" => "success",
        "total"  => count($orders),
        "data"   => $orders
    ]);

} else {

    echo json_encode([
        "status" => "success",
        "total"  => 0,
        "data"   => []
    ]);
}

$stmt->close();
$conn->close();

?>