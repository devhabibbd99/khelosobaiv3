<?php
include 'config.php'; // তোমার DB connection

if(isset($_FILES['file']) && isset($_POST['email'])) {
    $email = $_POST['email'];
    $uploads_dir = 'profile_picture/';

    // ফোল্ডার না থাকলে তৈরি করবে
    if(!file_exists($uploads_dir)){
        mkdir($uploads_dir, 0755, true);
    }

    $tmp_name = $_FILES['file']['tmp_name'];
    $file_name = basename($_FILES['file']['name']);

    // নিরাপদ filename
    $file_name = time() . "_" . preg_replace("/[^a-zA-Z0-9.]/", "_", $file_name);

    if(move_uploaded_file($tmp_name, $uploads_dir . $file_name)) {
        // DB-এ আপডেট
        $stmt = $conn->prepare("UPDATE users SET profile_pic=? WHERE email=?");
        $stmt->bind_param("ss", $file_name, $email);
        if($stmt->execute()){
            echo "Success";
        } else {
            echo "DB update failed";
        }
        $stmt->close();
    } else {
        echo "File upload failed";
    }

} else {
    echo "No file or email provided";
}
?>