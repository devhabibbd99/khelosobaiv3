<?php
header("Content-Type: application/json");
include 'config.php';

$data = [];

$query = mysqli_query($conn, "SELECT * FROM slider ORDER BY id DESC");

while($row = mysqli_fetch_assoc($query)){
    $data[] = [
        "id" => $row['id'],
        "image" => $row['image'],
        "click_link" => $row['click_link']
    ];
}

echo json_encode([
    "status" => true,
    "data" => $data
]);
?>