package com.khelosobaiv3.user;

import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import android.util.Base64;
import org.json.JSONObject;

public class AESGCM {

    // নেটিভ লাইব্রেরি লোড করা (লাইব্রেরির নাম 'native-lib' হলে)
    static {
        System.loadLibrary("appcrypto");
    }

    // নেটিভ মেথড ঘোষণা
    public static native String helloFromJNI();

    public static String encrypt(String plainText) {
        try {
            if (plainText == null || plainText.isEmpty()) {
                plainText = "{}";
            }

            // নেটিভ লাইব্রেরি থেকে সিক্রেট কী সংগ্রহ
            String secretFromJNI = helloFromJNI();

            // AES-256 এর জন্য ৩২ বাইট কী নিশ্চিত করা
            byte[] keyBytes = new byte[32];
            byte[] secretBytes = secretFromJNI.getBytes("UTF-8");
            int length = Math.min(secretBytes.length, 32);
            System.arraycopy(secretBytes, 0, keyBytes, 0, length);
            SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");

            // ১২ বাইট IV (GCM এর জন্য স্ট্যান্ডার্ড)
            byte[] iv = new byte[12];
            new SecureRandom().nextBytes(iv);

            // AES/GCM Cipher ইনিশিয়ালাইজ
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmSpec);

            byte[] encrypted = cipher.doFinal(plainText.getBytes("UTF-8"));

            // CipherText এবং Tag আলাদা করা
            byte[] cipherTextOnly = Arrays.copyOf(encrypted, encrypted.length - 16);
            byte[] tag = Arrays.copyOfRange(encrypted, encrypted.length - 16, encrypted.length);

            // JSON ফরম্যাটে ডেটা তৈরি
            JSONObject json = new JSONObject();
            json.put("iv", Base64.encodeToString(iv, Base64.NO_WRAP));
            json.put("data", Base64.encodeToString(cipherTextOnly, Base64.NO_WRAP));
            json.put("tag", Base64.encodeToString(tag, Base64.NO_WRAP));

            return json.toString();

        } catch (Exception e) {
            e.printStackTrace();
            return "{\"error\":\"" + e.getMessage() + "\"}";
        }
    }
}
