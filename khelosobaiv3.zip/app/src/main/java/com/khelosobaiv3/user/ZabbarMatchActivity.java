package com.khelosobaiv3.user;

import android.animation.ObjectAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ZabbarMatchActivity extends AppCompatActivity {

public static final String ACTION_REFRESH_MATCHES = "com.khelosobaiv3.user.ACTION_REFRESH_MATCHES";

private ZabbarMatchBinding binding;
private final ArrayList<HashMap<String, Object>> matchesList = new ArrayList<>();
private final ArrayList<HashMap<String, Object>> resultsList = new ArrayList<>();
private CircularProgressIndicator loadingIndicator;
private ViewPager2 viewPager;
private TabLayout tabLayout;
private ImageView imageview1, app_icon;
private SharedPreferences Save_User_Status, ApiPrefs;
private boolean isLoading = true;
private boolean isLoadingData = false;
private boolean isReceiverRegistered = false;
private final ExecutorService imageExecutor = Executors.newCachedThreadPool();
private final Handler mainHandler = new Handler(Looper.getMainLooper());

private final BroadcastReceiver refreshReceiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && ACTION_REFRESH_MATCHES.equals(intent.getAction())) {
            loadData();
        }
    }
};

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    binding = ZabbarMatchBinding.inflate(getLayoutInflater());
    setContentView(binding.getRoot());
    Save_User_Status = getSharedPreferences("Save_User_Status", MODE_PRIVATE);
    ApiPrefs = getSharedPreferences("Api", MODE_PRIVATE);
    FirebaseApp.initializeApp(this);
    ZabbarNavigation.INSTANCE.setup(this);
    initializeLogic();
    registerRefreshReceiver();
    loadData();
    String displayTitle = getIntent().getStringExtra("Title");

    if (displayTitle == null || displayTitle.trim().isEmpty()) {
        displayTitle = getIntent().getStringExtra("Type");
    }

    if (displayTitle != null) {
        binding.zabbarApplicationName.setText(displayTitle);
    }
}

@Override
protected void onDestroy() {
    if (isReceiverRegistered) {
        try {
            unregisterReceiver(refreshReceiver);
        } catch (Exception ignored) {
        }
        isReceiverRegistered = false;
    }
    super.onDestroy();
}

@Override
protected void onResume() {
    super.onResume();
    // Belt-and-suspenders alongside the ACTION_REFRESH_MATCHES broadcast: whenever the
    // user comes back to this screen (e.g. finishing the join flow), reload the list
    // so spots-left/joined-state is current without needing a manual pull-to-refresh.
    // loadData() already guards against overlapping calls, so this is safe even if the
    // broadcast also fires around the same time.
    loadData();
}

private void registerRefreshReceiver() {
    if (isReceiverRegistered) return;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        registerReceiver(refreshReceiver, new IntentFilter(ACTION_REFRESH_MATCHES), Context.RECEIVER_NOT_EXPORTED);
    } else {
        registerReceiver(refreshReceiver, new IntentFilter(ACTION_REFRESH_MATCHES));
    }
    isReceiverRegistered = true;
}

private void initializeLogic() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) getWindow().setDecorFitsSystemWindows(false);
    getWindow().setStatusBarColor(Color.TRANSPARENT);
    getWindow().setNavigationBarColor(Color.TRANSPARENT);

    loadingIndicator = binding.loadingIndicator;
    viewPager = binding.viewPager;
    tabLayout = binding.tabLayout;
    imageview1 = binding.imageview1;
    app_icon = binding.appIcon;

    BlurView blurView = binding.blurView;
    ViewGroup rootView = (ViewGroup) getWindow().getDecorView();
    Drawable windowBackground = rootView.getBackground();
    if (windowBackground == null) windowBackground = new ColorDrawable(Color.TRANSPARENT);

    if (blurView != null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blurView.setupWith(rootView, new RenderEffectBlur()).setFrameClearDrawable(windowBackground).setBlurRadius(8f).setBlurAutoUpdate(true);
        } else {
            blurView.setupWith(rootView, new RenderScriptBlur(this)).setFrameClearDrawable(windowBackground).setBlurRadius(8f).setBlurAutoUpdate(true);
        }
    }

    if (viewPager != null && tabLayout != null) {
        viewPager.setAdapter(new ViewPagerAdapter());
        new TabLayoutMediator(tabLayout, viewPager, (tab, pos) -> tab.setText(pos == 0 ? "Matches" : "Result")).attach();
    }

    if (imageview1 != null) {
        imageview1.setOnClickListener(v -> {
            ObjectAnimator rotate = ObjectAnimator.ofFloat(imageview1, "rotation", 0f, 360f);
            rotate.setDuration(1000);
            rotate.setRepeatCount(1);
            rotate.setInterpolator(new LinearInterpolator());
            rotate.start();
            loadData();
        });
    }

    if (app_icon != null) app_icon.setOnClickListener(v -> finish());
}

private String makePostRequest(String urlStr, String postData, String ua) {
    HttpURLConnection conn = null;
    try {
        conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        if (ua != null) conn.setRequestProperty("User-Agent", ua);
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(postData.getBytes("UTF-8"));
        }

        InputStream is = (conn.getResponseCode() >= 200 && conn.getResponseCode() < 300) ? conn.getInputStream() : conn.getErrorStream();
        if (is == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    } catch (Exception e) {
        return null;
    } finally {
        if (conn != null) conn.disconnect();
    }
}

private void loadData() {
    if (isLoadingData) return;
    isLoadingData = true;

    runOnUiThread(() -> {
        isLoading = true;
        if (loadingIndicator != null) loadingIndicator.setVisibility(View.VISIBLE);
        if (viewPager != null) {
            viewPager.animate().alpha(0.5f).setDuration(200).start();
            if (viewPager.getAdapter() != null) viewPager.getAdapter().notifyDataSetChanged();
        }
    });

    new Thread(() -> {
        String baseUrl = ApiPrefs.getString("Api", "https://api.khelosobai20.live/ElitegoxUser/");
        String token = Save_User_Status.getString("token", Save_User_Status.getString("Token", ""));
        String type = getIntent().getStringExtra("Type");
        if (type == null || type.isEmpty()) type = "BR Match";

        ArrayList<HashMap<String, Object>> tMatches = new ArrayList<>();
        ArrayList<HashMap<String, Object>> tResults = new ArrayList<>();

        try {
            String postData = "token=" + URLEncoder.encode(token, "UTF-8") + "&match_type=" + URLEncoder.encode(type, "UTF-8");
            String responseStr = makePostRequest(baseUrl + "getmatches.php", postData, "Mozilla/5.0 (Linux; Android 12)");

            if (responseStr != null && !responseStr.trim().isEmpty()) {
                org.json.JSONObject jsonObject = new org.json.JSONObject(responseStr.trim());

                if (jsonObject.has("matches")) {
                    ArrayList<HashMap<String, Object>> tempMatches = new Gson().fromJson(
                            jsonObject.getJSONArray("matches").toString(),
                            new TypeToken<ArrayList<HashMap<String, Object>>>() {}.getType()
                    );

                    for (HashMap<String, Object> map : tempMatches) {
                        String mResult = map.get("match_result") != null ? String.valueOf(map.get("match_result")).trim() : "";
                        if (mResult.isEmpty() || mResult.equalsIgnoreCase("NO")) {
                            tMatches.add(map);
                        } else {
                            tResults.add(map);
                        }
                    }
                }

                if (jsonObject.has("results")) {
                    ArrayList<HashMap<String, Object>> tempResults = new Gson().fromJson(
                            jsonObject.getJSONArray("results").toString(),
                            new TypeToken<ArrayList<HashMap<String, Object>>>() {}.getType()
                    );

                    for (HashMap<String, Object> map : tempResults) {
                        String mResult = map.get("match_result") != null ? String.valueOf(map.get("match_result")).trim() : "";
                        if (mResult.isEmpty() || mResult.equalsIgnoreCase("NO")) {
                            tMatches.add(map);
                        } else {
                            tResults.add(map);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }

        runOnUiThread(() -> {
            matchesList.clear();
            resultsList.clear();
            matchesList.addAll(tMatches);
            resultsList.addAll(tResults);
            isLoading = false;
            isLoadingData = false;
            if (viewPager != null && viewPager.getAdapter() != null) viewPager.getAdapter().notifyDataSetChanged();
            if (loadingIndicator != null) loadingIndicator.setVisibility(View.GONE);
            if (viewPager != null) viewPager.animate().alpha(1f).setDuration(300).start();
        });
    }).start();
}

private boolean parseJoined(Object value) {
    if (value == null) return false;
    String s = String.valueOf(value).trim();
    return s.equalsIgnoreCase("true") || s.equals("1") || s.equalsIgnoreCase("yes") || s.equalsIgnoreCase("joined");
}

private long parseDateToMillis(String rawStr) {
    if (rawStr == null || rawStr.isEmpty()) return 0;
    String cleanStr = rawStr.replaceAll("(?i)(timer|time|start\\s*in\\s*time)\\s*:", "").replaceAll("(?i)\\bat\\b", "").replaceAll("\\s+", " ").trim();
    String[] patterns = {"yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm", "yyyy-MM-dd HH:mm", "dd/MM/yyyy hh:mm a", "dd/MM/yyyy HH:mm:ss", "yyyy/MM/dd HH:mm:ss", "dd/MM/yyyy HH:mm", "dd-MM-yyyy hh:mm a"};
    for (String pattern : patterns) {
        try {
            Date d = new SimpleDateFormat(pattern, Locale.ENGLISH).parse(cleanStr);
            if (d != null) return d.getTime();
        } catch (Exception ignored) {
        }
    }
    String fallbackStr = cleanStr.replace("-", "/");
    for (String pattern : patterns) {
        try {
            Date d = new SimpleDateFormat(pattern, Locale.ENGLISH).parse(fallbackStr);
            if (d != null) return d.getTime();
        } catch (Exception ignored) {
        }
    }
    try {
        return Long.parseLong(rawStr.trim());
    } catch (Exception ignored) {
        return 0;
    }
}

private String getStr(HashMap<String, Object> map, String key) {
    if (map == null || !map.containsKey(key) || map.get(key) == null) return "";
    String val = String.valueOf(map.get(key));
    return val.endsWith(".0") ? val.replace(".0", "") : val;
}

private void loadBannerImage(ImageView imageView, String imgLink) {
    if (imageView == null) return;

    String url = imgLink == null ? "" : imgLink.trim();
    CircularProgressDrawable pDrawable = new CircularProgressDrawable(imageView.getContext());
    pDrawable.setStrokeWidth(5f);
    pDrawable.setCenterRadius(25f);
    pDrawable.setColorSchemeColors(Color.WHITE);
    pDrawable.start();

    imageView.setBackgroundColor(Color.BLACK);
    imageView.setImageDrawable(pDrawable);

    if (url.isEmpty() || "null".equalsIgnoreCase(url) || "none".equalsIgnoreCase(url)) return;

    imageView.setTag(url);

    imageExecutor.execute(() -> {
        Bitmap bitmap = null;
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(12000);
            connection.setInstanceFollowRedirects(true);
            connection.setDoInput(true);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12)");
            connection.connect();

            int code = connection.getResponseCode();
            if (code >= 200 && code < 300) {
                try (InputStream in = connection.getInputStream()) {
                    bitmap = BitmapFactory.decodeStream(in);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (connection != null) connection.disconnect();
        }

        Bitmap finalBitmap = bitmap;
        mainHandler.post(() -> {
            if (imageView.getTag() != null && url.equals(String.valueOf(imageView.getTag()))) {
                if (finalBitmap != null) {
                    imageView.setImageBitmap(finalBitmap);
                } else {
                    imageView.setImageDrawable(new ColorDrawable(Color.BLACK));
                }
            }
        });
    });
}

public class ViewPagerAdapter extends RecyclerView.Adapter<UniversalViewHolder> {

    @NonNull
    @Override
    public UniversalViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        float density = parent.getResources().getDisplayMetrics().density;

        FrameLayout frameLayout = new FrameLayout(parent.getContext());
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));

        RecyclerView rv = new RecyclerView(parent.getContext());
        rv.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        rv.setPadding((int) (8 * density), (int) (150 * density), (int) (8 * density), (int) (8 * density));
        rv.setClipToPadding(false);
        rv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        rv.setVerticalScrollBarEnabled(false);
        rv.setNestedScrollingEnabled(true);

        LinearLayout emptyLayout = new LinearLayout(parent.getContext());
        emptyLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        emptyLayout.setOrientation(LinearLayout.VERTICAL);
        emptyLayout.setGravity(Gravity.CENTER);
        emptyLayout.setPadding(0, (int) (100 * density), 0, 0);

        ImageView sticker = new ImageView(parent.getContext());
        sticker.setLayoutParams(new LinearLayout.LayoutParams((int) (120 * density), (int) (120 * density)));
        int resId = parent.getContext().getResources().getIdentifier("zabbar_nodata_found", "drawable", parent.getContext().getPackageName());
        if (resId != 0) sticker.setImageResource(resId);

        TextView textNoData = new TextView(parent.getContext());
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-2, -2);
        textParams.setMargins(0, (int) (16 * density), 0, 0);
        textNoData.setLayoutParams(textParams);
        textNoData.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        textNoData.setTextColor(Color.parseColor("#7A7A7A"));
        textNoData.setTypeface(null, Typeface.BOLD);

        emptyLayout.addView(sticker);
        emptyLayout.addView(textNoData);
        frameLayout.addView(emptyLayout);
        frameLayout.addView(rv);

        return new UniversalViewHolder(frameLayout, rv, emptyLayout, textNoData);
    }

    @Override
    public void onBindViewHolder(@NonNull UniversalViewHolder holder, int position) {
        holder.rv.setLayoutManager(new LinearLayoutManager(holder.rv.getContext()));
        ArrayList<HashMap<String, Object>> currentList = position == 0 ? matchesList : resultsList;
        holder.textNoData.setText(position == 0 ? "Matches Not Found" : "Results Not Found");

        if (isLoading) {
            holder.emptyView.setVisibility(View.GONE);
            holder.rv.setVisibility(View.GONE);
            return;
        }

        if (currentList.isEmpty()) {
            holder.emptyView.setVisibility(View.VISIBLE);
            holder.rv.setVisibility(View.GONE);
        } else {
            holder.emptyView.setVisibility(View.GONE);
            holder.rv.setVisibility(View.VISIBLE);
            holder.rv.setAdapter(new Recyclerview1Adapter(currentList));
        }
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}

public static class UniversalViewHolder extends RecyclerView.ViewHolder {
    RecyclerView rv;
    LinearLayout emptyView;
    TextView textNoData;

    public UniversalViewHolder(View v, RecyclerView r, LinearLayout e, TextView t) {
        super(v);
        rv = r;
        emptyView = e;
        textNoData = t;
    }
}

public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
    ArrayList<HashMap<String, Object>> dataList;

    public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> arrayList) {
        this.dataList = arrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(ZabbarxMatchBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HashMap<String, Object> map = dataList.get(position);

        if (holder.timerRunnable != null) {
            holder.timerHandler.removeCallbacks(holder.timerRunnable);
            holder.timerRunnable = null;
        }

        try {
            String tPrize = getStr(map, "total_prize");
            if (tPrize.isEmpty()) tPrize = "0";
            String pKill = getStr(map, "per_kill");
            if (pKill.isEmpty()) pKill = "0";
            String eFee = getStr(map, "entry_fee");
            if (eFee.isEmpty()) eFee = "0";

            String matchId = getStr(map, "id");
            String matchTitle = getStr(map, "match_title");
            if (matchTitle.isEmpty()) matchTitle = "Match Title";
            String entryType = getStr(map, "entry_type");
            if (entryType.isEmpty()) entryType = "Solo";
            String joinerStr = getStr(map, "total_joiner");
            String totalStr = getStr(map, "total_player");
            String rawMatchTime = getStr(map, "match_time");

            final long targetMillis = parseDateToMillis(rawMatchTime);
            final String finalMatchTitle = matchTitle;
            final String finalEt = entryType;

            holder.tvMatchType.setText(finalMatchTitle);

            int titleLen = finalMatchTitle.length();
            if (titleLen > 25) {
                holder.tvMatchType.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            } else if (titleLen > 18) {
                holder.tvMatchType.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            } else if (titleLen > 12) {
                holder.tvMatchType.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            } else {
                holder.tvMatchType.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            }

            holder.tvMap.setText(getStr(map, "play_map"));
            holder.tvMatchId.setText("ID: " + matchId);
            holder.tvTime.setText(targetMillis > 0 ? new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH).format(new Date(targetMillis)) : rawMatchTime);
            holder.tvTime.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            holder.tvTime.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            holder.tvTotalPrize.setText("৳" + tPrize + " ▼");
            holder.tvPerKill.setText("৳" + pKill);
            holder.tvEntryFee.setText("৳" + eFee);
            holder.tvEntryType.setText(finalEt);

            final boolean joined = parseJoined(map.get("joined"));
            String matchResultVal = getStr(map, "match_result").trim();
            final boolean isNo = matchResultVal.isEmpty() || "NO".equalsIgnoreCase(matchResultVal);

            int joiner = 0, totalPlayer = 0;
            try {
                if (!joinerStr.isEmpty()) joiner = Integer.parseInt(joinerStr.trim());
                if (!totalStr.isEmpty()) totalPlayer = Integer.parseInt(totalStr.trim());
            } catch (Exception ignored) {
            }

            holder.binding.textview244.setText(joiner + "/" + totalPlayer);

            final int left = Math.max(totalPlayer - joiner, 0);

            ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) holder.progressView.getLayoutParams();
            params.matchConstraintPercentWidth = totalPlayer > 0 ? Math.min((float) joiner / totalPlayer, 1f) : 0f;
            holder.progressView.setLayoutParams(params);

            if (holder.rlResultActions != null) holder.rlResultActions.setVisibility(isNo ? View.VISIBLE : View.GONE);
            if (holder.clProgressArea != null) holder.clProgressArea.setVisibility(isNo ? View.VISIBLE : View.GONE);

            boolean matchStarted = targetMillis > 0 && System.currentTimeMillis() >= targetMillis;

            if (!isNo) {
                holder.binding.textview249.setVisibility(View.GONE);
                holder.btnJoin.setText("Participants");
                holder.btnJoin.setAlpha(1.0f);
                holder.btnJoin.setEnabled(true);
                if (holder.cvSpotBadge != null) holder.cvSpotBadge.setVisibility(View.GONE);
                if (holder.cvRoomIdPass != null) holder.cvRoomIdPass.setVisibility(View.GONE);
                holder.tvSpotsLeft.setVisibility(View.GONE);
                holder.progressView.setVisibility(View.GONE);
                holder.tvStatus.setText("Match Results");
            } else {
                if (holder.cvSpotBadge != null) holder.cvSpotBadge.setVisibility(View.VISIBLE);
                if (holder.cvRoomIdPass != null) holder.cvRoomIdPass.setVisibility(View.VISIBLE);
                holder.tvSpotsLeft.setVisibility(View.VISIBLE);
                holder.progressView.setVisibility(View.VISIBLE);

                if (matchStarted) holder.binding.textview249.setVisibility(View.GONE);
                else holder.binding.textview249.setVisibility(View.VISIBLE);

                holder.tvSpotsLeft.setText(left == 0 ? "Match Full" : "Only " + left + " Spots Left");
                holder.tvSpotsLeft.setTextColor(Color.parseColor("#EF4444"));

                String registrationStatus = getStr(map, "registration");
                boolean isRegOpen = registrationStatus.isEmpty() || "Open".equalsIgnoreCase(registrationStatus);

                if (!isRegOpen) {
                    holder.btnJoin.setText("Close");
                    holder.btnJoin.setAlpha(0.6f);
                    holder.btnJoin.setEnabled(false);
                } else if (joined) {
                    holder.btnJoin.setText("Joined");
                    holder.btnJoin.setAlpha(0.6f);
                    holder.btnJoin.setEnabled(true);
                } else if (left == 0) {
                    holder.btnJoin.setText("Match Full");
                    holder.btnJoin.setAlpha(0.6f);
                    holder.btnJoin.setEnabled(false);
                } else {
                    holder.btnJoin.setText("Join Now");
                    holder.btnJoin.setAlpha(1.0f);
                    holder.btnJoin.setEnabled(true);
                }

                if (targetMillis > 0) {
                    holder.timerRunnable = new Runnable() {
                        @Override
                        public void run() {
                            long diff = targetMillis - System.currentTimeMillis();
                            if (diff > 0) {
                                long d = diff / 86400000;
                                long h = (diff % 86400000) / 3600000;
                                long m = (diff % 3600000) / 60000;
                                long s = (diff % 60000) / 1000;

                                StringBuilder sb = new StringBuilder("STARTS IN: ");
                                if (d > 0) sb.append(d).append("d ");
                                if (h > 0 || d > 0) sb.append(h).append("h ");
                                sb.append(m).append("m ").append(s).append("s");

                                holder.tvStatus.setText(sb.toString());
                                holder.binding.textview249.setVisibility(View.VISIBLE);
                                holder.timerHandler.postDelayed(this, 1000);
                            } else {
                                holder.tvStatus.setText("MATCH STARTED");
                                holder.binding.textview249.setVisibility(View.GONE);
                            }
                        }
                    };
                    holder.timerHandler.post(holder.timerRunnable);
                } else {
                    holder.tvStatus.setText("MATCH STARTED");
                    holder.binding.textview249.setVisibility(View.GONE);
                }
            }

            loadBannerImage(holder.ivBanner, getStr(map, "image_link"));

            String roomId = getStr(map, "room_id");
            if (roomId.isEmpty()) roomId = "NO";
            String roomPass = getStr(map, "room_pass");
            if (roomPass.isEmpty()) roomPass = "NO";
            String playMap = getStr(map, "play_map");
            if (playMap.isEmpty()) playMap = "Bermuda";

            final String finalRoomId = roomId;
            final String finalRoomPass = roomPass;
            final String finalPlayMap = playMap;
            final String finalPrizeDetailsData = getStr(map, "prize_details");
            final String finalTPrize = tPrize;
            final String finalEFee = eFee;
            final String finalPKill = pKill;

            holder.tvRoomId.setTextColor(Color.parseColor(joined ? "#00C853" : "#94A3B8"));

            View.OnClickListener idPassClickListener = v -> {
                MatchDetailsDialog dialog = new MatchDetailsDialog(ZabbarMatchActivity.this)
                        .setTitle(finalMatchTitle)
                        .setMatchInfo(finalPlayMap, "TPP", finalEt)
                        .setPrizes(finalTPrize, finalEFee, finalPKill)
                        .setPrizeDetails(finalPrizeDetailsData)
                        .setShowPrizeDetailsSection(false)
                        .setShowAccessCodeSection(true);

                if (joined && !"NO".equalsIgnoreCase(finalRoomId) && !"NO".equalsIgnoreCase(finalRoomPass) && !finalRoomId.trim().isEmpty()) {
                    dialog.setLiveText("LIVE").setAccessCode(finalRoomId, finalRoomPass).show();
                } else {
                    dialog.setLiveText("UPCOMING").setLockedMessage(!joined ? "আপনি এখনও জয়েন করেননি। এই ম্যাচের বিস্তারিত লক করা আছে।" : "ম্যাচ শুরু হওয়ার ৫ মিনিট আগে রুম আইডি এবং পাসওয়ার্ড দেওয়া হবে।").show();
                }
            };

            if (holder.cvRoomIdPass != null) holder.cvRoomIdPass.setOnClickListener(idPassClickListener);
            if (holder.tvRoomId != null) holder.tvRoomId.setOnClickListener(idPassClickListener);

            if (holder.linearPrizeArea != null) {
                holder.linearPrizeArea.setOnClickListener(v -> new MatchDetailsDialog(ZabbarMatchActivity.this)
                        .setTitle(finalMatchTitle)
                        .setMatchInfo(finalPlayMap, "TPP", finalEt)
                        .setPrizes(finalTPrize, finalEFee, finalPKill)
                        .setPrizeDetails(finalPrizeDetailsData)
                        .setShowPrizeDetailsSection(true)
                        .setShowAccessCodeSection(false)
                        .setLiveText("UPCOMING")
                        .show());
            }

            Intent baseIntent = new Intent();
            for (String key : map.keySet()) baseIntent.putExtra(key, getStr(map, key));
            baseIntent.putExtra("Id", matchId);
            baseIntent.putExtra("Title", finalMatchTitle);
            baseIntent.putExtra("EntryFee", finalEFee);
            baseIntent.putExtra("PerKill", finalPKill);
            baseIntent.putExtra("TotalPrize", finalTPrize);
            baseIntent.putExtra("TotalJoiner", joinerStr);
            baseIntent.putExtra("TotalPlayer", totalStr);
            baseIntent.putExtra("EntryType", finalEt);
            baseIntent.putExtra("Type", "freefire");
            baseIntent.putExtra("image_link", getStr(map, "image_link"));
            baseIntent.putExtra("isJoined", joined);

            Intent joinIntent = new Intent(baseIntent).setClass(holder.itemView.getContext(), ZabbarMatchJoinActivity.class).putExtra("onExtra", "Join");
            Intent rulesIntent = new Intent(baseIntent).setClass(holder.itemView.getContext(), ShvuoRulesActivity.class).putExtra("onExtra", isNo ? "Join" : "Result");

            holder.cvRules.setOnClickListener(v -> holder.itemView.getContext().startActivity(rulesIntent));

            holder.btnJoin.setOnClickListener(v -> {
                if (isNo) {
                    String regStatus = getStr(map, "registration");
                    boolean isROpen = regStatus.isEmpty() || "Open".equalsIgnoreCase(regStatus);
                    if (isROpen && !joined && left > 0) {
                        holder.itemView.getContext().startActivity(joinIntent);
                    }
                } else {
                    holder.itemView.getContext().startActivity(rulesIntent);
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onViewRecycled(@NonNull ViewHolder holder) {
        super.onViewRecycled(holder);
        if (holder.timerRunnable != null) {
            holder.timerHandler.removeCallbacks(holder.timerRunnable);
            holder.timerRunnable = null;
        }
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ZabbarxMatchBinding binding;
        TextView tvMatchType, tvMap, tvMatchId, tvTime, tvTotalPrize, tvPerKill, tvEntryFee, tvEntryType, tvSpotsLeft, tvStatus, tvRoomId;
        View progressView, rlResultActions, clProgressArea;
        AppCompatButton btnJoin;
        ImageView ivBanner;
        MaterialCardView cvRules, cvSpotBadge, cvRoomIdPass;
        LinearLayout linearPrizeArea;
        Handler timerHandler = new Handler(Looper.getMainLooper());
        Runnable timerRunnable;

        public ViewHolder(ZabbarxMatchBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            Typeface tf = Typeface.createFromAsset(itemView.getContext().getAssets(), "montserrat_bold.ttf");
            for (TextView tv : new TextView[]{binding.textview250, binding.textview249}) tv.setTypeface(tf);
            tvMatchType = binding.textview235;
            tvMap = binding.textview231;
            tvMatchId = binding.textview233;
            tvTime = binding.textview234;
            tvTotalPrize = binding.textview237;
            tvPerKill = binding.textview239;
            tvEntryFee = binding.textview241;
            tvEntryType = binding.textview243;
            tvSpotsLeft = binding.textview18;
            tvStatus = binding.textview250;
            tvRoomId = binding.textview248;
            progressView = binding.view154;
            btnJoin = binding.btnJoin;
            ivBanner = binding.imageview13;
            cvRules = binding.cardview29;
            cvRoomIdPass = binding.cardview154;
            cvSpotBadge = safeFind(R.id.cardview153);
            rlResultActions = safeFind(R.id.relativelayout28);
            clProgressArea = safeFind(R.id.constraint_layout153);
            linearPrizeArea = safeFind(R.id.linear149);
        }

        @SuppressWarnings("unchecked")
        private <T extends View> T safeFind(int id) {
            View v = itemView.findViewById(id);
            return v != null ? (T) v : null;
        }
    }
}

}