package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ZabbarTermsActivity extends AppCompatActivity {
	
	private ZabbarTermsBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ZabbarTermsBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		binding.btnBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			    Window window = getWindow();
			
			    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			
			    window.setStatusBarColor(Color.TRANSPARENT);
			    window.setNavigationBarColor(Color.TRANSPARENT);
		}
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			    getWindow().getDecorView().setSystemUiVisibility(
			            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			                    | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
			                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
			    );
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			    getWindow().getDecorView().setSystemUiVisibility(
			            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			                    | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
			    );
		}
		View rootView = getWindow().getDecorView().findViewById(android.R.id.content);
		setupBlurViews(rootView);
	}
	
	public void _ZabbarX_Method() {
	}
	public void setupBlurViews(View rootView) {
		    float radius = 15f;
		    eightbitlab.com.blurview.BlurView blurViewTop = findViewById(R.id.blurView);
		    eightbitlab.com.blurview.BlurView blurViewBottom = findViewById(R.id.blurViewBottom);
		    android.graphics.drawable.Drawable windowBackground = getWindow().getDecorView().getBackground();
		
		    if (blurViewTop != null) {
			        blurViewTop.setupWith((android.view.ViewGroup) rootView, new eightbitlab.com.blurview.RenderScriptBlur(this))
			                .setFrameClearDrawable(windowBackground)
			                .setBlurRadius(radius)
			                .setBlurAutoUpdate(true);
			    }
		
		    if (blurViewBottom != null) {
			        blurViewBottom.setupWith((android.view.ViewGroup) rootView, new eightbitlab.com.blurview.RenderScriptBlur(this))
			                .setFrameClearDrawable(windowBackground)
			                .setBlurRadius(radius)
			                .setBlurAutoUpdate(true);
			    }
	}
	
	{
	}
	
}