package com.khelosobaiv3.user;

import android.content.Intent;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.HashMap;

public class Recyclerview7Adapter extends RecyclerView.Adapter<Recyclerview7Adapter.ViewHolder> {

    private final ArrayList<HashMap<String, Object>> _data;

    public Recyclerview7Adapter(ArrayList<HashMap<String, Object>> _arr) {
        this._data = _arr;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.zabbarx_topup, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ZabbarxTopupBinding binding = ZabbarxTopupBinding.bind(holder.itemView);
        HashMap<String, Object> item = _data.get(position);

        String id1 = extractId(item, "id1", "product_id1");

        if (!id1.isEmpty()) {
            binding.cardview1.setVisibility(View.VISIBLE);
            binding.tvTitle1.setText(item.get("title1") != null ? item.get("title1").toString() : "");
            binding.tvAmount1.setText(item.get("amount1") != null ? item.get("amount1").toString() : "");
            binding.tvOriginalAmount1.setText(item.get("originalAmount1") != null ? item.get("originalAmount1").toString() : "");
            binding.tvOriginalAmount1.setPaintFlags(binding.tvOriginalAmount1.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

            if (item.get("photo1") != null && !item.get("photo1").toString().isEmpty()) {
                Glide.with(holder.itemView.getContext()).load(item.get("photo1").toString()).into(binding.zabbarMt1);
            }

            binding.cardview1.setOnClickListener(v -> {
                Intent i = new Intent(holder.itemView.getContext(), ShopConfirmPageActivity.class);
                i.putExtra("product_id", id1);
                i.putExtra("product_title", item.get("title1") != null ? item.get("title1").toString() : "");
                i.putExtra("product_amount", item.get("amount1") != null ? item.get("amount1").toString() : "0");
                i.putExtra("product_photo", item.get("photo1") != null ? item.get("photo1").toString() : "");
                holder.itemView.getContext().startActivity(i);
            });
        } else {
            binding.cardview1.setVisibility(View.INVISIBLE);
        }

        String id2 = extractId(item, "id2", "product_id2");

        if (!id2.isEmpty() && item.get("photo2") != null && !item.get("photo2").toString().isEmpty()) {
            binding.cardview2.setVisibility(View.VISIBLE);
            binding.tvTitle2.setText(item.get("title2") != null ? item.get("title2").toString() : "");
            binding.tvAmount2.setText(item.get("amount2") != null ? item.get("amount2").toString() : "");
            binding.tvOriginalAmount2.setText(item.get("originalAmount2") != null ? item.get("originalAmount2").toString() : "");
            binding.tvOriginalAmount2.setPaintFlags(binding.tvOriginalAmount2.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

            Glide.with(holder.itemView.getContext()).load(item.get("photo2").toString()).into(binding.zabbarMt2);

            binding.cardview2.setOnClickListener(v -> {
                Intent i = new Intent(holder.itemView.getContext(), ShopConfirmPageActivity.class);
                i.putExtra("product_id", id2);
                i.putExtra("product_title", item.get("title2") != null ? item.get("title2").toString() : "");
                i.putExtra("product_amount", item.get("amount2") != null ? item.get("amount2").toString() : "0");
                i.putExtra("product_photo", item.get("photo2") != null ? item.get("photo2").toString() : "");
                holder.itemView.getContext().startActivity(i);
            });
        } else {
            binding.cardview2.setVisibility(View.INVISIBLE);
        }
    }

    private String extractId(HashMap<String, Object> item, String... keys) {
        for (String key : keys) {
            if (item.containsKey(key) && item.get(key) != null) {
                String val = item.get(key).toString().trim();
                if (val.endsWith(".0")) {
                    val = val.substring(0, val.indexOf(".0"));
                }
                if (!val.isEmpty() && !val.equals("null")) return val;
            }
        }
        return "";
    }

    @Override
    public int getItemCount() {
        return _data != null ? _data.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View v) {
            super(v);
        }
    }
}
