import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox

private const val COLOR_DISABLED = "#94A3B8"
private const val COLOR_TELEGRAM = "#0088CC"

/**
 * এই ফাংশনটি সরাসরি যেকোনো ভিউ বা অ্যাক্টিভিটি থেকে লিংক সহ কল করতে পারবেন
 */
fun showTelegramConfirmSheet(activity: Activity, telegramUrl: String) {
    val dialog = BottomSheetDialog(activity, R.style.RoundedBottomSheetDialog)
    val view = LayoutInflater.from(activity).inflate(R.layout.dialog_telegram_confirm, null)
    dialog.setContentView(view)

    val iconBg = view.findViewById<View>(R.id.tg_confirm_icon_bg)
    val checkbox = view.findViewById<MaterialCheckBox>(R.id.tg_confirm_checkbox)
    val checkRow = view.findViewById<LinearLayout>(R.id.tg_confirm_check_row)
    val confirmBtn = view.findViewById<MaterialButton>(R.id.tg_confirm_proceed_btn)
    val cancelBtn = view.findViewById<MaterialButton>(R.id.tg_confirm_cancel_btn)

    iconBg?.let {
        it.scaleX = 0f
        it.scaleY = 0f
        it.animate()
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(80)
            .setDuration(320)
            .setInterpolator(OvershootInterpolator())
            .start()
    }

    fun setConfirmEnabled(enabled: Boolean) {
        confirmBtn.isEnabled = enabled
        val fromColor = (confirmBtn.backgroundTintList?.defaultColor)
            ?: Color.parseColor(COLOR_DISABLED)
        val toColor = Color.parseColor(if (enabled) COLOR_TELEGRAM else COLOR_DISABLED)

        ValueAnimator.ofArgb(fromColor, toColor).apply {
            duration = 220
            addUpdateListener {
                confirmBtn.backgroundTintList = ColorStateList.valueOf(it.animatedValue as Int)
            }
        }.start()
    }

    checkRow?.setOnClickListener {
        checkbox?.isChecked = !(checkbox?.isChecked ?: false)
    }
    
    checkbox?.setOnCheckedChangeListener { _, isChecked ->
        setConfirmEnabled(isChecked)
    }

    cancelBtn?.setOnClickListener { dialog.dismiss() }

    confirmBtn?.setOnClickListener {
        if (checkbox?.isChecked == false) {
            checkRow?.let {
                ObjectAnimator.ofFloat(
                    it, "translationX",
                    0f, -14f, 14f, -10f, 10f, -4f, 4f, 0f
                ).apply { duration = 420 }.start()
            }
            return@setOnClickListener
        }

        dialog.dismiss()
        try {
            activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(telegramUrl)))
        } catch (e: Exception) {
            Toast.makeText(activity, "Telegram খুলতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    dialog.setOnShowListener {
        val bottomSheet =
            dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
        bottomSheet?.let { BottomSheetBehavior.from(it).state = BottomSheetBehavior.STATE_EXPANDED }
    }

    dialog.show()
}
