package com.khelosobaiv3.user;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.FirebaseApp;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ZabbarNotificationActivity extends AppCompatActivity {

private final String[] tabTitles = {"Server", "My Notice"};
private ZabbarNotificationBinding binding;

private final ArrayList<HashMap<String, Object>> serverList = new ArrayList<>();
private final ArrayList<HashMap<String, Object>> userList = new ArrayList<>();

private RequestQueue requestQueue;
private String userEmail = "";
private ViewPagerAdapter adapter;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    binding = ZabbarNotificationBinding.inflate(getLayoutInflater());
    setContentView(binding.getRoot());

    FirebaseApp.initializeApp(this);
    initializeLogic();
    ZabbarNavigation.INSTANCE.setup(this);
}

private void initializeLogic() {
    SharedPreferences sp = getSharedPreferences("Save_User_Status", Context.MODE_PRIVATE);
    String emailData = sp.getString("Email", "");

    try {
        JSONObject jsonObject = new JSONObject(emailData);
        userEmail = jsonObject.optString("email", "");
    } catch (Exception e) {
        userEmail = emailData;
    }

    if (userEmail.isEmpty()) {
        userEmail = sp.getString("email", "");
    }

    requestQueue = Volley.newRequestQueue(getApplicationContext());

    TabLayout tabLayout = binding.tabLayout;
    ViewPager2 viewPager = binding.viewPager;

    adapter = new ViewPagerAdapter();
    viewPager.setAdapter(adapter);
    viewPager.setOffscreenPageLimit(2);

    new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> tab.setText(tabTitles[position])).attach();

    tabLayout.post(() -> {
        ViewGroup slidingTabStrip = (ViewGroup) tabLayout.getChildAt(0);
        if (slidingTabStrip == null) return;

        for (int i = 0; i < slidingTabStrip.getChildCount(); i++) {
            View tabView = slidingTabStrip.getChildAt(i);
            ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) tabView.getLayoutParams();
            int margin = (int) TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    6,
                    getResources().getDisplayMetrics()
            );
            params.setMargins(margin, 0, margin, 0);
            tabView.requestLayout();
        }
    });

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        getWindow().setDecorFitsSystemWindows(false);
    } else {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
    }

    getWindow().setStatusBarColor(Color.TRANSPARENT);
    getWindow().setNavigationBarColor(Color.TRANSPARENT);

    BlurView blurView = binding.blurView;
    ViewGroup rootView = (ViewGroup) binding.getRoot();
    Drawable windowBackground = rootView.getBackground();
    if (windowBackground == null) {
        windowBackground = new ColorDrawable(Color.parseColor("#DFEAFB"));
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        blurView.setupWith(rootView, new RenderEffectBlur())
                .setFrameClearDrawable(windowBackground)
                .setBlurRadius(3f)
                .setBlurAutoUpdate(true);
    } else {
        blurView.setupWith(rootView, new RenderScriptBlur(this))
                .setFrameClearDrawable(windowBackground)
                .setBlurRadius(3f)
                .setBlurAutoUpdate(true);
    }

    fetchServerData();
    fetchUserData();
}

private StringRequest newUtf8GetRequest(String url, Response.Listener<String> listener, Response.ErrorListener errorListener) {
    return new StringRequest(Request.Method.GET, url, listener, errorListener) {
        @Override
        protected Response<String> parseNetworkResponse(NetworkResponse response) {
            try {
                String parsed = new String(response.data, "UTF-8");
                return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
            } catch (Exception e) {
                return super.parseNetworkResponse(response);
            }
        }
    };
}

private StringRequest newUtf8PostRequest(
        String url,
        Map<String, String> params,
        Response.Listener<String> listener,
        Response.ErrorListener errorListener
) {
    return new StringRequest(Request.Method.POST, url, listener, errorListener) {
        @Override
        protected Map<String, String> getParams() {
            return params;
        }

        @Override
        protected Response<String> parseNetworkResponse(NetworkResponse response) {
            try {
                String parsed = new String(response.data, "UTF-8");
                return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
            } catch (Exception e) {
                return super.parseNetworkResponse(response);
            }
        }
    };
}

private void fetchServerData() {
    String url = "https://api.khelosobai20.live/ElitegoxUser/get_announcements.php";
    StringRequest request = newUtf8GetRequest(url, response -> {
        try {
            JSONObject jsonObject = new JSONObject(response);
            serverList.clear();

            if ("success".equalsIgnoreCase(jsonObject.optString("status", ""))) {
                JSONArray dataArray = jsonObject.optJSONArray("data");
                if (dataArray != null) {
                    for (int i = 0; i < dataArray.length(); i++) {
                        JSONObject obj = dataArray.optJSONObject(i);
                        if (obj == null) continue;

                        HashMap<String, Object> map = new HashMap<>();
                        map.put("id", obj.optString("id", ""));
                        map.put("title", obj.optString("title", ""));
                        map.put("image_link", obj.optString("image_link", ""));
                        map.put("message", obj.optString("message", ""));
                        map.put("date", obj.optString("date", ""));
                        map.put("time", obj.optString("time", ""));
                        serverList.add(map);
                    }
                }
            }

            if (adapter != null) adapter.notifyDataSetChanged();
        } catch (Exception e) {
            if (adapter != null) adapter.notifyDataSetChanged();
        }
    }, error -> {
        if (adapter != null) adapter.notifyDataSetChanged();
    });

    request.setRetryPolicy(new DefaultRetryPolicy(
            20000,
            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
    ));
    requestQueue.add(request);
}

private void fetchUserData() {
    String url = "https://api.khelosobai20.live/ElitegoxUser/get_user_announcements.php";
    Map<String, String> params = new HashMap<>();
    params.put("email", userEmail);

    StringRequest request = newUtf8PostRequest(url, params, response -> {
        try {
            JSONObject jsonObject = new JSONObject(response);
            userList.clear();

            if ("success".equalsIgnoreCase(jsonObject.optString("status", ""))) {
                JSONArray dataArray = jsonObject.optJSONArray("data");
                if (dataArray != null) {
                    for (int i = 0; i < dataArray.length(); i++) {
                        JSONObject obj = dataArray.optJSONObject(i);
                        if (obj == null) continue;

                        HashMap<String, Object> map = new HashMap<>();
                        map.put("id", obj.optString("id", ""));
                        map.put("title", obj.optString("title", ""));
                        map.put("image_link", obj.optString("image_link", ""));
                        map.put("message", obj.optString("message", ""));
                        map.put("date", obj.optString("date", ""));
                        map.put("time", obj.optString("time", ""));
                        userList.add(map);
                    }
                }
            }

            if (adapter != null) adapter.notifyDataSetChanged();
        } catch (Exception e) {
            if (adapter != null) adapter.notifyDataSetChanged();
        }
    }, error -> {
        if (adapter != null) adapter.notifyDataSetChanged();
    });

    request.setRetryPolicy(new DefaultRetryPolicy(
            20000,
            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
    ));
    requestQueue.add(request);
}

public void _methods() {
}

public class ViewPagerAdapter extends RecyclerView.Adapter<ViewPagerAdapter.PageViewHolder> {

    @NonNull
    @Override
    public PageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        FrameLayout frameLayout = new FrameLayout(parent.getContext());
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        RecyclerView rv = new RecyclerView(parent.getContext());
        rv.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        rv.setClipToPadding(false);
        rv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        int paddingTop = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                158,
                parent.getResources().getDisplayMetrics()
        );
        int paddingBottom = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                20,
                parent.getResources().getDisplayMetrics()
        );
        rv.setPadding(0, paddingTop, 0, paddingBottom);

        LinearLayout emptyLayout = new LinearLayout(parent.getContext());
        emptyLayout.setOrientation(LinearLayout.VERTICAL);
        emptyLayout.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams emptyParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        emptyParams.gravity = Gravity.CENTER;
        emptyLayout.setLayoutParams(emptyParams);
        emptyLayout.setVisibility(View.GONE);

        LottieAnimationView lottieView = new LottieAnimationView(parent.getContext());
        lottieView.setAnimation("no_found.json");
        lottieView.setRepeatCount(ValueAnimator.INFINITE);
        lottieView.playAnimation();

        int lottieSize = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                150,
                parent.getResources().getDisplayMetrics()
        );
        LinearLayout.LayoutParams lottieParams = new LinearLayout.LayoutParams(lottieSize, lottieSize);
        lottieView.setLayoutParams(lottieParams);

        TextView tvEmpty = new TextView(parent.getContext());
        tvEmpty.setText("No data found");
        tvEmpty.setTextSize(16f);
        tvEmpty.setTextColor(Color.parseColor("#6B7280"));
        tvEmpty.setGravity(Gravity.CENTER);

        LinearLayout.LayoutParams tvParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        tvParams.topMargin = (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                16,
                parent.getResources().getDisplayMetrics()
        );
        tvEmpty.setLayoutParams(tvParams);

        emptyLayout.addView(lottieView);
        emptyLayout.addView(tvEmpty);

        frameLayout.addView(rv);
        frameLayout.addView(emptyLayout);

        return new PageViewHolder(frameLayout, rv, emptyLayout);
    }

    @Override
    public void onBindViewHolder(@NonNull PageViewHolder holder, int position) {
        holder.recyclerView.setLayoutManager(new LinearLayoutManager(holder.itemView.getContext()));

        ArrayList<HashMap<String, Object>> currentList = position == 0 ? serverList : userList;
        holder.recyclerView.setAdapter(new MainRecyclerViewAdapter(currentList));

        if (currentList.isEmpty()) {
            holder.emptyLayout.setVisibility(View.VISIBLE);
            holder.recyclerView.setVisibility(View.GONE);
        } else {
            holder.emptyLayout.setVisibility(View.GONE);
            holder.recyclerView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return tabTitles.length;
    }

    class PageViewHolder extends RecyclerView.ViewHolder {
        RecyclerView recyclerView;
        LinearLayout emptyLayout;

        PageViewHolder(@NonNull View itemView, RecyclerView rv, LinearLayout empty) {
            super(itemView);
            recyclerView = rv;
            emptyLayout = empty;
        }
    }
}

public class MainRecyclerViewAdapter extends RecyclerView.Adapter<MainRecyclerViewAdapter.ViewHolder> {
    ArrayList<HashMap<String, Object>> _data;

    public MainRecyclerViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
        _data = _arr;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.shuvo_notification, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HashMap<String, Object> map = _data.get(position);

        String title = map.get("title") != null ? map.get("title").toString() : "";
        String date = map.get("date") != null ? map.get("date").toString() : "";
        String time = map.get("time") != null ? map.get("time").toString() : "";
        String message = map.get("message") != null ? map.get("message").toString() : "";
        String imageLink = map.get("image_link") != null ? map.get("image_link").toString() : "";

        holder.notice_title.setText(title);
        holder.notice_date.setText(date);
        holder.notice_time.setText(time);
        holder.notice_message.setText(message);

        holder.notice_image.setImageDrawable(null);

        if (!imageLink.isEmpty()) {
            holder.cardview2.setVisibility(View.VISIBLE);
            new Thread(() -> {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(imageLink);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(15000);
                    connection.connect();

                    InputStream input = connection.getInputStream();
                    Bitmap myBitmap = BitmapFactory.decodeStream(input);
                    input.close();

                    Handler mainHandler = new Handler(Looper.getMainLooper());
                    mainHandler.post(() -> {
                        if (myBitmap != null) {
                            holder.notice_image.setImageBitmap(myBitmap);
                        }
                    });
                } catch (Exception ignored) {
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }).start();
        } else {
            holder.cardview2.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return _data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public CardView cardview2;
        public ImageView notice_image;
        public TextView notice_title;
        public TextView notice_date;
        public TextView notice_time;
        public TextView notice_message;

        public ViewHolder(View v) {
            super(v);
            cardview2 = v.findViewById(R.id.cardview2);
            notice_image = v.findViewById(R.id.notice_image);
            notice_title = v.findViewById(R.id.notice_title);
            notice_date = v.findViewById(R.id.notice_date);
            notice_time = v.findViewById(R.id.notice_time);
            notice_message = v.findViewById(R.id.notice_message);
        }
    }
}

}