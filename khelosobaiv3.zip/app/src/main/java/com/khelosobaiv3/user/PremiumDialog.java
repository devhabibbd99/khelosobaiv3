package com.khelosobaiv3.user;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class PremiumDialog {

    public interface DialogListener {
        void onClick(Dialog dialog);
    }

    public static class Builder {
        private final Context context;
        private boolean isBottomSheet = true;
        private boolean isCancelable = true;
        private boolean isBlurBackground = true;
        private String lottieFileName = "";
        private String titleText = "";
        private String messageText = "";
        private String positiveText = "Confirm";
        private String negativeText = "Cancel";
        private String positiveColor = "#7B2CBF";
        private DialogListener positiveListener;
        private DialogListener negativeListener;

        public Builder(Context context) {
            this.context = context;
        }

        public Builder setDialogType(boolean isBottomSheet) {
            this.isBottomSheet = isBottomSheet;
            return this;
        }

        public Builder setCancelable(boolean isCancelable) {
            this.isCancelable = isCancelable;
            return this;
        }

        public Builder setBlurBackground(boolean isBlurBackground) {
            this.isBlurBackground = isBlurBackground;
            return this;
        }

        public Builder setLottie(String lottieFileName) {
            this.lottieFileName = lottieFileName;
            return this;
        }

        public Builder setTitle(String titleText) {
            this.titleText = titleText;
            return this;
        }

        public Builder setMessage(String messageText) {
            this.messageText = messageText;
            return this;
        }

        public Builder setPositiveButton(String text, String colorHex, DialogListener listener) {
            this.positiveText = text;
            if (colorHex != null && !colorHex.isEmpty()) {
                this.positiveColor = colorHex;
            }
            this.positiveListener = listener;
            return this;
        }

        public Builder setNegativeButton(String text, DialogListener listener) {
            this.negativeText = text;
            this.negativeListener = listener;
            return this;
        }

        public Dialog show() {
            final Dialog dialog = isBottomSheet
                    ? new BottomSheetDialog(context, R.style.TransparentBottomSheetDialogTheme)
                    : new Dialog(context);

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setCancelable(isCancelable);
            dialog.setCanceledOnTouchOutside(isCancelable);

            LinearLayout rootLayout = new LinearLayout(context);
            rootLayout.setOrientation(LinearLayout.VERTICAL);
            rootLayout.setGravity(Gravity.CENTER_HORIZONTAL);

            int pad = dpToPx(context, 24);
            rootLayout.setPadding(pad, dpToPx(context, 28), pad, dpToPx(context, 32));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#FFFFFF"));
            if (isBottomSheet) {
                float radius = dpToPx(context, 28);
                bg.setCornerRadii(new float[]{radius, radius, radius, radius, 0, 0, 0, 0});
            } else {
                bg.setCornerRadius(dpToPx(context, 28));
            }
            rootLayout.setBackground(bg);

            if (!lottieFileName.isEmpty()) {
                LottieAnimationView lottieView = new LottieAnimationView(context);
                int lottieSize = dpToPx(context, 80);
                LinearLayout.LayoutParams lottieParams = new LinearLayout.LayoutParams(lottieSize, lottieSize);
                lottieParams.bottomMargin = dpToPx(context, 16);
                lottieView.setLayoutParams(lottieParams);
                lottieView.setAnimation(lottieFileName);
                lottieView.setRepeatCount(LottieDrawable.INFINITE);
                lottieView.playAnimation();
                rootLayout.addView(lottieView);
            }

            if (!titleText.isEmpty()) {
                TextView titleView = new TextView(context);
                titleView.setText(titleText);
                titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
                titleView.setTextColor(Color.parseColor("#1D1B20"));
                titleView.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
                titleView.setGravity(Gravity.CENTER);
                rootLayout.addView(titleView);
            }

            if (!messageText.isEmpty()) {
                TextView messageView = new TextView(context);
                messageView.setText(messageText);
                messageView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                messageView.setTextColor(Color.parseColor("#49454F"));
                messageView.setGravity(Gravity.CENTER);
                messageView.setLineSpacing(
                        TypedValue.applyDimension(
                                TypedValue.COMPLEX_UNIT_DIP,
                                4,
                                context.getResources().getDisplayMetrics()
                        ),
                        1.1f
                );
                LinearLayout.LayoutParams msgParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                msgParams.topMargin = dpToPx(context, 12);
                messageView.setLayoutParams(msgParams);
                rootLayout.addView(messageView);
            }

            boolean hasNegative = negativeListener != null;
            boolean hasPositive = positiveListener != null;
            int buttonCount = (hasNegative ? 1 : 0) + (hasPositive ? 1 : 0);

            if (buttonCount > 0) {
                LinearLayout buttonContainer = new LinearLayout(context);
                buttonContainer.setOrientation(LinearLayout.HORIZONTAL);

                LinearLayout.LayoutParams btnContainerParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                btnContainerParams.topMargin = dpToPx(context, 32);
                buttonContainer.setLayoutParams(btnContainerParams);

                if (buttonCount == 1) {
                    if (hasNegative) {
                        TextView btnNegative = createButton(
                                context,
                                negativeText,
                                Color.parseColor("#1D192B"),
                                getRippleDrawable(
                                        Color.parseColor("#E8DEF8"),
                                        Color.parseColor("#D0C4E8"),
                                        dpToPx(context, 100)
                                )
                        );
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                        );
                        btnNegative.setLayoutParams(params);
                        btnNegative.setOnClickListener(v -> negativeListener.onClick(dialog));
                        buttonContainer.addView(btnNegative);
                    } else {
                        TextView btnPositive = createButton(
                                context,
                                positiveText,
                                Color.WHITE,
                                getRippleDrawable(
                                        Color.parseColor(positiveColor),
                                        Color.parseColor("#40000000"),
                                        dpToPx(context, 100)
                                )
                        );
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                        );
                        btnPositive.setLayoutParams(params);
                        btnPositive.setOnClickListener(v -> positiveListener.onClick(dialog));
                        buttonContainer.addView(btnPositive);
                    }
                } else {
                    if (hasNegative) {
                        TextView btnNegative = createButton(
                                context,
                                negativeText,
                                Color.parseColor("#1D192B"),
                                getRippleDrawable(
                                        Color.parseColor("#E8DEF8"),
                                        Color.parseColor("#D0C4E8"),
                                        dpToPx(context, 100)
                                )
                        );
                        LinearLayout.LayoutParams negParams = new LinearLayout.LayoutParams(
                                0,
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                1f
                        );
                        negParams.rightMargin = dpToPx(context, 6);
                        btnNegative.setLayoutParams(negParams);
                        btnNegative.setOnClickListener(v -> negativeListener.onClick(dialog));
                        buttonContainer.addView(btnNegative);
                    }

                    if (hasPositive) {
                        TextView btnPositive = createButton(
                                context,
                                positiveText,
                                Color.WHITE,
                                getRippleDrawable(
                                        Color.parseColor(positiveColor),
                                        Color.parseColor("#40000000"),
                                        dpToPx(context, 100)
                                )
                        );
                        LinearLayout.LayoutParams posParams = new LinearLayout.LayoutParams(
                                0,
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                1f
                        );
                        if (hasNegative) {
                            posParams.leftMargin = dpToPx(context, 6);
                        }
                        btnPositive.setLayoutParams(posParams);
                        btnPositive.setOnClickListener(v -> positiveListener.onClick(dialog));
                        buttonContainer.addView(btnPositive);
                    }
                }

                rootLayout.addView(buttonContainer);
            }

            dialog.setContentView(rootLayout);

            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                if (!isBottomSheet) {
                    window.setLayout(
                            (int) (context.getResources().getDisplayMetrics().widthPixels * 0.85),
                            ViewGroup.LayoutParams.WRAP_CONTENT
                    );
                }

                if (isBlurBackground && context instanceof Activity) {
                    window.setDimAmount(0f);
                    Activity activity = (Activity) context;
                    ViewGroup decorView = (ViewGroup) activity.getWindow().getDecorView();
                    ViewGroup rootView = decorView.findViewById(android.R.id.content);

                    BlurView blurView = new BlurView(context);
                    blurView.setLayoutParams(new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                    ));

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        blurView.setupWith(rootView, new RenderEffectBlur())
                                .setFrameClearDrawable(decorView.getBackground())
                                .setBlurRadius(4f);
                    } else {
                        blurView.setupWith(rootView, new RenderScriptBlur(context))
                                .setFrameClearDrawable(decorView.getBackground())
                                .setBlurRadius(4f);
                    }

                    View dimView = new View(context);
                    dimView.setBackgroundColor(Color.parseColor("#26000000"));
                    dimView.setLayoutParams(new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                    ));

                    FrameLayout blurContainer = new FrameLayout(context);
                    blurContainer.addView(blurView);
                    blurContainer.addView(dimView);

                    decorView.addView(blurContainer);
                    dialog.setOnDismissListener(d -> decorView.removeView(blurContainer));
                } else {
                    window.setDimAmount(0.5f);
                }
            }

            dialog.show();
            return dialog;
        }

        private TextView createButton(Context context, String text, int textColor, Drawable background) {
            TextView textView = new TextView(context);
            textView.setText(text);
            textView.setTextColor(textColor);
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            textView.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            textView.setGravity(Gravity.CENTER);
            textView.setPadding(0, dpToPx(context, 14), 0, dpToPx(context, 14));
            textView.setBackground(background);
            return textView;
        }

        private int dpToPx(Context c, int dp) {
            return (int) TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    dp,
                    c.getResources().getDisplayMetrics()
            );
        }

        private Drawable getRippleDrawable(int normalColor, int pressedColor, float radius) {
            GradientDrawable shape = new GradientDrawable();
            shape.setColor(normalColor);
            shape.setCornerRadius(radius);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                return new RippleDrawable(ColorStateList.valueOf(pressedColor), shape, null);
            }
            return shape;
        }
    }
}