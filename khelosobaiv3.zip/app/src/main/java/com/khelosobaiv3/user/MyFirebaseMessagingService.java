package com.khelosobaiv3.user;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.util.Xml;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.RemoteInput;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Stack;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "FCM";
    private static final String PREF_NAME = "Save_User_Status";
    private static final String DEFAULT_CHANNEL_ID = "My_App_Notifications";
    private static final String DEFAULT_CHANNEL_NAME = "Notification";

    public static final String KEY_REPLY_TEXT = "key_reply_text";
    public static final String ACTION_REPLY = "com.khelosobaiv3.user.ACTION_REPLY";
    public static final String ACTION_DISMISS = "com.khelosobaiv3.user.ACTION_DISMISS";
    public static final String ACTION_OPEN = "com.khelosobaiv3.user.ACTION_OPEN";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        Payload payload = Payload.from(remoteMessage);
        Map<String, String> localVars = loadLocalVariables();

        int notificationId = payload.id > 0 ? payload.id : new Random().nextInt(1_000_000);

        String immediateTitle = resolveTemplate(firstNonEmpty(payload.title, "Notification"), localVars);
        String immediateBody = resolveTemplate(firstNonEmpty(payload.body, "প্রিয় {Player Name}, আপনার জয়েনকৃত ম্যাচ"), localVars);

        showNotification(notificationId, immediateTitle, immediateBody, null, payload);

        if (payload.hasRemoteSource()) {
            executor.execute(() -> {
                try {
                    Map<String, String> vars = new LinkedHashMap<>(localVars);

                    for (SourceConfig source : payload.sources) {
                        String resolvedUrl = resolveTemplate(source.url, vars);
                        String responseText = requestText(
                                resolvedUrl,
                                source.method,
                                resolveTemplate(source.body, vars),
                                source.headers
                        );

                        if (responseText == null) continue;

                        if ("json".equalsIgnoreCase(source.contentType) || isJson(responseText)) {
                            JSONObject obj = new JSONObject(responseText);
                            flattenJson(obj, "", vars);
                        } else if ("xml".equalsIgnoreCase(source.contentType)) {
                            parseXmlToMap(responseText, vars);
                            vars.put("REMOTE_XML", prettyXml(responseText));
                        } else if ("html".equalsIgnoreCase(source.contentType)) {
                            vars.put("REMOTE_HTML", htmlToPlainText(responseText));
                        } else {
                            vars.put("REMOTE_TEXT", responseText);
                        }
                    }

                    String finalTitle = resolveTemplate(firstNonEmpty(payload.title, immediateTitle), vars);
                    String finalBodyRaw = resolveTemplate(firstNonEmpty(payload.body, immediateBody), vars);

                    CharSequence finalBody = renderPreview(finalBodyRaw, payload.contentType);

                    Bitmap image = null;
                    if (notBlank(payload.imageUrl)) {
                        image = getBitmapFromUrl(resolveTemplate(payload.imageUrl, vars));
                    }

                    Bitmap finalImage = image;
                    mainHandler.post(() -> showNotification(notificationId, finalTitle, finalBody, finalImage, payload));
                } catch (Exception e) {
                    Log.e(TAG, "Remote resolve failed", e);
                }
            });
        }
    }

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        Log.d(TAG, "FCM token: " + token);
    }

    private void showNotification(int notificationId, String title, CharSequence body, Bitmap image, Payload payload) {
        createNotificationChannel(payload);

        Intent contentIntent = buildTargetIntent(payload.activityName, payload.extraData, payload.deepLink);
        contentIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;

        PendingIntent contentPendingIntent =
                PendingIntent.getActivity(this, notificationId, contentIntent, piFlags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, firstNonEmpty(payload.channelId, DEFAULT_CHANNEL_ID))
                .setSmallIcon(payload.smallIconRes != 0 ? payload.smallIconRes : R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(!payload.ongoing)
                .setOngoing(payload.ongoing)
                .setOnlyAlertOnce(true)
                .setContentIntent(contentPendingIntent)
                .setPriority(mapPriority(payload.priority))
                .setCategory(firstNonEmpty(payload.category, NotificationCompat.CATEGORY_MESSAGE));

        if (payload.number >= 0) {
            builder.setNumber(payload.number);
        }

        if (notBlank(payload.subText)) {
            builder.setSubText(payload.subText);
        }

        builder.setShowWhen(payload.showWhen);

        if (payload.silent) {
            builder.setSound(null);
            builder.setVibrate(null);
        }

        if (!payload.vibrationPattern.isEmpty()) {
            long[] pattern = new long[payload.vibrationPattern.size()];
            for (int i = 0; i < payload.vibrationPattern.size(); i++) {
                pattern[i] = payload.vibrationPattern.get(i);
            }
            builder.setVibrate(pattern);
        }

        if (notBlank(payload.soundUri) && !payload.silent) {
            builder.setSound(Uri.parse(payload.soundUri));
        }

        if (payload.color != 0) {
            builder.setColor(payload.color);
        }

        if (payload.style.equalsIgnoreCase("inbox")) {
            NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
            for (String line : payload.inboxLines) {
                style.addLine(line);
            }
            if (!payload.inboxLines.isEmpty()) {
                style.setBigContentTitle(title);
            }
            builder.setStyle(style);
        } else if (payload.style.equalsIgnoreCase("messaging")) {
            NotificationCompat.MessagingStyle style = new NotificationCompat.MessagingStyle(
                    payload.personName != null ? payload.personName : "You");
            style.setConversationTitle(payload.conversationTitle);
            for (String msg : payload.messages) {
                style.addMessage(msg, System.currentTimeMillis(),
                        payload.personName != null ? payload.personName : "System");
            }
            builder.setStyle(style);
        } else if (image != null) {
            builder.setLargeIcon(image);
            builder.setStyle(new NotificationCompat.BigPictureStyle()
                    .bigPicture(image)
                    .bigLargeIcon((Bitmap) null)
                    .setBigContentTitle(title)
                    .setSummaryText(body.toString()));
        } else {
            builder.setStyle(new NotificationCompat.BigTextStyle()
                    .bigText(body)
                    .setBigContentTitle(title));
        }

        if (payload.enableReply) {
            Intent replyIntent = new Intent(this, NotificationActionReceiver.class);
            replyIntent.setAction(ACTION_REPLY);
            replyIntent.putExtra("notification_id", notificationId);
            replyIntent.putExtra("reply_target_activity", payload.activityName);
            replyIntent.putExtra("reply_extra", payload.extraData);

            PendingIntent replyPi = PendingIntent.getBroadcast(
                    this,
                    notificationId + 101,
                    replyIntent,
                    piFlags
            );

            RemoteInput remoteInput = new RemoteInput.Builder(KEY_REPLY_TEXT)
                    .setLabel(payload.replyLabel != null ? payload.replyLabel : "Reply")
                    .build();

            NotificationCompat.Action replyAction = new NotificationCompat.Action.Builder(
                    R.drawable.ic_reply,
                    payload.replyButtonTitle != null ? payload.replyButtonTitle : "Reply",
                    replyPi
            ).addRemoteInput(remoteInput).build();

            builder.addAction(replyAction);
        }

        for (ActionConfig action : payload.actions) {
            PendingIntent actionPi = buildActionPendingIntent(notificationId, action, payload, piFlags);
            if (actionPi != null) {
                builder.addAction(action.iconRes != 0 ? action.iconRes : R.drawable.ic_notification,
                        action.title, actionPi);
            }
        }

        if (notBlank(payload.groupKey)) {
            builder.setGroup(payload.groupKey);
            if (payload.groupSummary) {
                builder.setGroupSummary(true);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && payload.timeSensitive) {
            builder.setPriority(NotificationCompat.PRIORITY_HIGH);
        }

        if (notBlank(payload.lottieUrl)) {
            builder.addExtras(new android.os.Bundle());
        }

        NotificationManagerCompat.from(this).notify(notificationId, builder.build());
    }

    private PendingIntent buildActionPendingIntent(int notificationId, ActionConfig action, Payload payload, int flags) {
        try {
            Intent intent = new Intent(this, NotificationActionReceiver.class);
            intent.setAction(ACTION_OPEN);
            intent.putExtra("action_type", action.type);
            intent.putExtra("target_activity", action.activity);
            intent.putExtra("target_url", action.url);
            intent.putExtra("deep_link", action.deepLink);
            intent.putExtra("extra_data", payload.extraData);
            intent.putExtra("notification_id", notificationId);

            return PendingIntent.getBroadcast(this, notificationId + action.title.hashCode(), intent, flags);
        } catch (Exception e) {
            Log.e(TAG, "buildActionPendingIntent failed", e);
            return null;
        }
    }

    private void createNotificationChannel(Payload payload) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;

        String channelId = firstNonEmpty(payload.channelId, DEFAULT_CHANNEL_ID);
        String channelName = firstNonEmpty(payload.channelName, DEFAULT_CHANNEL_NAME);

        NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
        channel.enableLights(true);
        channel.enableVibration(true);

        if (payload.color != 0) {
            channel.setLightColor(payload.color);
        }

        if (notBlank(payload.soundUri) && !payload.silent) {
            Uri sound = Uri.parse(payload.soundUri);
            AudioAttributes aa = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            channel.setSound(sound, aa);
        }

        manager.createNotificationChannel(channel);
    }

    private Intent buildTargetIntent(String activityName, String extraData, String deepLink) {
        Class<?> targetClass = resolveActivityClass(activityName);
        Intent intent = new Intent(this, targetClass);

        if (notBlank(extraData)) intent.putExtra("EXTRA_DATA", extraData);
        if (notBlank(deepLink)) intent.putExtra("DEEP_LINK", deepLink);

        return intent;
    }

    private Class<?> resolveActivityClass(String activityName) {
        try {
            if (!notBlank(activityName)) return MainActivity.class;

            String clean = activityName.trim();
            if (clean.toLowerCase(Locale.US).endsWith(".java")) {
                clean = clean.substring(0, clean.length() - 5);
            }
            if (clean.startsWith(".")) {
                clean = getPackageName() + clean;
            } else if (!clean.contains(".")) {
                clean = getPackageName() + "." + clean;
            }
            return Class.forName(clean);
        } catch (Exception e) {
            Log.e(TAG, "resolveActivityClass failed", e);
            return MainActivity.class;
        }
    }

    private Map<String, String> loadLocalVariables() {
        Map<String, String> vars = new LinkedHashMap<>();
        SharedPreferences sp = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        String email = safe(sp.getString("Email", ""));
        String username = safe(sp.getString("Username", ""));
        String balance = safe(sp.getString("balance", "0"));
        String winning = safe(sp.getString("winning", "0"));
        String token = safe(sp.getString("token", ""));
        String uid = safe(sp.getString("UID", ""));
        String fcm = safe(sp.getString("Fcm", ""));

        putAlias(vars, "email", email);
        putAlias(vars, "Email", email);

        putAlias(vars, "username", username);
        putAlias(vars, "Username", username);
        putAlias(vars, "Player Name", username);
        putAlias(vars, "Player_Name", username);

        putAlias(vars, "Balance", balance);
        putAlias(vars, "Winning", winning);
        putAlias(vars, "token", token);
        putAlias(vars, "UID", uid);
        putAlias(vars, "Fcm", fcm);

        return vars;
    }

    private void putAlias(Map<String, String> vars, String key, String value) {
        if (!notBlank(key)) return;
        String v = value == null ? "" : value;

        vars.put(key, v);
        vars.put(key.toLowerCase(Locale.US), v);
        vars.put(key.toUpperCase(Locale.US), v);
        vars.put(key.replace("_", " "), v);
        vars.put(key.replace(" ", "_"), v);
    }

    private String resolveTemplate(String template, Map<String, String> vars) {
        if (template == null) return "";
        String out = template;

        if (vars != null) {
            for (Map.Entry<String, String> entry : vars.entrySet()) {
                String k = entry.getKey();
                String v = entry.getValue() == null ? "" : entry.getValue();
                out = out.replace("{" + k + "}", v);
                out = out.replace("{{" + k + "}}", v);
            }
        }
        return out;
    }

    private void flattenJson(JSONObject obj, String prefix, Map<String, String> vars) throws Exception {
        JSONArray names = obj.names();
        if (names == null) return;

        for (int i = 0; i < names.length(); i++) {
            String key = names.getString(i);
            Object value = obj.get(key);
            String fullKey = prefix.isEmpty() ? key : prefix + "." + key;

            if (value instanceof JSONObject) {
                flattenJson((JSONObject) value, fullKey, vars);
            } else if (value instanceof JSONArray) {
                String str = value.toString();
                vars.put(fullKey, str);
                putAlias(vars, key, str);
            } else {
                String str = String.valueOf(value);
                vars.put(fullKey, str);
                putAlias(vars, key, str);

                if ("username".equalsIgnoreCase(key) || "player_name".equalsIgnoreCase(key) || "name".equalsIgnoreCase(key)) {
                    putAlias(vars, "Player Name", str);
                    putAlias(vars, "Username", str);
                }
                if ("balance".equalsIgnoreCase(key)) putAlias(vars, "Balance", str);
                if ("winning".equalsIgnoreCase(key)) putAlias(vars, "Winning", str);
                if ("position".equalsIgnoreCase(key)) putAlias(vars, "position", str);
                if ("ip".equalsIgnoreCase(key)) putAlias(vars, "ip", str);
                if ("city".equalsIgnoreCase(key)) putAlias(vars, "city", str);
                if ("region".equalsIgnoreCase(key)) putAlias(vars, "region", str);
                if ("country".equalsIgnoreCase(key)) putAlias(vars, "country", str);
                if ("loc".equalsIgnoreCase(key)) putAlias(vars, "loc", str);
                if ("org".equalsIgnoreCase(key)) putAlias(vars, "org", str);
                if ("verify_badge".equalsIgnoreCase(key)) putAlias(vars, "verify_badge", str);
            }
        }
    }

    private void parseXmlToMap(String xml, Map<String, String> vars) throws XmlPullParserException, IOException {
        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(new java.io.StringReader(xml));

        int eventType = parser.getEventType();
        Stack<String> tagStack = new Stack<>();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            switch (eventType) {
                case XmlPullParser.START_TAG:
                    String tagName = parser.getName();
                    tagStack.push(tagName);
                    for (int i = 0; i < parser.getAttributeCount(); i++) {
                        String attrName = parser.getAttributeName(i);
                        String attrValue = parser.getAttributeValue(i);
                        String fullKey = buildXmlKey(tagStack, attrName);
                        vars.put(fullKey, attrValue);
                        putAlias(vars, attrName, attrValue);
                    }
                    break;

                case XmlPullParser.TEXT:
                    String text = parser.getText();
                    if (text != null && !text.trim().isEmpty()) {
                        String fullKey = buildXmlKey(tagStack, "text");
                        vars.put(fullKey, text.trim());
                        if (!tagStack.isEmpty()) {
                            String lastTag = tagStack.peek();
                            vars.put(lastTag, text.trim());
                            putAlias(vars, lastTag, text.trim());
                        }
                    }
                    break;

                case XmlPullParser.END_TAG:
                    if (!tagStack.isEmpty()) {
                        tagStack.pop();
                    }
                    break;
            }
            eventType = parser.next();
        }
    }

    private String buildXmlKey(Stack<String> stack, String suffix) {
        StringBuilder sb = new StringBuilder();
        for (String tag : stack) {
            if (sb.length() > 0) sb.append('.');
            sb.append(tag);
        }
        if (suffix != null && !suffix.isEmpty()) {
            sb.append('.').append(suffix);
        }
        return sb.toString();
    }

    private boolean isJson(String text) {
        if (text == null) return false;
        String t = text.trim();
        return (t.startsWith("{") && t.endsWith("}")) || (t.startsWith("[") && t.endsWith("]"));
    }

    private String requestText(String urlString, String method, String body, Map<String, String> headers) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        try {
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(4500);
            connection.setReadTimeout(6000);
            connection.setUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestMethod(firstNonEmpty(method, "GET").toUpperCase(Locale.US));

            if (headers != null) {
                for (Map.Entry<String, String> entry : headers.entrySet()) {
                    if (entry.getKey() != null && entry.getValue() != null) {
                        connection.setRequestProperty(entry.getKey(), entry.getValue());
                    }
                }
            }

            if ("POST".equalsIgnoreCase(connection.getRequestMethod())
                    || "PUT".equalsIgnoreCase(connection.getRequestMethod())
                    || "PATCH".equalsIgnoreCase(connection.getRequestMethod())) {
                connection.setDoOutput(true);
                if (!headersHasContentType(headers)) {
                    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                }
                String payload = body == null ? "" : body;
                connection.getOutputStream().write(payload.getBytes());
                connection.getOutputStream().flush();
                connection.getOutputStream().close();
            }

            int code = connection.getResponseCode();
            InputStream inputStream = (code >= 200 && code < 400) ? connection.getInputStream() : connection.getErrorStream();
            if (inputStream == null) return null;

            reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);

            return sb.toString();
        } catch (Exception e) {
            Log.e(TAG, "requestText failed: " + urlString, e);
            return null;
        } finally {
            try {
                if (reader != null) reader.close();
            } catch (Exception ignored) {}
            if (connection != null) connection.disconnect();
        }
    }

    private boolean headersHasContentType(Map<String, String> headers) {
        if (headers == null) return false;
        for (String k : headers.keySet()) {
            if ("content-type".equalsIgnoreCase(k)) return true;
        }
        return false;
    }

    private Bitmap getBitmapFromUrl(String imageUrl) {
        HttpURLConnection connection = null;
        InputStream inputStream = null;

        try {
            URL url = new URL(imageUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(4500);
            connection.setReadTimeout(6000);
            connection.setDoInput(true);
            connection.connect();

            inputStream = connection.getInputStream();
            return BitmapFactory.decodeStream(inputStream);
        } catch (Exception e) {
            Log.e(TAG, "Image download failed", e);
            return null;
        } finally {
            try {
                if (inputStream != null) inputStream.close();
            } catch (Exception ignored) {}
            if (connection != null) connection.disconnect();
        }
    }

    private CharSequence renderPreview(String text, String contentType) {
        if (text == null) return "";
        if ("html".equalsIgnoreCase(contentType)) {
            try {
                return Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY);
            } catch (Exception e) {
                return htmlToPlainText(text);
            }
        }
        if ("xml".equalsIgnoreCase(contentType)) {
            return prettyXml(text);
        }
        return text;
    }

    private String prettyXml(String xml) {
        if (xml == null) return "";
        return xml.trim().replace("><", ">\n<");
    }

    private String htmlToPlainText(String html) {
        if (html == null) return "";
        try {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
        } catch (Exception e) {
            return html.replaceAll("<[^>]*>", "");
        }
    }

    private String firstNonEmpty(String a, String b) {
        return notBlank(a) ? a : (b == null ? "" : b);
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private boolean notBlank(String s) {
        return s != null && !s.trim().isEmpty() && !"null".equalsIgnoreCase(s.trim());
    }

    private int mapPriority(String p) {
        if (p == null) return NotificationCompat.PRIORITY_HIGH;
        switch (p.toLowerCase(Locale.US)) {
            case "max": return NotificationCompat.PRIORITY_MAX;
            case "high": return NotificationCompat.PRIORITY_HIGH;
            case "default": return NotificationCompat.PRIORITY_DEFAULT;
            case "low": return NotificationCompat.PRIORITY_LOW;
            case "min": return NotificationCompat.PRIORITY_MIN;
            default: return NotificationCompat.PRIORITY_HIGH;
        }
    }

    private static class Payload {
        int id = -1;
        String title = "Notification";
        String body = "প্রিয় {Player Name}, আপনার জয়েনকৃত ম্যাচ";
        String imageUrl = "";
        String activityName = "MainActivity";
        String extraData = "";
        String deepLink = "";
        String channelId = DEFAULT_CHANNEL_ID;
        String channelName = DEFAULT_CHANNEL_NAME;
        String category = NotificationCompat.CATEGORY_MESSAGE;
        String priority = "high";
        String style = "text";
        String contentType = "text";
        String subText = "";
        String ticker = "";
        String soundUri = "";
        String groupKey = "";
        boolean groupSummary = false;
        boolean ongoing = false;
        boolean silent = false;
        boolean showWhen = true;
        boolean timeSensitive = false;
        int color = 0;
        int number = -1;
        int smallIconRes = 0;
        String lottieUrl = "";

        String conversationTitle = "";
        String personName = "System";
        ArrayList<String> inboxLines = new ArrayList<>();
        ArrayList<String> messages = new ArrayList<>();
        ArrayList<Long> vibrationPattern = new ArrayList<>();
        ArrayList<SourceConfig> sources = new ArrayList<>();
        ArrayList<ActionConfig> actions = new ArrayList<>();

        boolean enableReply = false;
        String replyLabel = "Reply";
        String replyButtonTitle = "Reply";

        boolean hasRemoteSource() {
            return sources != null && !sources.isEmpty();
        }

        static Payload from(RemoteMessage remoteMessage) {
            Payload p = new Payload();

            RemoteMessage.Notification n = remoteMessage.getNotification();
            if (n != null) {
                if (notBlank(n.getTitle())) p.title = n.getTitle().trim();
                if (notBlank(n.getBody())) p.body = n.getBody().trim();
                if (n.getImageUrl() != null) p.imageUrl = n.getImageUrl().toString();
            }

            Map<String, String> data = remoteMessage.getData();
            if (data == null) return p;

            if (notBlank(data.get("id"))) {
                try { p.id = Integer.parseInt(data.get("id").trim()); } catch (Exception ignored) {}
            }

            if (notBlank(data.get("title"))) p.title = data.get("title").trim();
            if (notBlank(data.get("body"))) p.body = data.get("body").trim();
            if (notBlank(data.get("image"))) p.imageUrl = data.get("image").trim();
            if (notBlank(data.get("activity"))) p.activityName = data.get("activity").trim();
            if (notBlank(data.get("activity_class"))) p.activityName = data.get("activity_class").trim();
            if (notBlank(data.get("screen"))) p.activityName = data.get("screen").trim();
            if (notBlank(data.get("extra"))) p.extraData = data.get("extra").trim();
            if (notBlank(data.get("deep_link"))) p.deepLink = data.get("deep_link").trim();
            if (notBlank(data.get("channel_id"))) p.channelId = data.get("channel_id").trim();
            if (notBlank(data.get("channel_name"))) p.channelName = data.get("channel_name").trim();
            if (notBlank(data.get("category"))) p.category = data.get("category").trim();
            if (notBlank(data.get("priority"))) p.priority = data.get("priority").trim();
            if (notBlank(data.get("style"))) p.style = data.get("style").trim();
            if (notBlank(data.get("content_type"))) p.contentType = data.get("content_type").trim();
            if (notBlank(data.get("subtitle"))) p.subText = data.get("subtitle").trim();
            if (notBlank(data.get("ticker"))) p.ticker = data.get("ticker").trim();
            if (notBlank(data.get("sound"))) p.soundUri = data.get("sound").trim();
            if (notBlank(data.get("group_key"))) p.groupKey = data.get("group_key").trim();
            if (notBlank(data.get("number"))) {
                try { p.number = Integer.parseInt(data.get("number").trim()); } catch (Exception ignored) {}
            }
            if (notBlank(data.get("color"))) {
                try { p.color = Color.parseColor(data.get("color").trim()); } catch (Exception ignored) {}
            }
            if (notBlank(data.get("small_icon"))) {
                try { p.smallIconRes = Integer.parseInt(data.get("small_icon").trim()); } catch (Exception ignored) {}
            }
            if (notBlank(data.get("lottie_url"))) p.lottieUrl = data.get("lottie_url").trim();

            if (notBlank(data.get("ongoing"))) p.ongoing = "true".equalsIgnoreCase(data.get("ongoing").trim());
            if (notBlank(data.get("silent"))) p.silent = "true".equalsIgnoreCase(data.get("silent").trim());
            if (notBlank(data.get("show_when"))) p.showWhen = !"false".equalsIgnoreCase(data.get("show_when").trim());
            if (notBlank(data.get("time_sensitive"))) p.timeSensitive = "true".equalsIgnoreCase(data.get("time_sensitive").trim());
            if (notBlank(data.get("group_summary"))) p.groupSummary = "true".equalsIgnoreCase(data.get("group_summary").trim());

            if (notBlank(data.get("reply"))) p.enableReply = "true".equalsIgnoreCase(data.get("reply").trim());
            if (notBlank(data.get("reply_label"))) p.replyLabel = data.get("reply_label").trim();
            if (notBlank(data.get("reply_button_title"))) p.replyButtonTitle = data.get("reply_button_title").trim();

            if (notBlank(data.get("person_name"))) p.personName = data.get("person_name").trim();
            if (notBlank(data.get("conversation_title"))) p.conversationTitle = data.get("conversation_title").trim();

            if (notBlank(data.get("inbox_lines"))) {
                try {
                    JSONArray arr = new JSONArray(data.get("inbox_lines"));
                    for (int i = 0; i < arr.length(); i++) p.inboxLines.add(arr.getString(i));
                } catch (Exception ignored) {}
            }

            if (notBlank(data.get("messages"))) {
                try {
                    JSONArray arr = new JSONArray(data.get("messages"));
                    for (int i = 0; i < arr.length(); i++) p.messages.add(arr.getString(i));
                } catch (Exception ignored) {}
            }

            if (notBlank(data.get("vibration_pattern"))) {
                try {
                    JSONArray arr = new JSONArray(data.get("vibration_pattern"));
                    for (int i = 0; i < arr.length(); i++) p.vibrationPattern.add(arr.getLong(i));
                } catch (Exception ignored) {}
            }

            if (notBlank(data.get("source_url"))) {
                p.sources.add(SourceConfig.single(data.get("source_url").trim(), data.get("request_method")));
            } else if (notBlank(data.get("json_url"))) {
                p.sources.add(SourceConfig.single(data.get("json_url").trim(), data.get("request_method")));
            } else if (notBlank(data.get("url"))) {
                p.sources.add(SourceConfig.single(data.get("url").trim(), data.get("request_method")));
            }

            if (notBlank(data.get("sources"))) {
                try {
                    JSONArray arr = new JSONArray(data.get("sources"));
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        SourceConfig sc = new SourceConfig();
                        sc.url = o.optString("url", "");
                        sc.method = o.optString("method", "GET");
                        sc.body = o.optString("body", "");
                        sc.contentType = o.optString("content_type", "json");
                        sc.headers = new HashMap<>();

                        JSONObject headers = o.optJSONObject("headers");
                        if (headers != null) {
                            JSONArray keys = headers.names();
                            if (keys != null) {
                                for (int j = 0; j < keys.length(); j++) {
                                    String hk = keys.getString(j);
                                    sc.headers.put(hk, headers.optString(hk, ""));
                                }
                            }
                        }
                        if (notBlank(sc.url)) p.sources.add(sc);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "sources parse failed", e);
                }
            }

            if (notBlank(data.get("actions"))) {
                try {
                    JSONArray arr = new JSONArray(data.get("actions"));
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        ActionConfig ac = new ActionConfig();
                        ac.title = o.optString("title", "Open");
                        ac.type = o.optString("type", "open_activity");
                        ac.activity = o.optString("activity", "");
                        ac.url = o.optString("url", "");
                        ac.deepLink = o.optString("deep_link", "");
                        String icon = o.optString("icon", "");
                        if (icon.matches("\\d+")) {
                            try { ac.iconRes = Integer.parseInt(icon); } catch (Exception ignored) {}
                        }
                        p.actions.add(ac);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "actions parse failed", e);
                }
            }

            return p;
        }

        private static boolean notBlank(String s) {
            return s != null && !s.trim().isEmpty();
        }
    }

    private static class SourceConfig {
        String url = "";
        String method = "GET";
        String body = "";
        String contentType = "json";
        Map<String, String> headers = new HashMap<>();

        static SourceConfig single(String url, String method) {
            SourceConfig sc = new SourceConfig();
            sc.url = url;
            sc.method = (method == null || method.trim().isEmpty()) ? "GET" : method.trim();
            return sc;
        }
    }

    private static class ActionConfig {
        String title = "Open";
        String type = "open_activity";
        String activity = "";
        String url = "";
        String deepLink = "";
        int iconRes = 0;
    }
}