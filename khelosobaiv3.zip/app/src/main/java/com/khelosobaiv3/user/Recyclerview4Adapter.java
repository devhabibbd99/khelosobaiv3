package com.khelosobaiv3.user;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashMap;

public class Recyclerview4Adapter extends RecyclerView.Adapter<Recyclerview4Adapter.ViewHolder> {
    
    ArrayList<HashMap<String, Object>> _data;
    
    public Recyclerview4Adapter(ArrayList<HashMap<String, Object>> _arr) {
        _data = _arr;
    }
    
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View _v = LayoutInflater.from(parent.getContext()).inflate(R.layout.zabbar_access_match, parent, false);
        return new ViewHolder(_v);
    }
    
    @Override
    public void onBindViewHolder(ViewHolder _holder, final int _position) {
        View _view = _holder.itemView;
        ZabbarAccessMatchBinding binding = ZabbarAccessMatchBinding.bind(_view);
        
        HashMap<String, Object> map = _data.get(_position);
        
        try {
            if (map.containsKey("title") && map.get("title") != null) {
                binding.tvMatchTitle.setText(map.get("title").toString());
            }

            if (map.containsKey("status") && map.get("status") != null) {
                String status = map.get("status").toString();
                binding.tvStatus.setText(status);
                
                String s = status.toLowerCase();
                if (s.contains("live")) {
                    binding.cvStatus.setCardBackgroundColor(Color.parseColor("#E11D48"));   
                } else if (s.contains("open")) {
                    binding.cvStatus.setCardBackgroundColor(Color.parseColor("#10B981"));   
                } else if (s.contains("close")) {
                    binding.cvStatus.setCardBackgroundColor(Color.parseColor("#64748B"));   
                } else if (s.contains("result")) {
                    binding.cvStatus.setCardBackgroundColor(Color.parseColor("#2563EB"));   
                } else {
                    binding.cvStatus.setCardBackgroundColor(Color.parseColor("#0EA5E9"));   
                }
            }

            if (map.containsKey("time") && map.get("time") != null) {
                binding.tvTime.setText(map.get("time").toString());
            }

            if (map.containsKey("fee") && map.get("fee") != null) {
                binding.tvFee.setText("৳ " + map.get("fee").toString().replace(".0", ""));
            }

            if (map.containsKey("refund_amount") && map.get("refund_amount") != null) {
                binding.tvRefundAmount.setText("৳ " + map.get("refund_amount").toString().replace(".0", ""));
            } else {
                binding.tvRefundAmount.setText("৳ 0");
            }

            if (map.containsKey("win_amount") && map.get("win_amount") != null) {
                binding.tvWinAmount.setText("৳ " + map.get("win_amount").toString().replace(".0", ""));
            }

            if (map.containsKey("refund_notice") && map.get("refund_notice") != null && !map.get("refund_notice").toString().equals("") && !map.get("refund_notice").toString().equals("NO")) {
                binding.tvRefundText.setText(map.get("refund_notice").toString());
            } else {
                binding.tvRefundText.setText("If canceled, entry fee will be 100% refunded.");
            }

            if (map.containsKey("notice") && map.get("notice") != null && !map.get("notice").toString().equals("")) {
                binding.tvNoticeText.setText(map.get("notice").toString());
            } else {
                String extra = "";
                if (map.containsKey("entry_type") && map.get("entry_type") != null) extra += "Entry: " + map.get("entry_type").toString() + " ";
                if (map.containsKey("match_type") && map.get("match_type") != null) extra += "Type: " + map.get("match_type").toString() + " ";
                if (map.containsKey("version") && map.get("version") != null) extra += "Version: " + map.get("version").toString() + " ";
                if (map.containsKey("play_map") && map.get("play_map") != null) extra += "Map: " + map.get("play_map").toString() + " ";
                binding.tvNoticeText.setText(extra.trim());
            }
              
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public int getItemCount() {
        return _data.size();
    }
    
    public class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View v) {
            super(v);
        }
    }
}
