package com.khelosobaiv3.user;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class DeviceChecker {
    private static DeviceChecker instance;
    private Context context;
    private Activity activity;

    private DeviceChecker() {}

    public static DeviceChecker getInstance() {
        if (instance == null) {
            instance = new DeviceChecker();
        }
        return instance;
    }

    public void init(Context context) {
        this.context = context;
    }

    public void init(Activity activity, Context context) {
        this.activity = activity;
        this.context = context;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public void checkDevice() {
        if (context == null) return;
        String deviceId = getDeviceId();
        String url = "https://api.khelosobai20.live/ElitegoxUser/check_device.php?device_id=" + deviceId;

        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response != null && response.toLowerCase().contains("banned")) {
                            showBannedAndExit(response);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
        queue.add(stringRequest);
    }

    private String getDeviceId() {
        String deviceId = "";
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
            } else {
                if (telephonyManager != null) {
                    deviceId = telephonyManager.getDeviceId();
                }
            }
        } catch (Exception e) {
            deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        }
        if (deviceId == null || deviceId.isEmpty()) {
            deviceId = "unknown_device";
        }
        return deviceId;
    }

    private void showBannedAndExit(final String message) {
        if (context == null) return;

        if (activity != null && !activity.isFinishing()) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(context, message != null ? message : "Device Banned", Toast.LENGTH_LONG).show();
                    activity.finishAffinity();
                }
            });
        } else {
            android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(context, message != null ? message : "Device Banned", Toast.LENGTH_LONG).show();
                    Process.killProcess(Process.myPid());
                    System.exit(1);
                }
            });
        }
    }
}