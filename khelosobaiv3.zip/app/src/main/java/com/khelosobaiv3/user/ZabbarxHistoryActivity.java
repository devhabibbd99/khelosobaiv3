package com.khelosobaiv3.user;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.FirebaseApp;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ZabbarxHistoryActivity extends AppCompatActivity {

    private final String[] tabTitles = {"Add Money", "Withdrawal", "Join Entry", "Gift", "TopUp", "Products"};
    private ZabbarxHistoryBinding binding;

    private ArrayList<HashMap<String, Object>> addMoneyList = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> withdrawList = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> joinEntryList = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> giftList = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> topUpList = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> productsList = new ArrayList<>();

    // Tab flickering fix: Keep track of inner adapters and layouts to update data without refreshing ViewPager
    private MainRecyclerViewAdapter[] innerAdapters = new MainRecyclerViewAdapter[6];
    private LinearLayout[] emptyLayouts = new LinearLayout[6];
    private RecyclerView[] innerRecyclerViews = new RecyclerView[6];

    private RequestQueue requestQueue;
    private String username = "";
    private String token = "";
    private String baseApiUrl = "https://api.khelosobai20.live/ElitegoxUser/";
    private ViewPagerAdapter adapter;
    private SharedPreferences Save_User_Status;

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = ZabbarxHistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        FirebaseApp.initializeApp(this);
        ZabbarNavigation.INSTANCE.setup(this);

        Save_User_Status = getSharedPreferences("Save_User_Status", Context.MODE_PRIVATE);
        token = Save_User_Status.getString("Token", ""); 
        requestQueue = Volley.newRequestQueue(this);
        
        setupSystemUI();
        setupViewPager();
        fetchUserData();
    }

    private void setupSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            );
        }
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        BlurView blurView = binding.blurView;
        ViewGroup rootView = (ViewGroup) binding.getRoot();
        Drawable windowBackground = rootView.getBackground();
        if (windowBackground == null) windowBackground = new ColorDrawable(Color.parseColor("#DFEAFB"));

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                blurView.setupWith(rootView, new RenderEffectBlur()).setFrameClearDrawable(windowBackground).setBlurRadius(3f).setBlurAutoUpdate(true);
            } else {
                blurView.setupWith(rootView, new RenderScriptBlur(this)).setFrameClearDrawable(windowBackground).setBlurRadius(3f).setBlurAutoUpdate(true);
            }
        } catch (Exception ignored) {}

        binding.appIcon.setOnClickListener(v -> onBackPressed());
    }

    private void setupViewPager() {
        TabLayout tabLayout = binding.tabLayout;
        ViewPager2 viewPager = binding.viewPager;
        adapter = new ViewPagerAdapter();
        viewPager.setAdapter(adapter);
        
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            tab.setText(tabTitles[position]);
        }).attach();
        
        // Prevent ViewPager from refreshing excessively
        viewPager.setOffscreenPageLimit(6);
    }

    private void fetchUserData() {
        String url = baseApiUrl + "XMapp_Us.js.php";
        StringRequest request = new StringRequest(Request.Method.POST, url, response -> {
            try {
                JSONObject jsonResponse = new JSONObject(response);
                if(jsonResponse.has("username")){
                    username = jsonResponse.getString("username");
                    initializeHistoryLogic();
                } else {
                    Toast.makeText(this, "Failed to get user data!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "JSON Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, error -> {
            Toast.makeText(this, "Network Error! Check Internet.", Toast.LENGTH_SHORT).show();
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("type", "1");
                params.put("token", token);
                return params;
            }
        };
        requestQueue.add(request);
    }

    private void initializeHistoryLogic() {
        fetchHistory("addmoney", addMoneyList, 0);
        fetchHistory("withdraw", withdrawList, 1);
        fetchHistory("product", joinEntryList, 2);
        fetchHistory("gift", giftList, 3);
        fetchHistory("topup", topUpList, 4);
        fetchHistory("products", productsList, 5);
    }

    private void fetchHistory(String type, ArrayList<HashMap<String, Object>> targetList, int tabIndex) {
        String url = baseApiUrl + "myhistory.php";
        StringRequest request = new StringRequest(Request.Method.POST, url, response -> {
            try {
                targetList.clear();
                String res = response.trim();
                if (!res.equals("No Data Found") && !res.equals("Invalid Type") && !res.equals("Invalid Request Method") && !res.equals("Invalid Token")) {
                    JSONArray jsonArray = new JSONArray(res);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        HashMap<String, Object> map = new HashMap<>();
                        Iterator<String> keys = obj.keys();
                        while(keys.hasNext()) {
                            String key = keys.next();
                            map.put(key, obj.getString(key));
                        }
                        targetList.add(map);
                    }
                }
            } catch (Exception ignored) {}
            
            // Fix Tab Flickering: Update only the inner RecyclerView, NOT the ViewPager
            if (innerAdapters[tabIndex] != null) {
                innerAdapters[tabIndex].notifyDataSetChanged();
            }
            updateEmptyState(tabIndex);
            
        }, error -> {
            updateEmptyState(tabIndex);
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("type", type);
                params.put("username", username);
                params.put("token", token);
                return params;
            }
        };
        requestQueue.add(request);
    }

    // New Method to manage empty state visibility properly
    private void updateEmptyState(int position) {
        if (emptyLayouts[position] != null && innerRecyclerViews[position] != null) {
            ArrayList<HashMap<String, Object>> currentList;
            if (position == 0) currentList = addMoneyList;
            else if (position == 1) currentList = withdrawList;
            else if (position == 2) currentList = joinEntryList;
            else if (position == 3) currentList = giftList;
            else if (position == 4) currentList = topUpList;
            else currentList = productsList;

            if (currentList.isEmpty()) {
                emptyLayouts[position].setVisibility(View.VISIBLE);
                innerRecyclerViews[position].setVisibility(View.GONE);
            } else {
                emptyLayouts[position].setVisibility(View.GONE);
                innerRecyclerViews[position].setVisibility(View.VISIBLE);
            }
        }
    }

    private int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
    }

    public class ViewPagerAdapter extends RecyclerView.Adapter<ViewPagerAdapter.PageViewHolder> {
        @NonNull
        @Override
        public PageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            FrameLayout frameLayout = new FrameLayout(parent.getContext());
            frameLayout.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            RecyclerView rv = new RecyclerView(parent.getContext());
            rv.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            rv.setClipToPadding(false);
            rv.setClipChildren(false);
            rv.setPadding(0, dpToPx(150), 0, dpToPx(40));

            LinearLayout emptyLayout = new LinearLayout(parent.getContext());
            emptyLayout.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            emptyLayout.setOrientation(LinearLayout.VERTICAL);
            emptyLayout.setGravity(Gravity.CENTER);

            LottieAnimationView lottie = new LottieAnimationView(parent.getContext());
            lottie.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(150), dpToPx(150)));
            lottie.setAnimation("empty_state_topup.json");
            lottie.playAnimation();
            lottie.setRepeatCount(ValueAnimator.INFINITE);

            TextView tvEmpty = new TextView(parent.getContext());
            tvEmpty.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            tvEmpty.setText("No History Found");
            tvEmpty.setTextSize(16f);
            tvEmpty.setTextColor(Color.parseColor("#6B7280"));

            emptyLayout.addView(lottie);
            emptyLayout.addView(tvEmpty);
            emptyLayout.setVisibility(View.GONE);

            frameLayout.addView(rv);
            frameLayout.addView(emptyLayout);

            return new PageViewHolder(frameLayout, rv, emptyLayout);
        }

        @Override
        public void onBindViewHolder(@NonNull PageViewHolder holder, int position) {
            holder.recyclerView.setLayoutManager(new LinearLayoutManager(holder.itemView.getContext()));
            ArrayList<HashMap<String, Object>> currentList;

            if (position == 0) currentList = addMoneyList;
            else if (position == 1) currentList = withdrawList;
            else if (position == 2) currentList = joinEntryList;
            else if (position == 3) currentList = giftList;
            else if (position == 4) currentList = topUpList;
            else currentList = productsList;

            MainRecyclerViewAdapter innerAdapter = new MainRecyclerViewAdapter(currentList, position);
            holder.recyclerView.setAdapter(innerAdapter);
            
            // Save references for data updating to prevent ViewPager reload
            innerAdapters[position] = innerAdapter;
            emptyLayouts[position] = holder.emptyLayout;
            innerRecyclerViews[position] = holder.recyclerView;

            updateEmptyState(position);
        }

        @Override
        public int getItemCount() {
            return tabTitles.length;
        }

        class PageViewHolder extends RecyclerView.ViewHolder {
            RecyclerView recyclerView;
            LinearLayout emptyLayout;
            PageViewHolder(@NonNull View itemView, RecyclerView rv, LinearLayout el) {
                super(itemView);
                recyclerView = rv;
                emptyLayout = el;
            }
        }
    }

    public class MainRecyclerViewAdapter extends RecyclerView.Adapter<MainRecyclerViewAdapter.ViewHolder> {
        ArrayList<HashMap<String, Object>> _data;
        int tabPosition;

        public MainRecyclerViewAdapter(ArrayList<HashMap<String, Object>> _arr, int tabPos) {
            _data = _arr;
            tabPosition = tabPos;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View _v = LayoutInflater.from(parent.getContext()).inflate(R.layout.zabbar_history, parent, false);
            return new ViewHolder(_v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder _holder, final int _position) {
            try {
                HashMap<String, Object> map = _data.get(_position);
                String valTitle = str(map, "method", str(map, "match_title", str(map, "product_title", str(map, "gift_name", str(map, "title", "Transaction")))));
                String valAmount = str(map, "amount", str(map, "price", str(map, "coin", "0")));
                String valStatus = str(map, "status", "Completed");
                String valTime = str(map, "date", str(map, "time", str(map, "created_at", "N/A")));
                String tabName = tabTitles[tabPosition];

                // Fix: Remove `(type)` or `(...)` from Join Entry (tabPosition 2)
                if (tabPosition == 2) {
                    valTitle = valTitle.replaceAll("\\(.*?\\)", "").trim(); 
                    if (valTitle.isEmpty()) {
                        valTitle = "Match Entry"; 
                    }
                }

                if (map.containsKey("receiver_uid") && map.containsKey("gift_name")) {
                    valTitle = map.get("gift_name").toString();
                    valAmount = "UID: " + map.get("receiver_uid").toString();
                } else if (!valAmount.contains("UID") && !valAmount.contains("Receiver")) {
                    if (tabPosition == 0 || tabPosition == 3) {
                        valAmount = "+৳" + valAmount;
                    } else {
                        valAmount = "-৳" + valAmount;
                    }
                }

                TextView tvTitle = _holder.itemView.findViewById(R.id.tvTitle);
                TextView tvType = _holder.itemView.findViewById(R.id.tvType);
                TextView tvAmount = _holder.itemView.findViewById(R.id.tvAmount);
                TextView tvStatus = _holder.itemView.findViewById(R.id.tvStatus);
                ImageView ivIcon = _holder.itemView.findViewById(R.id.ivTransactionIcon);
                MaterialCardView statusContainer = _holder.itemView.findViewById(R.id.statusContainer);
                MaterialCardView iconContainer = _holder.itemView.findViewById(R.id.iconContainer);

                if (tvTitle != null) tvTitle.setText(valTitle);
                if (tvType != null) tvType.setText(valTime + " • " + tabName);
                if (tvAmount != null) tvAmount.setText(valAmount);

                if (tvStatus != null && statusContainer != null) {
                    tvStatus.setText(valStatus.substring(0, 1).toUpperCase() + valStatus.substring(1).toLowerCase());
                    String s = valStatus.toLowerCase();
                    if (s.contains("success") || s.contains("approved") || s.contains("completed")) {
                        tvStatus.setTextColor(Color.parseColor("#10B981"));
                        statusContainer.setCardBackgroundColor(Color.parseColor("#D1FAE5"));
                        statusContainer.setStrokeColor(Color.parseColor("#A7F3D0"));
                    } else if (s.contains("pending") || s.contains("processing")) {
                        tvStatus.setTextColor(Color.parseColor("#F59E0B"));
                        statusContainer.setCardBackgroundColor(Color.parseColor("#FEF3C7"));
                        statusContainer.setStrokeColor(Color.parseColor("#FDE68A"));
                    } else {
                        tvStatus.setTextColor(Color.parseColor("#EF4444"));
                        statusContainer.setCardBackgroundColor(Color.parseColor("#FEE2E2"));
                        statusContainer.setStrokeColor(Color.parseColor("#FECACA"));
                    }
                }

                if (ivIcon != null && iconContainer != null) {
                    int iconTintColor;
                    if (tabPosition == 0) {
                        iconContainer.setCardBackgroundColor(Color.parseColor("#D1FAE5"));
                        iconTintColor = Color.parseColor("#10B981");
                    } else if (tabPosition == 1) {
                        iconContainer.setCardBackgroundColor(Color.parseColor("#FEE2E2"));
                        iconTintColor = Color.parseColor("#EF4444");
                    } else {
                        iconContainer.setCardBackgroundColor(Color.parseColor("#DBEAFE"));
                        iconTintColor = Color.parseColor("#3B82F6");
                    }
                    ivIcon.setImageDrawable(new JavaCanvasIconDrawable(tabPosition, iconTintColor));
                }
            } catch (Exception ignored) {}
        }

        private String str(HashMap<String, Object> map, String key, String fallback) {
            if (map.containsKey(key) && map.get(key) != null && !map.get(key).toString().isEmpty()) {
                return map.get(key).toString();
            }
            return fallback;
        }

        @Override
        public int getItemCount() {
            return _data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ViewHolder(View v) { super(v); }
        }
    }

    public class JavaCanvasIconDrawable extends Drawable {
        private final int iconType;
        private final Paint paint;

        public JavaCanvasIconDrawable(int iconType, int color) {
            this.iconType = iconType;
            paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(5f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override
        public void draw(@NonNull Canvas canvas) {
            int width = getBounds().width();
            int height = getBounds().height();
            float centerX = width / 2f;
            float centerY = height / 2f;
            Path path = new Path();

            switch (iconType) {
                case 0:
                    paint.setStyle(Paint.Style.STROKE);
                    canvas.drawRoundRect(new RectF(10, 20, width - 10, height - 20), 10, 10, paint);
                    canvas.drawLine(centerX - 15, centerY, centerX + 15, centerY, paint);
                    canvas.drawLine(centerX, centerY - 15, centerX, centerY + 15, paint);
                    break;
                case 1:
                    paint.setStyle(Paint.Style.STROKE);
                    canvas.drawRoundRect(new RectF(15, 15, width - 15, height - 15), 15, 15, paint);
                    canvas.drawLine(centerX, centerY + 15, centerX, centerY - 15, paint);
                    canvas.drawLine(centerX, centerY - 15, centerX - 10, centerY - 5, paint);
                    canvas.drawLine(centerX, centerY - 15, centerX + 10, centerY - 5, paint);
                    break;
                case 2:
                    paint.setStyle(Paint.Style.STROKE);
                    canvas.drawRoundRect(new RectF(5, 25, width - 5, height - 25), 20, 20, paint);
                    canvas.drawLine(25, centerY, 45, centerY, paint);
                    canvas.drawLine(35, centerY - 10, 35, centerY + 10, paint);
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(width - 30, centerY + 5, 4, paint);
                    canvas.drawCircle(width - 45, centerY - 5, 4, paint);
                    break;
                case 3:
                    paint.setStyle(Paint.Style.STROKE);
                    canvas.drawRect(new RectF(15, 30, width - 15, height - 15), paint);
                    canvas.drawRect(new RectF(10, 15, width - 10, 30), paint);
                    canvas.drawLine(centerX, 15, centerX, height - 15, paint);
                    canvas.drawLine(15, centerY + 5, width - 15, centerY + 5, paint);
                    path.moveTo(centerX, 15);
                    path.quadTo(centerX - 15, 0, centerX, 15);
                    path.moveTo(centerX, 15);
                    path.quadTo(centerX + 15, 0, centerX, 15);
                    canvas.drawPath(path, paint);
                    break;
                case 4:
                    paint.setStyle(Paint.Style.FILL_AND_STROKE);
                    path.moveTo(centerX + 10, 10);
                    path.lineTo(centerX - 15, centerY + 5);
                    path.lineTo(centerX + 5, centerY + 5);
                    path.lineTo(centerX - 10, height - 10);
                    path.lineTo(centerX + 15, centerY - 5);
                    path.lineTo(centerX - 5, centerY - 5);
                    path.close();
                    canvas.drawPath(path, paint);
                    break;
                case 5:
                    paint.setStyle(Paint.Style.STROKE);
                    canvas.drawRoundRect(new RectF(15, 30, width - 15, height - 10), 5, 5, paint);
                    path.moveTo(centerX - 15, 30);
                    path.quadTo(centerX, 5, centerX + 15, 30);
                    canvas.drawPath(path, paint);
                    break;
            }
        }
        @Override
        public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override
        public void setColorFilter(@Nullable ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override
        public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
