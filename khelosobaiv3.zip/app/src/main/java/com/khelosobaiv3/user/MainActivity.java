package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.*;
import com.google.firebase.messaging.FirebaseMessaging;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private MainBinding binding;
	private String a = "";
	private String failReason = "";
	private String status = "";
	private HashMap<String, Object> app_info_zabbar = new HashMap<>();
	private String home_notice = "";
	private String Key = "";
	private HashMap<String, Object> fjf = new HashMap<>();
	
	private Intent changes_activity_zabbar = new Intent();
	private SharedPreferences zabbar_sg;
	private TimerTask zabbar_time;
	private RequestNetwork WiFi;
	private RequestNetwork.RequestListener _WiFi_request_listener;
	private SharedPreferences Api;
	private TimerTask SHUVO_LOADING;
	private SharedPreferences Save_User_Status;
	private Intent shuvobro = new Intent();
	
	private OnCompleteListener PowerBy_Zabbar_Superbad_onCompleteListener;
	private RequestNetwork Zabbar_AppInfo;
	private RequestNetwork.RequestListener _Zabbar_AppInfo_request_listener;
	private RequestNetwork ckdevice;
	private RequestNetwork.RequestListener _ckdevice_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		zabbar_sg = getSharedPreferences("zabbar_sg", Activity.MODE_PRIVATE);
		WiFi = new RequestNetwork(this);
		Api = getSharedPreferences("Api", Activity.MODE_PRIVATE);
		Save_User_Status = getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE);
		Zabbar_AppInfo = new RequestNetwork(this);
		ckdevice = new RequestNetwork(this);
		
		_WiFi_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				SHUVO_LOADING = new TimerTask() {
					    @Override
					    public void run() {
						        runOnUiThread(new Runnable() {
							            @Override
							            public void run() {
								                Api.edit().putString("Api", "https://api.khelosobai20.live/".concat("ElitegoxUser/")).commit();
								                if (Save_User_Status.getString("Logged", "").equals("True")) {
									                    FirebaseMessaging.getInstance().subscribeToTopic("ttt");   // <-- এইখানে
									
									                    shuvobro.putExtra("notice", home_notice);
									                    shuvobro.setClass(getApplicationContext(), ZabbarHomeActivity.class);
									                    startActivity(shuvobro);
									                    finish();
									                } else {
									                    shuvobro.putExtra("notice", home_notice);
									                    shuvobro.setClass(getApplicationContext(), ZabbarSignupActivity.class);
									                    startActivity(shuvobro);
									                }
								            }
							        });
						    }
				};
				_timer.schedule(SHUVO_LOADING, (int)(SketchwareUtil.getRandom((int)(1000), (int)(1500))));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Zabbar_AppInfo_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					    app_info_zabbar = new Gson().fromJson(
					            _response,
					            new TypeToken<HashMap<String, Object>>() {}.getType()
					    );
					
					    String versionCode = app_info_zabbar.get("version_code") == null
					            ? ""
					            : app_info_zabbar.get("version_code").toString();
					
					    String appStatus = app_info_zabbar.get("application_status") == null
					            ? ""
					            : app_info_zabbar.get("application_status").toString();
					
					    String closedReason = app_info_zabbar.get("closed_reason") == null
					            ? ""
					            : app_info_zabbar.get("closed_reason").toString();
					
					    home_notice = app_info_zabbar.get("home_notice") == null
					            ? ""
					            : app_info_zabbar.get("home_notice").toString();
					
					    String currentVersion;
					
					    try {
						        currentVersion = getPackageManager()
						                .getPackageInfo(getPackageName(), 0)
						                .versionName;
						    } catch (PackageManager.NameNotFoundException e) {
						        currentVersion = "0";
						    }
					
					    boolean isUpdateRequired =
					            !versionCode.isEmpty()
					                    && !currentVersion.isEmpty()
					                    && compareVersions(currentVersion, versionCode);
					
					    if (!appStatus.equalsIgnoreCase("ON")
					            && !appStatus.equalsIgnoreCase("Open")) {
						
						        new PremiumDialog.Builder(MainActivity.this)
						                .setDialogType(true)
						                .setCancelable(false)
						                .setBlurBackground(true)
						                .setLottie("Appmaintenancemode.json")
						                .setTitle("Application Closed")
						                .setMessage(
						                        closedReason.isEmpty()
						                                ? "Application is currently under maintenance.\nPlease try again later."
						                                : closedReason
						                )
						                .setNegativeButton(
						                        "Exit",
						                        dialog -> {
							                            dialog.dismiss();
							                            finish();
							                        }
						                )
						                .setPositiveButton(
						                        "OK",
						                        "#004F50",
						                        dialog -> {
							                            dialog.dismiss();
							                            finish();
							                        }
						                )
						                .show();
						
						        return;
						    }
					
					    if (isUpdateRequired) {
						        startActivity(
						                new Intent(
						                        MainActivity.this,
						                        ZabbarUpdateActivity.class
						                )
						        );
						
						        finish();
						        return;
						    }
					
					    WiFi.startRequestNetwork(
					            RequestNetworkController.GET,
					            "https://api.khelosobai20.live",
					            "",
					            _WiFi_request_listener
					    );
					
				} catch (Exception e) {
					    new PremiumDialog.Builder(MainActivity.this)
					            .setDialogType(true)
					            .setCancelable(true)
					            .setBlurBackground(true)
					            .setLottie("error.json")
					            .setTitle("Something Went Wrong")
					            .setMessage(
					                    e.getMessage() == null
					                            ? "Unknown Error"
					                            : e.getMessage()
					            )
					            .setPositiveButton(
					                    "OK",
					                    "#D32F2F",
					                    dialog -> dialog.dismiss()
					            )
					            .show();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				new PremiumDialog.Builder(MainActivity.this)
				        .setLottie("warning.json")
				        .setTitle("No Internet Connection")
				        .setMessage("Please check your internet connection and try again.")
				        .setCancelable(false)
				        .setPositiveButton("Retry", "#004F50", dialog -> {
					            dialog.dismiss();
					            
					Zabbar_AppInfo.startRequestNetwork(RequestNetworkController.GET, "https://api.khelosobai20.live/ElitegoxUser/appinfo.php", "", _Zabbar_AppInfo_request_listener);
					        })
				        .setNegativeButton("Close", dialog -> {
					            dialog.dismiss();
					            finish();
					        })
				        .show();
			}
		};
		
		_ckdevice_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.contains("banned")) {
					SketchwareUtil.showMessage(getApplicationContext(), _response);
					finishAffinity();
				} else {
					Zabbar_AppInfo.startRequestNetwork(RequestNetworkController.GET, "https://api.khelosobai20.live/ElitegoxUser/appinfo.php", "", _Zabbar_AppInfo_request_listener);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// নোটিফিকেশন পারমিশন চেক ও রিকোয়েস্ট করার কোড
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
			    if (androidx.core.content.ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
				        androidx.core.app.ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
				    }
		}
		
		SecurityChecker.check(this);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			    getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			    getWindow().setStatusBarColor(Color.TRANSPARENT);
			    getWindow().setNavigationBarColor(Color.TRANSPARENT);
			    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
			    getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			    getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION, WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
		}
		Key = android.provider.Settings.Secure.getString(getApplicationContext().getContentResolver(),android.provider.Settings.Secure.ANDROID_ID);
		ckdevice.startRequestNetwork(RequestNetworkController.GET, "https://api.khelosobai20.live/ElitegoxUser/check_device.php?device_id=".concat(Key), "", _ckdevice_request_listener);
	}
	
	public void _Zabbar_Methods() {
	}
	private boolean compareVersions(String current, String server) {
		    String[] currParts = current.split("\\.");
		    String[] servParts = server.split("\\.");
		    int maxLength = Math.max(currParts.length, servParts.length);
		    for (int i = 0; i < maxLength; i++) {
			        int currVal = i < currParts.length ? Integer.parseInt(currParts[i]) : 0;
			        int servVal = i < servParts.length ? Integer.parseInt(servParts[i]) : 0;
			        if (servVal > currVal) return true;
			        if (servVal < currVal) return false;
			    }
		    return false;
	}
	{
	}
	
}