package com.khelosobaiv3.user;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ShvuoRulesActivity extends AppCompatActivity {

    private TextView tabMatch, tabRules, labelStartsIn, txtTotalTeams, slotsCountText, prizePoolTotal;
    private TextView textview260, textview261, textview263, textview265, textview267, tvDays, tvHours, tvMinutes, tvSeconds;
    private View layoutJoinersContainer, layoutRules;
    private LinearLayout layoutJoinersList, linear84, timerContainer;
    private ProgressBar progressPlayers;
    private ScrollView dynamicRulesScroll;
    private boolean showIncome = false;
    private boolean isJoined = false;
    private int totalTournamentSlots = 48;
    private String matchId = "", matchType = "", matchTimeStr = "";
    private SharedPreferences ApiPrefs, Save_User_Status;
    private CountDownTimer countDownTimer;

    public static class NetworkPlayer {
        String id, name, winning, totalKill, teamColor;
        int isLeader;
        int slot;
        boolean isOwner;
        public NetworkPlayer(String id, String name, String winning, String totalKill, int isLeader, boolean isOwner, int slot) {
            this.id = id; this.name = name; this.winning = winning; this.totalKill = totalKill;
            this.isLeader = isLeader; this.isOwner = isOwner; this.slot = slot;
        }
    }

    public static class NetworkTeam {
        String teamName, teamColor;
        List<NetworkPlayer> players;
        public NetworkTeam(String teamName, String teamColor, List<NetworkPlayer> players) {
            this.teamName = teamName; this.teamColor = teamColor; this.players = players;
        }
    }

    private interface NetCallback { void onRes(String res); void onErr(); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getSupportActionBar() != null) getSupportActionBar().hide();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
        setContentView(R.layout.shvuo_rules);

        ApiPrefs = getSharedPreferences("Api", MODE_PRIVATE);
        Save_User_Status = getSharedPreferences("Save_User_Status", MODE_PRIVATE);

        matchId = getIntent().getStringExtra("Id");
        matchType = getIntent().getStringExtra("EntryType");
        String title = getIntent().getStringExtra("Title");
        String entryFee = getIntent().getStringExtra("EntryFee");
        String perKill = getIntent().getStringExtra("PerKill");
        String totalPrize = getIntent().getStringExtra("TotalPrize");
        String totalPlayer = getIntent().getStringExtra("TotalPlayer");
        String onExtra = getIntent().getStringExtra("onExtra");
        String matchCategory = getIntent().getStringExtra("match_type");
        String imageLink = getIntent().getStringExtra("image_link");
        isJoined = getIntent().getBooleanExtra("isJoined", false);

        if (matchCategory == null || matchCategory.isEmpty()) matchCategory = "BR Match";

        String timeData = getIntent().getStringExtra("Time");
        if (timeData == null || timeData.isEmpty()) timeData = getIntent().getStringExtra("timer");
        if (timeData == null || timeData.isEmpty()) timeData = getIntent().getStringExtra("match_time");
        matchTimeStr = timeData != null ? timeData : "";
        showIncome = onExtra != null && onExtra.equalsIgnoreCase("Result");

        try {
            if (totalPlayer != null && !totalPlayer.isEmpty()) totalTournamentSlots = Integer.parseInt(totalPlayer.trim());
        } catch (Exception e) { totalTournamentSlots = 48; }

        setupHeaderImage(findViewById(R.id.header_layout), imageLink);

        ImageView btnBack = findViewById(R.id.btn_back);
        TextView tagBrMatch = findViewById(R.id.tag_br_match), tagBermuda = findViewById(R.id.tag_bermuda), tagSolo = findViewById(R.id.tag_solo);
        labelStartsIn = findViewById(R.id.label_starts_in);
        linear84 = findViewById(R.id.linear84);
        textview260 = findViewById(R.id.textview260); textview261 = findViewById(R.id.textview261);
        textview263 = findViewById(R.id.textview263); textview265 = findViewById(R.id.textview265);
        textview267 = findViewById(R.id.textview267); prizePoolTotal = findViewById(R.id.prize_pool_total);
        tabMatch = findViewById(R.id.tab_match); tabRules = findViewById(R.id.tab_rules);
        layoutJoinersContainer = findViewById(R.id.layout_joiners_container); layoutJoinersList = findViewById(R.id.layout_joiners_list);
        layoutRules = findViewById(R.id.layout_rules_and_prizes); txtTotalTeams = findViewById(R.id.txt_total_teams);
        progressPlayers = findViewById(R.id.progress_players); slotsCountText = findViewById(R.id.slots_count_text);

        textview260.setText(title != null ? title : ""); 
        textview260.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        textview261.setText((entryFee != null ? entryFee : "0") + " BDT");
        textview263.setText((perKill != null ? perKill : "0") + " BDT"); 
        textview265.setText((totalPrize != null ? totalPrize : "0") + " BDT");
        textview267.setText(matchType != null ? matchType : "Squad"); 
        prizePoolTotal.setText((totalPrize != null ? totalPrize : "0") + " BDT Total");
        tagSolo.setText(matchType != null ? matchType.toUpperCase() : "SQUAD");

        btnBack.setBackground(createPillDrawable("#4D000000", 50, "#66FFFFFF"));
        btnBack.setImageDrawable(getSizedIcon("arrow_back", Color.WHITE, 24));
        btnBack.setOnClickListener(v -> finish());

        setupTag(tagBrMatch, "gamepad"); 
        setupTag(tagBermuda, "location"); 
        setupTag(tagSolo, "users");
        slotsCountText.setCompoundDrawables(getSizedIcon("users", Color.parseColor("#334155"), 16), null, null, null);

        GradientDrawable gridItemBg = createPillDrawable("#FFFFFF", 24, null);
        findViewById(R.id.grid_card1).setBackground(gridItemBg); findViewById(R.id.grid_card2).setBackground(gridItemBg);
        findViewById(R.id.grid_card3).setBackground(gridItemBg); findViewById(R.id.grid_card4).setBackground(gridItemBg);

        ((ImageView) findViewById(R.id.img_wallet)).setImageDrawable(getSizedIcon("wallet", Color.parseColor("#4F46E5"), 40));
        ((ImageView) findViewById(R.id.img_skull)).setImageDrawable(getSizedIcon("skull", Color.parseColor("#E11D48"), 40));
        ((ImageView) findViewById(R.id.img_trophy)).setImageDrawable(getSizedIcon("trophy", Color.parseColor("#D97706"), 40));
        ((ImageView) findViewById(R.id.img_users)).setImageDrawable(getSizedIcon("users", Color.parseColor("#059669"), 40));

        findViewById(R.id.tab_container).setBackground(createPillDrawable("#E2E8F0", 50, null));
        tabMatch.setOnClickListener(v -> switchTab(true)); tabRules.setOnClickListener(v -> switchTab(false));

        txtTotalTeams.setBackground(createPillDrawable("#EEF2FF", 50, null)); txtTotalTeams.setTextColor(Color.parseColor("#4F46E5"));
        ImageView imgTeamsHeaderIcon = findViewById(R.id.img_teams_header_icon);
        imgTeamsHeaderIcon.setBackground(createPillDrawable("#4F46E5", 12, null));
        imgTeamsHeaderIcon.setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(8));
        imgTeamsHeaderIcon.setImageDrawable(getSizedIcon("users", Color.WHITE, 20));

        TextView labelMatchRules = findViewById(R.id.label_match_rules), labelPrizeBreakdown = findViewById(R.id.label_prize_breakdown);
        if (labelMatchRules != null) labelMatchRules.setCompoundDrawables(getSizedIcon("document", Color.parseColor("#0F172A"), 18), null, null, null);
        if (labelPrizeBreakdown != null) labelPrizeBreakdown.setCompoundDrawables(getSizedIcon("crown", Color.parseColor("#0F172A"), 20), null, null, null);

        prizePoolTotal.setBackground(createPillDrawable("#FEF3C7", 12, null)); prizePoolTotal.setTextColor(Color.parseColor("#D97706"));
        prizePoolTotal.setCompoundDrawables(getSizedIcon("coin", Color.parseColor("#D97706"), 16), null, null, null);

        setupTimerUI();
        if (showIncome) {
            timerContainer.setVisibility(View.GONE); linear84.setVisibility(View.GONE); labelStartsIn.setVisibility(View.GONE);
        } else {
            labelStartsIn.setText("MATCH STARTS IN"); labelStartsIn.setCompoundDrawables(getSizedIcon("timer", Color.parseColor("#64748B"), 14), null, null, null);
            labelStartsIn.setVisibility(View.VISIBLE); timerContainer.setVisibility(View.VISIBLE); linear84.setVisibility(View.VISIBLE);
            startCountdown();
        }
        switchTab(true); fetchDataFromServer(); fetchRulesFromServer(matchCategory);
    }

    private void setupTag(TextView tag, String icon) {
        tag.setTextColor(Color.WHITE);
        tag.setCompoundDrawables(getSizedIcon(icon, Color.WHITE, 12), null, null, null);
        tag.setCompoundDrawablePadding(dpToPx(6));
        tag.setPadding(dpToPx(12), dpToPx(6), dpToPx(12), dpToPx(6));

        ViewGroup parent = (ViewGroup) tag.getParent();
        if (parent != null && !(parent instanceof BlurView)) {
            int index = parent.indexOfChild(tag);
            ViewGroup.LayoutParams params = tag.getLayoutParams();
            parent.removeView(tag);

            BlurView blurView = new BlurView(this);
            blurView.setLayoutParams(params);

            View decorView = getWindow().getDecorView();
            ViewGroup rootView = decorView.findViewById(android.R.id.content);
            Drawable windowBackground = decorView.getBackground();

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    blurView.setupWith(rootView, new RenderEffectBlur())
                            .setFrameClearDrawable(windowBackground)
                            .setBlurRadius(10f);
                } else {
                    blurView.setupWith(rootView, new RenderScriptBlur(this))
                            .setFrameClearDrawable(windowBackground)
                            .setBlurRadius(10f);
                }
            } catch (Exception ignored) {}

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                blurView.setOutlineProvider(new ViewOutlineProvider() {
                    @Override
                    public void getOutline(View view, Outline outline) {
                        outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dpToPx(8));
                    }
                });
                blurView.setClipToOutline(true);
            }
            blurView.setBackground(createPillDrawable("#4D000000", 8, "#66FFFFFF"));

            tag.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            tag.setBackground(null);

            blurView.addView(tag);
            parent.addView(blurView, index);
        } else if (parent == null) {
            tag.setBackground(createPillDrawable("#4D000000", 8, "#66FFFFFF"));
        }
    }

    private void postRequest(String url, String postData, NetCallback callback) {
        new Thread(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setDoOutput(true);
                try (OutputStream os = conn.getOutputStream()) { os.write(postData.getBytes("UTF-8")); }
                int code = conn.getResponseCode();
                InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                if (is == null) return;
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                String res = sb.toString().trim();
                runOnUiThread(() -> callback.onRes(res));
            } catch (Exception e) { runOnUiThread(callback::onErr); }
        }).start();
    }

    private void fetchRulesFromServer(String category) {
        try {
            String targetUrl = ApiPrefs.getString("Api", "https://api.khelosobai20.live/ElitegoxUser/") + "match_rule_get.php";
            postRequest(targetUrl, "match_type=" + URLEncoder.encode(category, "UTF-8"), new NetCallback() {
                public void onRes(String res) {
                    try {
                        JSONObject obj = new JSONObject(res);
                        displayRules(obj.optBoolean("status") ? obj.optString("rules", "No rules available.") : "Rules not found for this match type.");
                    } catch (Exception e) { displayRules("Error loading rules data."); }
                }
                public void onErr() { displayRules("Failed to load rules."); }
            });
        } catch (Exception ignored) {}
    }

    private void displayRules(String rulesText) {
        if (layoutRules == null) return;
        if (dynamicRulesScroll == null) {
            ViewGroup parent = (ViewGroup) layoutRules.getParent();
            int index = parent.indexOfChild(layoutRules);
            layoutRules.setVisibility(View.GONE);
            dynamicRulesScroll = new ScrollView(this);
            dynamicRulesScroll.setLayoutParams(layoutRules.getLayoutParams());
            dynamicRulesScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
            dynamicRulesScroll.setVisibility(layoutRules.getVisibility());
            LinearLayout container = new LinearLayout(this);
            container.setOrientation(LinearLayout.VERTICAL);
            container.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
            TextView title = new TextView(this);
            title.setText("Match Rules"); title.setTypeface(null, Typeface.BOLD); title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            title.setTextColor(Color.parseColor("#0F172A")); title.setCompoundDrawables(getSizedIcon("document", Color.parseColor("#0F172A"), 18), null, null, null);
            title.setCompoundDrawablePadding(dpToPx(8)); title.setPadding(0, 0, 0, dpToPx(16));
            container.addView(title);
            TextView tvRules = new TextView(this);
            tvRules.setText(rulesText); tvRules.setTextColor(Color.parseColor("#334155"));
            tvRules.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14); tvRules.setLineSpacing(dpToPx(6), 1.2f);
            container.addView(tvRules); dynamicRulesScroll.addView(container);
            parent.addView(dynamicRulesScroll, index); layoutRules = dynamicRulesScroll;
        } else {
            LinearLayout container = (LinearLayout) dynamicRulesScroll.getChildAt(0);
            if (container.getChildCount() > 1) ((TextView) container.getChildAt(1)).setText(rulesText);
        }
    }

    private void loadNativeImage(String urlString, ImageView imageView, ProgressBar progressBar) {
        if (urlString == null || urlString.trim().isEmpty()) {
            if (progressBar != null) progressBar.setVisibility(View.GONE);
            return;
        }

        new Thread(() -> {
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.connect();
                
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream input = connection.getInputStream();
                    final Bitmap myBitmap = BitmapFactory.decodeStream(input);
                    input.close();
                    
                    runOnUiThread(() -> {
                        if (myBitmap != null) {
                            imageView.setImageBitmap(myBitmap);
                        }
                        if (progressBar != null) {
                            progressBar.setVisibility(View.GONE);
                        }
                    });
                } else {
                    runOnUiThread(() -> {
                        if (progressBar != null) progressBar.setVisibility(View.GONE);
                    });
                }
                connection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    if (progressBar != null) progressBar.setVisibility(View.GONE);
                });
            }
        }).start();
    }

    private void setupHeaderImage(RelativeLayout headerLayout, String imgUrl) {
        int statusBarHeight = 0, resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resId > 0) statusBarHeight = getResources().getDimensionPixelSize(resId);
        List<View> existingChildren = new ArrayList<>();
        for (int i = 0; i < headerLayout.getChildCount(); i++) existingChildren.add(headerLayout.getChildAt(i));
        headerLayout.removeAllViews(); headerLayout.setBackground(null);
        
        ImageView headerImageView = new ImageView(this);
        headerImageView.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        headerImageView.setScaleType(ImageView.ScaleType.CENTER_CROP); 
        headerImageView.setBackgroundColor(Color.parseColor("#1E293B"));
        headerLayout.addView(headerImageView); 
        
        View gradientOverlay = new View(this);
        gradientOverlay.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        GradientDrawable gradientDrawable = new GradientDrawable(
                GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xCC000000, 0x66000000, 0x00000000}
        );
        gradientOverlay.setBackground(gradientDrawable);
        headerLayout.addView(gradientOverlay);
        
        ProgressBar progressBar = new ProgressBar(this);
        progressBar.getIndeterminateDrawable().setColorFilter(Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN);
        RelativeLayout.LayoutParams progressParams = new RelativeLayout.LayoutParams(dpToPx(40), dpToPx(40));
        progressParams.addRule(RelativeLayout.CENTER_IN_PARENT); 
        progressBar.setLayoutParams(progressParams);
        headerLayout.addView(progressBar);
        
        RelativeLayout contentContainer = new RelativeLayout(this);
        contentContainer.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        contentContainer.setPadding(0, statusBarHeight, 0, 0);
        for (View child : existingChildren) contentContainer.addView(child);
        headerLayout.addView(contentContainer);
        
        loadNativeImage(imgUrl, headerImageView, progressBar);
    }

    private void setupTimerUI() {
        TextView oldTimer = findViewById(R.id.textview1198);
        ViewGroup parent = (ViewGroup) oldTimer.getParent();
        int index = parent.indexOfChild(oldTimer); parent.removeView(oldTimer);
        timerContainer = new LinearLayout(this);
        timerContainer.setOrientation(LinearLayout.HORIZONTAL); timerContainer.setGravity(Gravity.CENTER_VERTICAL);
        timerContainer.setLayoutParams(oldTimer.getLayoutParams());
        tvDays = createTimeTextView(); tvHours = createTimeTextView(); tvMinutes = createTimeTextView(); tvSeconds = createTimeTextView();
        timerContainer.addView(tvDays); timerContainer.addView(tvHours); timerContainer.addView(tvMinutes); timerContainer.addView(tvSeconds);
        parent.addView(timerContainer, index);
    }

    private TextView createTimeTextView() {
        TextView t = new TextView(this);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28); t.setTypeface(null, Typeface.BOLD);
        t.setTextColor(Color.parseColor("#F59E0B")); t.setPadding(0, 0, dpToPx(4), 0); return t;
    }

    private long parseDateToMillis(String rawStr) {
        if (rawStr == null || rawStr.isEmpty()) return 0;
        String cleanStr = rawStr.replaceAll("(?i)(timer|time|start\\s*in\\s*time)\\s*:", "").replaceAll("(?i)\\bat\\b", "").replaceAll("\\s+", " ").trim().replace("-", "/");
        String[] patterns = {"dd/MM/yyyy hh:mm a", "dd/MM/yyyy HH:mm:ss", "yyyy/MM/dd HH:mm:ss", "dd/MM/yyyy HH:mm"};
        for (String pattern : patterns) {
            try { Date d = new SimpleDateFormat(pattern, Locale.ENGLISH).parse(cleanStr); if (d != null) return d.getTime(); } catch (Exception ignored) {}
        }
        try { return Long.parseLong(rawStr.trim()); } catch (Exception ignored) {}
        return 0;
    }

    private void startCountdown() {
        if (countDownTimer != null) countDownTimer.cancel();
        long timeToWait = parseDateToMillis(matchTimeStr) - System.currentTimeMillis();
        if (timeToWait <= 0) {
            tvDays.setVisibility(View.GONE); tvHours.setVisibility(View.GONE); tvMinutes.setVisibility(View.GONE); tvSeconds.setText("Timer Expired"); return;
        }
        countDownTimer = new CountDownTimer(timeToWait, 1000) {
            public void onTick(long m) {
                long d = m / 86400000, h = (m % 86400000) / 3600000, min = (m % 3600000) / 60000, s = (m % 60000) / 1000;
                tvDays.setVisibility(d > 0 ? View.VISIBLE : View.GONE); if (d > 0) tvDays.setText(String.format(Locale.ENGLISH, "%02dd ", d));
                tvHours.setVisibility((h > 0 || d > 0) ? View.VISIBLE : View.GONE); if (h > 0 || d > 0) tvHours.setText(String.format(Locale.ENGLISH, "%02dh ", h));
                tvMinutes.setVisibility(View.VISIBLE); tvMinutes.setText(String.format(Locale.ENGLISH, "%02dm ", min));
                tvSeconds.setText(String.format(Locale.ENGLISH, "%02ds", s));
            }
            public void onFinish() {
                tvDays.setVisibility(View.GONE); tvHours.setVisibility(View.GONE); tvMinutes.setVisibility(View.GONE); tvSeconds.setText("Timer Expired");
            }
        }.start();
    }

    @Override protected void onDestroy() { super.onDestroy(); if (countDownTimer != null) countDownTimer.cancel(); }

    private void switchTab(boolean showJoiners) {
        if (showIncome) {
            tabMatch.setText("Results"); tabRules.setVisibility(View.GONE);
            tabMatch.setBackground(createPillDrawable("#4F46E5", 50, null)); tabMatch.setTextColor(Color.WHITE);
            tabMatch.setCompoundDrawables(getSizedIcon("trophy", Color.WHITE, 24), null, null, null);
            layoutRules.setVisibility(View.GONE); layoutJoinersContainer.setVisibility(View.VISIBLE); return;
        }
        if (showJoiners) {
            tabMatch.setBackground(createPillDrawable("#4F46E5", 50, null)); tabMatch.setTextColor(Color.WHITE);
            tabMatch.setCompoundDrawables(getSizedIcon("users", Color.WHITE, 24), null, null, null);
            tabRules.setBackgroundColor(Color.TRANSPARENT); tabRules.setTextColor(Color.parseColor("#64748B"));
            tabRules.setCompoundDrawables(getSizedIcon("document", Color.parseColor("#64748B"), 24), null, null, null);
            layoutRules.setVisibility(View.GONE); layoutJoinersContainer.setVisibility(View.VISIBLE);
            layoutJoinersContainer.setAlpha(0f); layoutJoinersContainer.animate().alpha(1f).setDuration(250).start();
        } else {
            tabRules.setBackground(createPillDrawable("#4F46E5", 50, null)); tabRules.setTextColor(Color.WHITE);
            tabRules.setCompoundDrawables(getSizedIcon("document", Color.WHITE, 24), null, null, null);
            tabMatch.setBackgroundColor(Color.TRANSPARENT); tabMatch.setTextColor(Color.parseColor("#64748B"));
            tabMatch.setCompoundDrawables(getSizedIcon("users", Color.parseColor("#64748B"), 24), null, null, null);
            layoutJoinersContainer.setVisibility(View.GONE); layoutRules.setVisibility(View.VISIBLE);
            layoutRules.setAlpha(0f); layoutRules.animate().alpha(1f).setDuration(250).start();
        }
    }

    private void fetchDataFromServer() {
        try {
            String url = ApiPrefs.getString("Api", "https://api.khelosobai20.live/ElitegoxUser/") + (showIncome ? "results_matches.php" : "joiners.php");
            String postData = showIncome ? "id=" + URLEncoder.encode(matchId, "UTF-8") + "&match_type=freefire&type=all" 
                : "id=" + URLEncoder.encode(matchId, "UTF-8") + "&match_type=freefire&type=getdata";
            if (!showIncome) {
                String token = Save_User_Status.getString("Token", "");
                if (!token.isEmpty()) postData += "&token=" + URLEncoder.encode(token, "UTF-8");
            }
            postRequest(url, postData, new NetCallback() {
                public void onRes(String res) { parseAndPopulateUI(res); }
                public void onErr() { Toast.makeText(ShvuoRulesActivity.this, "Connection Error!", Toast.LENGTH_SHORT).show(); }
            });
        } catch (Exception ignored) {}
    }

    private void parseAndPopulateUI(String response) {
        try {
            if (!isJoined && !showIncome) {
                layoutJoinersList.removeAllViews();
                ParticipantsDialog.show(this);
                TextView lockedText = new TextView(this);
                lockedText.setText("আপনি এই ম্যাচে জয়েন করেননি। প্লেয়ার লিস্ট দেখতে হলে আগে জয়েন করুন।");
                lockedText.setTextColor(Color.parseColor("#E11D48"));
                lockedText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                lockedText.setTypeface(null, Typeface.BOLD);
                lockedText.setGravity(Gravity.CENTER);
                lockedText.setPadding(dpToPx(16), dpToPx(50), dpToPx(16), dpToPx(50));
                layoutJoinersList.addView(lockedText);

                txtTotalTeams.setText("Locked");
                slotsCountText.setText("Locked");
                progressPlayers.setProgress(0);
                layoutJoinersContainer.setVisibility(View.VISIBLE);
                return;
            }

            List<NetworkTeam> parsedTeams = new ArrayList<>();
            int totalJoinedPlayers = 0;
            if (response.startsWith("{")) {
                JSONObject obj = new JSONObject(response);
                if (obj.optBoolean("status") && obj.has("teams")) {
                    JSONArray teamsArray = obj.getJSONArray("teams");
                    for (int i = 0; i < teamsArray.length(); i++) {
                        JSONObject tObj = teamsArray.getJSONObject(i);
                        String tColor = tObj.optString("team_color", "#4F46E5");
                        List<NetworkPlayer> pList = parsePlayers(tObj.optJSONArray("players"), tColor);
                        parsedTeams.add(new NetworkTeam(tObj.optString("team_name", "Team"), tColor, pList));
                        totalJoinedPlayers += pList.size();
                    }
                }
            } else if (response.startsWith("[")) {
                JSONArray arr = new JSONArray(response);
                if (arr.length() > 0) {
                    if (arr.getJSONObject(0).has("players")) {
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject tObj = arr.getJSONObject(i);
                            String tColor = tObj.optString("team_color", "#4F46E5");
                            List<NetworkPlayer> pList = parsePlayers(tObj.optJSONArray("players"), tColor);
                            parsedTeams.add(new NetworkTeam(tObj.optString("team_name", "Team"), tColor, pList));
                            totalJoinedPlayers += pList.size();
                        }
                    } else {
                        List<NetworkPlayer> flatPlayers = new ArrayList<>();
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject pObj = arr.getJSONObject(i);
                            NetworkPlayer p = new NetworkPlayer(pObj.optString("id"), pObj.optString("name", "Player"), pObj.optString("winning", "0"), pObj.optString("total_kill", "0"), pObj.optInt("is_leader", 0), pObj.optBoolean("is_owner", false) || pObj.optInt("is_owner", 0) == 1, pObj.optInt("slot", 0));
                            p.teamColor = pObj.optString("team_color", "#4F46E5");
                            flatPlayers.add(p); totalJoinedPlayers++;
                        }
                        int gSize = (matchType != null && matchType.toLowerCase().contains("solo")) ? 1 : (matchType != null && matchType.toLowerCase().contains("duo") ? 2 : 4);
                        List<NetworkPlayer> cGroup = new ArrayList<>(); int tCount = 1;
                        for (NetworkPlayer p : flatPlayers) {
                            cGroup.add(p);
                            if (cGroup.size() == gSize) {
                                parsedTeams.add(new NetworkTeam(gSize == 1 ? p.name : "Team " + tCount++, p.teamColor, new ArrayList<>(cGroup)));
                                cGroup.clear();
                            }
                        }
                        if (!cGroup.isEmpty()) parsedTeams.add(new NetworkTeam(gSize == 1 ? cGroup.get(0).name : "Team " + tCount, cGroup.get(0).teamColor, new ArrayList<>(cGroup)));
                    }
                }
            }
            if (parsedTeams.isEmpty()) { layoutJoinersContainer.setVisibility(View.GONE); return; }
            if (showIncome) {
                Collections.sort(parsedTeams, (t1, t2) -> Integer.compare(getWin(t2), getWin(t1)));
                NetworkTeam winner = parsedTeams.get(0);
                boolean isSolo = matchType != null && matchType.toLowerCase().contains("solo");
                labelStartsIn.setVisibility(View.VISIBLE); labelStartsIn.setText("MATCH WINNER"); labelStartsIn.setTextColor(Color.parseColor("#F59E0B"));
                labelStartsIn.setCompoundDrawablesWithIntrinsicBounds(getSizedIcon("crown", Color.parseColor("#F59E0B"), 18), null, getSizedIcon("crown", Color.parseColor("#F59E0B"), 18), null);
                labelStartsIn.setCompoundDrawablePadding(dpToPx(8)); timerContainer.removeAllViews();
                TextView wText = new TextView(this);
                wText.setText((isSolo ? "Player: " : "Team: ") + (isSolo && !winner.players.isEmpty() ? winner.players.get(0).name : winner.teamName) + " - " + getWin(winner) + " BDT");
                wText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18); wText.setTypeface(null, Typeface.BOLD);
                wText.setTextColor(Color.parseColor("#F59E0B")); wText.setGravity(Gravity.CENTER);
                timerContainer.addView(wText); timerContainer.setVisibility(View.VISIBLE); linear84.setVisibility(View.VISIBLE);
            }
            layoutJoinersList.removeAllViews();
            for (int i = 0; i < parsedTeams.size(); i++) layoutJoinersList.addView(createDynamicTeamCard(parsedTeams.get(i), i));
            boolean isSoloMatch = matchType != null && matchType.toLowerCase().contains("solo");
            txtTotalTeams.setText(parsedTeams.size() + (isSoloMatch ? (parsedTeams.size() > 1 ? " Players" : " Player") : (parsedTeams.size() > 1 ? " Teams" : " Team")));
            slotsCountText.setText(totalJoinedPlayers + " / " + totalTournamentSlots + " Slots");
            if (totalTournamentSlots > 0) progressPlayers.setProgress((totalJoinedPlayers * 100) / totalTournamentSlots);
            layoutJoinersContainer.setVisibility(View.VISIBLE);
        } catch (Exception e) { Toast.makeText(this, "Data Parse Error!", Toast.LENGTH_SHORT).show(); }
    }

    private List<NetworkPlayer> parsePlayers(JSONArray arr, String color) throws Exception {
        List<NetworkPlayer> list = new ArrayList<>();
        if (arr == null) return list;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.getJSONObject(i);
            NetworkPlayer pl = new NetworkPlayer(p.optString("id"), p.optString("name", "Player"), p.optString("winning", "0"), p.optString("total_kill", "0"), p.optInt("is_leader", 0), p.optBoolean("is_owner", false) || p.optInt("is_owner", 0) == 1, p.optInt("slot", 0));
            pl.teamColor = color; list.add(pl);
        }
        return list;
    }

    private int getWin(NetworkTeam t) {
        int w = 0;
        for (NetworkPlayer p : t.players) { try { w += Integer.parseInt(p.winning.replace(".0", "").trim()); } catch (Exception ignored) {} }
        return w;
    }

    private View createDynamicTeamCard(NetworkTeam team, int position) {
        int tWin = 0, tKills = 0;
        for (NetworkPlayer p : team.players) {
            try { tWin += Integer.parseInt(p.winning.replace(".0", "").trim()); } catch (Exception ignored) {}
            try { tKills += Integer.parseInt(p.totalKill.trim()); } catch (Exception ignored) {}
        }
        boolean isSolo = matchType != null && matchType.toLowerCase().contains("solo");
        boolean hasPlayers = team.players != null && !team.players.isEmpty();

        LinearLayout wrapper = new LinearLayout(this); wrapper.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wp.setMargins(0, 0, 0, dpToPx(20)); wrapper.setLayoutParams(wp);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.WHITE); bg.setCornerRadius(dpToPx(20));
        wrapper.setBackground(bg);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { wrapper.setElevation(dpToPx(4)); wrapper.setClipToOutline(true); }
        View stick = new View(this); stick.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(8), ViewGroup.LayoutParams.MATCH_PARENT));
        stick.setBackgroundColor(Color.parseColor(team.teamColor != null && !team.teamColor.isEmpty() ? team.teamColor : "#4F46E5")); wrapper.addView(stick);
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL);
        main.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (showIncome && position == 0) {
            TextView winH = new TextView(this);
            winH.setText("1st Place - " + (isSolo && hasPlayers ? team.players.get(0).name : team.teamName));
            winH.setTextColor(Color.parseColor("#D97706")); winH.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13); winH.setTypeface(null, Typeface.BOLD);
            winH.setGravity(Gravity.CENTER); winH.setPadding(0, dpToPx(8), 0, dpToPx(8)); winH.setBackgroundColor(Color.parseColor("#FEF3C7"));
            winH.setCompoundDrawablesWithIntrinsicBounds(getSizedIcon("trophy", Color.parseColor("#D97706"), 14), null, null, null);
            winH.setCompoundDrawablePadding(dpToPx(6)); main.addView(winH);
        }
        LinearLayout hRow = new LinearLayout(this); hRow.setOrientation(LinearLayout.HORIZONTAL); hRow.setGravity(Gravity.CENTER_VERTICAL);
        hRow.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        TextView tAv = new TextView(this);

        String displayName = isSolo ? (hasPlayers ? team.players.get(0).name : "Player") : team.teamName;
        String displayAv = isSolo ? (displayName.isEmpty() ? "P" : displayName.substring(0, 1).toUpperCase()) : (displayName.replaceAll("[^0-9]", "").isEmpty() ? "T" : "T" + displayName.replaceAll("[^0-9]", ""));

        tAv.setText(displayAv);
        tAv.setTextColor(Color.WHITE); tAv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); tAv.setTypeface(null, Typeface.BOLD);
        tAv.setGravity(Gravity.CENTER); tAv.setBackground(createPillDrawable("#0F172A", 12, null));
        hRow.addView(tAv, new LinearLayout.LayoutParams(dpToPx(48), dpToPx(48)));
        LinearLayout tTime = new LinearLayout(this); tTime.setOrientation(LinearLayout.VERTICAL); tTime.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ttp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        ttp.setMargins(dpToPx(14), 0, dpToPx(14), 0); tTime.setLayoutParams(ttp);
        TextView tName = new TextView(this); tName.setText(displayName);
        tName.setTextColor(Color.parseColor("#0F172A")); tName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); tName.setTypeface(null, Typeface.BOLD); tTime.addView(tName);
        TextView txtT = new TextView(this); txtT.setText(showIncome ? tKills + " Kills" : "Joined");
        txtT.setCompoundDrawables(getSizedIcon(showIncome ? "skull" : "timer", Color.parseColor("#94A3B8"), 12), null, null, null);
        txtT.setTextColor(Color.parseColor("#64748B")); txtT.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        txtT.setCompoundDrawablePadding(dpToPx(4)); txtT.setPadding(0, dpToPx(4), 0, 0); tTime.addView(txtT); hRow.addView(tTime);
        if (showIncome) {
            TextView pStatus = new TextView(this); pStatus.setText("Win: " + tWin + " BDT");
            pStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13); pStatus.setTypeface(null, Typeface.BOLD);
            pStatus.setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8)); pStatus.setTextColor(Color.parseColor("#059669"));
            pStatus.setBackground(createPillDrawable("#D1FAE5", 50, null)); hRow.addView(pStatus);
        }
        main.addView(hRow);
        
        LinearLayout pListCon = new LinearLayout(this); pListCon.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable pBg = new GradientDrawable(); pBg.setColor(Color.parseColor("#F8FAFC"));
        pBg.setCornerRadii(new float[]{0, 0, 0, 0, dpToPx(20), dpToPx(20), dpToPx(20), dpToPx(20)}); pListCon.setBackground(pBg);
        View divTop = new View(this); divTop.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(1))); divTop.setBackgroundColor(Color.parseColor("#E2E8F0")); pListCon.addView(divTop);
        for (int i = 0; i < team.players.size(); i++) {
            NetworkPlayer pl = team.players.get(i);
            LinearLayout pRow = new LinearLayout(this); pRow.setOrientation(LinearLayout.HORIZONTAL); pRow.setGravity(Gravity.CENTER_VERTICAL);
            pRow.setPadding(dpToPx(16), dpToPx(14), dpToPx(16), dpToPx(14));
            TextView pAv = new TextView(this); String ini = !pl.name.isEmpty() ? pl.name.substring(0, 1).toUpperCase() : "P";
            pAv.setText(ini); pAv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); pAv.setTypeface(null, Typeface.BOLD); pAv.setGravity(Gravity.CENTER);
            String[] bgC = {"#FEE2E2", "#FEF3C7", "#D1FAE5", "#DBEAFE", "#F3E8FF"}, txtC = {"#DC2626", "#D97706", "#059669", "#2563EB", "#7C3AED"};
            int cIdx = Math.abs(ini.hashCode()) % bgC.length;
            pAv.setTextColor(Color.parseColor(txtC[cIdx])); pAv.setBackground(createPillDrawable(bgC[cIdx], 50, null));
            pAv.setLayoutParams(new LinearLayout.LayoutParams(dpToPx(38), dpToPx(38))); pRow.addView(pAv);
            LinearLayout nRow = new LinearLayout(this); nRow.setOrientation(LinearLayout.VERTICAL); nRow.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1); np.setMargins(dpToPx(14), 0, 0, 0); nRow.setLayoutParams(np);
            LinearLayout hNBox = new LinearLayout(this); hNBox.setOrientation(LinearLayout.HORIZONTAL); hNBox.setGravity(Gravity.CENTER_VERTICAL);
            
            TextView pNText = new TextView(this); pNText.setText(pl.name); pNText.setTextColor(Color.parseColor("#1E293B"));
            pNText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15); pNText.setTypeface(null, Typeface.BOLD); pNText.setMaxLines(1); pNText.setEllipsize(TextUtils.TruncateAt.END);

            if (pl.slot > 0) {
                TextView slotChip = new TextView(this); slotChip.setText(String.valueOf(pl.slot));
                slotChip.setTextColor(Color.parseColor("#4F46E5")); slotChip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                slotChip.setTypeface(null, Typeface.BOLD); slotChip.setGravity(Gravity.CENTER);
                slotChip.setBackground(createPillDrawable("#EEF2FF", 10, null));
                slotChip.setPadding(dpToPx(9), dpToPx(3), dpToPx(9), dpToPx(3)); slotChip.setMinWidth(dpToPx(30));
                LinearLayout.LayoutParams slotLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                slotLp.setMargins(0, 0, dpToPx(8), 0); hNBox.addView(slotChip, slotLp);
            }

            hNBox.addView(pNText);
            
            if (pl.isLeader == 1 || i == 0) {
                TextView cap = new TextView(this); cap.setText("LEADER"); cap.setTextColor(Color.WHITE); cap.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
                cap.setTypeface(null, Typeface.BOLD); cap.setBackground(createPillDrawable("#F59E0B", 6, null));
                cap.setCompoundDrawables(getSizedIcon("crown", Color.WHITE, 12), null, null, null); cap.setCompoundDrawablePadding(dpToPx(4));
                cap.setPadding(dpToPx(6), dpToPx(3), dpToPx(6), dpToPx(3)); cap.setSingleLine(true);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                cp.setMargins(dpToPx(8), 0, 0, 0); hNBox.addView(cap, cp);
            }
            nRow.addView(hNBox); pRow.addView(nRow);
            
            if (showIncome) {
                TextView pInc = new TextView(this); pInc.setText("+" + pl.winning.replace(".0", "") + " BDT (" + pl.totalKill + " Kills)");
                pInc.setTextColor(Color.parseColor("#059669")); pInc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13); pInc.setTypeface(null, Typeface.BOLD);
                pInc.setCompoundDrawables(getSizedIcon("coin", Color.parseColor("#059669"), 16), null, null, null);
                pInc.setCompoundDrawablePadding(dpToPx(6)); pInc.setPadding(dpToPx(8), dpToPx(4), 0, dpToPx(4)); pRow.addView(pInc);
            }
            
            if (pl.isOwner) {
                ImageView editIcon = new ImageView(this);
                editIcon.setImageDrawable(getSizedIcon("edit", Color.parseColor("#4F46E5"), 18));
                
                LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(dpToPx(38), dpToPx(38));
                ep.gravity = Gravity.CENTER_VERTICAL;
                ep.leftMargin = dpToPx(8);
                editIcon.setLayoutParams(ep);
                editIcon.setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6));
                editIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                
                TypedValue outValue = new TypedValue();
                getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, outValue, true);
                editIcon.setBackgroundResource(outValue.resourceId);
                
                final String pid = pl.id;
                View.OnClickListener editAction = v -> showBottomSheetEdit(pNText, "Edit Player Name", matchId, pid);
                
                editIcon.setOnClickListener(editAction);
                pNText.setOnClickListener(editAction);
                
                pRow.addView(editIcon);
            }
            
            pListCon.addView(pRow);
            if (i < team.players.size() - 1) {
                View div = new View(this); LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(1));
                dp.setMargins(dpToPx(68), 0, dpToPx(16), 0); div.setLayoutParams(dp); div.setBackgroundColor(Color.parseColor("#E2E8F0")); pListCon.addView(div);
            }
        }
        main.addView(pListCon);
        
        wrapper.addView(main); return wrapper;
    }

    private void showBottomSheetEdit(TextView target, String title, String mId, String pId) {
        BottomSheetDialog bsd = new BottomSheetDialog(this);
        LinearLayout con = new LinearLayout(this); con.setOrientation(LinearLayout.VERTICAL); con.setPadding(dpToPx(24), dpToPx(16), dpToPx(24), dpToPx(24));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.WHITE); bg.setCornerRadii(new float[]{dpToPx(24), dpToPx(24), dpToPx(24), dpToPx(24), 0, 0, 0, 0}); con.setBackground(bg);
        View han = new View(this); LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dpToPx(40), dpToPx(4)); hp.gravity = Gravity.CENTER_HORIZONTAL; hp.bottomMargin = dpToPx(20); han.setLayoutParams(hp); han.setBackground(createPillDrawable("#E2E8F0", 50, null)); con.addView(han);
        TextView tv = new TextView(this); tv.setText(title); tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20); tv.setTypeface(null, Typeface.BOLD); tv.setTextColor(Color.parseColor("#0F172A")); tv.setPadding(0, 0, 0, dpToPx(16)); con.addView(tv);
        
        TextView notice = new TextView(this);
        notice.setText("নাম পরিবর্তন করলে আপনার আইডি থেকে ১ টাকা কেটে নেওয়া হবে");
        notice.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        notice.setTextColor(Color.parseColor("#D97706"));
        notice.setTypeface(null, Typeface.BOLD);
        notice.setPadding(0, 0, 0, dpToPx(12));
        con.addView(notice);
        
        EditText inp = new EditText(this); LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(52)); ip.bottomMargin = dpToPx(24); inp.setLayoutParams(ip);
        inp.setText(target.getText().toString()); inp.setInputType(InputType.TYPE_CLASS_TEXT); inp.setPadding(dpToPx(16), 0, dpToPx(16), 0); inp.setBackground(createPillDrawable("#F8FAFC", 12, "#CBD5E1")); inp.setTextColor(Color.parseColor("#1E293B")); inp.setSingleLine(true); inp.requestFocus(); con.addView(inp);
        TextView btn = new TextView(this); btn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(52))); btn.setText("Save Changes"); btn.setGravity(Gravity.CENTER); btn.setTextColor(Color.WHITE); btn.setTypeface(null, Typeface.BOLD); btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); btn.setBackground(createPillDrawable("#4F46E5", 14, null));
        btn.setOnClickListener(v -> { String txt = inp.getText().toString().trim(); if (!txt.isEmpty()) updatePlayerNameOnServer(mId, pId, txt, target); bsd.dismiss(); });
        con.addView(btn); bsd.setContentView(con); if (con.getParent() != null) ((View) con.getParent()).setBackgroundColor(Color.TRANSPARENT); bsd.show();
    }

    private void updatePlayerNameOnServer(String mId, String pId, String newName, TextView target) {
    try {
        String token = Save_User_Status.getString("Token", "");
        String url = ApiPrefs.getString("Api", "https://api.khelosobai20.live/ElitegoxUser/") + "joiners.php";
        String pd = "type=player_name_change&id=" + URLEncoder.encode(mId, "UTF-8") +
                    "&name=" + URLEncoder.encode(newName, "UTF-8") +
                    "&change_id=" + URLEncoder.encode(pId, "UTF-8") +
                    "&token=" + URLEncoder.encode(token, "UTF-8");
        postRequest(url, pd, new NetCallback() {
            public void onRes(String res) {
                if (res.toLowerCase().contains("successfully")) {
                    target.setText(newName);
                    Toast.makeText(ShvuoRulesActivity.this, "Player name updated!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ShvuoRulesActivity.this, "Update failed: " + res, Toast.LENGTH_LONG).show();
                }
            }
            public void onErr() {
                Toast.makeText(ShvuoRulesActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    } catch (Exception ignored) {}
}

    private int dpToPx(float dp) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics()); }
    private GradientDrawable createPillDrawable(String bgHex, float radDp, String strHex) {
        GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.RECTANGLE); d.setColor(Color.parseColor(bgHex)); d.setCornerRadius(radDp * getResources().getDisplayMetrics().density);
        if (strHex != null) d.setStroke((int) (1.5f * getResources().getDisplayMetrics().density), Color.parseColor(strHex)); return d;
    }
    private Drawable getSizedIcon(String type, int color, int sizeDp) {
        int s = dpToPx(sizeDp); CustomIconDrawable d = new CustomIconDrawable(type, color, s); d.setBounds(0, 0, s, s); return d;
    }

    public static class CustomIconDrawable extends Drawable {
        private final Paint paint; private final Path path; private final String type;
        public CustomIconDrawable(String type, int color, int size) {
            this.type = type; paint = new Paint(Paint.ANTI_ALIAS_FLAG); paint.setColor(color); paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(size / 12f); paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND); path = new Path(); createPath();
        }
        private void createPath() {
            switch (type) {
                case "arrow_back": path.moveTo(45, 20); path.lineTo(15, 50); path.lineTo(45, 80); path.moveTo(15, 50); path.lineTo(85, 50); break;
                case "gamepad": path.addRoundRect(new RectF(10, 30, 90, 70), 20, 20, Path.Direction.CW); path.moveTo(25, 50); path.lineTo(35, 50); path.moveTo(30, 45); path.lineTo(30, 55); path.addCircle(70, 45, 3, Path.Direction.CW); path.addCircle(75, 55, 3, Path.Direction.CW); break;
                case "location": path.moveTo(50, 95); path.quadTo(20, 55, 20, 35); path.addArc(new RectF(20, 5, 80, 65), 180, 180); path.quadTo(80, 55, 50, 95); path.addCircle(50, 35, 12, Path.Direction.CW); break;
                case "users": path.addCircle(40, 35, 15, Path.Direction.CW); path.moveTo(10, 85); path.cubicTo(10, 65, 70, 65, 70, 85); path.addCircle(70, 25, 12, Path.Direction.CW); path.moveTo(65, 53); path.cubicTo(85, 55, 95, 70, 95, 85); break;
                case "wallet": path.addRoundRect(new RectF(15, 25, 85, 75), 10, 10, Path.Direction.CW); path.moveTo(15, 45); path.lineTo(85, 45); path.moveTo(65, 45); path.lineTo(65, 75); path.moveTo(75, 60); path.lineTo(75.1f, 60); break;
                case "skull": path.moveTo(25, 50); path.cubicTo(25, 10, 75, 10, 75, 50); path.lineTo(75, 75); path.lineTo(65, 85); path.lineTo(35, 85); path.lineTo(25, 75); path.close(); path.addCircle(35, 48, 8, Path.Direction.CW); path.addCircle(65, 48, 8, Path.Direction.CW); path.moveTo(50, 62); path.lineTo(45, 68); path.lineTo(55, 68); path.close(); path.moveTo(40, 85); path.lineTo(40, 75); path.moveTo(50, 85); path.lineTo(50, 75); path.moveTo(60, 85); path.lineTo(60, 75); break;
                case "trophy": path.moveTo(25, 20); path.lineTo(75, 20); path.lineTo(75, 40); path.cubicTo(75, 65, 25, 65, 25, 40); path.close(); path.moveTo(50, 62); path.lineTo(50, 85); path.moveTo(30, 85); path.lineTo(70, 85); path.moveTo(25, 25); path.cubicTo(5, 25, 5, 50, 25, 45); path.moveTo(75, 25); path.cubicTo(95, 25, 95, 50, 75, 45); break;
                case "timer": path.addCircle(50, 55, 35, Path.Direction.CW); path.moveTo(42, 10); path.lineTo(58, 10); path.moveTo(50, 10); path.lineTo(50, 20); path.moveTo(50, 55); path.lineTo(65, 40); break;
                case "document": path.moveTo(30, 10); path.lineTo(55, 10); path.lineTo(75, 30); path.lineTo(75, 90); path.lineTo(30, 90); path.close(); path.moveTo(55, 10); path.lineTo(55, 30); path.lineTo(75, 30); path.moveTo(40, 50); path.lineTo(65, 50); path.moveTo(40, 65); path.lineTo(65, 65); path.moveTo(40, 80); path.lineTo(55, 80); break;
                case "crown": path.moveTo(15, 80); path.lineTo(85, 80); path.lineTo(90, 30); path.lineTo(65, 50); path.lineTo(50, 15); path.lineTo(35, 50); path.lineTo(10, 30); path.close(); break;
                case "coin": path.addCircle(50, 50, 40, Path.Direction.CW); path.addCircle(50, 50, 25, Path.Direction.CW); path.moveTo(50, 15); path.lineTo(50, 85); path.moveTo(60, 35); path.cubicTo(40, 25, 30, 45, 50, 50); path.cubicTo(70, 55, 60, 75, 40, 65); break;
                case "edit": path.moveTo(70, 20); path.lineTo(80, 30); path.lineTo(35, 75); path.lineTo(20, 80); path.lineTo(25, 65); path.close(); path.moveTo(60, 30); path.lineTo(70, 40); break;
            }
        }
        @Override public void draw(@NonNull Canvas c) { Rect b = getBounds(); c.save(); c.translate(b.left, b.top); c.scale(b.width() / 100f, b.height() / 100f); c.drawPath(path, paint); c.restore(); }
        @Override public void setAlpha(int a) { paint.setAlpha(a); }
        @Override public void setColorFilter(@Nullable ColorFilter f) { paint.setColorFilter(f); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}