package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ZabbarLiveChatActivity extends AppCompatActivity {
	
	private ZabbarLiveChatBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ZabbarLiveChatBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		Window window = getWindow();
		androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false);
		window.setStatusBarColor(android.graphics.Color.TRANSPARENT);
		window.setNavigationBarColor(android.graphics.Color.TRANSPARENT);
		
		
		BlurView blurView = binding.blurView;
		BlurView blurViewBottom = binding.blurViewBottom; 
		
		ViewGroup rootView = (ViewGroup) window.getDecorView();
		android.graphics.drawable.Drawable windowBackground = rootView.getBackground();
		
		boolean isAndroidSOrLater = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S;
		
		
		blurView.setupWith(rootView, isAndroidSOrLater ? new RenderEffectBlur() : new RenderScriptBlur(this))
		        .setFrameClearDrawable(windowBackground)
		        .setBlurRadius(5f)
		        .setBlurAutoUpdate(true);
		
		blurViewBottom.setupWith(rootView, isAndroidSOrLater ? new RenderEffectBlur() : new RenderScriptBlur(this))
		        .setFrameClearDrawable(windowBackground)
		        .setBlurRadius(15f)
		        .setBlurAutoUpdate(true);
		
		androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(blurViewBottom, (v, insets) -> {
			    
			    int imeHeight = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime()).bottom;
			    int navigationBarsHeight = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.navigationBars()).bottom;
			
			    android.view.ViewGroup.MarginLayoutParams params = (android.view.ViewGroup.MarginLayoutParams) v.getLayoutParams();
			    
			    params.bottomMargin = Math.max(imeHeight, navigationBarsHeight);
			    v.setLayoutParams(params);
			
			    return insets;
		});
		
	}
	
	public class Recyclerview4Adapter extends RecyclerView.Adapter<Recyclerview4Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview4Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.zabbar_rules, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			ZabbarRulesBinding binding = ZabbarRulesBinding.bind(_view);
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
}