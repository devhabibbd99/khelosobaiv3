package com.khelosobaiv3.user;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.FirebaseApp;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ZabbarAddWalletActivity extends AppCompatActivity {

    private ZabbarAddWalletBinding binding;
    private SharedPreferences apiPrefs;
    private SharedPreferences saveUserStatus;

    private String apiBase = "";
    private String selectedMethod = "bKash";

    private String bkashPersonal = "";
    private String nagadPersonal = "";
    private String rocketPersonal = "";
    private String upayPersonal = "";

    private String bkashMerchant = "";
    private String nagadMerchant = "";
    private String rocketMerchant = "";
    private String upayMerchant = "";

    private String username = "";
    private String email = "";
    private String fcm = "";
    private String authorization = "";
    private String token = "";

    private boolean depositOpen = true;
    private boolean appInfoLoaded = false;
    private boolean autoPayEnabled = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SSLHelper.trustAllCertificates();

        binding = ZabbarAddWalletBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        apiPrefs = getSharedPreferences("Api", Activity.MODE_PRIVATE);
        saveUserStatus = getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE);

        FirebaseApp.initializeApp(this);
        initializeLogic();
        setupClickListeners();
        selectPaymentMethod("bKash");
        updateVerifyState();
        ZabbarNavigation.INSTANCE.setup(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        loadAppInfo();
        loadUserProfile();
    }

    private void initializeLogic() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.md_theme_tertiaryFixed_highContrast));
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.md_theme_tertiaryFixed_highContrast));
        }

        getWindow().setDecorFitsSystemWindows(false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        BlurView blurView = findViewById(R.id.blurView);
        ViewGroup rootView = (ViewGroup) getWindow().getDecorView();
        Drawable windowBackground = rootView.getBackground();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blurView.setupWith(rootView, new RenderEffectBlur()).setFrameClearDrawable(windowBackground).setBlurRadius(8f).setBlurAutoUpdate(true);
        } else {
            blurView.setupWith(rootView, new RenderScriptBlur(this)).setFrameClearDrawable(windowBackground).setBlurRadius(8f).setBlurAutoUpdate(true);
        }
    }

    private void setupClickListeners() {
        binding.btnBkash.setOnClickListener(v -> selectPaymentMethod("bKash"));
        binding.btnNagad.setOnClickListener(v -> selectPaymentMethod("Nagad"));
        binding.btnRocket.setOnClickListener(v -> selectPaymentMethod("Rocket"));
        binding.btnUpay.setOnClickListener(v -> selectPaymentMethod("Upay"));

        binding.btnCopyMerchant.setOnClickListener(v -> copyToClipboard(binding.txtMerchantNumber.getText().toString(), "Merchant Number"));
        binding.btnCopy.setOnClickListener(v -> copyToClipboard(binding.txtPhoneNumber.getText().toString(), "Phone Number"));

        binding.btnVerify.setOnClickListener(v -> processVerification());
        binding.appIcon.setOnClickListener(v -> finish());
        binding.imageview1.setOnClickListener(v -> {
            loadAppInfo();
            loadUserProfile();
        });
        binding.imgHelp.setOnClickListener(v -> showMessageDialog("Help", "Help section clicked.", "info.json"));
        binding.imgNotification.setOnClickListener(v -> showMessageDialog("Notifications", "No new notifications.", "info.json"));
    }

    private void applyAutoPayMode() {
        if (autoPayEnabled) {
            binding.textinputlayout22.setVisibility(View.GONE);
            binding.textinputlayout19.setVisibility(View.GONE);
        } else {
            binding.textinputlayout22.setVisibility(View.VISIBLE);
            binding.textinputlayout19.setVisibility(View.VISIBLE);
        }
    }

    private void loadAppInfo() {
        apiBase = apiPrefs.getString("Api", "");
        if (TextUtils.isEmpty(apiBase)) {
            appInfoLoaded = false;
            updateMerchantUi();
            updateVerifyState();
            showMessageDialog("Error", "API URL Missing", "error.json");
            return;
        }

        StringRequest request = new StringRequest(Request.Method.GET, apiBase.concat("appinfo.php"),
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);

                        bkashPersonal = opt(obj, "bkash_number");
                        nagadPersonal = opt(obj, "nagad_number");
                        rocketPersonal = opt(obj, "rocket_number");
                        upayPersonal = opt(obj, "upay_number");

                        bkashMerchant = opt(obj, "bKash_Merchant", "bkash_merchant");
                        nagadMerchant = opt(obj, "Nagad_Merchant", "nagad_merchant");
                        rocketMerchant = opt(obj, "Rocket_Merchant", "rocket_merchant");
                        upayMerchant = opt(obj, "Upay_Merchant", "upay_merchant");

                        String addMoneyOpen = opt(obj, "addmoney_open");
                        depositOpen = "0".equals(addMoneyOpen);

                        String autoPayStr = opt(obj, "auto_pay");
                        autoPayEnabled = !"OFF".equalsIgnoreCase(autoPayStr);

                        appInfoLoaded = true;
                        applyAutoPayMode();
                        updateMerchantUi();
                        updateVerifyState();

                        if (!depositOpen) {
                            showDepositClosedDialog();
                        }
                    } catch (Exception e) {
                        appInfoLoaded = false;
                        updateMerchantUi();
                        updateVerifyState();
                        showMessageDialog("Parse Error", safeText(response, "AppInfo Parse Error"), "error.json");
                    }
                },
                error -> {
                    appInfoLoaded = false;
                    updateMerchantUi();
                    updateVerifyState();
                    showMessageDialog("Network Error", buildVolleyError(error), "error.json");
                });

        request.setRetryPolicy(new DefaultRetryPolicy(15000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(request);
    }

    private void loadUserProfile() {
        apiBase = apiPrefs.getString("Api", "");
        if (TextUtils.isEmpty(apiBase)) {
            showMessageDialog("Error", "API URL Missing", "error.json");
            return;
        }

        token = pref(saveUserStatus, "Token", "token", "USER_TOKEN", "user_token");

        if (TextUtils.isEmpty(token)) {
            showMessageDialog("Error", "Token Missing", "error.json");
            return;
        }

        StringRequest request = new StringRequest(Request.Method.POST, apiBase.concat("XMapp_Us.js.php"),
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);

                        if (obj.has("error")) {
                            showMessageDialog("Profile Error", obj.optString("error", "Profile Error"), "error.json");
                            return;
                        }

                        username = opt(obj, "username", "user_name", "name", "user");
                        email = opt(obj, "email", "user_email");
                        fcm = opt(obj, "fcm", "fcm_key", "fcmToken", "firebaseToken");
                        authorization = opt(obj, "Authorization", "authorization", "key_value", "api_key", "apikey", "auth_key");

                        String newToken = obj.optString("token", "");
                        if (!TextUtils.isEmpty(newToken)) {
                            token = newToken;
                        }

                        if (TextUtils.isEmpty(username)) username = pref(saveUserStatus, "username", "user_name", "name", "user");
                        if (TextUtils.isEmpty(email)) email = pref(saveUserStatus, "email", "user_email");
                        if (TextUtils.isEmpty(fcm)) fcm = pref(saveUserStatus, "fcm", "fcm_key", "fcmToken", "firebaseToken");
                        if (TextUtils.isEmpty(authorization)) authorization = pref(saveUserStatus, "Authorization", "authorization", "key_value", "api_key", "apikey", "auth_key");
                        if (TextUtils.isEmpty(authorization)) authorization = pref(apiPrefs, "Authorization", "authorization", "key_value", "api_key", "apikey", "auth_key");

                        if (TextUtils.isEmpty(authorization)) {
                            authorization = token;
                        }

                        saveUserStatus.edit()
                                .putString("Token", token)
                                .putString("token", token)
                                .putString("username", username)
                                .putString("email", email)
                                .putString("fcm", fcm)
                                .putString("Authorization", authorization)
                                .commit();

                        updateVerifyState();

                        if (!autoPayEnabled) {
                            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(email) || TextUtils.isEmpty(fcm) || TextUtils.isEmpty(authorization)) {
                                showMessageDialog("Data Missing", buildMissingUserMessage(), "error.json");
                            }
                        }
                    } catch (Exception e) {
                        showMessageDialog("Parse Error", safeText(response, "Profile Parse Error"), "error.json");
                    }
                },
                error -> showMessageDialog("Network Error", buildVolleyError(error), "error.json")) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("type", "1");
                params.put("token", token);
                return params;
            }
        };

        request.setRetryPolicy(new DefaultRetryPolicy(15000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(request);
    }

    private void selectPaymentMethod(String method) {
        selectedMethod = method;
        resetCardStyles();
        applySelectedCardStyle(method);
        updateInstructions(method);
        updateMerchantUi();
    }

    private void resetCardStyles() {
        int unselectedStrokeColor = Color.parseColor("#CAC4D0");
        int unselectedTextColor = Color.parseColor("#1D1B20");
        int unselectedStrokeWidth = dpToPx(1);
        int unselectedBgColor = Color.TRANSPARENT;

        binding.btnBkash.setStrokeColor(unselectedStrokeColor);
        binding.btnBkash.setStrokeWidth(unselectedStrokeWidth);
        binding.btnBkash.setCardBackgroundColor(unselectedBgColor);
        binding.textview175.setTextColor(unselectedTextColor);

        binding.btnNagad.setStrokeColor(unselectedStrokeColor);
        binding.btnNagad.setStrokeWidth(unselectedStrokeWidth);
        binding.btnNagad.setCardBackgroundColor(unselectedBgColor);
        binding.textview176.setTextColor(unselectedTextColor);

        binding.btnRocket.setStrokeColor(unselectedStrokeColor);
        binding.btnRocket.setStrokeWidth(unselectedStrokeWidth);
        binding.btnRocket.setCardBackgroundColor(unselectedBgColor);
        binding.textview177.setTextColor(unselectedTextColor);

        binding.btnUpay.setStrokeColor(unselectedStrokeColor);
        binding.btnUpay.setStrokeWidth(unselectedStrokeWidth);
        binding.btnUpay.setCardBackgroundColor(unselectedBgColor);
        binding.textview178.setTextColor(unselectedTextColor);
    }

    private void applySelectedCardStyle(String method) {
        int selectedStrokeColor = Color.parseColor("#004F50");
        int selectedTextColor = Color.parseColor("#004F50");
        int selectedBgColor = Color.parseColor("#D9F2F2");
        int selectedStrokeWidth = dpToPx(3);

        switch (method) {
            case "bKash":
                binding.btnBkash.setStrokeColor(selectedStrokeColor);
                binding.btnBkash.setStrokeWidth(selectedStrokeWidth);
                binding.btnBkash.setCardBackgroundColor(selectedBgColor);
                binding.textview175.setTextColor(selectedTextColor);
                break;
            case "Nagad":
                binding.btnNagad.setStrokeColor(selectedStrokeColor);
                binding.btnNagad.setStrokeWidth(selectedStrokeWidth);
                binding.btnNagad.setCardBackgroundColor(selectedBgColor);
                binding.textview176.setTextColor(selectedTextColor);
                break;
            case "Rocket":
                binding.btnRocket.setStrokeColor(selectedStrokeColor);
                binding.btnRocket.setStrokeWidth(selectedStrokeWidth);
                binding.btnRocket.setCardBackgroundColor(selectedBgColor);
                binding.textview177.setTextColor(selectedTextColor);
                break;
            case "Upay":
                binding.btnUpay.setStrokeColor(selectedStrokeColor);
                binding.btnUpay.setStrokeWidth(selectedStrokeWidth);
                binding.btnUpay.setCardBackgroundColor(selectedBgColor);
                binding.textview178.setTextColor(selectedTextColor);
                break;
        }
    }

    private void updateInstructions(String method) {
        String pNum = "";
        String mNum = "";

        switch (method) {
            case "bKash":
                binding.txtInstructionsTitle.setText("Payment Instructions (bKash)");
                pNum = bkashPersonal;
                mNum = bkashMerchant;
                binding.txtStep1Desc.setText("*247# ডায়াল করে অথবা bKash অ্যাপে প্রবেশ করুন।");
                break;
            case "Nagad":
                binding.txtInstructionsTitle.setText("Payment Instructions (Nagad)");
                pNum = nagadPersonal;
                mNum = nagadMerchant;
                binding.txtStep1Desc.setText("*167# ডায়াল করে অথবা Nagad অ্যাপে প্রবেশ করুন।");
                break;
            case "Rocket":
                binding.txtInstructionsTitle.setText("Payment Instructions (Rocket)");
                pNum = rocketPersonal;
                mNum = rocketMerchant;
                binding.txtStep1Desc.setText("*322# ডায়াল করে অথবা Rocket অ্যাপে প্রবেশ করুন।");
                break;
            case "Upay":
                binding.txtInstructionsTitle.setText("Payment Instructions (Upay)");
                pNum = upayPersonal;
                mNum = upayMerchant;
                binding.txtStep1Desc.setText("*268# ডায়াল করে অথবা Upay অ্যাপে প্রবেশ করুন।");
                break;
        }

        if (TextUtils.isEmpty(pNum)) {
            binding.txtPhoneNumber.setText("");
            binding.linear6.setVisibility(View.GONE);
        } else {
            binding.txtPhoneNumber.setText(pNum);
            binding.linear6.setVisibility(View.VISIBLE);
        }

        if (TextUtils.isEmpty(mNum)) {
            binding.txtMerchantNumber.setText("");
            binding.linear5.setVisibility(View.GONE);
        } else {
            binding.txtMerchantNumber.setText(mNum);
            binding.linear5.setVisibility(View.VISIBLE);
        }
    }

    private void updateMerchantUi() {
        boolean bkashOk = !TextUtils.isEmpty(bkashPersonal) || !TextUtils.isEmpty(bkashMerchant);
        boolean nagadOk = !TextUtils.isEmpty(nagadPersonal) || !TextUtils.isEmpty(nagadMerchant);
        boolean rocketOk = !TextUtils.isEmpty(rocketPersonal) || !TextUtils.isEmpty(rocketMerchant);
        boolean upayOk = !TextUtils.isEmpty(upayPersonal) || !TextUtils.isEmpty(upayMerchant);

        setViewVisible(binding.btnBkash, bkashOk);
        setViewVisible(binding.btnNagad, nagadOk);
        setViewVisible(binding.btnRocket, rocketOk);
        setViewVisible(binding.btnUpay, upayOk);

        setViewVisible(binding.textview175, bkashOk);
        setViewVisible(binding.textview176, nagadOk);
        setViewVisible(binding.textview177, rocketOk);
        setViewVisible(binding.textview178, upayOk);

        boolean anyMethodAvailable = bkashOk || nagadOk || rocketOk || upayOk;

        if (!anyMethodAvailable) {
            binding.linear5.setVisibility(View.GONE);
            binding.linear6.setVisibility(View.GONE);
            updateVerifyState();
            return;
        }

        boolean selectedAvailable = isSelectedMethodAvailable();
        if (!selectedAvailable) {
            if (bkashOk) {
                selectedMethod = "bKash";
            } else if (nagadOk) {
                selectedMethod = "Nagad";
            } else if (rocketOk) {
                selectedMethod = "Rocket";
            } else if (upayOk) {
                selectedMethod = "Upay";
            }
        }

        resetCardStyles();
        applySelectedCardStyle(selectedMethod);
        updateInstructions(selectedMethod);
    }

    private boolean isSelectedMethodAvailable() {
        if ("bKash".equals(selectedMethod)) return !TextUtils.isEmpty(bkashPersonal) || !TextUtils.isEmpty(bkashMerchant);
        if ("Nagad".equals(selectedMethod)) return !TextUtils.isEmpty(nagadPersonal) || !TextUtils.isEmpty(nagadMerchant);
        if ("Rocket".equals(selectedMethod)) return !TextUtils.isEmpty(rocketPersonal) || !TextUtils.isEmpty(rocketMerchant);
        if ("Upay".equals(selectedMethod)) return !TextUtils.isEmpty(upayPersonal) || !TextUtils.isEmpty(upayMerchant);
        return false;
    }

    private void setViewVisible(View view, boolean visible) {
        if (view == null) return;
        view.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    private void copyToClipboard(String text, String label) {
        if (TextUtils.isEmpty(text)) {
            showMessageDialog("Error", label + " not available.", "error.json");
            return;
        }

        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            ClipData clip = ClipData.newPlainText(label, text);
            clipboard.setPrimaryClip(clip);
            showMessageDialog("Success", label + " successfully copied!", "success.json");
        }
    }

    private void processVerification() {
        if (!depositOpen) {
            showDepositClosedDialog();
            return;
        }

        if (!appInfoLoaded) {
            showMessageDialog("Loading", "App data is loading. Please wait.", "info.json");
            return;
        }

        boolean anyNumberExists = !TextUtils.isEmpty(bkashPersonal) || !TextUtils.isEmpty(bkashMerchant) ||
                                  !TextUtils.isEmpty(nagadPersonal) || !TextUtils.isEmpty(nagadMerchant) ||
                                  !TextUtils.isEmpty(rocketPersonal) || !TextUtils.isEmpty(rocketMerchant) ||
                                  !TextUtils.isEmpty(upayPersonal) || !TextUtils.isEmpty(upayMerchant);

        if (!anyNumberExists) {
            showMessageDialog("Error", "Payment data is missing.", "error.json");
            return;
        }

        String trxId = binding.etTransactionId.getText() != null ? binding.etTransactionId.getText().toString().trim() : "";

        if (TextUtils.isEmpty(token)) token = pref(saveUserStatus, "Token", "token", "USER_TOKEN", "user_token");

        if (TextUtils.isEmpty(token)) {
            showMessageDialog("Error", "Token Missing", "error.json");
            return;
        }

        if (autoPayEnabled) {
            if (TextUtils.isEmpty(trxId)) {
                showMessageDialog("Error", "Transaction ID Missing", "error.json");
                return;
            }
            sendAutoPayRequest(selectedMethod, trxId);
            return;
        }

        String amount = binding.etAmount.getText() != null ? binding.etAmount.getText().toString().trim() : "";
        String number = binding.numberx.getText() != null ? binding.numberx.getText().toString().trim() : "";

        if (TextUtils.isEmpty(username)) username = pref(saveUserStatus, "username", "user_name", "name", "user");
        if (TextUtils.isEmpty(email)) email = pref(saveUserStatus, "email", "user_email");
        if (TextUtils.isEmpty(fcm)) fcm = pref(saveUserStatus, "fcm", "fcm_key", "fcmToken", "firebaseToken");
        if (TextUtils.isEmpty(authorization)) authorization = pref(saveUserStatus, "Authorization", "authorization", "key_value", "api_key", "apikey", "auth_key");
        if (TextUtils.isEmpty(authorization)) authorization = pref(apiPrefs, "Authorization", "authorization", "key_value", "api_key", "apikey", "auth_key");
        if (TextUtils.isEmpty(authorization)) {
            authorization = token;
        }

        if (TextUtils.isEmpty(username)) {
            showMessageDialog("Error", "Username Missing", "error.json");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            showMessageDialog("Error", "Email Missing", "error.json");
            return;
        }
        if (TextUtils.isEmpty(fcm)) {
            showMessageDialog("Error", "FCM Missing", "error.json");
            return;
        }
        if (TextUtils.isEmpty(authorization)) {
            showMessageDialog("Error", "Authorization Missing", "error.json");
            return;
        }
        if (TextUtils.isEmpty(amount)) {
            showMessageDialog("Error", "Amount Missing", "error.json");
            return;
        }
        if (TextUtils.isEmpty(trxId)) {
            showMessageDialog("Error", "Transaction ID Missing", "error.json");
            return;
        }
        if (TextUtils.isEmpty(number)) {
            showMessageDialog("Error", "Recipient Number Missing", "error.json");
            return;
        }

        sendAddMoneyRequest(selectedMethod, number, amount, trxId);
    }

    private void sendAutoPayRequest(String method, String trxId) {
        if (TextUtils.isEmpty(apiBase)) {
            showMessageDialog("Error", "API URL Missing", "error.json");
            return;
        }

        binding.btnVerify.setEnabled(false);
        binding.btnVerify.setText("VERIFYING...");

        StringRequest request = new StringRequest(Request.Method.POST, apiBase.concat("Xmap_autopay.js.php"),
                response -> {
                    binding.btnVerify.setText("VERIFY PAYMENT");
                    updateVerifyState();
                    String res = safeTrim(response);
                    if (TextUtils.isEmpty(res)) {
                        showMessageDialog("Error", "Empty Response", "error.json");
                        return;
                    }
                    if (res.toLowerCase().contains("success") || res.toLowerCase().contains("successful")) {
                        showMessageDialog("Success", res, "success.json");
                        binding.etTransactionId.setText("");
                    } else {
                        showMessageDialog("Information", res, "error.json");
                    }
                },
                error -> {
                    binding.btnVerify.setText("VERIFY PAYMENT");
                    updateVerifyState();
                    showMessageDialog("Network Error", buildVolleyError(error), "error.json");
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("token", token);
                params.put("method", method);
                params.put("trxid", trxId);
                return params;
            }
        };

        request.setRetryPolicy(new DefaultRetryPolicy(15000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(request);
    }

    private void sendAddMoneyRequest(String method, String number, String amount, String trxId) {
        if (TextUtils.isEmpty(apiBase)) {
            showMessageDialog("Error", "API URL Missing", "error.json");
            return;
        }

        binding.btnVerify.setEnabled(false);
        binding.btnVerify.setText("VERIFYING...");

        StringRequest request = new StringRequest(Request.Method.POST, apiBase.concat("addmoney.php"),
                response -> {
                    binding.btnVerify.setText("VERIFY PAYMENT");
                    updateVerifyState();
                    String res = safeTrim(response);
                    if (TextUtils.isEmpty(res)) {
                        showMessageDialog("Error", "Empty Response", "error.json");
                        return;
                    }
                    if (res.toLowerCase().contains("success") || res.toLowerCase().contains("successful")) {
                        showMessageDialog("Success", res, "success.json");
                        binding.etAmount.setText("");
                        binding.etTransactionId.setText("");
                    } else {
                        showMessageDialog("Information", res, "error.json");
                    }
                },
                error -> {
                    binding.btnVerify.setText("VERIFY PAYMENT");
                    updateVerifyState();
                    showMessageDialog("Network Error", buildVolleyError(error), "error.json");
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("type", "requestxstrong");
                params.put("username", username);
                params.put("email", email);
                params.put("method", method);
                params.put("number", number);
                params.put("amount", amount);
                params.put("trxid", trxId);
                params.put("fcm", fcm);
                params.put("Authorization", authorization);
                params.put("token", token);
                return params;
            }
        };

        request.setRetryPolicy(new DefaultRetryPolicy(15000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(request);
    }

    private void showMessageDialog(String title, String message, String lottieFile) {
        new PremiumDialog.Builder(ZabbarAddWalletActivity.this)
                .setDialogType(true)
                .setCancelable(false)
                .setBlurBackground(true)
                .setLottie(lottieFile)
                .setTitle(title)
                .setMessage(message)
                .setNegativeButton("Close", dialog -> dialog.dismiss())
                .setPositiveButton("OK", "#004F50", dialog -> dialog.dismiss())
                .show();
    }

    private void showDepositClosedDialog() {
        new PremiumDialog.Builder(ZabbarAddWalletActivity.this)
                .setDialogType(true)
                .setCancelable(false)
                .setBlurBackground(true)
                .setLottie("withdraw_closed.json")
                .setTitle("Deposit Closed")
                .setMessage("Deposit বর্তমানে বন্ধ রয়েছে।\n\nঅনুগ্রহ করে পরে আবার চেষ্টা করুন।")
                .setNegativeButton("Exit", dialog -> {
                    dialog.dismiss();
                    finish();
                })
                .setPositiveButton("OK", "#004F50", dialog -> {
                    dialog.dismiss();
                    finish();
                })
                .show();
    }

    private void updateVerifyState() {
        boolean anyNumberExists = !TextUtils.isEmpty(bkashPersonal) || !TextUtils.isEmpty(bkashMerchant) ||
                                  !TextUtils.isEmpty(nagadPersonal) || !TextUtils.isEmpty(nagadMerchant) ||
                                  !TextUtils.isEmpty(rocketPersonal) || !TextUtils.isEmpty(rocketMerchant) ||
                                  !TextUtils.isEmpty(upayPersonal) || !TextUtils.isEmpty(upayMerchant);
                                  
        boolean ready = appInfoLoaded && depositOpen && anyNumberExists;
        binding.btnVerify.setEnabled(ready);
        binding.btnVerify.setAlpha(ready ? 1f : 0.5f);
    }

    private String buildMissingUserMessage() {
        StringBuilder sb = new StringBuilder();
        if (TextUtils.isEmpty(token)) sb.append("Token Missing");
        if (TextUtils.isEmpty(username)) appendLine(sb, "Username Missing");
        if (TextUtils.isEmpty(email)) appendLine(sb, "Email Missing");
        if (TextUtils.isEmpty(fcm)) appendLine(sb, "FCM Missing");
        if (TextUtils.isEmpty(authorization)) appendLine(sb, "Authorization Missing");
        return sb.length() == 0 ? "User Data Missing" : sb.toString();
    }

    private void appendLine(StringBuilder sb, String text) {
        if (sb.length() > 0) sb.append("\n");
        sb.append(text);
    }

    private String opt(JSONObject obj, String... keys) {
        for (String key : keys) {
            String value = obj.optString(key, "");
            if (!TextUtils.isEmpty(value) && !"null".equalsIgnoreCase(value.trim())) return value.trim();
        }
        return "";
    }

    private String pref(SharedPreferences prefs, String... keys) {
        for (String key : keys) {
            String value = prefs.getString(key, "");
            if (!TextUtils.isEmpty(value)) return value.trim();
        }
        return "";
    }

    private String safeTrim(String s) {
        return s == null ? "" : s.trim();
    }

    private String safeText(String response, String fallback) {
        String s = safeTrim(response);
        return TextUtils.isEmpty(s) ? fallback : s;
    }

    private String buildVolleyError(VolleyError error) {
        if (error == null) return "Network Error";
        if (error.networkResponse != null) {
            int code = error.networkResponse.statusCode;
            String body = "";
            try {
                if (error.networkResponse.data != null) {
                    body = new String(error.networkResponse.data, StandardCharsets.UTF_8).trim();
                }
            } catch (Exception ignored) {
            }
            if (!TextUtils.isEmpty(body)) return "HTTP " + code + ": " + body;
            return "HTTP " + code;
        }
        String msg = error.getMessage();
        if (!TextUtils.isEmpty(msg)) return msg;
        return "Network Error";
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private static class SSLHelper {
        public static void trustAllCertificates() {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }
                    }
            };

            try {
                SSLContext sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, trustAllCerts, new SecureRandom());
                HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
                HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String hostname, SSLSession session) {
                        return true;
                    }
                });
            } catch (KeyManagementException | NoSuchAlgorithmException e) {
            }
        }
    }
}
