package com.image.silder;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ZabbarSliderManager {

    private final Activity activity;
    private final CardView cardView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ViewPager2 viewPager2;
    private LinearLayout indicatorContainer;
    private View[] indicators;
    private String[] sliderList;
    private SliderAdapter adapter;
    private final LruCache<String, Bitmap> memoryCache;

    private final Runnable sliderRunnable = new Runnable() {
        @Override
        public void run() {
            if (viewPager2 == null || viewPager2.getAdapter() == null) return;
            int count = viewPager2.getAdapter().getItemCount();
            if (count <= 1) return;
            int current = viewPager2.getCurrentItem();
            syncSliderToPage((current == count - 1) ? 0 : current + 1);
            handler.postDelayed(this, 3000);
        }
    };

    public ZabbarSliderManager(Activity activity, CardView cardView, String[] imageUrls) {
        this.activity = activity;
        this.cardView = cardView;
        this.sliderList = imageUrls != null ? imageUrls : new String[0];

        int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
        int cacheSize = maxMemory / 8;
        memoryCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount() / 1024;
            }
        };

        setupViews();
        setupPager();
        processImages();
    }

    public void updateImages(String[] newUrls) {
        this.sliderList = newUrls != null ? newUrls : new String[0];
        if (adapter != null) {
            adapter.updateData(this.sliderList);
        }
        processImages();
    }

    private void setupViews() {
        cardView.removeAllViews();

        viewPager2 = new ViewPager2(activity);
        viewPager2.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        cardView.addView(viewPager2);

        BlurView blurView = new BlurView(activity);
        FrameLayout.LayoutParams blurParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blurParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        blurParams.bottomMargin = dpToPx(8);
        blurView.setLayoutParams(blurParams);
        blurView.setPadding(dpToPx(14), dpToPx(6), dpToPx(14), dpToPx(6));

        GradientDrawable blurBackground = new GradientDrawable();
        blurBackground.setShape(GradientDrawable.RECTANGLE);
        blurBackground.setCornerRadius(dpToPx(100));
        blurBackground.setColor(Color.parseColor("#4DFFFFFF"));
        blurView.setBackground(blurBackground);
        blurView.setClipToOutline(true);

        try {
            blurView.setupWith(cardView, new RenderScriptBlur(activity)).setBlurRadius(10f);
        } catch (Exception e) {
            e.printStackTrace();
        }

        indicatorContainer = new LinearLayout(activity);
        indicatorContainer.setOrientation(LinearLayout.HORIZONTAL);
        indicatorContainer.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        blurView.addView(indicatorContainer);

        cardView.addView(blurView);
    }

    private void setupPager() {
        adapter = new SliderAdapter(sliderList);
        viewPager2.setAdapter(adapter);

        CompositePageTransformer transformer = new CompositePageTransformer();
        transformer.addTransformer(new MarginPageTransformer(40));
        transformer.addTransformer((page, position) -> page.setScaleY(0.85f + (1 - Math.abs(position)) * 0.15f));
        viewPager2.setPageTransformer(transformer);

        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                if (indicators != null && !viewPager2.isFakeDragging()) {
                    for (int i = 0; i < indicators.length; i++) animateIndicator(indicators[i], i == position);
                }
                handler.removeCallbacks(sliderRunnable);
                if (sliderList.length > 1) handler.postDelayed(sliderRunnable, 3000);
            }
        });
    }

    private void processImages() {
        createIndicators(sliderList.length);
        if (sliderList.length > 0) {
            animateIndicator(indicators[0], true);
            viewPager2.setCurrentItem(0, false);
            handler.removeCallbacks(sliderRunnable);
            if (sliderList.length > 1) handler.postDelayed(sliderRunnable, 3000);
        }
    }

    private void syncSliderToPage(int target) {
        if (viewPager2 == null || viewPager2.getAdapter() == null) return;
        int current = viewPager2.getCurrentItem();
        if (current == target) return;
        int width = viewPager2.getWidth();
        if (width <= 0) {
            viewPager2.setCurrentItem(target, true);
            return;
        }
        if (indicators != null) {
            for (int i = 0; i < indicators.length; i++) animateIndicator(indicators[i], i == target);
        }
        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        final float[] lastFraction = {0f};
        int distance = width * (target - current);
        animator.addUpdateListener(animation -> {
            float fraction = animation.getAnimatedFraction();
            float deltaPx = (fraction - lastFraction[0]) * distance;
            if (viewPager2.isFakeDragging()) viewPager2.fakeDragBy(-deltaPx);
            lastFraction[0] = fraction;
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) { viewPager2.beginFakeDrag(); }
            @Override
            public void onAnimationEnd(Animator animation) {
                if (viewPager2.isFakeDragging()) viewPager2.endFakeDrag();
                viewPager2.setCurrentItem(target, false);
            }
        });
        animator.setDuration(600).start();
    }

    private void createIndicators(int count) {
        indicatorContainer.removeAllViews();
        indicators = new View[count];
        for (int i = 0; i < count; i++) {
            indicators[i] = new View(activity);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dpToPx(8), dpToPx(8));
            params.setMargins(dpToPx(4), 0, dpToPx(4), 0);
            indicators[i].setLayoutParams(params);

            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.RECTANGLE);
            drawable.setCornerRadius(dpToPx(100));
            drawable.setColor(Color.parseColor("#FFFFFF"));
            indicators[i].setBackground(drawable);
            indicators[i].setAlpha(0.4f);
            indicatorContainer.addView(indicators[i]);
        }
    }

    private void animateIndicator(View view, boolean isActive) {
        if (view == null) return;
        ViewGroup.LayoutParams params = view.getLayoutParams();
        int currentWidth = params.width == 0 ? dpToPx(8) : params.width;
        ValueAnimator animator = ValueAnimator.ofInt(currentWidth, isActive ? dpToPx(35) : dpToPx(8));
        animator.addUpdateListener(animation -> {
            ViewGroup.LayoutParams lp = view.getLayoutParams();
            lp.width = (int) animation.getAnimatedValue();
            view.setLayoutParams(lp);
        });
        animator.setDuration(600).start();
        view.animate().alpha(isActive ? 1.0f : 0.4f).setDuration(600).start();
    }

    private int dpToPx(int dp) {
        return (int) (dp * activity.getResources().getDisplayMetrics().density);
    }

    public void stop() {
        handler.removeCallbacks(sliderRunnable);
    }

    public void onPause() {
        stop();
    }

    public void onResume() {
        if (sliderList.length > 1) handler.postDelayed(sliderRunnable, 3000);
    }

    public class SliderAdapter extends RecyclerView.Adapter<SliderAdapter.SliderViewHolder> {
        private String[] imageList;
        private final ExecutorService executor = Executors.newCachedThreadPool();
        private final Handler adapterHandler = new Handler(Looper.getMainLooper());
        private final Set<String> loadedUrls = new HashSet<>();

        SliderAdapter(String[] list) { this.imageList = list; }

        public void updateData(String[] newList) {
            this.imageList = newList;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public SliderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            FrameLayout frameLayout = new FrameLayout(parent.getContext());
            frameLayout.setLayoutParams(new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            frameLayout.setBackgroundColor(Color.BLACK);

            ImageView imageView = new ImageView(parent.getContext());
            imageView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

            ProgressBar progressBar = new ProgressBar(parent.getContext());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                progressBar.setIndeterminateTintList(ColorStateList.valueOf(Color.WHITE));
            } else {
                progressBar.getIndeterminateDrawable().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
            }

            float density = parent.getContext().getResources().getDisplayMetrics().density;
            int pbSize = (int) (42 * density);
            FrameLayout.LayoutParams pbParams = new FrameLayout.LayoutParams(pbSize, pbSize);
            pbParams.gravity = Gravity.CENTER;
            progressBar.setLayoutParams(pbParams);

            frameLayout.addView(imageView);
            frameLayout.addView(progressBar);

            return new SliderViewHolder(frameLayout, imageView, progressBar);
        }

        @Override
        public void onBindViewHolder(@NonNull SliderViewHolder holder, int position) {
            String tempUrl = imageList[position];
            
            if (tempUrl != null && !tempUrl.isEmpty()) {
                tempUrl = tempUrl.trim();
                if (tempUrl.startsWith("http://")) {
                    tempUrl = tempUrl.replace("http://", "https://");
                }
                tempUrl = tempUrl.replace(" ", "%20");
            }

            final String finalUrl = tempUrl;

            if (finalUrl == null || finalUrl.isEmpty()) {
                holder.progressBar.setVisibility(View.GONE);
                return;
            }

            if (loadedUrls.contains(finalUrl)) {
                Bitmap memBitmap = memoryCache.get(finalUrl);
                if (memBitmap != null) {
                    holder.imageView.setImageBitmap(memBitmap);
                } else {
                    String fileName = "zabbar_cache_" + finalUrl.hashCode() + ".png";
                    File cacheFile = new File(activity.getCacheDir(), fileName);
                    if (cacheFile.exists()) {
                        Bitmap diskBitmap = BitmapFactory.decodeFile(cacheFile.getAbsolutePath());
                        if (diskBitmap != null) {
                            memoryCache.put(finalUrl, diskBitmap);
                            holder.imageView.setImageBitmap(diskBitmap);
                        }
                    }
                }
                holder.progressBar.setVisibility(View.GONE);
                holder.imageView.setVisibility(View.VISIBLE);
                return;
            }

            holder.imageView.setVisibility(View.INVISIBLE);
            holder.progressBar.setVisibility(View.VISIBLE);

            long startTime = System.currentTimeMillis();

            executor.execute(() -> {
                Bitmap bitmap = null;
                try {
                    String fileName = "zabbar_cache_" + finalUrl.hashCode() + ".png";
                    File cacheFile = new File(activity.getCacheDir(), fileName);
                    if (cacheFile.exists()) {
                        bitmap = BitmapFactory.decodeFile(cacheFile.getAbsolutePath());
                        if (bitmap != null) {
                            memoryCache.put(finalUrl, bitmap);
                        }
                    }
                    if (bitmap == null) {
                        HttpURLConnection conn = (HttpURLConnection) new URL(finalUrl).openConnection();
                        conn.setConnectTimeout(5000);
                        conn.setReadTimeout(5000);
                        InputStream in = conn.getInputStream();
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] buffer = new byte[16384];
                        int read;
                        while ((read = in.read(buffer)) != -1) {
                            bos.write(buffer, 0, read);
                        }
                        in.close();
                        conn.disconnect();
                        byte[] imageData = bos.toByteArray();
                        if (imageData.length > 0) {
                            bitmap = BitmapFactory.decodeByteArray(imageData, 0, imageData.length);
                            if (bitmap != null) {
                                memoryCache.put(finalUrl, bitmap);
                                try (FileOutputStream out = new FileOutputStream(cacheFile)) {
                                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                final Bitmap finalBitmap = bitmap;
                long elapsed = System.currentTimeMillis() - startTime;
                long remaining = Math.max(0, 1000 - elapsed);

                adapterHandler.postDelayed(() -> {
                    if (holder.progressBar.getVisibility() == View.VISIBLE) {
                        if (finalBitmap != null) {
                            holder.imageView.setImageBitmap(finalBitmap);
                            loadedUrls.add(finalUrl);
                        }
                        holder.progressBar.setVisibility(View.GONE);
                        holder.imageView.setVisibility(View.VISIBLE);
                    }
                }, remaining);
            });
        }

        @Override
        public int getItemCount() { return imageList.length; }

        class SliderViewHolder extends RecyclerView.ViewHolder {
            ImageView imageView;
            ProgressBar progressBar;

            SliderViewHolder(@NonNull View itemView, ImageView imageView, ProgressBar progressBar) {
                super(itemView);
                this.imageView = imageView;
                this.progressBar = progressBar;
            }
        }
    }
}