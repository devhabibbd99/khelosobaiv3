package com.khelosobaiv3.user;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ZabbarHomeActivity extends AppCompatActivity {
    private ZabbarClessHome delegate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        delegate = new ZabbarClessHome(this);
        delegate.onCreate(savedInstanceState);
    }

    @Override
    protected void onStart() {
        SecurityChecker.check(this);
        super.onStart();
        delegate.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        delegate.onResume();
    }

    @Override
    public void onBackPressed() {
        delegate.onBackPressed();
    }
}