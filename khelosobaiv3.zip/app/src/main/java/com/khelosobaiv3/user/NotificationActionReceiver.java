package com.khelosobaiv3.user;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import androidx.core.app.RemoteInput;

public class NotificationActionReceiver extends BroadcastReceiver {

    private static final String TAG = "NotifAction";

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            String actionType = intent.getStringExtra("action_type");
            if (actionType == null) actionType = "open_activity";

            switch (actionType.toLowerCase()) {
                case "reply": {
                    CharSequence reply = RemoteInput.getResultsFromIntent(intent)
                            .getCharSequence(MyFirebaseMessagingService.KEY_REPLY_TEXT);

                    Intent replyIntent = new Intent(context, MainActivity.class);
                    replyIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    replyIntent.putExtra("INLINE_REPLY_TEXT", reply != null ? reply.toString() : "");
                    context.startActivity(replyIntent);
                    break;
                }

                case "open_url": {
                    String url = intent.getStringExtra("target_url");
                    if (url != null && !url.trim().isEmpty()) {
                        Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(web);
                    }
                    break;
                }

                case "open_activity":
                default: {
                    String activityName = intent.getStringExtra("target_activity");
                    Class<?> target = resolveActivityClass(context, activityName);

                    Intent open = new Intent(context, target);
                    open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

                    String extraData = intent.getStringExtra("extra_data");
                    if (extraData != null) open.putExtra("EXTRA_DATA", extraData);

                    context.startActivity(open);
                    break;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Notification action failed", e);
        }
    }

    private Class<?> resolveActivityClass(Context context, String activityName) {
        try {
            if (activityName == null || activityName.trim().isEmpty()) {
                return MainActivity.class;
            }

            String clean = activityName.trim();

            if (clean.toLowerCase().endsWith(".java")) {
                clean = clean.substring(0, clean.length() - 5);
            }

            if (clean.startsWith(".")) {
                clean = context.getPackageName() + clean;
            } else if (!clean.contains(".")) {
                clean = context.getPackageName() + "." + clean;
            }

            return Class.forName(clean);
        } catch (Exception e) {
            return MainActivity.class;
        }
    }
}