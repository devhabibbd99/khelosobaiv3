package com.khelosobaiv3.user;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ZabbarLeaderboardActivity extends AppCompatActivity {

    private ZabbarLeaderboardBinding binding;
    private RequestQueue requestQueue;
    private final ArrayList<LeaderboardUser> leaderboardList = new ArrayList<>();
    private String currentUsername = "";
    private int pendingRequests = 0;
    private static final String BASE_URL = "https://api.khelosobai20.live/ElitegoxUser/XMapp_Rank.js.php";
    private static final String URL_LEADERBOARD = BASE_URL + "?type=leaderboard";
    private static final String URL_POSITION = BASE_URL + "?type=position&username=";
    private static final String MY_PROFILE_URL = "";
    private final ExecutorService imageExecutor = Executors.newCachedThreadPool();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ZabbarLeaderboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        FirebaseApp.initializeApp(this);
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        initializeLogic();
        ZabbarNavigation.INSTANCE.setup(this);
    }

    private void initializeLogic() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        binding.appIcon.setOnClickListener(v -> finish());

        ViewGroup rootView = (ViewGroup) getWindow().getDecorView();
        Drawable windowBackground = rootView.getBackground();
        if (windowBackground == null) windowBackground = new ColorDrawable(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            binding.blurView.setupWith(rootView, new RenderEffectBlur()).setFrameClearDrawable(windowBackground).setBlurRadius(5f).setBlurAutoUpdate(true);
            binding.blurViewBottom.setupWith(rootView, new RenderEffectBlur()).setFrameClearDrawable(windowBackground).setBlurRadius(5f).setBlurAutoUpdate(true);
        } else {
            binding.blurView.setupWith(rootView, new RenderScriptBlur(this)).setFrameClearDrawable(windowBackground).setBlurRadius(5f).setBlurAutoUpdate(true);
            binding.blurViewBottom.setupWith(rootView, new RenderScriptBlur(this)).setFrameClearDrawable(windowBackground).setBlurRadius(5f).setBlurAutoUpdate(true);
        }

        currentUsername = getCurrentUsername();

        binding.imageview1.setOnClickListener(v -> {
            ObjectAnimator rotate = ObjectAnimator.ofFloat(binding.imageview1, "rotation", 0f, 360f);
            rotate.setDuration(900);
            rotate.setRepeatCount(0);
            rotate.setInterpolator(new LinearInterpolator());
            rotate.start();
            loadAllData();
        });

        loadAllData();
    }

    private String getCurrentUsername() {
        String u = getIntent().getStringExtra("username");
        if (TextUtils.isEmpty(u)) u = getIntent().getStringExtra("Username");
        if (TextUtils.isEmpty(u)) u = getSharedPreferences("app_prefs", MODE_PRIVATE).getString("Username", "");
        if (TextUtils.isEmpty(u)) u = getSharedPreferences("Save_User_Status", MODE_PRIVATE).getString("Username", "");
        return u == null ? "" : u.trim();
    }

    private void loadAllData() {
        leaderboardList.clear();
        showLoading(true);
        pendingRequests = 1;
        if (!TextUtils.isEmpty(currentUsername)) pendingRequests = 2;
        else binding.myStickyPositionLayout.setVisibility(View.GONE);
        requestLeaderboard();
        if (!TextUtils.isEmpty(currentUsername)) {
            if (!TextUtils.isEmpty(MY_PROFILE_URL)) requestMyProfile(currentUsername);
            else requestMyPosition(currentUsername);
        }
    }

    private StringRequest newUtf8GetRequest(String url, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        return new StringRequest(Request.Method.GET, url, listener, errorListener) {
            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String parsed = new String(response.data, "UTF-8");
                    return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
                } catch (Exception e) {
                    return super.parseNetworkResponse(response);
                }
            }
        };
    }

    private StringRequest newUtf8PostRequest(String url, Map<String, String> params, Response.Listener<String> listener, Response.ErrorListener errorListener) {
        return new StringRequest(Request.Method.POST, url, listener, errorListener) {
            @Override
            protected Map<String, String> getParams() {
                return params;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String parsed = new String(response.data, "UTF-8");
                    return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
                } catch (Exception e) {
                    return super.parseNetworkResponse(response);
                }
            }
        };
    }

    private void requestLeaderboard() {
        StringRequest request = newUtf8GetRequest(URL_LEADERBOARD, response -> {
            try {
                ArrayList<LeaderboardUser> list = parseLeaderboardResponse(response);
                leaderboardList.clear();
                leaderboardList.addAll(list);
                renderLeaderboard(list);
                if (TextUtils.isEmpty(MY_PROFILE_URL) && !TextUtils.isEmpty(currentUsername)) {
                    LeaderboardUser me = findUserByUsername(list, currentUsername);
                    if (me != null) renderMyPosition(me);
                }
            } catch (Exception e) {
                Toast.makeText(this, "Leaderboard parse error", Toast.LENGTH_SHORT).show();
            }
            finishOneRequest();
        }, error -> {
            Toast.makeText(this, "Leaderboard load failed", Toast.LENGTH_SHORT).show();
            finishOneRequest();
        });
        request.setRetryPolicy(new DefaultRetryPolicy(12000, 2, 1.5f));
        requestQueue.add(request);
    }

    private void requestMyPosition(String username) {
        String url = URL_POSITION + encode(username);
        StringRequest request = newUtf8GetRequest(url, response -> {
            try {
                LeaderboardUser user = parseSingleUserResponse(response);
                if (user != null) {
                    renderMyPosition(user);
                } else {
                    LeaderboardUser me = findUserByUsername(leaderboardList, currentUsername);
                    if (me != null) renderMyPosition(me);
                    else binding.myStickyPositionLayout.setVisibility(View.GONE);
                }
            } catch (Exception e) {
                LeaderboardUser me = findUserByUsername(leaderboardList, currentUsername);
                if (me != null) renderMyPosition(me);
                else binding.myStickyPositionLayout.setVisibility(View.GONE);
            }
            finishOneRequest();
        }, error -> {
            LeaderboardUser me = findUserByUsername(leaderboardList, currentUsername);
            if (me != null) renderMyPosition(me);
            else binding.myStickyPositionLayout.setVisibility(View.GONE);
            finishOneRequest();
        });
        request.setRetryPolicy(new DefaultRetryPolicy(12000, 2, 1.5f));
        requestQueue.add(request);
    }

    private void requestMyProfile(String username) {
        String url = MY_PROFILE_URL + encode(username);
        StringRequest request = newUtf8GetRequest(url, response -> {
            try {
                bindMyProfileFromJson(response);
            } catch (Exception ignored) {
            }
        }, error -> {
        });
        request.setRetryPolicy(new DefaultRetryPolicy(12000, 2, 1.5f));
        requestQueue.add(request);
    }

    private void finishOneRequest() {
        pendingRequests--;
        if (pendingRequests <= 0) {
            pendingRequests = 0;
            showLoading(false);
        }
    }

    private ArrayList<LeaderboardUser> parseLeaderboardResponse(String response) throws Exception {
        ArrayList<LeaderboardUser> list = new ArrayList<>();
        String trimmed = response == null ? "" : response.trim();
        if (trimmed.startsWith("[")) {
            JSONArray arr = new JSONArray(trimmed);
            for (int i = 0; i < arr.length(); i++) list.add(readUser(arr.getJSONObject(i), i + 1));
        } else if (trimmed.startsWith("{")) {
            JSONObject obj = new JSONObject(trimmed);
            if (obj.has("message") && "No Users Found".equalsIgnoreCase(obj.optString("message", ""))) return list;
        }
        return list;
    }

    private LeaderboardUser parseSingleUserResponse(String response) throws Exception {
        String trimmed = response == null ? "" : response.trim();
        if (trimmed.startsWith("{")) {
            JSONObject obj = new JSONObject(trimmed);
            if (obj.has("message")) return null;
            return readUser(obj, obj.optInt("position", 0));
        }
        return null;
    }

    private boolean isVerifiedBadgeRaw(String raw) {
        if (raw == null) return false;
        String v = raw.trim().toLowerCase(Locale.US);
        return "1".equals(v) || "yes".equals(v) || "true".equals(v) || "verified".equals(v);
    }

    private boolean isDevBadgeRaw(String raw) {
        if (raw == null) return false;
        String v = raw.trim().toLowerCase(Locale.US);
        return v.contains("dev");
    }

    private boolean isDevUsername(String username) {
        if (username == null) return false;
        String v = username.trim().toLowerCase(Locale.US);
        return v.equals("found_null") || v.contains("found_null") || v.equals("dev");
    }

    private LeaderboardUser readUser(JSONObject obj, int fallbackPosition) {
        String username = obj.optString("username", "");
        double totalWin = obj.optDouble("total_win", 0);
        int totalPlay = obj.optInt("total_play", 0);
        String profilePic = obj.optString("profile_pic", "");
        String verifyBadgeRaw = obj.optString("verify_badge", "");
        int position = obj.optInt("position", fallbackPosition);

        boolean devBadge = isDevBadgeRaw(verifyBadgeRaw) || isDevUsername(username);
        boolean verifiedBadge = !devBadge && isVerifiedBadgeRaw(verifyBadgeRaw);

        return new LeaderboardUser(username, totalWin, totalPlay, profilePic, verifyBadgeRaw, verifiedBadge, devBadge, position);
    }

    private void renderLeaderboard(ArrayList<LeaderboardUser> list) {
        if (list == null) return;

        if (list.size() > 0) {
            LeaderboardUser u = list.get(0);
            bindTopCard(binding.txtName1, binding.txtUid1, binding.txtWon1, binding.imgRank1, u, 1);
            bindBadgeViews(binding.rank1Layout, u);
            binding.rank1Layout.setVisibility(View.VISIBLE);
            binding.imgRank1.setOnClickListener(v -> showBottomSheet(u));
        } else binding.rank1Layout.setVisibility(View.GONE);

        if (list.size() > 1) {
            LeaderboardUser u = list.get(1);
            bindTopCard(binding.txtName2, binding.txtUid2, binding.txtWon2, binding.imgRank2, u, 2);
            bindBadgeViews(binding.rank2Layout, u);
            binding.rank2Layout.setVisibility(View.VISIBLE);
            binding.imgRank2.setOnClickListener(v -> showBottomSheet(u));
        } else binding.rank2Layout.setVisibility(View.GONE);

        if (list.size() > 2) {
            LeaderboardUser u = list.get(2);
            bindTopCard(binding.txtName3, binding.txtUid3, binding.txtWon3, binding.imgRank3, u, 3);
            bindBadgeViews(binding.rank3Layout, u);
            binding.rank3Layout.setVisibility(View.VISIBLE);
            binding.imgRank3.setOnClickListener(v -> showBottomSheet(u));
        } else binding.rank3Layout.setVisibility(View.GONE);

        binding.playersContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);

        for (int i = 3; i < list.size(); i++) {
            LeaderboardUser user = list.get(i);
            View itemView = inflater.inflate(R.layout.zabbarx_leaderboard, binding.playersContainer, false);
            TextView rankText = itemView.findViewById(R.id.item_rank);
            TextView nameText = itemView.findViewById(R.id.item_name);
            TextView uidText = itemView.findViewById(R.id.item_uid);
            TextView wonText = itemView.findViewById(R.id.item_won);
            ImageView profileImg = itemView.findViewById(R.id.item_profile_img);

            rankText.setText(formatRank(user.position));
            setSafeText(nameText, displayName(user), 20);
            setSafeText(uidText, "@" + safe(user.username), 24);
            wonText.setText("Won: ৳ " + formatMoney(user.totalWin));
            loadAvatar(profileImg, user.profilePic, user.username);
            bindBadgeViews(itemView, user);

            if (!TextUtils.isEmpty(currentUsername) && currentUsername.equalsIgnoreCase(safe(user.username))) {
                itemView.setBackgroundColor(Color.parseColor("#14FFFFFF"));
            }

            itemView.setOnClickListener(v -> showBottomSheet(user));
            itemView.setAlpha(0f);
            itemView.setTranslationY(90f);
            itemView.animate().alpha(1f).translationY(0f).setDuration(320).setStartDelay((i - 3) * 30L).setInterpolator(new DecelerateInterpolator()).start();
            binding.playersContainer.addView(itemView);
        }

        if (list.isEmpty()) Toast.makeText(this, "No Users Found", Toast.LENGTH_SHORT).show();
    }

    private void bindTopCard(TextView nameView, TextView uidView, TextView wonView, ImageView imageView, LeaderboardUser user, int topIndex) {
        setSafeText(nameView, displayName(user), 20);
        setSafeText(uidView, topEmoji(topIndex) + " @" + safe(user.username) + " • " + formatRank(user.position), 32);
        wonView.setText("Won: ৳ " + formatMoney(user.totalWin));
        loadAvatar(imageView, user.profilePic, user.username);
    }

    private void bindBadgeViews(View root, LeaderboardUser user) {
        if (root == null || user == null) return;

        View verifiedContainer = root.findViewById(R.id.item_verified_lottie);
        if (verifiedContainer == null) verifiedContainer = root.findViewById(R.id.lottie11);

        View devContainer = root.findViewById(R.id.item_dev_lottie);
        if (devContainer == null) devContainer = root.findViewById(R.id.lottie12);

        if (verifiedContainer instanceof LottieAnimationView) {
            LottieAnimationView verifiedView = (LottieAnimationView) verifiedContainer;
            if (user.verifiedBadge && !user.devBadge) {
                verifiedView.setVisibility(View.VISIBLE);
                verifiedView.setAnimation("verified.json");
                verifiedView.playAnimation();
            } else {
                verifiedView.cancelAnimation();
                verifiedView.setVisibility(View.GONE);
            }
        }

        if (devContainer instanceof LottieAnimationView) {
            LottieAnimationView devView = (LottieAnimationView) devContainer;
            if (user.devBadge) {
                devView.setVisibility(View.VISIBLE);
                devView.setAnimation("dev.json");
                devView.playAnimation();
            } else {
                devView.cancelAnimation();
                devView.setVisibility(View.GONE);
            }
        }
    }

    private void renderMyPosition(LeaderboardUser user) {
        binding.myStickyPositionLayout.setVisibility(View.VISIBLE);
        binding.txtMyRank.setText(formatRank(user.position));
        setSafeText(binding.txtMyName, displayName(user), 22);
        setSafeText(binding.txtMyUid, "@" + safe(user.username), 24);
        binding.txtMyWon.setText("Won: ৳ " + formatMoney(user.totalWin));
        loadAvatar(binding.imgMyProfile, user.profilePic, user.username);
        bindBadgeViews(binding.myStickyPositionLayout, user);
        binding.myStickyPositionLayout.setOnClickListener(v -> showBottomSheet(user));
    }

    private void bindMyProfileFromJson(String response) {
        try {
            Gson gson = new Gson();
            Type type = new TypeToken<HashMap<String, Object>>() {}.getType();
            HashMap<String, Object> map = gson.fromJson(response, type);
            if (map == null) return;

            String username = getStringValue(map, "username");
            String uid = getStringValue(map, "uid");
            String balance = getStringValue(map, "balance");
            String winning = getStringValue(map, "winning");
            String totalPlay = getStringValue(map, "total_play");
            String totalWin = getStringValue(map, "total_win");
            String totalKill = getStringValue(map, "total_kill");
            String email = getStringValue(map, "email");
            String fcmKey = getStringValue(map, "fcm_key");
            String status = getStringValue(map, "status");
            String profilePic = getStringValue(map, "profile_pic");

            if (!TextUtils.isEmpty(username)) currentUsername = username.trim();

            SharedPreferencesCompat.save(this, "Save_User_Status", "Email", email);
            SharedPreferencesCompat.save(this, "Save_User_Status", "Fcm", fcmKey);
            SharedPreferencesCompat.save(this, "Save_User_Status", "Username", username);
            SharedPreferencesCompat.save(this, "Save_User_Status", "Uid", uid);
            SharedPreferencesCompat.save(this, "Save_User_Status", "Balance", balance);
            SharedPreferencesCompat.save(this, "Save_User_Status", "Winning", winning);
            SharedPreferencesCompat.save(this, "Save_User_Status", "TotalPlay", totalPlay);
            SharedPreferencesCompat.save(this, "Save_User_Status", "TotalWin", totalWin);
            SharedPreferencesCompat.save(this, "Save_User_Status", "TotalKill", totalKill);
            SharedPreferencesCompat.save(this, "Save_User_Status", "Status", status);
            SharedPreferencesCompat.save(this, "Save_User_Status", "ProfilePic", profilePic);

            binding.myStickyPositionLayout.setVisibility(View.VISIBLE);
            binding.txtMyRank.setText("#-");
            setSafeText(binding.txtMyName, username, 22);
            setSafeText(binding.txtMyUid, "UID : " + uid, 24);
            binding.txtMyWon.setText("Won: ৳ " + formatMoneyFromRaw(totalWin));
            loadAvatar(binding.imgMyProfile, profilePic, username);

            if ("Ban".equalsIgnoreCase(status)) Toast.makeText(this, "Account Banned", Toast.LENGTH_LONG).show();
        } catch (Exception ignored) {
        }
    }

    private void showBottomSheet(LeaderboardUser user) {
        if (user == null) return;

        ViewGroup decorView = (ViewGroup) getWindow().getDecorView();
        BlurView blurOverlay = new BlurView(this);
        blurOverlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Drawable windowBackground = decorView.getBackground();
        if (windowBackground == null) windowBackground = new ColorDrawable(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blurOverlay.setupWith(decorView, new RenderEffectBlur()).setFrameClearDrawable(windowBackground).setBlurRadius(2f).setBlurAutoUpdate(true);
        } else {
            blurOverlay.setupWith(decorView, new RenderScriptBlur(this)).setFrameClearDrawable(windowBackground).setBlurRadius(2f).setBlurAutoUpdate(true);
        }

        decorView.addView(blurOverlay);
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.ZabbarX9);
        View sheetView = LayoutInflater.from(this).inflate(R.layout.zabbar_sheet, null);

        int sheetColor = ContextCompat.getColor(this, R.color.md_theme_tertiaryFixed_highContrast);
        GradientDrawable rootBg = new GradientDrawable();
        rootBg.setShape(GradientDrawable.RECTANGLE);
        rootBg.setColor(sheetColor);
        rootBg.setCornerRadii(new float[]{dp(28), dp(28), dp(28), dp(28), 0f, 0f, 0f, 0f});
        sheetView.setBackground(rootBg);

        TextView nameView = sheetView.findViewById(R.id.name_view);
        TextView uidView = sheetView.findViewById(R.id.uid_view);
        TextView winValue = sheetView.findViewById(R.id.win_value);
        TextView totalPlayView = sheetView.findViewById(R.id.textview77);
        ImageView sheetProfileImage = sheetView.findViewById(R.id.imageview23);

        setSafeText(nameView, displayName(user), 24);
        setSafeText(uidView, "@" + safe(user.username) + " • " + formatRank(user.position), 34);
        winValue.setText("৳ " + formatMoney(user.totalWin));
        totalPlayView.setText(String.valueOf(user.totalPlay));
        loadAvatar(sheetProfileImage, user.profilePic, user.username);
        bindBadgeViews(sheetView, user);

        bottomSheetDialog.setContentView(sheetView);
        Window window = bottomSheetDialog.getWindow();
        if (window != null) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            window.setNavigationBarColor(Color.TRANSPARENT);
            WindowCompat.setDecorFitsSystemWindows(window, false);
        }

        int originalNavBarColor = getWindow().getNavigationBarColor();
        bottomSheetDialog.setOnShowListener(dialog -> {
            View bottomSheetInternal = ((BottomSheetDialog) dialog).findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (bottomSheetInternal != null) {
                bottomSheetInternal.setBackgroundColor(Color.TRANSPARENT);
                BottomSheetBehavior<View> behavior = BottomSheetBehavior.from(bottomSheetInternal);
                behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                behavior.setSkipCollapsed(true);
            }
            getWindow().setNavigationBarColor(Color.parseColor("#DAE8FF"));
            new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(true);
        });

        bottomSheetDialog.setOnDismissListener(dialog -> {
            try {
                decorView.removeView(blurOverlay);
            } catch (Exception ignored) {
            }
            getWindow().setNavigationBarColor(originalNavBarColor);
            new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(false);
        });

        bottomSheetDialog.show();
    }

    private LeaderboardUser findUserByUsername(ArrayList<LeaderboardUser> list, String username) {
        if (list == null || TextUtils.isEmpty(username)) return null;
        for (LeaderboardUser user : list) if (user != null && username.equalsIgnoreCase(safe(user.username))) return user;
        return null;
    }

    private String displayName(LeaderboardUser user) {
        if (user == null) return "-";
        String name = safe(user.username);
        return TextUtils.isEmpty(name) ? "-" : name;
    }

    private String topEmoji(int index) {
        if (index == 1) return "🥇";
        if (index == 2) return "🥈";
        if (index == 3) return "🥉";
        return "•";
    }

    private String formatRank(int position) {
        return position <= 0 ? "#-" : "#" + position;
    }

    private String formatMoney(double value) {
        return String.format(Locale.US, "%,.0f", value);
    }

    private String formatMoneyFromRaw(String raw) {
        try {
            double v = Double.parseDouble(raw.replace(",", "").trim());
            return String.format(Locale.US, "%,.0f", v);
        } catch (Exception e) {
            return "0";
        }
    }

    private String safe(String s) {
        return s == null ? "" : s.trim();
    }

    private String getStringValue(HashMap<String, Object> map, String key) {
        Object obj = map.get(key);
        return obj == null ? "" : String.valueOf(obj);
    }

    private String encode(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (Exception e) {
            return value;
        }
    }

    private void showLoading(boolean loading) {
        binding.loadingIndicator.setVisibility(loading ? View.VISIBLE : View.GONE);
        binding.vscroll4.setAlpha(loading ? 0f : 1f);
        binding.blurViewBottom.setAlpha(loading ? 0f : 1f);
    }

    private void setSafeText(TextView tv, String text, int maxChars) {
        if (tv == null) return;
        tv.setMaxLines(1);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setText(limitText(text, maxChars));
    }

    private String limitText(String text, int limit) {
        String value = safe(text);
        if (value.length() <= limit) return value;
        if (limit <= 3) return value.substring(0, limit);
        return value.substring(0, limit - 3) + "...";
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void loadAvatar(ImageView imageView, String profilePic, String username) {
        if (imageView == null) return;

        Drawable fallback = createLetterDrawable(firstLetter(username), username);

        if (!hasValidImage(profilePic)) {
            imageView.setImageDrawable(fallback);
            return;
        }

        String url = profilePic.trim();
        imageView.setTag(url);
        imageView.setImageDrawable(createTransparentDrawable());

        imageExecutor.execute(() -> {
            Bitmap bitmap = null;
            HttpURLConnection connection = null;

            try {
                URL u = new URL(url);
                connection = (HttpURLConnection) u.openConnection();
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setInstanceFollowRedirects(true);
                connection.setDoInput(true);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0");
                connection.connect();

                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    try (InputStream in = connection.getInputStream()) {
                        bitmap = BitmapFactory.decodeStream(in);
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }

            Bitmap finalBitmap = bitmap;
            mainHandler.post(() -> {
                Object tag = imageView.getTag();
                if (tag != null && url.equals(tag.toString())) {
                    if (finalBitmap != null) {
                        imageView.setImageBitmap(finalBitmap);
                    } else {
                        imageView.setImageDrawable(fallback);
                    }
                }
            });
        });
    }

    private boolean hasValidImage(String profilePic) {
        if (profilePic == null) return false;
        String v = profilePic.trim();
        if (v.isEmpty()) return false;
        if ("null".equalsIgnoreCase(v)) return false;
        if ("none".equalsIgnoreCase(v)) return false;
        return v.startsWith("http://") || v.startsWith("https://");
    }

    private String firstLetter(String username) {
        String v = safe(username);
        if (TextUtils.isEmpty(v)) return "?";
        return v.substring(0, 1).toUpperCase(Locale.US);
    }

    private Drawable createTransparentDrawable() {
        return new ColorDrawable(Color.TRANSPARENT);
    }

    private Drawable createLetterDrawable(String letter, String username) {
        int color = generateColorForUsername(username);
        return new LetterDrawable(letter, color);
    }

    private int generateColorForUsername(String username) {
        int hash = safe(username).hashCode();
        float hue = (Math.abs(hash) % 360);
        float saturation = 0.7f;
        float value = 0.6f;
        return Color.HSVToColor(new float[]{hue, saturation, value});
    }

    private static class LetterDrawable extends Drawable {
        private final String letter;
        private final android.graphics.Paint bgPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint textPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Rect textBounds = new android.graphics.Rect();

        LetterDrawable(String letter, int backgroundColor) {
            this.letter = TextUtils.isEmpty(letter) ? "?" : letter.substring(0, 1).toUpperCase(Locale.US);
            bgPaint.setColor(backgroundColor);
            bgPaint.setStyle(android.graphics.Paint.Style.FILL);
            textPaint.setColor(Color.WHITE);
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        }

        @Override
        public void draw(@NonNull android.graphics.Canvas canvas) {
            android.graphics.Rect b = getBounds();
            float cx = b.exactCenterX();
            float cy = b.exactCenterY();
            float r = Math.min(b.width(), b.height()) / 2f;
            canvas.drawCircle(cx, cy, r, bgPaint);
            textPaint.setTextSize(r * 0.95f);
            textPaint.getTextBounds(letter, 0, letter.length(), textBounds);
            float y = cy + textBounds.height() / 2f - textBounds.bottom;
            canvas.drawText(letter, cx, y, textPaint);
        }

        @Override
        public void setAlpha(int alpha) {
            bgPaint.setAlpha(alpha);
            textPaint.setAlpha(alpha);
            invalidateSelf();
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter colorFilter) {
            bgPaint.setColorFilter(colorFilter);
            textPaint.setColorFilter(colorFilter);
            invalidateSelf();
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }
    }

    public static class LeaderboardUser {
        public final String username;
        public final double totalWin;
        public final int totalPlay;
        public final String profilePic;
        public final String badgeRaw;
        public final boolean verifiedBadge;
        public final boolean devBadge;
        public final int position;

        public LeaderboardUser(String username, double totalWin, int totalPlay, String profilePic, String badgeRaw, boolean verifiedBadge, boolean devBadge, int position) {
            this.username = username;
            this.totalWin = totalWin;
            this.totalPlay = totalPlay;
            this.profilePic = profilePic;
            this.badgeRaw = badgeRaw;
            this.verifiedBadge = verifiedBadge;
            this.devBadge = devBadge;
            this.position = position;
        }
    }

    public static class SharedPreferencesCompat {
        public static void save(AppCompatActivity activity, String prefName, String key, String value) {
            activity.getSharedPreferences(prefName, Context.MODE_PRIVATE).edit().putString(key, value == null ? "" : value).apply();
        }
    }
}
