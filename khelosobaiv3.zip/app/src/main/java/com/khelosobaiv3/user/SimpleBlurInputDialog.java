package com.khelosobaiv3.user;

import android.accounts.AccountManager;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class SimpleBlurInputDialog {

    public interface OnActionListener {
        void onAction(Dialog dialog, String input);
    }

    public static class Builder {
        private final Context context;
        private boolean isBottomSheet = true;
        private boolean isCancelable = true;
        private boolean isBlurBackground = true;
        private String titleText = "Title";
        private String hintText = "Type here";
        private String buttonText = "Submit";
        private String buttonColor = "#004F50";
        private String messageText = "";
        private int inputType = InputType.TYPE_CLASS_TEXT;
        private OnActionListener actionListener;

        public Builder(Context context) {
            this.context = context;
        }

        public Builder setDialogType(boolean isBottomSheet) {
            this.isBottomSheet = isBottomSheet;
            return this;
        }

        public Builder setCancelable(boolean isCancelable) {
            this.isCancelable = isCancelable;
            return this;
        }

        public Builder setBlurBackground(boolean isBlurBackground) {
            this.isBlurBackground = isBlurBackground;
            return this;
        }

        public Builder setTitle(String titleText) {
            this.titleText = titleText;
            return this;
        }

        public Builder setMessage(String messageText) {
            this.messageText = messageText;
            return this;
        }

        public Builder setHint(String hintText) {
            this.hintText = hintText;
            return this;
        }

        public Builder setButtonText(String buttonText) {
            this.buttonText = buttonText;
            return this;
        }

        public Builder setButtonColor(String buttonColor) {
            if (buttonColor != null && !buttonColor.trim().isEmpty()) {
                this.buttonColor = buttonColor;
            }
            return this;
        }

        public Builder setInputType(int inputType) {
            this.inputType = inputType;
            return this;
        }

        public Builder setOnActionListener(OnActionListener actionListener) {
            this.actionListener = actionListener;
            return this;
        }

        public Dialog show() {
            Dialog dialog = isBottomSheet
                    ? new BottomSheetDialog(context)
                    : new Dialog(context);

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setCancelable(isCancelable);
            dialog.setCanceledOnTouchOutside(isCancelable);

            LinearLayout root = new LinearLayout(context);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setGravity(Gravity.CENTER_HORIZONTAL);
            int pad = dp(24);
            root.setPadding(pad, dp(28), pad, dp(28));

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#FFFFFF"));
            if (isBottomSheet) {
                float r = dp(28);
                bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
            } else {
                bg.setCornerRadius(dp(28));
            }
            root.setBackground(bg);

            TextView titleView = new TextView(context);
            titleView.setText(titleText);
            titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            titleView.setTextColor(Color.parseColor("#1D1B20"));
            titleView.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            titleView.setGravity(Gravity.CENTER);
            root.addView(titleView);

            if (!messageText.isEmpty()) {
                TextView messageView = new TextView(context);
                messageView.setText(messageText);
                messageView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                messageView.setTextColor(Color.parseColor("#49454F"));
                messageView.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams msgParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                msgParams.topMargin = dp(10);
                messageView.setLayoutParams(msgParams);
                root.addView(messageView);
            }

            EditText editText = new EditText(context);
            editText.setHint(hintText);
            editText.setInputType(inputType);
            editText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            editText.setTextColor(Color.parseColor("#1D1B20"));
            editText.setHintTextColor(Color.parseColor("#8A8A8A"));
            editText.setPadding(dp(16), dp(14), dp(16), dp(14));
            
            editText.setFocusable(false);
            editText.setFocusableInTouchMode(false);
            editText.setLongClickable(false);
            editText.setCursorVisible(false);
            editText.setClickable(true);

            GradientDrawable inputBg = new GradientDrawable();
            inputBg.setColor(Color.parseColor("#F6F6F6"));
            inputBg.setCornerRadius(dp(16));
            inputBg.setStroke(dp(1), Color.parseColor("#E5E5E5"));
            editText.setBackground(inputBg);

            LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            inputParams.topMargin = dp(22);
            root.addView(editText, inputParams);

            editText.setOnClickListener(v -> {
                if (context instanceof Activity) {
                    Activity activity = (Activity) context;
                    android.app.FragmentTransaction ft = activity.getFragmentManager().beginTransaction();
                    android.app.Fragment prev = activity.getFragmentManager().findFragmentByTag("email_picker_fragment");
                    if (prev != null) {
                        ft.remove(prev);
                    }
                    EmailPickerFragment fragment = new EmailPickerFragment();
                    fragment.setTarget(editText);
                    ft.add(fragment, "email_picker_fragment");
                    ft.commitAllowingStateLoss();
                }
            });

            TextView button = new TextView(context);
            button.setText(buttonText);
            button.setTextColor(Color.WHITE);
            button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            button.setGravity(Gravity.CENTER);
            button.setPadding(0, dp(14), 0, dp(14));
            button.setBackground(getRippleDrawable(Color.parseColor(buttonColor), Color.parseColor("#40000000"), dp(100)));

            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            btnParams.topMargin = dp(18);
            root.addView(button, btnParams);

            TextView statusView = new TextView(context);
            statusView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            statusView.setTextColor(Color.parseColor("#D32F2F"));
            statusView.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            statusParams.topMargin = dp(12);
            root.addView(statusView, statusParams);

            button.setOnClickListener(v -> {
                String input = editText.getText().toString().trim();
                if (input.isEmpty()) {
                    statusView.setText("Please select your email address");
                    return;
                }
                statusView.setText("");
                if (actionListener != null) {
                    actionListener.onAction(dialog, input);
                } else {
                    dialog.dismiss();
                }
            });

            dialog.setContentView(root);

            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                if (!isBottomSheet) {
                    window.setLayout((int) (context.getResources().getDisplayMetrics().widthPixels * 0.88), ViewGroup.LayoutParams.WRAP_CONTENT);
                }

                if (isBlurBackground && context instanceof Activity) {
                    window.setDimAmount(0f);

                    Activity activity = (Activity) context;
                    ViewGroup decorView = (ViewGroup) activity.getWindow().getDecorView();
                    ViewGroup rootView = decorView.findViewById(android.R.id.content);

                    BlurView blurView = new BlurView(context);
                    blurView.setLayoutParams(new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                    ));

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        blurView.setupWith(rootView, new RenderEffectBlur())
                                .setFrameClearDrawable(decorView.getBackground())
                                .setBlurRadius(4f);
                    } else {
                        blurView.setupWith(rootView, new RenderScriptBlur(context))
                                .setFrameClearDrawable(decorView.getBackground())
                                .setBlurRadius(4f);
                    }

                    View dimView = new View(context);
                    dimView.setBackgroundColor(Color.parseColor("#26000000"));
                    dimView.setLayoutParams(new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        ));

                    FrameLayout blurContainer = new FrameLayout(context);
                    blurContainer.addView(blurView);
                    blurContainer.addView(dimView);

                    decorView.addView(blurContainer);

                    dialog.setOnDismissListener(d -> {
                        try {
                            decorView.removeView(blurContainer);
                        } catch (Exception ignored) {
                        }
                    });
                } else {
                    window.setDimAmount(0.5f);
                }
            }

            dialog.show();
            return dialog;
        }

        private int dp(int value) {
            return (int) TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP,
                    value,
                    context.getResources().getDisplayMetrics()
            );
        }

        private Drawable getRippleDrawable(int normalColor, int pressedColor, float radius) {
            GradientDrawable shape = new GradientDrawable();
            shape.setColor(normalColor);
            shape.setCornerRadius(radius);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                return new RippleDrawable(ColorStateList.valueOf(pressedColor), shape, null);
            }
            return shape;
        }
    }

    public static class EmailPickerFragment extends android.app.Fragment {
        private EditText targetInput;
        private boolean isLaunched = false;

        public void setTarget(EditText targetInput) {
            this.targetInput = targetInput;
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setRetainInstance(true);
            if (!isLaunched) {
                isLaunched = true;
                try {
                    Intent intent = AccountManager.newChooseAccountIntent(
                            null, null, new String[]{"com.google"},
                            false, null, null, null, null);
                    startActivityForResult(intent, 1001);
                } catch (Exception ignored) {
                }
            }
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == 1001 && resultCode == Activity.RESULT_OK && data != null) {
                String email = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                if (email != null && targetInput != null) {
                    targetInput.setText(email);
                }
            }
            try {
                getFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
            } catch (Exception ignored) {
            }
        }
    }
}