package com.khelosobaiv3.user;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.FirebaseApp;

import org.json.JSONObject;

import java.io.File;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public class ZabbarUpdateActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private LinearLayout progressContainer;
    private Button btnDownload;
    private TextView tvProgressSize, tvSpeed, tvVersion, tvUpdateNotice;
    private ImageView updateIcon;
    private Handler handler = new Handler(Looper.getMainLooper());

    private String version_code = "";
    private String update_link = "";
    private String update_notice = "";
    private File currentApkFile;

    private volatile boolean isDownloading = false;
    private volatile boolean isCancelled = false;
    private boolean isDataLoaded = false;

    // Smooth speed (moving average over last 5 samples)
    private final int SMOOTH_WINDOW = 5;
    private final double[] speedSamples = new double[SMOOTH_WINDOW];
    private int sampleIndex = 0;
    private int sampleCount = 0;

    private long lastBytes = 0L;
    private long lastTime = 0L;

    private ExecutorService downloadExecutor;
    private final int THREAD_COUNT = 5;

    // 👇 Authority fixed as per your Manifest
    private static final String FILE_PROVIDER_AUTHORITY = "com.khelosobaiv3.user";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zabbar_update);

        FirebaseApp.initializeApp(this);
        downloadExecutor = Executors.newFixedThreadPool(THREAD_COUNT);

        updateIcon = findViewById(R.id.update_icon);
        tvVersion = findViewById(R.id.tv_version);
        tvUpdateNotice = findViewById(R.id.textview16);
        progressBar = findViewById(R.id.progress_bar);
        progressContainer = findViewById(R.id.progress_container);
        btnDownload = findViewById(R.id.btn_download);
        tvProgressSize = findViewById(R.id.tv_progress_size);
        tvSpeed = findViewById(R.id.tv_speed);

        updateIcon.setImageDrawable(createUpdateIconDrawable());

        GradientDrawable versionBg = new GradientDrawable();
        versionBg.setColor(Color.parseColor("#EEF2FF"));
        versionBg.setCornerRadius(40);
        tvVersion.setBackground(versionBg);

        GradientDrawable buttonBg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor("#4F46E5"), Color.parseColor("#6366F1")}
        );
        buttonBg.setCornerRadius(30);
        btnDownload.setBackground(buttonBg);

        setupCustomProgressBar();

        progressContainer.setVisibility(View.GONE);
        progressBar.setProgress(0);
        tvProgressSize.setText("0.0 MB / 0.0 MB");
        tvSpeed.setText("0.0 MB/s");
        btnDownload.setText("Loading...");
        btnDownload.setEnabled(false);

        fetchAppInfo();

        btnDownload.setOnClickListener(v -> {
            if (isDownloading) return;
            if (!isDataLoaded) {
                Toast.makeText(this, "Loading version info...", Toast.LENGTH_SHORT).show();
                return;
            }
            File existing = findExistingApk();
            if (existing != null && existing.exists()) {
                installApk(existing);
                return;
            }
            if (version_code.trim().isEmpty()) {
                Toast.makeText(this, "Version not loaded", Toast.LENGTH_SHORT).show();
                fetchAppInfo();
                return;
            }
            if (update_link.trim().isEmpty()) {
                Toast.makeText(this, "Update link not loaded", Toast.LENGTH_SHORT).show();
                fetchAppInfo();
                return;
            }
            startMultiThreadDownload();
        });
    }

    private void fetchAppInfo() {
        btnDownload.setEnabled(false);
        btnDownload.setText("Loading...");

        String url = "https://api.khelosobai20.live/ElitegoxUser/appinfo.php";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                response -> {
                    try {
                        version_code = response.optString("version_code", "");
                        update_link = response.optString("update_link", "");
                        update_notice = response.optString("update_notice", "");

                        isDataLoaded = true;
                        tvVersion.setText(version_code);
                        if (update_notice != null && !update_notice.trim().isEmpty()) {
                            tvUpdateNotice.setText(update_notice);
                        } else {
                            tvUpdateNotice.setText("No update notice available.");
                        }

                        File existing = findExistingApk();
                        if (existing != null && existing.exists()) {
                            btnDownload.setText("Install");
                        } else {
                            btnDownload.setText("Download");
                        }
                        btnDownload.setEnabled(true);

                    } catch (Exception e) {
                        Toast.makeText(this, "Parse error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        btnDownload.setText("Retry");
                        btnDownload.setEnabled(true);
                        isDataLoaded = false;
                    }
                },
                error -> {
                    String msg = "Network error: ";
                    if (error.networkResponse != null) {
                        msg += "HTTP " + error.networkResponse.statusCode;
                    } else {
                        msg += error.getMessage();
                    }
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
                    btnDownload.setText("Retry");
                    btnDownload.setEnabled(true);
                    isDataLoaded = false;
                }
        );

        jsonObjectRequest.setRetryPolicy(new com.android.volley.DefaultRetryPolicy(
                20000, 3, 1.0f
        ));

        Volley.newRequestQueue(this).add(jsonObjectRequest);
    }

    private void setupCustomProgressBar() {
        GradientDrawable bgShape = new GradientDrawable();
        bgShape.setColor(Color.parseColor("#E2E8F0"));
        bgShape.setCornerRadius(20);

        GradientDrawable progressShape = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor("#4F46E5"), Color.parseColor("#10B981")}
        );
        progressShape.setCornerRadius(20);

        ClipDrawable clipProgress = new ClipDrawable(progressShape, Gravity.LEFT, ClipDrawable.HORIZONTAL);

        Drawable[] layers = {bgShape, clipProgress};
        LayerDrawable layerDrawable = new LayerDrawable(layers);
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.progress);

        progressBar.setProgressDrawable(layerDrawable);
        progressBar.setMax(100);
        progressBar.setProgress(0);
    }

    private Drawable createUpdateIconDrawable() {
        return new Drawable() {
            @Override
            public void draw(@NonNull Canvas canvas) {
                int w = canvas.getWidth();
                int h = canvas.getHeight();

                Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                bgPaint.setColor(Color.parseColor("#EEF2FF"));
                canvas.drawCircle(w / 2f, h / 2f, w / 2f, bgPaint);

                Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                iconPaint.setColor(Color.parseColor("#4F46E5"));
                iconPaint.setStyle(Paint.Style.STROKE);
                iconPaint.setStrokeWidth(w * 0.075f);
                iconPaint.setStrokeCap(Paint.Cap.ROUND);
                iconPaint.setStrokeJoin(Paint.Join.ROUND);

                Path path = new Path();

                float arrowX = w / 2f;
                float arrowTopY = h * 0.28f;
                float arrowBottomY = h * 0.58f;

                path.moveTo(arrowX, arrowTopY);
                path.lineTo(arrowX, arrowBottomY);

                path.moveTo(w * 0.36f, h * 0.46f);
                path.lineTo(arrowX, arrowBottomY);
                path.lineTo(w * 0.64f, h * 0.46f);

                path.moveTo(w * 0.32f, h * 0.72f);
                path.lineTo(w * 0.68f, h * 0.72f);

                canvas.drawPath(path, iconPaint);
            }

            @Override
            public void setAlpha(int alpha) {}
            @Override
            public void setColorFilter(android.graphics.ColorFilter colorFilter) {}
            @Override
            public int getOpacity() {
                return android.graphics.PixelFormat.TRANSLUCENT;
            }
        };
    }

    // -----------------------------------------------------------
    // MULTI‑THREADED DOWNLOAD (5 parts)
    // -----------------------------------------------------------
    private void startMultiThreadDownload() {
        try {
            File dir = getExternalFilesDir(null);
            if (dir == null) {
                Toast.makeText(this, "Storage unavailable", Toast.LENGTH_SHORT).show();
                return;
            }

            String fileName = UUID.randomUUID().toString().replace("-", "").substring(0, 8) + version_code + ".apk";
            currentApkFile = new File(dir, fileName);

            isDownloading = true;
            isCancelled = false;
            lastBytes = 0L;
            lastTime = System.currentTimeMillis();
            sampleIndex = 0;
            sampleCount = 0;

            btnDownload.setEnabled(false);
            btnDownload.setText("Downloading");
            progressContainer.setVisibility(View.VISIBLE);
            progressBar.setProgress(0);
            tvProgressSize.setText("0.0 MB / ?");
            tvSpeed.setText("0.0 MB/s");

            new Thread(() -> {
                try {
                    // Get file size via HEAD request
                    HttpURLConnection conn = (HttpURLConnection) new URL(update_link).openConnection();
                    conn.setRequestMethod("HEAD");
                    conn.setConnectTimeout(10000);
                    conn.connect();
                    long totalSize = conn.getContentLengthLong();
                    conn.disconnect();

                    if (totalSize <= 0) {
                        handler.post(() -> {
                            Toast.makeText(ZabbarUpdateActivity.this, "Cannot determine file size", Toast.LENGTH_SHORT).show();
                            resetDownloadState();
                        });
                        return;
                    }

                    // Create empty file with total size
                    try (RandomAccessFile raf = new RandomAccessFile(currentApkFile, "rw")) {
                        raf.setLength(totalSize);
                    }

                    final long finalTotal = totalSize;
                    AtomicLong totalDownloaded = new AtomicLong(0);
                    final long partSize = totalSize / THREAD_COUNT;

                    for (int i = 0; i < THREAD_COUNT; i++) {
                        final int threadIndex = i;
                        final long startByte = i * partSize;
                        final long endByte = (i == THREAD_COUNT - 1) ? totalSize - 1 : (i + 1) * partSize - 1;

                        downloadExecutor.submit(() -> {
                            try {
                                HttpURLConnection connPart = (HttpURLConnection) new URL(update_link).openConnection();
                                connPart.setRequestProperty("Range", "bytes=" + startByte + "-" + endByte);
                                connPart.setConnectTimeout(15000);
                                connPart.setReadTimeout(30000);
                                connPart.connect();

                                if (connPart.getResponseCode() != HttpURLConnection.HTTP_PARTIAL) {
                                    throw new Exception("Server does not support range requests");
                                }

                                try (java.io.InputStream is = connPart.getInputStream();
                                     RandomAccessFile raf = new RandomAccessFile(currentApkFile, "rw")) {
                                    raf.seek(startByte);
                                    byte[] buffer = new byte[8192];
                                    int read;
                                    while ((read = is.read(buffer)) != -1) {
                                        if (isCancelled) break;
                                        raf.write(buffer, 0, read);
                                        long total = totalDownloaded.addAndGet(read);
                                        final long currentTotal = total;
                                        handler.post(() -> updateProgress(currentTotal, finalTotal));
                                    }
                                }
                            } catch (Exception e) {
                                handler.post(() -> {
                                    Toast.makeText(ZabbarUpdateActivity.this, "Part " + threadIndex + " error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    cancelDownload();
                                });
                            }
                        });
                    }

                    // Monitor completion
                    new Thread(() -> {
                        try {
                            downloadExecutor.shutdown();
                            if (downloadExecutor.awaitTermination(120, TimeUnit.SECONDS)) {
                                handler.post(() -> {
                                    if (!isCancelled && totalDownloaded.get() == finalTotal) {
                                        isDownloading = false;
                                        btnDownload.setEnabled(true);
                                        btnDownload.setText("Install");
                                        progressBar.setProgress(100);
                                        tvSpeed.setText("Done");
                                        tvProgressSize.setText(String.format(Locale.US, "%.1f MB / %.1f MB",
                                                finalTotal / 1024d / 1024d, finalTotal / 1024d / 1024d));
                                        Toast.makeText(ZabbarUpdateActivity.this, "✅ Download complete", Toast.LENGTH_SHORT).show();
                                    } else if (!isCancelled) {
                                        Toast.makeText(ZabbarUpdateActivity.this, "Download incomplete", Toast.LENGTH_SHORT).show();
                                        resetDownloadState();
                                    }
                                });
                            } else {
                                handler.post(() -> {
                                    Toast.makeText(ZabbarUpdateActivity.this, "Download timed out", Toast.LENGTH_SHORT).show();
                                    resetDownloadState();
                                });
                            }
                        } catch (InterruptedException e) {
                            handler.post(() -> {
                                Toast.makeText(ZabbarUpdateActivity.this, "Download interrupted", Toast.LENGTH_SHORT).show();
                                resetDownloadState();
                            });
                        }
                    }).start();

                } catch (Exception e) {
                    handler.post(() -> {
                        Toast.makeText(ZabbarUpdateActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        resetDownloadState();
                    });
                }
            }).start();

        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            resetDownloadState();
        }
    }

    private void updateProgress(long downloaded, long total) {
        int progress = (int) ((downloaded * 100L) / total);
        if (progress > 100) progress = 100;
        progressBar.setProgress(progress);

        double downloadedMb = downloaded / 1024d / 1024d;
        double totalMb = total / 1024d / 1024d;
        tvProgressSize.setText(String.format(Locale.US, "%.1f MB / %.1f MB", downloadedMb, totalMb));

        // Smooth speed using moving average
        long now = System.currentTimeMillis();
        long diffBytes = downloaded - lastBytes;
        long diffTime = now - lastTime;
        if (diffTime > 0 && diffBytes > 0) {
            double instantSpeed = ((diffBytes * 1000d) / diffTime) / 1024d / 1024d;
            speedSamples[sampleIndex] = instantSpeed;
            sampleIndex = (sampleIndex + 1) % SMOOTH_WINDOW;
            if (sampleCount < SMOOTH_WINDOW) sampleCount++;
            double sum = 0;
            for (int i = 0; i < sampleCount; i++) {
                sum += speedSamples[i];
            }
            double avgSpeed = sum / sampleCount;
            tvSpeed.setText(String.format(Locale.US, "%.1f MB/s", avgSpeed));
        } else {
            tvSpeed.setText("0.0 MB/s");
        }

        lastBytes = downloaded;
        lastTime = now;
    }

    private void cancelDownload() {
        isCancelled = true;
        isDownloading = false;
        resetDownloadState();
    }

    private void resetDownloadState() {
        handler.post(() -> {
            btnDownload.setEnabled(true);
            btnDownload.setText("Download");
            progressContainer.setVisibility(View.GONE);
            if (currentApkFile != null && currentApkFile.exists()) {
                currentApkFile.delete();
            }
            isDownloading = false;
        });
    }

    // -----------------------------------------------------------
    // INSTALL APK with Permission Check
    // -----------------------------------------------------------
    private void installApk(File file) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!getPackageManager().canRequestPackageInstalls()) {
                Toast.makeText(this, "Please allow install from unknown sources", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                return;
            }
        }

        try {
            Uri uri;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                // 👇 Using exact authority from Manifest
                uri = FileProvider.getUriForFile(this, FILE_PROVIDER_AUTHORITY, file);
            } else {
                uri = Uri.fromFile(file);
            }
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Install error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private File findExistingApk() {
        try {
            File dir = getExternalFilesDir(null);
            if (dir == null || !dir.exists()) return null;
            File[] files = dir.listFiles();
            if (files == null) return null;
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(".apk") && file.getName().contains(version_code)) {
                    return file;
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isCancelled = true;
        downloadExecutor.shutdownNow();
        handler.removeCallbacksAndMessages(null);
    }
}