package com.khelosobaiv3.user;

import android.app.Dialog;
import android.content.Context;

public class ParticipantsDialog {
    
    public static void show(Context context) {
        new PremiumDialog.Builder(context)
                .setDialogType(true)
                .setCancelable(true)
                .setBlurBackground(true)
                .setLottie("warning.json")
                .setTitle("Participants")
                .setMessage("আপনি এই ম্যাচে জয়েন করেননি। প্লেয়ার লিস্ট দেখতে হলে আগে জয়েন করুন।")
                .setPositiveButton("OK", "#7B2CBF", new PremiumDialog.DialogListener() {
                    @Override
                    public void onClick(Dialog dialog) {
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("Close", new PremiumDialog.DialogListener() {
                    @Override
                    public void onClick(Dialog dialog) {
                        dialog.dismiss();
                    }
                })
                .show();
    }
}