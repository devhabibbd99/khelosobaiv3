package com.khelosobaiv3.user;

import androidx.annotation.NonNull;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

public class FCMManager {

    public interface FCMListener {
        void onSuccess(String result);
        void onError(String error);
    }

    public static void subscribe(final String topicName, final FCMListener listener) {
        try {
            FirebaseMessaging.getInstance().subscribeToTopic(topicName)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                listener.onSuccess(topicName);
                            } else {
                                String errorMsg = (task.getException() != null) ? task.getException().toString() : "Unknown Subscription Error";
                                listener.onError(errorMsg);
                            }
                        }
                    });
        } catch (Exception e) {
            listener.onError(e.toString());
        }
    }

    public static void unsubscribe(final String topicName, final FCMListener listener) {
        try {
            FirebaseMessaging.getInstance().unsubscribeFromTopic(topicName)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                listener.onSuccess(topicName);
                            } else {
                                String errorMsg = (task.getException() != null) ? task.getException().toString() : "Unknown Unsubscription Error";
                                listener.onError(errorMsg);
                            }
                        }
                    });
        } catch (Exception e) {
            listener.onError(e.toString());
        }
    }

    public static void getToken(final FCMListener listener) {
        try {
            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                        @Override
                        public void onComplete(@NonNull Task<InstanceIdResult> task) {
                            if (task.isSuccessful() && task.getResult() != null) {
                                String token = task.getResult().getToken();
                                if (token != null && !token.isEmpty()) {
                                    listener.onSuccess(token);
                                } else {
                                    listener.onError("Token is empty or null");
                                }
                            } else {
                                String errorMsg = "Task Failed. ";
                                if (task.getException() != null) {
                                    errorMsg = task.getException().toString();
                                }
                                listener.onError(errorMsg);
                            }
                        }
                    });
        } catch (Exception e) {
            listener.onError(e.toString());
        }
    }
}
