package com.khelosobaiv3.user;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashMap;

public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
	
	ArrayList<HashMap<String, Object>> _data;
	
	public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
		_data = _arr;
	}
	
	@Override
	public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
		LayoutInflater _inflater = LayoutInflater.from(parent.getContext());
		View _v = _inflater.inflate(R.layout.zabbar_daily_match, parent, false);
		RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		_v.setLayoutParams(_lp);
		return new ViewHolder(_v);
	}
	
	@Override
	public void onBindViewHolder(ViewHolder _holder, final int _position) {
		ZabbarDailyMatchBinding binding = _holder.binding;
		Context context = _holder.itemView.getContext();
		
		GradientDrawable gd = new GradientDrawable();
		gd.setCornerRadius(dpToPx(15, context));
		gd.setStroke((int)dpToPx(1, context), 0xFFE0E0E0);
		gd.setColor(context.getResources().getColor(R.color.md_theme_tertiaryFixed_highContrast));
		
		binding.zabbarMatchBg.setBackground(gd);
		binding.zabbarMatchBg2.setBackground(gd);
	}
	
	@Override
	public int getItemCount() {
		return _data.size();
	}
	
	private float dpToPx(float dp, Context context) {
		return dp * context.getResources().getDisplayMetrics().density;
	}
	
	public class ViewHolder extends RecyclerView.ViewHolder {
		ZabbarDailyMatchBinding binding;
		
		public ViewHolder(View v) {
			super(v);
			binding = ZabbarDailyMatchBinding.bind(v);
		}
	}
}
