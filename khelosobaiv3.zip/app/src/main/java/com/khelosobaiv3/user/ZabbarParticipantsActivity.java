package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class ZabbarParticipantsActivity extends AppCompatActivity {
	
	private ZabbarParticipantsBinding binding;
	
	private ArrayList<HashMap<String, Object>> zabbar_map = new ArrayList<>();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ZabbarParticipantsBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		getWindow().setDecorFitsSystemWindows(false);
		getWindow().setStatusBarColor(Color.TRANSPARENT);
		getWindow().setNavigationBarColor(Color.TRANSPARENT);
		
		BlurView blurView = findViewById(R.id.blurView);
		
		ViewGroup rootView = (ViewGroup) getWindow().getDecorView();
		
		Drawable windowBackground = rootView.getBackground();
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
				
				blurView.setupWith(rootView, new RenderEffectBlur())
				.setFrameClearDrawable(windowBackground)
				.setBlurRadius(8f)
				.setBlurAutoUpdate(true);
				
		} else {
				
				blurView.setupWith(rootView, new RenderScriptBlur(this))
				.setFrameClearDrawable(windowBackground)
				.setBlurRadius(8f)
				.setBlurAutoUpdate(true);
		}
		for(int _repeat12 = 0; _repeat12 < (int)(10); _repeat12++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("tt", "gg");
				zabbar_map.add(_item);
			}
		}
		recyclerViewRules.setAdapter(new RecyclerViewRulesAdapter(zabbar_map));
		recyclerViewRules.setLayoutManager(new LinearLayoutManager(this));
		noFoundView.setVisibility(View.GONE);
	}
	
	public class RecyclerViewRulesAdapter extends RecyclerView.Adapter<RecyclerViewRulesAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public RecyclerViewRulesAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.shuvo_participants, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			ShuvoParticipantsBinding binding = ShuvoParticipantsBinding.bind(_view);
			
			zabbarUserCard.setVisibility(View.GONE);
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
}