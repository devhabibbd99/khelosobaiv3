package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;


public class ZabbarProfileEditActivity extends AppCompatActivity {
	
	private boolean isCurrentPassVisible = false;
	private boolean isNewPassVisible = false;
	private boolean isConfirmPassVisible = false;
	
	private static final int ICON_BACK = 1;
	private static final int ICON_PERSON = 2;
	private static final int ICON_EMAIL = 3;
	private static final int ICON_PHONE = 4;
	private static final int ICON_LOCK = 5;
	private static final int ICON_EYE_ON = 6;
	private static final int ICON_EYE_OFF = 7;
	
	private ZabbarProfileEditBinding binding;
	private HashMap<String, Object> zabbar_D = new HashMap<>();
	private HashMap<String, Object> zabbarx = new HashMap<>();
	private String username = "";
	private HashMap<String, Object> changed = new HashMap<>();
	
	private SharedPreferences Save_User_Status;
	private RequestNetwork ZabbarGetUser;
	private RequestNetwork.RequestListener _ZabbarGetUser_request_listener;
	private SharedPreferences Api;
	private RequestNetwork new_password;
	private RequestNetwork.RequestListener _new_password_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ZabbarProfileEditBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		Save_User_Status = getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE);
		ZabbarGetUser = new RequestNetwork(this);
		Api = getSharedPreferences("Api", Activity.MODE_PRIVATE);
		new_password = new RequestNetwork(this);
		
		_ZabbarGetUser_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				zabbarx = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				etEmail.setEnabled(false);
				etEmail.setEnabled(false);
				boxEmail.setClickable(false);
				boxEmail.setFocusableInTouchMode(false);
				boxEmail.setFocusable(false);
				etEmail.setClickable(false);
				etEmail.setFocusableInTouchMode(false);
				etEmail.setFocusable(false);
				etPhone.setEnabled(false);
				boxPhone.setEnabled(false);
				boxPhone.setClickable(false);
				boxPhone.setFocusableInTouchMode(false);
				boxPhone.setFocusable(false);
				etPhone.setClickable(false);
				etPhone.setFocusableInTouchMode(false);
				etPhone.setFocusable(false);
				etFullName.setText(zabbarx.get("username").toString());
				username = zabbarx.get("username").toString();
				try{
					if (zabbarx.get("extra_json").toString().equals("")) {
						etPhone.setText(zabbarx.get("number").toString());
						etEmail.setText(zabbarx.get("email").toString());
					} else {
						if (zabbarx.get("extra_json").toString().contains("telegram_id")) {
							etPhone.setText("your change login methods");
							etEmail.setText("your change login methods");
						} else {
							etEmail.setText(zabbarx.get("email").toString());
							etPhone.setText(zabbarx.get("number").toString());
						}
					}
				}catch(Exception e){
					etEmail.setText(zabbarx.get("email").toString());
					etPhone.setText(zabbarx.get("number").toString());
				}
				Save_User_Status.edit().putString("Username", zabbarx.get("username").toString()).commit();
				Save_User_Status.edit().putString("Token", zabbarx.get("token").toString()).commit();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "No Internet Service Unavailable Error 403!");
			}
		};
		
		_new_password_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				SketchwareUtil.showMessage(getApplicationContext(), _response);
				zabbar_D = new HashMap<>();
				zabbar_D.put("type", "1");
				zabbar_D.put("token", Save_User_Status.getString("Token", ""));
				ZabbarGetUser.setParams(zabbar_D, RequestNetworkController.REQUEST_PARAM);
				ZabbarGetUser.startRequestNetwork(RequestNetworkController.POST, Api.getString("Api", "").concat("XMapp_Us.js.php"), "", _ZabbarGetUser_request_listener);
				zabbar_D.clear();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
		getWindow().setStatusBarColor(Color.TRANSPARENT);
		getWindow().setNavigationBarColor(Color.TRANSPARENT);
		
		
		if (getSupportActionBar() != null) {
				getSupportActionBar().hide();
		}
		
		setupWindowInsets();
		setupBackgrounds();
		drawAndSetIcons();
		setupClickListeners();
		setupInputFocusEffects();
	}
	
	
	@Override
	public void onStart() {
		super.onStart();
		zabbar_D = new HashMap<>();
		zabbar_D.put("type", "1");
		zabbar_D.put("token", Save_User_Status.getString("Token", ""));
		ZabbarGetUser.setParams(zabbar_D, RequestNetworkController.REQUEST_PARAM);
		ZabbarGetUser.startRequestNetwork(RequestNetworkController.POST, Api.getString("Api", "").concat("XMapp_Us.js.php"), "", _ZabbarGetUser_request_listener);
		zabbar_D.clear();
	}
	public void _ZabbarX_Method() {
	}
	private void setupWindowInsets() {
			ConstraintLayout mainLayout = findViewById(R.id.mainLayout);
			int basePadding = (int) (24 * getResources().getDisplayMetrics().density);
			
			ViewCompat.setOnApplyWindowInsetsListener(mainLayout, (v, insets) -> {
					int top = insets.getInsets(WindowInsetsCompat.Type.systemBars()).top;
					int bottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom;
					v.setPadding(basePadding, top + basePadding, basePadding, bottom + basePadding);
					return insets;
			});
	}
	
	private void setupBackgrounds() {
			ConstraintLayout mainLayout = findViewById(R.id.mainLayout);
			GradientDrawable mainGradient = new GradientDrawable(
			GradientDrawable.Orientation.TOP_BOTTOM,
			new int[]{Color.parseColor("#F8FAFC"), Color.parseColor("#E2E8F0")}
			);
			mainLayout.setBackground(mainGradient);
			
			AppCompatButton btnSave = findViewById(R.id.btnSaveChanges);
			GradientDrawable btnBg = new GradientDrawable();
			btnBg.setColor(Color.parseColor("#4361EE"));
			btnBg.setCornerRadius(60f);
			btnSave.setBackground(btnBg);
	}
	
	private void setupInputFocusEffects() {
			applyFocusBehavior(findViewById(R.id.etFullName), findViewById(R.id.boxName));
			applyFocusBehavior(findViewById(R.id.etEmail), findViewById(R.id.boxEmail));
			applyFocusBehavior(findViewById(R.id.etPhone), findViewById(R.id.boxPhone));
			applyFocusBehavior(findViewById(R.id.etCurrentPassword), findViewById(R.id.boxCurrentPass));
			applyFocusBehavior(findViewById(R.id.etNewPassword), findViewById(R.id.boxNewPass));
			applyFocusBehavior(findViewById(R.id.etConfirmPassword), findViewById(R.id.boxConfirmPass));
	}
	
	private void applyFocusBehavior(EditText editText, LinearLayout box) {
			updateBoxBackground(box, false);
			editText.setOnFocusChangeListener((v, hasFocus) -> updateBoxBackground(box, hasFocus));
	}
	
	private void updateBoxBackground(LinearLayout box, boolean isFocused) {
			GradientDrawable inputBg = new GradientDrawable();
			inputBg.setColor(Color.parseColor("#FFFFFF"));
			inputBg.setCornerRadius(40f);
			if (isFocused) {
					inputBg.setStroke(4, Color.parseColor("#4361EE"));
			} else {
					inputBg.setStroke(3, Color.parseColor("#CBD5E1"));
			}
			box.setBackground(inputBg);
	}
	
	private void drawAndSetIcons() {
			int iconColor = Color.parseColor("#64748B");
			int titleIconColor = Color.parseColor("#4361EE");
			int backIconColor = Color.parseColor("#0F172A");
			
			((ImageView) findViewById(R.id.btnBack)).setImageBitmap(drawIcon(ICON_BACK, backIconColor));
			((ImageView) findViewById(R.id.ivTitlePerson)).setImageBitmap(drawIcon(ICON_PERSON, titleIconColor));
			((ImageView) findViewById(R.id.ivTitleSecurity)).setImageBitmap(drawIcon(ICON_LOCK, titleIconColor));
			((ImageView) findViewById(R.id.ivIconPerson)).setImageBitmap(drawIcon(ICON_PERSON, iconColor));
			((ImageView) findViewById(R.id.ivIconEmail)).setImageBitmap(drawIcon(ICON_EMAIL, iconColor));
			((ImageView) findViewById(R.id.ivIconPhone)).setImageBitmap(drawIcon(ICON_PHONE, iconColor));
			((ImageView) findViewById(R.id.ivIconLock1)).setImageBitmap(drawIcon(ICON_LOCK, iconColor));
			((ImageView) findViewById(R.id.ivIconLock2)).setImageBitmap(drawIcon(ICON_LOCK, iconColor));
			((ImageView) findViewById(R.id.ivIconLock3)).setImageBitmap(drawIcon(ICON_LOCK, iconColor));
			((ImageView) findViewById(R.id.ivToggleCurrentPass)).setImageBitmap(drawIcon(ICON_EYE_OFF, iconColor));
			((ImageView) findViewById(R.id.ivToggleNewPass)).setImageBitmap(drawIcon(ICON_EYE_OFF, iconColor));
			((ImageView) findViewById(R.id.ivToggleConfirmPass)).setImageBitmap(drawIcon(ICON_EYE_OFF, iconColor));
	}
	
	private Bitmap drawIcon(int iconType, int color) {
			Bitmap bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
			Canvas canvas = new Canvas(bitmap);
			
			Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
			paint.setColor(color);
			paint.setStyle(Paint.Style.STROKE);
			paint.setStrokeWidth(7f);
			paint.setStrokeCap(Paint.Cap.ROUND);
			paint.setStrokeJoin(Paint.Join.ROUND);
			
			Path path = new Path();
			
			switch (iconType) {
					case ICON_BACK:
					path.moveTo(60, 20); 
					path.lineTo(30, 50); 
					path.lineTo(60, 80);
					canvas.drawPath(path, paint);
					break;
					
					case ICON_PERSON:
					canvas.drawCircle(50, 32, 16, paint);
					path.moveTo(18, 88);
					path.quadTo(50, 55, 82, 88);
					canvas.drawPath(path, paint);
					break;
					
					case ICON_EMAIL:
					canvas.drawRoundRect(new RectF(12, 28, 88, 72), 12, 12, paint); 
					path.moveTo(12, 28); 
					path.lineTo(50, 55); 
					path.lineTo(88, 28); 
					canvas.drawPath(path, paint);
					break;
					
					case ICON_PHONE:
					canvas.drawRoundRect(new RectF(28, 12, 72, 88), 16, 16, paint); 
					path.moveTo(42, 24); 
					path.lineTo(58, 24);
					canvas.drawPath(path, paint);
					paint.setStyle(Paint.Style.FILL);
					canvas.drawCircle(50, 78, 3.5f, paint);
					break;
					
					case ICON_LOCK:
					canvas.drawRoundRect(new RectF(25, 45, 75, 85), 10, 10, paint);
					path.moveTo(35, 45); 
					path.lineTo(35, 32);
					path.arcTo(new RectF(35, 17, 65, 47), 180, 180);
					path.lineTo(65, 45);
					canvas.drawPath(path, paint);
					paint.setStyle(Paint.Style.FILL);
					canvas.drawCircle(50, 65, 4f, paint);
					break;
					
					case ICON_EYE_ON:
					path.moveTo(10, 50);
					path.quadTo(50, 15, 90, 50);
					path.quadTo(50, 85, 10, 50);
					canvas.drawPath(path, paint);
					canvas.drawCircle(50, 50, 12, paint);
					break;
					
					case ICON_EYE_OFF:
					path.moveTo(10, 50);
					path.quadTo(50, 15, 90, 50);
					path.quadTo(50, 85, 10, 50);
					canvas.drawPath(path, paint);
					canvas.drawCircle(50, 50, 12, paint);
					Path slash = new Path();
					slash.moveTo(25, 25); 
					slash.lineTo(75, 75);
					canvas.drawPath(slash, paint);
					break;
			}
			
			return bitmap;
	}
	
	
	
	private void setupPasswordToggle(int imageViewId, int editTextId, int type) {
			ImageView eyeIcon = findViewById(imageViewId);
			EditText editText = findViewById(editTextId);
			
			eyeIcon.setOnClickListener(v -> {
					boolean isVisible = false;
					if (type == 1) { isCurrentPassVisible = !isCurrentPassVisible; isVisible = isCurrentPassVisible; }
					else if (type == 2) { isNewPassVisible = !isNewPassVisible; isVisible = isNewPassVisible; }
					else if (type == 3) { isConfirmPassVisible = !isConfirmPassVisible; isVisible = isConfirmPassVisible; }
					
					int iconColor = Color.parseColor("#64748B");
					
					if (isVisible) {
							editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
							eyeIcon.setImageBitmap(drawIcon(ICON_EYE_ON, iconColor));
					} else {
							editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
							eyeIcon.setImageBitmap(drawIcon(ICON_EYE_OFF, iconColor));
					}
					editText.setSelection(editText.getText().length());
			});
	}
	private void setupClickListeners() {
			findViewById(R.id.btnBack).setOnClickListener(v -> finish());
			setupPasswordToggle(R.id.ivToggleCurrentPass, R.id.etCurrentPassword, 1);
			setupPasswordToggle(R.id.ivToggleNewPass, R.id.etNewPassword, 2);
			setupPasswordToggle(R.id.ivToggleConfirmPass, R.id.etConfirmPassword, 3);
			findViewById(R.id.btnSaveChanges).setOnClickListener(v -> {
					
			changed = new HashMap<>();
			changed.put("username", username);
			changed.put("new_username", etFullName.getText().toString());
			if (etNewPassword.getText().toString().equals(etConfirmPassword.getText().toString())) {
				changed.put("password", etCurrentPassword.getText().toString());
				changed.put("new_password", etNewPassword.getText().toString());
				new_password.setParams(changed, RequestNetworkController.REQUEST_PARAM);
				new_password.startRequestNetwork(RequestNetworkController.POST, Api.getString("Api", "").concat("changes_password.php"), "", _new_password_request_listener);
			} else {
				SketchwareUtil.showMessage(getApplicationContext(), "Your confirmed password has not same");
			}
			changed.clear();
		});
	}
	{
	}
	
}