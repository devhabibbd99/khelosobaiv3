package com.khelosobaiv3.user;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class PremiumBottomSheet extends Dialog {

    private final ClickListener listener;
    private static final String API_URL = "https://api.khelosobai20.live/ElitegoxUser/get_dialouge_slider.php";

    private ViewPager2 viewPager;
    private LinearLayout indicatorContainer;
    private ImageView btnLeft;
    private ImageView btnRight;
    private int density;

    public interface ClickListener {
        void onActionClick();
    }

    public PremiumBottomSheet(@NonNull Context context, ClickListener listener) {
        super(context);
        this.listener = listener;
        init(context);
    }

    public PremiumBottomSheet(@NonNull Context context, String title, String message, String btnText, Runnable runnable) {
        super(context);
        this.listener = null;
        init(context);
    }

    public static void showDialog(Context context, boolean cancelable, String title, String message, String btnText, boolean cancelOutside, Runnable runnable) {
        PremiumBottomSheet dialog = new PremiumBottomSheet(context, title, message, btnText, runnable);
        dialog.setCancelable(cancelable);
        dialog.setCanceledOnTouchOutside(cancelOutside);
        dialog.show();
    }

    private void init(Context context) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        View view = LayoutInflater.from(context).inflate(R.layout.layout_premium_bottom_sheet, null);
        setContentView(view);

        density = (int) context.getResources().getDisplayMetrics().density;

        if (getWindow() != null) {
            getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            getWindow().setLayout((int) (context.getResources().getDisplayMetrics().widthPixels * 0.90), ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        LinearLayout mainContainer = view.findViewById(R.id.main_container);
        GradientDrawable containerBg = new GradientDrawable();
        containerBg.setColor(Color.WHITE);
        containerBg.setCornerRadius(dpToPx(28));
        mainContainer.setBackground(containerBg);

        viewPager = view.findViewById(R.id.slider_viewpager);
        indicatorContainer = view.findViewById(R.id.indicator_container);
        btnLeft = view.findViewById(R.id.btn_left);
        btnRight = view.findViewById(R.id.btn_right);

        View btnClose = view.findViewById(R.id.btn_close);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> dismiss());
        }

        updateUiStates(new ImageView[0], 0, 0);

        loadSliderData(context);
    }

    private void loadSliderData(Context context) {
        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            try {
                URL url = new URL(API_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONObject jsonObject = new JSONObject(response.toString());
                boolean status = jsonObject.getBoolean("status");

                if (status) {
                    JSONArray dataArray = jsonObject.getJSONArray("data");
                    List<SliderItem> itemList = new ArrayList<>();

                    for (int i = 0; i < dataArray.length(); i++) {
                        JSONObject obj = dataArray.getJSONObject(i);
                        itemList.add(new SliderItem(
                                obj.getString("image"),
                                obj.getString("click_link")
                        ));
                    }

                    handler.post(() -> {
                        if (!isShowing()) return;

                        if (!itemList.isEmpty()) {
                            SliderAdapter adapter = new SliderAdapter(context, itemList);
                            viewPager.setAdapter(adapter);
                            setupIndicators(context, itemList.size());

                            btnLeft.setOnClickListener(v -> {
                                int current = viewPager.getCurrentItem();
                                if (current > 0) viewPager.setCurrentItem(current - 1, true);
                            });

                            btnRight.setOnClickListener(v -> {
                                int current = viewPager.getCurrentItem();
                                if (current < itemList.size() - 1) viewPager.setCurrentItem(current + 1, true);
                            });
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private GradientDrawable createSoftButtonBg(boolean isActive) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.parseColor(isActive ? "#1E293B" : "#F1F5F9"));
        return bg;
    }

    private void setupIndicators(Context context, int count) {
        indicatorContainer.removeAllViews();
        ImageView[] indicators = new ImageView[count];

        for (int i = 0; i < count; i++) {
            indicators[i] = new ImageView(context);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(10 * density, 10 * density);
            params.setMargins(6 * density, 0, 6 * density, 0);
            indicators[i].setLayoutParams(params);
            indicators[i].setImageDrawable(getIndicatorDrawable(Color.parseColor("#E2E8F0"), 5 * density));
            indicatorContainer.addView(indicators[i]);
        }

        updateUiStates(indicators, 0, count);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                updateUiStates(indicators, position, count);
            }
        });
    }

    private void updateUiStates(ImageView[] indicators, int position, int count) {
        if (indicators != null && indicators.length > 0) {
            for (int i = 0; i < indicators.length; i++) {
                LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) indicators[i].getLayoutParams();
                if (i == position) {
                    params.width = 28 * density;
                    indicators[i].setImageDrawable(getIndicatorDrawable(Color.parseColor("#1E293B"), 5 * density));
                } else {
                    params.width = 10 * density;
                    indicators[i].setImageDrawable(getIndicatorDrawable(Color.parseColor("#E2E8F0"), 5 * density));
                }
                indicators[i].setLayoutParams(params);
            }
        }

        boolean canGoLeft = position > 0;
        boolean canGoRight = position < count - 1 && count > 0;

        btnLeft.setBackground(createSoftButtonBg(canGoLeft));
        btnLeft.setImageDrawable(new ArrowDrawable(true, canGoLeft));

        btnRight.setBackground(createSoftButtonBg(canGoRight));
        btnRight.setImageDrawable(new ArrowDrawable(false, canGoRight));
    }

    private GradientDrawable getIndicatorDrawable(int color, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int dpToPx(int dp) {
        return dp * density;
    }

    private class ArrowDrawable extends Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final boolean isLeft;
        private final int size;
        private final float arrowWidth;
        private final float arrowHeight;

        ArrowDrawable(boolean isLeft, boolean isActive) {
            this.isLeft = isLeft;
            this.size = dpToPx(24);
            this.arrowWidth = dpToPx(4);
            this.arrowHeight = dpToPx(7);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpToPx(3));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(isActive ? Color.WHITE : Color.parseColor("#94A3B8"));
        }

        @Override
        public void draw(@NonNull Canvas canvas) {
            Rect bounds = getBounds();
            float cx = bounds.centerX();
            float cy = bounds.centerY();

            path.reset();
            if (isLeft) {
                path.moveTo(cx + arrowWidth, cy - arrowHeight);
                path.lineTo(cx - arrowWidth, cy);
                path.lineTo(cx + arrowWidth, cy + arrowHeight);
            } else {
                path.moveTo(cx - arrowWidth, cy - arrowHeight);
                path.lineTo(cx + arrowWidth, cy);
                path.lineTo(cx - arrowWidth, cy + arrowHeight);
            }
            canvas.drawPath(path, paint);
        }

        @Override
        public int getIntrinsicWidth() { return size; }

        @Override
        public int getIntrinsicHeight() { return size; }

        @Override
        public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override
        public void setColorFilter(android.graphics.ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override
        public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private static class SliderItem {
        String imageUrL;
        String clickLink;

        SliderItem(String imageUrL, String clickLink) {
            this.imageUrL = imageUrL;
            this.clickLink = clickLink;
        }
    }

    private static class SliderAdapter extends RecyclerView.Adapter<SliderAdapter.SliderViewHolder> {
        private final List<SliderItem> items;
        private final Context context;
        private final Executor executor = Executors.newSingleThreadExecutor();
        private final Handler handler = new Handler(Looper.getMainLooper());

        public SliderAdapter(Context context, List<SliderItem> items) {
            this.context = context;
            this.items = items;
        }

        @NonNull
        @Override
        public SliderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            FrameLayout frameLayout = new FrameLayout(parent.getContext());
            frameLayout.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));

            ImageView imageView = new ImageView(parent.getContext());
            imageView.setLayoutParams(new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
            ));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            frameLayout.addView(imageView);

            float density = parent.getContext().getResources().getDisplayMetrics().density;
            int lottieSize = (int) (42 * density);

            LottieAnimationView lottieView = new LottieAnimationView(parent.getContext());
            FrameLayout.LayoutParams lottieParams = new FrameLayout.LayoutParams(lottieSize, lottieSize);
            lottieParams.gravity = android.view.Gravity.CENTER;
            lottieView.setLayoutParams(lottieParams);
            lottieView.setAnimation("lood.json");
            lottieView.setRepeatCount(LottieDrawable.INFINITE);
            frameLayout.addView(lottieView);

            return new SliderViewHolder(frameLayout);
        }

        @Override
        public void onBindViewHolder(@NonNull SliderViewHolder holder, int position) {
            SliderItem item = items.get(position);

            holder.imageView.setVisibility(View.INVISIBLE);
            holder.lottieView.setVisibility(View.VISIBLE);
            holder.lottieView.playAnimation();

            executor.execute(() -> {
                try {
                    InputStream in = new URL(item.imageUrL).openStream();
                    Bitmap bitmap = BitmapFactory.decodeStream(in);
                    handler.post(() -> {
                        holder.imageView.setImageBitmap(bitmap);
                        holder.lottieView.cancelAnimation();
                        holder.lottieView.setVisibility(View.GONE);
                        holder.imageView.setVisibility(View.VISIBLE);
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            holder.imageView.setOnClickListener(v -> {
                if (item.clickLink != null && !item.clickLink.isEmpty()) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(item.clickLink));
                        context.startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(context, "Link Error", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        static class SliderViewHolder extends RecyclerView.ViewHolder {
            FrameLayout container;
            ImageView imageView;
            LottieAnimationView lottieView;

            public SliderViewHolder(@NonNull View itemView) {
                super(itemView);
                this.container = (FrameLayout) itemView;
                this.imageView = (ImageView) container.getChildAt(0);
                this.lottieView = (LottieAnimationView) container.getChildAt(1);
            }
        }
    }
}