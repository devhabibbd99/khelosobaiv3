package com.khelosobaiv3.user;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.os.Build;
import android.os.Process;
import android.widget.Toast;

public class SecurityChecker {

    public static boolean isProxyEnabled(Context context) {
        String host = System.getProperty("http.proxyHost");
        String port = System.getProperty("http.proxyPort");

        if (host != null && !host.isEmpty()) {
            return true;
        }

        if (port != null && !port.isEmpty()) {
            return true;
        }

        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network != null) {
                LinkProperties lp = cm.getLinkProperties(network);
                if (lp != null && lp.getHttpProxy() != null) {
                    return true;
                }
            }
        }

        return false;
    }

    public static void check(Context context) {
        if (context == null) return;

        if (isProxyEnabled(context)) {
            Toast.makeText(context, "Proxy Detected", Toast.LENGTH_LONG).show();

            if (context instanceof Activity) {
                ((Activity) context).finishAffinity();
            }

            Process.killProcess(Process.myPid());
            System.exit(0);
        }
    }
}