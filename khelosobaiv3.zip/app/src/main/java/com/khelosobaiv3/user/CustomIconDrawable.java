package com.khelosobaiv3.user;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

public class CustomIconDrawable extends Drawable {
    private final String type;
    private final Paint paint;
    private final int size;

    public CustomIconDrawable(String type, int color, int size) {
        this.type = type;
        this.size = size;

        this.paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        this.paint.setColor(color);
    }

    @Override public int getIntrinsicWidth() { return size; }
    @Override public int getIntrinsicHeight() { return size; }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        float w = b.width(), h = b.height(), cx = b.exactCenterX(), cy = b.exactCenterY();

        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(w * 0.08f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);

        switch (type) {
            case "arrow_back":
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawLine(cx + w * 0.25f, cy, cx - w * 0.25f, cy, paint);
                canvas.drawLine(cx - w * 0.25f, cy, cx, cy - h * 0.22f, paint);
                canvas.drawLine(cx - w * 0.25f, cy, cx, cy + h * 0.22f, paint);
                break;
            case "gamepad":
                canvas.drawRoundRect(cx - w * 0.42f, cy - h * 0.26f, cx + w * 0.42f, cy + h * 0.26f, w * 0.16f, w * 0.16f, paint);
                int ogColorGamepad = paint.getColor();
                paint.setColor(Color.WHITE);
                canvas.drawCircle(cx - w * 0.18f, cy, w * 0.08f, paint);
                canvas.drawCircle(cx + w * 0.18f, cy, w * 0.08f, paint);
                paint.setColor(ogColorGamepad);
                break;
            case "location":
                Path pin = new Path();
                pin.moveTo(cx, cy + h * 0.35f);
                pin.quadTo(cx - w * 0.3f, cy, cx - w * 0.3f, cy - h * 0.15f);
                pin.arcTo(cx - w * 0.3f, cy - h * 0.45f, cx + w * 0.3f, cy + h * 0.15f, 180, 180, false);
                pin.quadTo(cx + w * 0.3f, cy, cx, cy + h * 0.35f);
                canvas.drawPath(pin, paint);
                int ogColorLoc = paint.getColor();
                paint.setColor(Color.WHITE);
                canvas.drawCircle(cx, cy - h * 0.15f, w * 0.12f, paint);
                paint.setColor(ogColorLoc);
                break;
            case "wallet":
                canvas.drawRoundRect(cx - w * 0.38f, cy - h * 0.26f, cx + w * 0.38f, cy + h * 0.26f, w * 0.1f, w * 0.1f, paint);
                int ogColorWal = paint.getColor();
                paint.setColor(Color.WHITE);
                canvas.drawCircle(cx + w * 0.18f, cy, w * 0.06f, paint);
                paint.setColor(ogColorWal);
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawLine(cx - w * 0.38f, cy - h * 0.08f, cx + w * 0.38f, cy - h * 0.08f, paint);
                break;
            case "skull":
                canvas.drawCircle(cx, cy - h * 0.05f, w * 0.28f, paint);
                canvas.drawRoundRect(cx - w * 0.16f, cy, cx + w * 0.16f, cy + h * 0.34f, w * 0.06f, w * 0.06f, paint);
                int ogColorSkull = paint.getColor();
                paint.setColor(Color.WHITE); 
                canvas.drawCircle(cx - w * 0.1f, cy - h * 0.05f, w * 0.07f, paint);
                canvas.drawCircle(cx + w * 0.1f, cy - h * 0.05f, w * 0.07f, paint);
                paint.setColor(ogColorSkull);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(w * 0.04f);
                canvas.drawLine(cx - w * 0.06f, cy + h * 0.2f, cx - w * 0.06f, cy + h * 0.26f, paint);
                canvas.drawLine(cx + w * 0.06f, cy + h * 0.2f, cx + w * 0.06f, cy + h * 0.26f, paint);
                break;
            case "trophy":
                Path trophy = new Path();
                trophy.moveTo(cx - w * 0.28f, cy - h * 0.34f);
                trophy.lineTo(cx + w * 0.28f, cy - h * 0.34f);
                trophy.lineTo(cx + w * 0.22f, cy + h * 0.08f);
                trophy.lineTo(cx - w * 0.22f, cy + h * 0.08f);
                trophy.close();
                canvas.drawPath(trophy, paint);
                canvas.drawRoundRect(cx - w * 0.06f, cy + h * 0.08f, cx + w * 0.06f, cy + h * 0.26f, 0, 0, paint);
                canvas.drawRoundRect(cx - w * 0.24f, cy + h * 0.24f, cx + w * 0.24f, cy + h * 0.36f, w * 0.06f, w * 0.06f, paint);
                break;
            case "crown":
                Path crown = new Path();
                crown.moveTo(cx - w * 0.35f, cy - h * 0.25f);
                crown.lineTo(cx - w * 0.15f, cy - h * 0.05f);
                crown.lineTo(cx, cy - h * 0.35f);
                crown.lineTo(cx + w * 0.15f, cy - h * 0.05f);
                crown.lineTo(cx + w * 0.35f, cy - h * 0.25f);
                crown.lineTo(cx + w * 0.25f, cy + h * 0.25f);
                crown.lineTo(cx - w * 0.25f, cy + h * 0.25f);
                crown.close();
                canvas.drawPath(crown, paint);
                break;
            case "coin":
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawCircle(cx, cy, w * 0.35f, paint);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy, w * 0.2f, paint);
                break;
            case "users":
                canvas.drawCircle(cx - w * 0.16f, cy - h * 0.08f, w * 0.15f, paint);
                canvas.drawCircle(cx + w * 0.16f, cy + h * 0.08f, w * 0.15f, paint);
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawArc(cx - w * 0.35f, cy, cx + w * 0.05f, cy + h * 0.3f, 180, 180, false, paint);
                break;
            case "timer":
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawCircle(cx, cy, w * 0.36f, paint);
                canvas.drawLine(cx, cy, cx, cy - h * 0.18f, paint);
                canvas.drawLine(cx, cy, cx + w * 0.16f, cy, paint);
                break;
            case "chevron":
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(w * 0.1f);
                canvas.drawLine(cx - w * 0.12f, cy - h * 0.2f, cx + w * 0.15f, cy, paint);
                canvas.drawLine(cx + w * 0.15f, cy, cx - w * 0.12f, cy + h * 0.2f, paint);
                break;
            case "document":
                canvas.drawRoundRect(cx - w * 0.28f, cy - h * 0.36f, cx + w * 0.28f, cy + h * 0.36f, w * 0.08f, w * 0.08f, paint);
                paint.setColor(Color.WHITE);
                paint.setStrokeWidth(w * 0.05f);
                canvas.drawLine(cx - w * 0.14f, cy - h * 0.14f, cx + w * 0.14f, cy - h * 0.14f, paint);
                canvas.drawLine(cx - w * 0.14f, cy, cx + w * 0.14f, cy, paint);
                canvas.drawLine(cx - w * 0.14f, cy + h * 0.14f, cx + w * 0.14f, cy + h * 0.14f, paint);
                break;
            case "target":
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawCircle(cx, cy, w * 0.36f, paint);
                canvas.drawCircle(cx, cy, w * 0.15f, paint);
                canvas.drawLine(cx - w * 0.46f, cy, cx + w * 0.46f, cy, paint);
                canvas.drawLine(cx, cy - h * 0.46f, cx, cy + h * 0.46f, paint);
                break;
        }
    }

    @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
    @Override public void setColorFilter(ColorFilter cf) { paint.setColorFilter(cf); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}