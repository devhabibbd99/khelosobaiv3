package com.khelosobaiv3.user;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MatchDetailsDialog {

    private final int C_PRI = 0xFF4F46E5, C_SEC = 0xFFEC4899, C_TXT_D = 0xFF0F172A, C_TXT_M = 0xFF64748B, C_BG = 0xFFF8FAFC, C_ACC = 0xFFFF4081;
    private final Activity activity;
    private String title = "", map = "", perspective = "", mode = "", liveText = "", prizeTotalWin = "", prizeEntryFee = "", prizePerKill = "", prizeDetails = "", roomId = "", password = "", lockedMsg = "";
    private boolean hasAccessCode = false, showPrizeDetailsSection = true, showAccessCodeSection = true;
    private final boolean isPassRevealed = true; // password is always shown directly, never masked
    private FrameLayout dialogRoot;
    private View overlay;
    private LinearLayout bottomSheet, dynamicIsland;
    private TextView toastMsg;

    public MatchDetailsDialog(Activity activity) { this.activity = activity; }
    public MatchDetailsDialog setTitle(String t) { this.title = t; return this; }
    public MatchDetailsDialog setMatchInfo(String m, String p, String md) { this.map = m; this.perspective = p; this.mode = md; return this; }
    public MatchDetailsDialog setLiveText(String l) { this.liveText = l; return this; }
    public MatchDetailsDialog setPrizes(String tw, String ef, String pk) { this.prizeTotalWin = tw; this.prizeEntryFee = ef; this.prizePerKill = pk; return this; }
    public MatchDetailsDialog setPrizeDetails(String pd) { this.prizeDetails = pd; return this; }
    public MatchDetailsDialog setAccessCode(String rid, String pass) { this.hasAccessCode = true; this.roomId = rid; this.password = pass; return this; }
    public MatchDetailsDialog setLockedMessage(String m) { this.hasAccessCode = false; this.lockedMsg = m; return this; }
    public MatchDetailsDialog setShowPrizeDetailsSection(boolean s) { this.showPrizeDetailsSection = s; return this; }
    public MatchDetailsDialog setShowAccessCodeSection(boolean s) { this.showAccessCodeSection = s; return this; }

    public void show() {
        ViewGroup contentRoot = activity.findViewById(android.R.id.content);
        dialogRoot = new FrameLayout(activity);
        dialogRoot.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        
        dialogRoot.setFocusableInTouchMode(true);
        dialogRoot.requestFocus();
        dialogRoot.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                toggleSheet(false);
                return true;
            }
            return false;
        });

        createOverlay();
        createBottomSheet();
        createDynamicIsland();

        bottomSheet.setTranslationY(activity.getResources().getDisplayMetrics().heightPixels);
        contentRoot.addView(dialogRoot);
        toggleSheet(true);
    }

    private void createOverlay() {
        overlay = new View(activity);
        overlay.setBackgroundColor(0x40000000);
        overlay.setAlpha(0f);
        overlay.setOnClickListener(v -> toggleSheet(false));
        dialogRoot.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
    }

    @SuppressLint("ClickableViewAccessibility")
    private void createBottomSheet() {
        bottomSheet = new LinearLayout(activity);
        bottomSheet.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable glassBg = new GradientDrawable();
        glassBg.setColor(0xFFFFFFFF);
        glassBg.setCornerRadii(new float[]{dp(28), dp(28), dp(28), dp(28), 0, 0, 0, 0});
        bottomSheet.setBackground(glassBg);
        bottomSheet.setElevation(dp(20));
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            bottomSheet.setOutlineAmbientShadowColor(C_PRI);
            bottomSheet.setOutlineSpotShadowColor(C_PRI);
        }
        
        bottomSheet.setPadding(dp(20), dp(10), dp(20), dp(20));
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, -2);
        params.gravity = Gravity.BOTTOM;
        bottomSheet.setLayoutParams(params);

        View handle = new View(activity);
        handle.setBackground(createBg(0xFFE2E8F0, dp(10)));
        LinearLayout.LayoutParams hParams = new LinearLayout.LayoutParams(dp(36), dp(4));
        hParams.gravity = Gravity.CENTER_HORIZONTAL;
        hParams.bottomMargin = dp(16);
        handle.setLayoutParams(hParams);
        bottomSheet.addView(handle);

        bottomSheet.setOnTouchListener(new View.OnTouchListener() {
            float startY, initY;
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startY = e.getRawY();
                        initY = bottomSheet.getTranslationY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dy = e.getRawY() - startY;
                        if (dy > 0) bottomSheet.setTranslationY(initY + (dy * 0.7f));
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (e.getRawY() - startY > dp(80)) toggleSheet(false);
                        else bottomSheet.animate().translationY(0).setDuration(300).setInterpolator(new OvershootInterpolator(1f)).start();
                        return true;
                }
                return false;
            }
        });

        LinearLayout headerBox = new LinearLayout(activity);
        headerBox.setOrientation(LinearLayout.HORIZONTAL);
        headerBox.setGravity(Gravity.CENTER_VERTICAL);
        
        LinearLayout titleBox = new LinearLayout(activity);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        AnimatedShimmerTextView tvTitle = new AnimatedShimmerTextView(activity, C_TXT_D, C_PRI);
        tvTitle.setText(title);
        tvTitle.setTextSize(20);
        tvTitle.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        
        LinearLayout subBox = new LinearLayout(activity);
        subBox.setOrientation(LinearLayout.HORIZONTAL);
        subBox.setGravity(Gravity.CENTER_VERTICAL);
        subBox.addView(new DuotoneIconView(activity, DuotoneIconView.GAMEPAD, C_TXT_M, dp(12)));
        TextView subTitle = new TextView(activity);
        subTitle.setText(" " + map + " • " + perspective + " • " + mode);
        subTitle.setTextSize(11);
        subTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        subTitle.setTextColor(C_TXT_M);
        subBox.addView(subTitle);
        
        titleBox.addView(tvTitle);
        titleBox.addView(subBox);
        headerBox.addView(titleBox);

        LinearLayout badgeBox = new LinearLayout(activity);
        badgeBox.setBackground(createStrokeBg(0x1AEF4444, 0x33EF4444, dp(20)));
        badgeBox.setPadding(dp(10), dp(4), dp(10), dp(4));
        badgeBox.setGravity(Gravity.CENTER);
        
        View dot = new View(activity);
        dot.setBackground(createBg(0xFFEF4444, dp(4)));
        dot.setLayoutParams(new LinearLayout.LayoutParams(dp(6), dp(6)));
        ValueAnimator pulse = ValueAnimator.ofFloat(1f, 0.4f);
        pulse.setDuration(800);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.addUpdateListener(a -> dot.setAlpha((float) a.getAnimatedValue()));
        pulse.start();

        TextView badgeTxt = new TextView(activity);
        badgeTxt.setText(" " + liveText);
        badgeTxt.setTextColor(0xFFEF4444);
        badgeTxt.setTextSize(11);
        badgeTxt.setTypeface(Typeface.create("sans-serif-bold", Typeface.NORMAL));
        badgeBox.addView(dot);
        badgeBox.addView(badgeTxt);
        headerBox.addView(badgeBox);
        bottomSheet.addView(headerBox);
        bottomSheet.addView(createSpace(dp(16)));

        bottomSheet.addView(createSectionTitle(DuotoneIconView.TROPHY, 0xFFF59E0B, "Rewards", "৳ " + prizeTotalWin + " Pool"));
        bottomSheet.addView(createSpace(dp(10)));
        
        LinearLayout grid = new LinearLayout(activity);
        grid.setOrientation(LinearLayout.HORIZONTAL);
        grid.addView(new Tilt3DCard(activity, DuotoneIconView.CROWN, 0xFFF59E0B, "Total Win", "৳" + prizeTotalWin, 0xFFFFFBEB, 0xFFFDE68A, 0xFFF59E0B, 0xFFD97706));
        grid.addView(new Tilt3DCard(activity, DuotoneIconView.MEDAL, 0xFF64748B, "Entry Fee", "৳" + prizeEntryFee, C_BG, 0xFFE2E8F0, C_TXT_D, C_TXT_M));
        grid.addView(new Tilt3DCard(activity, DuotoneIconView.TARGET, 0xFFEF4444, "Per Kill", "৳" + prizePerKill, 0xFFFEF2F2, 0xFFFECACA, 0xFFEF4444, 0xFFBE123C));
        bottomSheet.addView(grid);
        bottomSheet.addView(createSpace(dp(16)));

        if (showPrizeDetailsSection && prizeDetails != null && !prizeDetails.isEmpty()) {
            bottomSheet.addView(createSectionTitle(DuotoneIconView.TROPHY, C_PRI, "Prize Details", ""));
            bottomSheet.addView(createSpace(dp(10)));
            LinearLayout detailsBox = new LinearLayout(activity);
            detailsBox.setOrientation(LinearLayout.VERTICAL);
            detailsBox.setBackground(createStrokeBg(Color.WHITE, 0xFFE2E8F0, dp(16)));
            detailsBox.setPadding(dp(16), dp(16), dp(16), dp(16));
            TextView detailsTxt = new TextView(activity);
            detailsTxt.setText(prizeDetails);
            detailsTxt.setTextColor(C_TXT_D);
            detailsTxt.setTextSize(13);
            detailsTxt.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            detailsTxt.setLineSpacing(dp(4), 1.0f);
            detailsBox.addView(detailsTxt);
            bottomSheet.addView(detailsBox);
            bottomSheet.addView(createSpace(dp(16)));
        }

        if (showAccessCodeSection) {
            bottomSheet.addView(createSectionTitle(DuotoneIconView.LOCK, C_SEC, "Access Code", ""));
            bottomSheet.addView(createSpace(dp(10)));
            if (hasAccessCode) {
                LinearLayout credBox = new LinearLayout(activity);
                credBox.setOrientation(LinearLayout.VERTICAL);
                credBox.setBackground(createStrokeBg(Color.WHITE, 0xFFE2E8F0, dp(16)));
                credBox.setPadding(dp(14), dp(6), dp(14), dp(6));
                credBox.addView(createCredRow("ROOM ID", roomId, false));
                View div = new View(activity);
                div.setBackgroundColor(0x1A000000);
                div.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
                credBox.addView(div);
                credBox.addView(createCredRow("PASSWORD", password, true));
                bottomSheet.addView(credBox);
            } else {
                LinearLayout lockedBox = new LinearLayout(activity);
                lockedBox.setOrientation(LinearLayout.HORIZONTAL);
                lockedBox.setGravity(Gravity.CENTER_VERTICAL);
                lockedBox.setBackground(createStrokeBg(0xFFFEF2F2, 0xFFFECACA, dp(16)));
                lockedBox.setPadding(dp(16), dp(16), dp(16), dp(16));
                lockedBox.addView(new DuotoneIconView(activity, DuotoneIconView.LOCK, 0xFFEF4444, dp(24)));
                TextView msgTxt = new TextView(activity);
                msgTxt.setText(" " + lockedMsg);
                msgTxt.setTextColor(0xFFBE123C);
                msgTxt.setTextSize(13);
                msgTxt.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
                msgTxt.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
                msgTxt.setPadding(dp(8), 0, 0, 0);
                lockedBox.addView(msgTxt);
                bottomSheet.addView(lockedBox);
            }
            bottomSheet.addView(createSpace(dp(20)));
        }

        LinearLayout joinBtn = new LinearLayout(activity);
        joinBtn.setOrientation(LinearLayout.HORIZONTAL);
        joinBtn.setGravity(Gravity.CENTER);
        joinBtn.setBackground(createGradientBg(C_TXT_D, 0xFF1E293B, dp(12)));
        joinBtn.setPadding(0, dp(12), 0, dp(12));
        TextView joinTxt = new TextView(activity);
        joinTxt.setText("Close");
        joinTxt.setTextColor(Color.WHITE);
        joinTxt.setTextSize(14);
        joinTxt.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        joinBtn.addView(joinTxt);
        joinBtn.setOnTouchListener(new BouncyTouchListener(() -> toggleSheet(false)));
        bottomSheet.addView(joinBtn);
        dialogRoot.addView(bottomSheet);
    }

    private void createDynamicIsland() {
        dynamicIsland = new LinearLayout(activity);
        dynamicIsland.setGravity(Gravity.CENTER);
        dynamicIsland.setBackground(createBg(0xFF1E293B, dp(24)));
        dynamicIsland.setPadding(dp(16), dp(10), dp(16), dp(10));
        dynamicIsland.setElevation(dp(8));
        dynamicIsland.addView(new DuotoneIconView(activity, DuotoneIconView.CHECK, 0xFF10B981, dp(14)));
        toastMsg = new TextView(activity);
        toastMsg.setText(" Copied!");
        toastMsg.setTextColor(Color.WHITE);
        toastMsg.setTextSize(12);
        toastMsg.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        toastMsg.setPadding(dp(6), 0, 0, 0);
        dynamicIsland.addView(toastMsg);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-2, -2);
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.topMargin = dp(40);
        dynamicIsland.setLayoutParams(params);
        dynamicIsland.setTranslationY(dp(-150));
        dialogRoot.addView(dynamicIsland);
    }

    private void toggleSheet(boolean open) {
        int screenHeight = activity.getResources().getDisplayMetrics().heightPixels;
        if (open) {
            overlay.animate().alpha(1f).setDuration(300).start();
            bottomSheet.animate().translationY(0).setDuration(400).setInterpolator(new OvershootInterpolator(0.85f)).start();
        } else {
            overlay.animate().alpha(0f).setDuration(250).start();
            bottomSheet.animate().translationY(screenHeight).setDuration(300).setInterpolator(new DecelerateInterpolator()).withEndAction(() -> {
                ViewGroup contentRoot = activity.findViewById(android.R.id.content);
                contentRoot.removeView(dialogRoot);
            }).start();
        }
    }

    private void copyToClipboard(String text, boolean isSecret) {
        ClipboardManager cb = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText("Code", text));
        toastMsg.setText(isSecret ? " Password Copied!" : " ID Copied!");
        dynamicIsland.animate().translationY(0).setDuration(400).setInterpolator(new OvershootInterpolator(1f)).withEndAction(() -> {
            dynamicIsland.postDelayed(() -> dynamicIsland.animate().translationY(dp(-150)).setDuration(300).start(), 1500);
        }).start();
    }

    private LinearLayout createSectionTitle(int iconType, int color, String titleStr, String rightStr) {
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(new DuotoneIconView(activity, iconType, color, dp(16)));
        TextView titleTv = new TextView(activity);
        titleTv.setText(" " + titleStr);
        titleTv.setTypeface(Typeface.create("sans-serif-bold", Typeface.NORMAL));
        titleTv.setTextColor(C_TXT_D);
        titleTv.setTextSize(14);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(titleTv);
        if (!rightStr.isEmpty()) {
            GradientTextView right = new GradientTextView(activity, C_PRI, C_ACC);
            right.setText(rightStr);
            right.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
            right.setTextSize(13);
            row.addView(right);
        }
        return row;
    }

    private LinearLayout createCredRow(String labelStr, String valStr, boolean isSecret) {
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));
        LinearLayout infoBox = new LinearLayout(activity);
        infoBox.setOrientation(LinearLayout.VERTICAL);
        infoBox.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        TextView label = new TextView(activity);
        label.setText(labelStr);
        label.setTextSize(9);
        label.setTextColor(C_TXT_M);
        label.setTypeface(Typeface.create("sans-serif-bold", Typeface.NORMAL));
        TextView val = new TextView(activity);
        val.setText(valStr);
        val.setTextSize(18);
        val.setTextColor(isSecret && !isPassRevealed ? C_TXT_M : C_PRI);
        val.setTypeface(Typeface.create("monospace", Typeface.BOLD));
        val.setLetterSpacing(0.03f);
        infoBox.addView(label);
        infoBox.addView(val);
        row.addView(infoBox);
        LinearLayout actions = new LinearLayout(activity);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        // Eye/lock toggle removed - password is now always shown directly, no click needed.
        // Masking (########) is only a VISUAL state - copy should always give the
        // real password, whether it's currently shown revealed or hidden.
        LinearLayout btnCopy = createIconButton(new DuotoneIconView(activity, DuotoneIconView.COPY, C_TXT_D, dp(18)));
        btnCopy.setOnTouchListener(new BouncyTouchListener(() -> copyToClipboard(isSecret ? password : valStr, isSecret)));
        actions.addView(btnCopy);
        row.addView(actions);
        return row;
    }

    private LinearLayout createIconButton(View icon) {
        LinearLayout btn = new LinearLayout(activity);
        btn.setGravity(Gravity.CENTER);
        btn.setBackground(createStrokeBg(Color.WHITE, 0xFFCBD5E1, dp(10)));
        btn.setLayoutParams(new LinearLayout.LayoutParams(dp(36), dp(36)));
        btn.addView(icon);
        return btn;
    }

    private int dp(int dp) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, activity.getResources().getDisplayMetrics()); }
    private View createSpace(int h) { View v = new View(activity); v.setLayoutParams(new LinearLayout.LayoutParams(1, h)); return v; }
    private View createSpaceHorizontal(int w) { View v = new View(activity); v.setLayoutParams(new LinearLayout.LayoutParams(w, 1)); return v; }
    private GradientDrawable createBg(int c, int r) { GradientDrawable gd = new GradientDrawable(); gd.setColor(c); gd.setCornerRadius(r); return gd; }
    private GradientDrawable createStrokeBg(int sc, int stc, int r) { GradientDrawable gd = new GradientDrawable(); gd.setColor(sc); gd.setCornerRadius(r); gd.setStroke(dp(1), stc); return gd; }
    private GradientDrawable createGradientBg(int s, int e, int r) { GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{s, e}); gd.setCornerRadius(r); return gd; }

    public static class GradientTextView extends TextView {
        private int c1, c2;
        public GradientTextView(Context context, int c1, int c2) { super(context); this.c1 = c1; this.c2 = c2; }
        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) { super.onSizeChanged(w, h, oldw, oldh); getPaint().setShader(new LinearGradient(0, 0, w, 0, c1, c2, Shader.TileMode.CLAMP)); }
    }

    public static class AnimatedShimmerTextView extends TextView {
        private LinearGradient gradient; private Matrix matrix; private float translate = 0; private int c1, c2;
        public AnimatedShimmerTextView(Context context, int c1, int c2) { super(context); this.c1 = c1; this.c2 = c2; matrix = new Matrix(); }
        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            gradient = new LinearGradient(0, 0, w, 0, new int[]{c1, c2, Color.WHITE, c2, c1}, new float[]{0, 0.4f, 0.5f, 0.6f, 1}, Shader.TileMode.CLAMP);
            getPaint().setShader(gradient);
            ValueAnimator anim = ValueAnimator.ofFloat(0, w * 2);
            anim.setDuration(2500); anim.setRepeatCount(ValueAnimator.INFINITE); anim.setInterpolator(new LinearInterpolator());
            anim.addUpdateListener(a -> { translate = (float) a.getAnimatedValue() - w; matrix.setTranslate(translate, 0); gradient.setLocalMatrix(matrix); invalidate(); });
            anim.start();
        }
    }

    public static class BouncyTouchListener implements View.OnTouchListener {
        Runnable action;
        public BouncyTouchListener(Runnable action){ this.action = action; }
        @Override public boolean onTouch(View v, MotionEvent e) {
            switch(e.getAction()){
                case MotionEvent.ACTION_DOWN: v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(100).start(); break;
                case MotionEvent.ACTION_UP: v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); v.animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(new OvershootInterpolator(1.5f)).start(); if(action != null) action.run(); break;
                case MotionEvent.ACTION_CANCEL: v.animate().scaleX(1f).scaleY(1f).setDuration(150).start(); break;
            } return true;
        }
    }

    public class Tilt3DCard extends LinearLayout {
        private Paint lightP; private float lightX = -1000, lightY = -1000;
        public Tilt3DCard(Context c, int icon, int iColor, String titleStr, String amtStr, int bg, int strk, int txtColor1, int txtColor2) {
            super(c); setOrientation(VERTICAL); setGravity(Gravity.CENTER); setBackground(createStrokeBg(bg, strk, dp(12))); setPadding(dp(2), dp(10), dp(2), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f); lp.setMargins(dp(4), 0, dp(4), 0); setLayoutParams(lp);
            DuotoneIconView imgIcon = new DuotoneIconView(c, icon, iColor, dp(22));
            LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(22), dp(22)); iconParams.gravity = Gravity.CENTER_HORIZONTAL; imgIcon.setLayoutParams(iconParams); addView(imgIcon);
            TextView tv1 = new TextView(c); tv1.setText(titleStr); tv1.setTextSize(9); tv1.setTextColor(C_TXT_M); tv1.setTypeface(Typeface.create("sans-serif-bold", Typeface.NORMAL)); tv1.setPadding(0, dp(6), 0, 0); tv1.setGravity(Gravity.CENTER); addView(tv1);
            GradientTextView tv2 = new GradientTextView(c, txtColor1, txtColor2); tv2.setText(amtStr); tv2.setTextSize(16); tv2.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL)); tv2.setGravity(Gravity.CENTER); addView(tv2);
            lightP = new Paint(Paint.ANTI_ALIAS_FLAG); setClipToOutline(true);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            lightX = e.getX(); lightY = e.getY();
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN: case MotionEvent.ACTION_MOVE: setRotationX(-(lightY - getHeight() / 2f) / 8f); setRotationY((lightX - getWidth() / 2f) / 8f); setScaleX(0.95f); setScaleY(0.95f); break;
                case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: lightX = -1000; animate().rotationX(0).rotationY(0).scaleX(1f).scaleY(1f).setDuration(300).setInterpolator(new OvershootInterpolator(1f)).start(); break;
            } invalidate(); return true;
        }
        @Override protected void dispatchDraw(Canvas cv) {
            super.dispatchDraw(cv);
            if(lightX > -100) { lightP.setShader(new RadialGradient(lightX, lightY, getWidth() * 0.8f, 0x4DFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)); cv.drawRect(0, 0, getWidth(), getHeight(), lightP); }
        }
    }

    public static class DuotoneIconView extends View {
        public static final int ROCKET=0, GAMEPAD=1, TROPHY=2, CROWN=3, MEDAL=4, TARGET=5, LOCK=6, UNLOCK=7, COPY=8, CHECK=9, ARROW=10;
        private int type; private Paint pMain, pAccent;
        public DuotoneIconView(Context c, int type, int color, int size) {
            super(c); this.type = type; setLayoutParams(new LinearLayout.LayoutParams(size, size));
            pMain = new Paint(Paint.ANTI_ALIAS_FLAG); pMain.setColor(color); pMain.setStyle(Paint.Style.STROKE); pMain.setStrokeWidth(Math.max(3f, size / 13f)); pMain.setStrokeCap(Paint.Cap.ROUND); pMain.setStrokeJoin(Paint.Join.ROUND);
            pAccent = new Paint(pMain); pAccent.setAlpha(80);
        }
        public void setType(int t) { this.type = t; invalidate(); }
        @Override protected void onDraw(Canvas cv) {
            super.onDraw(cv); cv.scale(getWidth() / 100f, getHeight() / 100f);
            Path phMain = new Path(); Path phAccent = new Path();
            switch (type) {
                case ROCKET: phMain.moveTo(45, 15); phMain.lineTo(85, 15); phMain.lineTo(85, 55); phMain.lineTo(60, 80); phMain.lineTo(45, 80); phMain.lineTo(20, 55); phMain.close(); phAccent.addCircle(55, 45, 10, Path.Direction.CW); phAccent.moveTo(25, 50); phAccent.lineTo(10, 85); phAccent.lineTo(45, 75); break;
                case GAMEPAD: phMain.addRoundRect(new RectF(10, 25, 90, 75), 25, 25, Path.Direction.CW); phAccent.moveTo(25, 50); phAccent.lineTo(45, 50); phAccent.moveTo(35, 40); phAccent.lineTo(35, 60); phAccent.moveTo(65, 50); phAccent.lineTo(65.1f, 50); phAccent.moveTo(75, 40); phAccent.lineTo(75.1f, 40); pAccent.setStrokeCap(Paint.Cap.ROUND); pAccent.setStrokeWidth(pMain.getStrokeWidth() * 2); break;
                case TROPHY: phMain.moveTo(25, 15); phMain.lineTo(75, 15); phMain.lineTo(65, 55); phMain.cubicTo(65, 65, 35, 65, 35, 55); phMain.close(); phAccent.moveTo(50, 60); phAccent.lineTo(50, 85); phAccent.moveTo(30, 85); phAccent.lineTo(70, 85); phAccent.moveTo(25, 15); phAccent.cubicTo(5, 15, 5, 45, 30, 45); phAccent.moveTo(75, 15); phAccent.cubicTo(95, 15, 95, 45, 70, 45); break;
                case CROWN: phMain.moveTo(15, 80); phMain.lineTo(85, 80); phMain.lineTo(85, 65); phMain.lineTo(15, 65); phMain.close(); phAccent.moveTo(15, 65); phAccent.lineTo(20, 20); phAccent.lineTo(40, 45); phAccent.lineTo(50, 15); phAccent.lineTo(60, 45); phAccent.lineTo(80, 20); phAccent.lineTo(85, 65); break;
                case MEDAL: phMain.addCircle(50, 65, 22, Path.Direction.CW); phAccent.moveTo(35, 50); phAccent.lineTo(25, 15); phAccent.lineTo(50, 30); phAccent.lineTo(75, 15); phAccent.lineTo(65, 50); break;
                case TARGET: phMain.addCircle(50, 50, 35, Path.Direction.CW); phAccent.addCircle(50, 50, 15, Path.Direction.CW); phAccent.moveTo(50, 5); phAccent.lineTo(50, 20); phAccent.moveTo(50, 80); phAccent.lineTo(50, 95); phAccent.moveTo(5, 50); phAccent.lineTo(20, 50); phAccent.moveTo(80, 50); phAccent.lineTo(95, 50); break;
                case LOCK: phMain.addRoundRect(new RectF(25, 45, 75, 85), 10, 10, Path.Direction.CW); phAccent.moveTo(35, 45); phAccent.lineTo(35, 30); phAccent.cubicTo(35, 15, 65, 15, 65, 30); phAccent.lineTo(65, 45); phAccent.moveTo(50, 55); phAccent.lineTo(50, 70); break;
                case UNLOCK: phMain.addRoundRect(new RectF(25, 45, 75, 85), 10, 10, Path.Direction.CW); phAccent.moveTo(65, 45); phAccent.lineTo(65, 30); phAccent.cubicTo(65, 15, 35, 15, 35, 30); phAccent.moveTo(50, 55); phAccent.lineTo(50, 70); break;
                case COPY: phMain.addRoundRect(new RectF(35, 35, 85, 85), 10, 10, Path.Direction.CW); phAccent.moveTo(15, 65); phAccent.lineTo(15, 25); phAccent.cubicTo(15, 15, 15, 15, 25, 15); phAccent.lineTo(65, 15); break;
                case CHECK: phMain.moveTo(25, 50); phMain.lineTo(45, 70); phMain.lineTo(75, 30); phAccent.addCircle(50, 50, 45, Path.Direction.CW); break;
                case ARROW: phMain.moveTo(55, 25); phMain.lineTo(80, 50); phMain.lineTo(55, 75); phAccent.moveTo(20, 50); phAccent.lineTo(80, 50); break;
            }
            cv.drawPath(phMain, pMain); pAccent.setStrokeWidth(pMain.getStrokeWidth()); cv.drawPath(phAccent, pAccent);
        }
    }
}