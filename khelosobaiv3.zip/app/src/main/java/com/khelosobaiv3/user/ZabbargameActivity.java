package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebViewClient;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import androidx.core.view.WindowCompat;

public class ZabbargameActivity extends AppCompatActivity {
	
	private ZabbargameBinding binding;
	
	private SharedPreferences Save_User_Status;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ZabbargameBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		Save_User_Status = getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE);
		
		binding.webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				webview1.setVisibility(View.GONE);
				linear34.setVisibility(View.VISIBLE);
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				linear34.setVisibility(View.GONE);
				webview1.setVisibility(View.VISIBLE);
				super.onPageFinished(_param1, _param2);
			}
		});
	}
	
	private void initializeLogic() {
		binding.webview1.getSettings().setJavaScriptEnabled(true);
		binding.webview1.getSettings().setDomStorageEnabled(true);
		binding.webview1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
		binding.webview1.clearCache(true);
		
		binding.linear34.setVisibility(View.VISIBLE);
		binding.webview1.setVisibility(View.GONE);
		
		binding.webview1.setWebViewClient(new WebViewClient() {
			
			    @Override
			    public void onPageStarted(WebView view, String url, Bitmap favicon) {
				        super.onPageStarted(view, url, favicon);
				
				        binding.linear34.setVisibility(View.VISIBLE);
				        binding.webview1.setVisibility(View.GONE);
				    }
			
			    @Override
			    public void onPageFinished(WebView view, String url) {
				        super.onPageFinished(view, url);
				
				        binding.linear34.setVisibility(View.GONE);
				        binding.webview1.setVisibility(View.VISIBLE);
				        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
					    getWindow().setStatusBarColor(Color.parseColor("#FF07060E"));
					    getWindow().setNavigationBarColor(Color.parseColor("#FF07060E"));
				}
				    }
			
			    @Override
			    public void onReceivedError(
			            WebView view,
			            WebResourceRequest request,
			            WebResourceError error) {
				
				        super.onReceivedError(view, request, error);
				
				        binding.linear34.setVisibility(View.GONE);
				        binding.webview1.setVisibility(View.VISIBLE);
				    }
		});
		
		String token = getSharedPreferences(
		        "Save_User_Status",
		        MODE_PRIVATE
		).getString("Token", "");
		
		if (!token.isEmpty()) {
			    binding.webview1.loadUrl(
			            "https://zvy.devhabibbd.shop/Bom/index.php?token=" + token
			    );
		} else {
			    binding.linear34.setVisibility(View.GONE);
			
			    Toast.makeText(
			            ZabbargameActivity.this,
			            "Token নেই!",
			            Toast.LENGTH_SHORT
			    ).show();
		}
	}
	
}