package com.khelosobaiv3.user;

public class ChatMessage {
    public int id;
    public String senderType; // "user" or "admin"
    public String message;
    public String createdAt;

    public ChatMessage(int id, String senderType, String message, String createdAt) {
        this.id = id;
        this.senderType = senderType;
        this.message = message;
        this.createdAt = createdAt;
    }
}
