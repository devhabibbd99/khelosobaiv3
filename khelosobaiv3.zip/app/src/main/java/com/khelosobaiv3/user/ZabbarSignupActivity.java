package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.*;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import android.app.AlertDialog;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class ZabbarSignupActivity extends AppCompatActivity {
	
	public final int REQ_CD_ZABBAR_GOOGLE_LOGIN = 101;
	
	private ZabbarLoading loading;
	private ZabbarSignupBinding binding;
	private HashMap<String, Object> Dev_Shuvo = new HashMap<>();
	private String FcmId = "";
	private String Key = "";
	private HashMap<String, Object> Data = new HashMap<>();
	private String zabbar_key_rendom = "";
	private HashMap<String, Object> zabbar_login_aj = new HashMap<>();
	private HashMap<String, Object> zabbarx = new HashMap<>();
	private String zabbar_google_login_key = "";
	private HashMap<String, Object> realtime = new HashMap<>();
	
	private GoogleSignInClient zabbar_google_login;
	private FirebaseAuth zabbar_auth;
	private OnCompleteListener<AuthResult> _zabbar_auth_create_user_listener;
	private OnCompleteListener<AuthResult> _zabbar_auth_sign_in_listener;
	private OnCompleteListener<Void> _zabbar_auth_reset_password_listener;
	private OnCompleteListener<Void> zabbar_auth_updateEmailListener;
	private OnCompleteListener<Void> zabbar_auth_updatePasswordListener;
	private OnCompleteListener<Void> zabbar_auth_emailVerificationSentListener;
	private OnCompleteListener<Void> zabbar_auth_deleteUserListener;
	private OnCompleteListener<Void> zabbar_auth_updateProfileListener;
	private OnCompleteListener<AuthResult> zabbar_auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> zabbar_auth_googleSignInListener;
	
	private Intent zabbar_i = new Intent();
	private RequestNetwork Manul_Login;
	private RequestNetwork.RequestListener _Manul_Login_request_listener;
	private SharedPreferences Api;
	private SharedPreferences Save_User_Status;
	private SharedPreferences dialogue;
	private Intent shuvobrogo = new Intent();
	
	private OnCompleteListener fcm_onCompleteListener;
	private Intent zabbar_no_use_only_tg = new Intent();
	private RequestNetwork zabbar_login;
	private RequestNetwork.RequestListener _zabbar_login_request_listener;
	private RequestNetwork Reset;
	private RequestNetwork.RequestListener _Reset_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ZabbarSignupBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		zabbar_auth = FirebaseAuth.getInstance();
		Manul_Login = new RequestNetwork(this);
		Api = getSharedPreferences("Api", Activity.MODE_PRIVATE);
		Save_User_Status = getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE);
		dialogue = getSharedPreferences("dialogue", Activity.MODE_PRIVATE);
		zabbar_login = new RequestNetwork(this);
		Reset = new RequestNetwork(this);
		
		binding.textview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				new SimpleBlurInputDialog.Builder(ZabbarSignupActivity.this)
				        .setTitle("Forget Your Password")
				        .setMessage("Reset and set a new password to recover your account")
				        .setHint("Email")
				        .setButtonText("Reset Password")
				        .setButtonColor("#004F50")
				        .setInputType(
				                InputType.TYPE_CLASS_TEXT |
				                InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
				        )
				        .setOnActionListener((dialog, input) -> {
					
					            String email = input.trim();
					
					            if (email.isEmpty()) {
						                Toast.makeText(
						                        ZabbarSignupActivity.this,
						                        "Please enter your email address",
						                        Toast.LENGTH_SHORT
						                ).show();
						                return;
						            }
					
					            try {
						                String url =
						                        "https://zvy.devhabibbd.shop/ElitegoxUser/reset_password.php?email="
						                        + java.net.URLEncoder.encode(email, "UTF-8");
						
						                Reset.startRequestNetwork(
						                        RequestNetworkController.GET,
						                        url,
						                        "",
						                        _Reset_request_listener
						                );
						
						            } catch (Exception e) {
						                Toast.makeText(
						                        ZabbarSignupActivity.this,
						                        e.toString(),
						                        Toast.LENGTH_SHORT
						                ).show();
						            }
					
					            dialog.dismiss();
					        })
				        .show();
			}
		});
		
		binding.getOtp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Dev_Shuvo = new HashMap<>();
				Dev_Shuvo.put("username", username.getText().toString());
				Dev_Shuvo.put("password", password.getText().toString());
				Dev_Shuvo.put("fcm_key", FcmId);
				Dev_Shuvo.put("DeVicE_iD", Key);
				Manul_Login.setParams(Dev_Shuvo, RequestNetworkController.REQUEST_PARAM);
				Manul_Login.startRequestNetwork(RequestNetworkController.POST, Api.getString("Api", "").concat("XMpp_Login.js.php"), "", _Manul_Login_request_listener);
				Dev_Shuvo.clear();
				showLoading();
			}
		});
		
		binding.zabbarGmail.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				zabbar_google_acount();
			}
		});
		
		binding.zabbarTg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				loading.show();
				
				zabbar_key_rendom = generateRandomKey(20);
				
				String deviceId = android.provider.Settings.Secure.getString(
				        getContentResolver(),
				        android.provider.Settings.Secure.ANDROID_ID
				);
				
				Intent zabbar_no_use_only_tg = new Intent();
				zabbar_no_use_only_tg.setAction(Intent.ACTION_VIEW);
				zabbar_no_use_only_tg.setData(Uri.parse(
				        "tg://resolve?domain=Skmesports_bot&start=" +
				                Uri.encode("start_code=" + zabbar_key_rendom +
				                        "=====device_id=" + deviceId)
				));
				startActivity(zabbar_no_use_only_tg);
			}
		});
		
		binding.zabbarWhatsapp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		binding.regGo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				shuvobrogo.putExtra("notice", getIntent().getStringExtra("notice"));
				zabbar_i.setClass(getApplicationContext(), ShuvobroRegisterpageActivity.class);
				startActivity(zabbar_i);
			}
		});
		
		_Manul_Login_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				loading.dismiss();
				hideLoading();
				Data = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				if (Data.get("status").toString().equals("success") && Data.get("message").toString().equals("Login Success")) {
					Save_User_Status.edit().putString("Token", Data.get("token").toString()).commit();
					Save_User_Status.edit().putString("Username", Data.get("username").toString()).commit();
					Save_User_Status.edit().putString("FcmId", Data.get("fcm_key").toString()).commit();
					Save_User_Status.edit().putString("Logged", "True").commit();
					SketchwareUtil.showMessage(getApplicationContext(), "Login Successful");
					dialogue.edit().putString("X", "True").commit();
					shuvobrogo.putExtra("notice", getIntent().getStringExtra("notice"));
					shuvobrogo.setClass(getApplicationContext(), ZabbarHomeActivity.class);
					startActivity(shuvobrogo);
					finish();
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), Data.get("message").toString());
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				new PremiumDialog.Builder(ZabbarSignupActivity.this)
				        .setLottie("warning.json")
				        .setTitle("No Internet Connection")
				        .setMessage("Please check your internet connection and try again.")
				        .setCancelable(false)
				        .setPositiveButton("Retry", "#004F50", dialog -> {
					            dialog.dismiss();
					            
					        })
				        .setNegativeButton("Close", dialog -> {
					            dialog.dismiss();
					            finish();
					        })
				        .show();
			}
		};
		
		fcm_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_zabbar_login_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				zabbarx = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				if (zabbarx.get("status").toString().contains("success")) {
					Dev_Shuvo = new HashMap<>();
					Dev_Shuvo.put("username", zabbarx.get("username").toString());
					Dev_Shuvo.put("password", zabbarx.get("password").toString());
					Dev_Shuvo.put("fcm_key", FcmId);
					Dev_Shuvo.put("DeVicE_iD", Key);
					Manul_Login.setParams(Dev_Shuvo, RequestNetworkController.REQUEST_PARAM);
					Manul_Login.startRequestNetwork(RequestNetworkController.POST, Api.getString("Api", "").concat("XMpp_Login.js.php"), "", _Manul_Login_request_listener);
					Dev_Shuvo.clear();
				} else {
					loading.dismiss();
					SketchwareUtil.showMessage(getApplicationContext(), "You are unable to log in due to a problem. Please try again!");
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				new PremiumDialog.Builder(ZabbarSignupActivity.this)
				        .setLottie("warning.json")
				        .setTitle("No Internet Connection")
				        .setMessage("Please check your internet connection and try again.")
				        .setCancelable(false)
				        .setPositiveButton("Retry", "#004F50", dialog -> {
					            dialog.dismiss();
					            
					        })
				        .setNegativeButton("Close", dialog -> {
					            dialog.dismiss();
					            finish();
					        })
				        .show();
			}
		};
		
		_Reset_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try{
					realtime = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					SketchwareUtil.showMessage(getApplicationContext(), realtime.get("message").toString());
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				new PremiumDialog.Builder(ZabbarSignupActivity.this)
				        .setLottie("warning.json")
				        .setTitle("No Internet Connection")
				        .setMessage("Please check your internet connection and try again.")
				        .setCancelable(false)
				        .setPositiveButton("Retry", "#004F50", dialog -> {
					            dialog.dismiss();
					            
					        })
				        .setNegativeButton("Close", dialog -> {
					            dialog.dismiss();
					            finish();
					        })
				        .show();
			}
		};
		
		zabbar_auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		zabbar_auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		zabbar_auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		zabbar_auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		zabbar_auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		zabbar_auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		zabbar_auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_zabbar_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_zabbar_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_zabbar_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		zabbarGmail.setVisibility(View.GONE);
		zabbarTg.setVisibility(View.GONE);
		SecurityChecker.check(this);
		Key = android.provider.Settings.Secure.getString(getApplicationContext().getContentResolver(),android.provider.Settings.Secure.ANDROID_ID);
		// xml android:fitsSystemWindows="true"
		
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
			    View decor = getWindow().getDecorView();
			    decor.setSystemUiVisibility(
			            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN 
			            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION 
			            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE 
			            | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
			    );
		}
		
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
			    getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			    getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
			    getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);
		}
		
		zabbarGmail.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFFE0E0E0, Color.TRANSPARENT));
		zabbarTg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFFE0E0E0, Color.TRANSPARENT));
		zabbarWhatsapp.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFFE0E0E0, Color.TRANSPARENT));
		numberBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)60, (int)2, 0xFFE0E0E0, Color.TRANSPARENT));
		pass.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)60, (int)2, 0xFFE0E0E0, Color.TRANSPARENT));
		binding.getOtp.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, getResources().getColor(R.color.md_theme_onPrimaryFixedVariant)));
		zabbarGetStart.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/zabbar_sans.ttf"), 1);
		binding.zabbarOtpText.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/montserratbold.ttf"), 1);
		binding.regGo.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/montserratbold.ttf"), 1);
		String text = "By continuing thereby accept the Terms of Service and Privacy Policy";
		SpannableString spannableString = new SpannableString(text);
		
		setBlueSpan(spannableString, text, "Terms of Service");
		setBlueSpan(spannableString, text, "Privacy Policy");
		
		
		binding.zabbarPolicy.setTextColor(Color.parseColor("#212121"));
		binding.zabbarPolicy.setText(spannableString);
		
		loading = new ZabbarLoading(this);
		_FcmDeviceID();
	}
	
	
	@Override
	public void onStart() {
		super.onStart();
		if (new ArabWareFileManager(zabbar_key_rendom).isEmpty()) {
			
		} else {
			zabbar_login_aj = new HashMap<>();
			zabbar_login_aj.put("start_code", zabbar_key_rendom);
			zabbar_login.setParams(zabbar_login_aj, RequestNetworkController.REQUEST_PARAM);
			zabbar_login.startRequestNetwork(RequestNetworkController.POST, "https://zvy.devhabibbd.shop/ElitegoxUser/start_code_check.php?", "", _zabbar_login_request_listener);
			zabbar_login_aj.clear();
		}
	}
	public void _Zabbar_Method() {
	}
	private void setBlueSpan(SpannableString ss, String fullText, String targetText) {
		    int start = fullText.indexOf(targetText);
		    if (start >= 0) {
			        ss.setSpan(
			            new ForegroundColorSpan(Color.BLUE),
			            start,
			            start + targetText.length(),
			            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
			        );
			    }
	}
	
	private androidx.appcompat.app.AlertDialog zabbarLoading;
	private com.google.android.gms.auth.api.identity.SignInClient oneTapClient;
	private com.google.android.gms.auth.api.identity.BeginSignInRequest signInRequest;
	private static final int REQ_ONE_TAP = 1002;
	
	private String generateRandomKey(int length) {
		    String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		    java.security.SecureRandom random = new java.security.SecureRandom();
		    StringBuilder sb = new StringBuilder();
		    for (int i = 0; i < length; i++) {
			        sb.append(chars.charAt(random.nextInt(chars.length())));
			    }
		    return sb.toString();
	}
	
	private String generateRandomNumber11() {
		    java.security.SecureRandom random = new java.security.SecureRandom();
		    StringBuilder sb = new StringBuilder();
		    sb.append(1 + random.nextInt(9));
		    for (int i = 0; i < 10; i++) {
			        sb.append(random.nextInt(10));
			    }
		    return sb.toString();
	}
	
	private String generateRandomPassword(int length) {
		    String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$_-";
		    java.security.SecureRandom random = new java.security.SecureRandom();
		    StringBuilder sb = new StringBuilder();
		    for (int i = 0; i < length; i++) {
			        sb.append(chars.charAt(random.nextInt(chars.length())));
			    }
		    return sb.toString();
	}
	
	private String getDhakaTime() {
		    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US);
		    sdf.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Dhaka"));
		    return sdf.format(new java.util.Date());
	}
	
	private String getGoogleSubFromIdToken(String idToken) {
		    try {
			        String[] parts = idToken.split("\\.");
			        if (parts.length < 2) return "";
			        byte[] decoded = android.util.Base64.decode(parts[1], android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP | android.util.Base64.NO_PADDING);
			        String payload = new String(decoded, "UTF-8");
			        org.json.JSONObject obj = new org.json.JSONObject(payload);
			        return obj.optString("sub", "");
			    } catch (Exception e) {
			        return "";
			    }
	}
	
	private void postGoogleLogin(String body, String telegramId) {
		    new Thread(() -> {
			        java.net.HttpURLConnection connection = null;
			        try {
				            java.net.URL url = new java.net.URL("https://api.khelosobai20.live/ElitegoxUser/Xampp_Reg.js.php");
				            connection = (java.net.HttpURLConnection) url.openConnection();
				            connection.setRequestMethod("POST");
				            connection.setDoOutput(true);
				            connection.setConnectTimeout(15000);
				            connection.setReadTimeout(15000);
				            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				            connection.setRequestProperty("User-Agent", "EliteGox/1.0");
				
				            java.io.OutputStream os = connection.getOutputStream();
				            os.write(body.getBytes("UTF-8"));
				            os.flush();
				            os.close();
				
				            java.io.InputStream is;
				            int code = connection.getResponseCode();
				            if (code >= 200 && code < 400) {
					                is = connection.getInputStream();
					            } else {
					                is = connection.getErrorStream();
					            }
				
				            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is));
				            StringBuilder response = new StringBuilder();
				            String line;
				            while ((line = br.readLine()) != null) {
					                response.append(line);
					            }
				            br.close();
				
				            String resp = response.toString();
				            runOnUiThread(() -> {
					                try {
						                    org.json.JSONObject obj = new org.json.JSONObject(resp);
						                    String status = obj.optString("status", "");
						                    String message = obj.optString("message", "Unknown error");
						                    if ("success".equalsIgnoreCase(status)) {
							                        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show();
							                        if (zabbar_google_login_key == null || zabbar_google_login_key.isEmpty()) {
								
								                        } else {
								                            zabbar_login_aj = new java.util.HashMap<>();
								                            zabbar_login_aj.put("start_code", zabbar_google_login_key);
								                            zabbar_login.setParams(zabbar_login_aj, RequestNetworkController.REQUEST_PARAM);
								                            zabbar_login.startRequestNetwork(RequestNetworkController.POST, "https://zvy.devhabibbd.shop/ElitegoxUser/start_code_check.php?", "", _zabbar_login_request_listener);
								                            zabbar_login_aj.clear();
								                        }
							                    } else {
							                        updateExistingUser(telegramId);
							                    }
						                } catch (Exception e) {
						                    android.widget.Toast.makeText(this, resp, android.widget.Toast.LENGTH_LONG).show();
						                }
					            });
				        } catch (Exception e) {
				            runOnUiThread(() -> android.widget.Toast.makeText(this, e.getMessage(), android.widget.Toast.LENGTH_LONG).show());
				        } finally {
				            if (connection != null) connection.disconnect();
				        }
			    }).start();
	}
	
	private void updateExistingUser(String telegramId) {
		    new Thread(() -> {
			        java.net.HttpURLConnection connection = null;
			        try {
				            zabbar_google_login_key = generateRandomKey(20);
				            String newTime = getDhakaTime();
				
				            org.json.JSONObject extra = new org.json.JSONObject();
				            extra.put("start_code", zabbar_google_login_key);
				            extra.put("start_code_date_and_full_time", newTime);
				            extra.put("telegram_id", telegramId);
				
				            String extraJson = extra.toString();
				
				            String body = "telegram_id=" + java.net.URLEncoder.encode(telegramId, "UTF-8") +
				                          "&extract_json=" + java.net.URLEncoder.encode(extraJson, "UTF-8");
				
				            java.net.URL url = new java.net.URL("https://api.khelosobai20.live/ElitegoxUser/tgidcheck.php");
				            connection = (java.net.HttpURLConnection) url.openConnection();
				            connection.setRequestMethod("POST");
				            connection.setDoOutput(true);
				            connection.setConnectTimeout(15000);
				            connection.setReadTimeout(15000);
				            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				
				            java.io.OutputStream os = connection.getOutputStream();
				            os.write(body.getBytes("UTF-8"));
				            os.flush();
				            os.close();
				
				            java.io.InputStream is;
				            int code = connection.getResponseCode();
				            if (code >= 200 && code < 400) {
					                is = connection.getInputStream();
					            } else {
					                is = connection.getErrorStream();
					            }
				
				            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is));
				            StringBuilder response = new StringBuilder();
				            String line;
				            while ((line = br.readLine()) != null) {
					                response.append(line);
					            }
				            br.close();
				
				            String resp = response.toString();
				            runOnUiThread(() -> {
					                try {
						                    org.json.JSONObject obj = new org.json.JSONObject(resp);
						                    boolean account = obj.optBoolean("account", false);
						                    if (account) {
							                        android.widget.Toast.makeText(this, "Account data updated successfully", android.widget.Toast.LENGTH_LONG).show();
							                        if (zabbar_google_login_key == null || zabbar_google_login_key.isEmpty()) {
								
								                        } else {
								                            zabbar_login_aj = new java.util.HashMap<>();
								                            zabbar_login_aj.put("start_code", zabbar_google_login_key);
								                            zabbar_login.setParams(zabbar_login_aj, RequestNetworkController.REQUEST_PARAM);
								                            zabbar_login.startRequestNetwork(RequestNetworkController.POST, "https://api.khelosobai20.live/ElitegoxUser/start_code_check.php?", "", _zabbar_login_request_listener);
								                            zabbar_login_aj.clear();
								                        }
							                    } else {
							                        android.widget.Toast.makeText(this, "Update failed", android.widget.Toast.LENGTH_LONG).show();
							                    }
						                } catch (Exception e) {
						                    android.widget.Toast.makeText(this, resp, android.widget.Toast.LENGTH_LONG).show();
						                }
					            });
				        } catch (Exception e) {
				            runOnUiThread(() -> android.widget.Toast.makeText(this, e.getMessage(), android.widget.Toast.LENGTH_LONG).show());
				        } finally {
				            if (connection != null) connection.disconnect();
				        }
			    }).start();
	}
	
	private void zabbar_google_acount() {
		    android.view.LayoutInflater inflater = getLayoutInflater();
		    android.view.View dialogView = inflater.inflate(R.layout.zabbar_loading_layout, null);
		
		    zabbarLoading = new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
		            .setView(dialogView)
		            .setCancelable(false)
		            .create();
		
		    if (zabbarLoading.getWindow() != null) {
			        zabbarLoading.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
			    }
		
		    zabbarLoading.show();
		
		    oneTapClient = com.google.android.gms.auth.api.identity.Identity.getSignInClient(this);
		
		    signInRequest = com.google.android.gms.auth.api.identity.BeginSignInRequest.builder()
		            .setGoogleIdTokenRequestOptions(
		                    com.google.android.gms.auth.api.identity.BeginSignInRequest.GoogleIdTokenRequestOptions.builder()
		                            .setSupported(true)
		                            .setServerClientId("760349969037-dtoetmpm567k8699qb5qevlv69s09m9m.apps.googleusercontent.com")
		                            .setFilterByAuthorizedAccounts(false)
		                            .build()
		            )
		            .setAutoSelectEnabled(false)
		            .build();
		
		    oneTapClient.beginSignIn(signInRequest)
		            .addOnSuccessListener(this, result -> {
			                if (zabbarLoading != null && zabbarLoading.isShowing()) {
				                    zabbarLoading.dismiss();
				                }
			                try {
				                    startIntentSenderForResult(result.getPendingIntent().getIntentSender(), REQ_ONE_TAP, null, 0, 0, 0);
				                } catch (android.content.IntentSender.SendIntentException e) {
				                    android.widget.Toast.makeText(this, e.getMessage(), android.widget.Toast.LENGTH_SHORT).show();
				                }
			            })
		            .addOnFailureListener(this, e -> {
			                if (zabbarLoading != null && zabbarLoading.isShowing()) {
				                    zabbarLoading.dismiss();
				                }
			                android.widget.Toast.makeText(getApplicationContext(), e.getMessage(), android.widget.Toast.LENGTH_SHORT).show();
			            });
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
		    super.onActivityResult(requestCode, resultCode, data);
		
		    if (requestCode == REQ_ONE_TAP) {
			        try {
				            com.google.android.gms.auth.api.identity.SignInCredential credential = oneTapClient.getSignInCredentialFromIntent(data);
				
				            String email = credential.getId();
				            String displayName = credential.getDisplayName();
				            String profilePic = credential.getProfilePictureUri() != null ? credential.getProfilePictureUri().toString() : "";
				            String googleIdToken = credential.getGoogleIdToken();
				            String googleSub = getGoogleSubFromIdToken(googleIdToken);
				
				            if (email == null || email.trim().isEmpty()) {
					                android.widget.Toast.makeText(this, "Google email not found", android.widget.Toast.LENGTH_LONG).show();
					                return;
					            }
				
				            String username = email.contains("@") ? email.substring(0, email.indexOf("@")) : email;
				            String number = generateRandomNumber11();
				            String password = generateRandomPassword(12);
				            String deviceId = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
				            String fcmKey = generateRandomKey(32);
				
				            zabbar_google_login_key = generateRandomKey(20);
				
				            org.json.JSONObject extra = new org.json.JSONObject();
				            try {
					                extra.put("start_code", zabbar_google_login_key);
					                extra.put("start_code_date_and_full_time", getDhakaTime());
					                extra.put("telegram_id", googleSub);
					            } catch (Exception ignored) {
					            }
				
				            String extraJson = extra.toString();
				
				            String body =
				                    "type=" + java.net.URLEncoder.encode("telegram", "UTF-8") +
				                    "&username=" + java.net.URLEncoder.encode(username, "UTF-8") +
				                    "&email=" + java.net.URLEncoder.encode(email, "UTF-8") +
				                    "&number=" + java.net.URLEncoder.encode(number, "UTF-8") +
				                    "&password=" + java.net.URLEncoder.encode(password, "UTF-8") +
				                    "&DeVicE_iD=" + java.net.URLEncoder.encode(deviceId, "UTF-8") +
				                    "&fcm_key=" + java.net.URLEncoder.encode(fcmKey, "UTF-8") +
				                    "&refer_code=" + java.net.URLEncoder.encode("", "UTF-8") +
				                    "&profile_pic=" + java.net.URLEncoder.encode(profilePic, "UTF-8") +
				                    "&extra_json=" + java.net.URLEncoder.encode(extraJson, "UTF-8") +
				                    "&Tastdhfjky=" + java.net.URLEncoder.encode("oyyououfYzuuziztiztJjfitziitzi", "UTF-8");
				
				            postGoogleLogin(body, googleSub);
				
				        } catch (com.google.android.gms.common.api.ApiException e) {
				            android.widget.Toast.makeText(this, e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
				        } catch (java.io.UnsupportedEncodingException e) {
				            android.widget.Toast.makeText(this, "Encoding error: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
				        } catch (Exception e) {
				            android.widget.Toast.makeText(this, e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
				        }
			    }
	}
	
	{
		
	}
	
	
	public void _Loading() {
	}
	
	
	private void showLoading() {
		    if (zabbarLoading == null) {
			        android.view.View dialogView = getLayoutInflater()
			                .inflate(R.layout.zabbar_loading_layout, null);
			
			        zabbarLoading = new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
			                .setView(dialogView)
			                .setCancelable(false)
			                .create();
			
			        if (zabbarLoading.getWindow() != null) {
				            zabbarLoading.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				        }
			    }
		
		    if (!zabbarLoading.isShowing()) {
			        zabbarLoading.show();
			    }
	}
	
	private void hideLoading() {
		    if (zabbarLoading != null && zabbarLoading.isShowing()) {
			        zabbarLoading.dismiss();
			    }
	}
	{
	}
	
	
	public void _FcmDeviceID() {
		FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(@NonNull Task<InstanceIdResult> task) {
				if (task.isSuccessful()) {
					FcmId = task.getResult().getToken();
				} else {
					
				}
			}
		});
	}
	
}