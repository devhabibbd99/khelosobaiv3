package com.khelosobaiv3.user;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.BackgroundColorSpan;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.URLSpan;
import android.text.style.UpdateAppearance;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseApp;
import com.image.silder.ZabbarSliderManager;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import eightbitlab.com.blurview.RenderScriptBlur;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class ShopConfirmPageActivity extends AppCompatActivity {

    private ShopConfirmPageBinding binding;
    private ZabbarSliderManager sliderManager;
    private String productId = "", productTitle = "", productPhoto = "", stockStatus = "";
    private double currentPrice = 0.0, originalPrice = 0.0, deliveryFee = 0.0;
    private int quantity = 1, sold = 0, left = 0;
    private boolean isHomeDelivery = true;
    private String[] sliderImagesList = new String[]{""};

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = ShopConfirmPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        FirebaseApp.initializeApp(this);

        productId = getIntent().getStringExtra("id");
        if (productId == null) productId = getIntent().getStringExtra("product_id");
        productTitle = getIntent().getStringExtra("title");
        if (productTitle == null) productTitle = getIntent().getStringExtra("product_title");
        if (productTitle == null) productTitle = getIntent().getStringExtra("title1");
        productPhoto = getIntent().getStringExtra("image_link");
        if (productPhoto == null) productPhoto = getIntent().getStringExtra("photo1");
        String currentPriceStr = getIntent().getStringExtra("discount_price");
        if (currentPriceStr == null) currentPriceStr = getIntent().getStringExtra("amount1");
        if (currentPriceStr == null) currentPriceStr = getIntent().getStringExtra("amount");
        String originalPriceStr = getIntent().getStringExtra("real_price");
        if (originalPriceStr == null) originalPriceStr = getIntent().getStringExtra("originalAmount1");
        if (originalPriceStr == null) originalPriceStr = getIntent().getStringExtra("original_amount");
        String description = getIntent().getStringExtra("description");
        stockStatus = getIntent().getStringExtra("stock_status");

        String dfStr = getIntent().getStringExtra("DeliveryFree");
        if (dfStr != null && !dfStr.isEmpty()) parseDeliveryFee(dfStr);

        String hdStr = getIntent().getStringExtra("home_delivery");
        if (hdStr != null && !hdStr.isEmpty()) isHomeDelivery = "yes".equalsIgnoreCase(hdStr);

        try { sold = Integer.parseInt(getIntent().getStringExtra("sold")); } catch (Exception e) { sold = 0; }
        try { left = Integer.parseInt(getIntent().getStringExtra("left")); } catch (Exception e) { left = 10; }
        if (productId == null) productId = "0";
        if (productTitle == null || productTitle.isEmpty()) productTitle = "Premium Product";
        if (stockStatus == null || stockStatus.isEmpty()) stockStatus = "IN STOCK";
        if (description == null || description.isEmpty())
            description = "এই প্যাকটি সম্পর্কে বিস্তারিত জানতে নিচে ক্লিক করুন:\n$$$হেল্প এবং সাপোর্ট\nhttps://www.google.com\n$$$\n\n<b>প্যাকের ফিচারসমূহ:</b>\n১. ইনস্ট্যান্ট ডেলিভারি\n২. ১০০% নিরাপদ ট্রানজেকশন\n৩. ২৪/৭ কাস্টমার সাপোর্ট";

        try { if (currentPriceStr != null) currentPrice = Double.parseDouble(currentPriceStr.replaceAll("[^0-9.]", "")); } catch (Exception e) { currentPrice = 450.0; }
        try { if (originalPriceStr != null) originalPrice = Double.parseDouble(originalPriceStr.replaceAll("[^0-9.]", "")); } catch (Exception e) { originalPrice = currentPrice; }
        if (originalPrice < currentPrice) originalPrice = currentPrice;

        setupUI();
        setupDescription(description);
        initializeLogic();
        ZabbarNavigation.INSTANCE.setup(this);
    }

    private void parseDeliveryFee(String df) {
        String lowerDf = df.toLowerCase();
        if (lowerDf.contains("free") || lowerDf.equals("0")) {
            deliveryFee = 0.0;
        } else {
            String num = lowerDf.replaceAll("[^0-9.]", "");
            if (!num.isEmpty()) {
                try { deliveryFee = Double.parseDouble(num); } catch (Exception e) {}
            }
        }
    }

    private void setupUI() {
        binding.tvProductTitle.setText(productTitle);
        binding.tvCurrentPrice.setText("৳" + currentPrice);
        binding.tvStockStatus.setText(stockStatus);
        binding.textview35.setText("🔥 " + sold + " SOLD");
        binding.textview36.setText("💎 " + left + " LEFT");
        binding.appIcon.setOnClickListener(v -> onBackPressed());

        if (originalPrice > currentPrice) {
            binding.tvOldPrice.setVisibility(View.VISIBLE);
            binding.tvDiscount.setVisibility(View.VISIBLE);
            binding.tvSavings.setVisibility(View.VISIBLE);
            binding.tvOldPrice.setText("৳" + originalPrice);
            binding.tvOldPrice.setPaintFlags(binding.tvOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            int discountPercent = (int) Math.round(((originalPrice - currentPrice) / originalPrice) * 100);
            binding.tvDiscount.setText("-" + discountPercent + "%");
            binding.tvSavings.setText("✓ Total Savings: ৳" + (originalPrice - currentPrice));
        } else {
            binding.tvOldPrice.setVisibility(View.GONE);
            binding.tvDiscount.setVisibility(View.GONE);
            binding.tvSavings.setVisibility(View.GONE);
        }

        sliderManager = new ZabbarSliderManager(this, binding.cardview1, sliderImagesList);
        loadProductImages();

        binding.tvQuantity.setText(String.valueOf(quantity));
        binding.btnPlus.setOnClickListener(v -> {
            quantity++;
            binding.tvQuantity.setText(String.valueOf(quantity));
        });
        binding.btnMinus.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                binding.tvQuantity.setText(String.valueOf(quantity));
            }
        });

        binding.btnOrderNow.setOnClickListener(v -> {
            SharedPreferences sp = getSharedPreferences("Save_User_Status", Context.MODE_PRIVATE);
            String token = sp.getString("token", "");
            if (token.isEmpty()) token = sp.getString("Token", "");
            if (token.isEmpty()) {
                new com.khelosobaiv3.user.PremiumDialog.Builder(ShopConfirmPageActivity.this)
                        .setDialogType(true)
                        .setLottie("warning.json")
                        .setTitle("Login Required")
                        .setMessage("Please login to continue.")
                        .setPositiveButton("OK", "#7B2CBF", d -> d.dismiss())
                        .show();
                return;
            }

            String firstImage = (sliderImagesList.length > 0 && !sliderImagesList[0].isEmpty())
                    ? sliderImagesList[0] : productPhoto;

            CheckoutHelper.showCheckoutBottomSheet(
                    ShopConfirmPageActivity.this,
                    productId,
                    token,
                    productTitle,
                    firstImage,
                    currentPrice,
                    quantity,
                    deliveryFee,
                    isHomeDelivery
            );
        });
    }

    private void loadProductImages() {
        String url = "https://api.khelosobai20.live/ElitegoxUser/product_images.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                if ("success".equals(jsonObject.optString("status"))) {
                    JSONArray jsonArray = jsonObject.optJSONArray("images");
                    if (jsonArray != null && jsonArray.length() > 0) {
                        sliderImagesList = new String[jsonArray.length()];
                        for (int i = 0; i < jsonArray.length(); i++) {
                            sliderImagesList[i] = jsonArray.optString(i);
                        }
                        if (sliderManager != null) {
                            sliderManager.updateImages(sliderImagesList);
                        }
                    }
                    if (jsonObject.has("DeliveryFree")) {
                        String df = jsonObject.optString("DeliveryFree", "");
                        if (!df.isEmpty()) parseDeliveryFee(df);
                    }
                    if (jsonObject.has("home_delivery")) {
                        String hd = jsonObject.optString("home_delivery", "");
                        if (!hd.isEmpty()) isHomeDelivery = "yes".equalsIgnoreCase(hd);
                    }
                }
            } catch (Exception e) {}
        }, error -> {}) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("product_id", productId);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void setupDescription(String rawDesc) {
        try {
            TextView tvDesc = binding.tvDescription;
            tvDesc.setMovementMethod(LinkMovementMethod.getInstance());
            SharedPreferences sp = getSharedPreferences("Save_User_Status", Context.MODE_PRIVATE);
            String desc = rawDesc.replace("---name---", sp.getString("name", "User"))
                    .replace("---balance---", sp.getString("balance", "0"));
            SpannableStringBuilder ssb = new SpannableStringBuilder(desc);
            applyRegex(ssb, "&&&([\\s\\S]*?)&&&", m -> m.group(1), m -> new Object[]{new StyleSpan(Typeface.BOLD)});
            applyRegex(ssb, "\\$\\$\\$([\\s\\S]*?)\\n([\\s\\S]*?)\\n?\\$\\$\\$", m -> m.group(1).trim(),
                    m -> new Object[]{new URLSpan(m.group(2).trim())});
            applyRegex(ssb, "```([\\s\\S]*?)\\n([#A-Za-z0-9]+)\\n?```", m -> m.group(1).trim(),
                    m -> {
                        try { return new Object[]{new ForegroundColorSpan(Color.parseColor(m.group(2).trim()))}; }
                        catch (Exception e) { return null; }
                    });
            applyRegex(ssb, "\\*\\*\\*([\\s\\S]*?)\\n([\\s\\S]*?)\\n?\\*\\*\\*",
                    m -> "   " + m.group(1).trim() + "   ",
                    m -> new Object[]{ new URLSpan(m.group(2).trim()), new BackgroundColorSpan(Color.parseColor("#4CAF50")), new ForegroundColorSpan(Color.WHITE), new StyleSpan(Typeface.BOLD) });
            applyRegex(ssb, "★★★([\\s\\S]*?)★★★", m -> Html.fromHtml(m.group(1)), m -> null);
            applyRegex(ssb, "•••([\\s\\S]*?)\\n([0-9]+)s\\n?•••", m -> m.group(1).trim(),
                    m -> {
                        int delay = 3000;
                        try { delay = Integer.parseInt(m.group(2).trim()) * 1000; } catch (Exception e) {}
                        return new Object[]{new GlowingSpan(delay, tvDesc)};
                    });
            tvDesc.setText(ssb);
        } catch (Exception e) {}
    }

    private void applyRegex(SpannableStringBuilder ssb, String regex, ReplacementProvider rp, SpanProvider sp) {
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(ssb.toString());
        int offset = 0;
        while (m.find()) {
            int start = m.start() + offset, end = m.end() + offset;
            CharSequence replacement = rp.getReplacement(m);
            ssb.replace(start, end, replacement);
            Object[] spans = sp.getSpans(m);
            if (spans != null) {
                for (Object span : spans) {
                    if (span != null)
                        ssb.setSpan(span, start, start + replacement.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
            offset += replacement.length() - (end - start);
        }
    }

    private void initializeLogic() {
        Window window = getWindow();
        window.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        View decorView = getWindow().getDecorView();
        ViewGroup rootView = decorView.findViewById(android.R.id.content);
        Drawable windowBackground = decorView.getBackground();
        if (windowBackground == null) windowBackground = new ColorDrawable(Color.parseColor("#DFEAFB"));
        try {
            binding.blurView.setupWith(rootView, new RenderScriptBlur(this))
                    .setFrameClearDrawable(windowBackground)
                    .setBlurRadius(5f);
            binding.bottomBarLayout.setupWith(rootView, new RenderScriptBlur(this))
                    .setFrameClearDrawable(windowBackground)
                    .setBlurRadius(5f);
        } catch (Exception e) {
            binding.blurView.setBackgroundColor(Color.parseColor("#CCFFFFFF"));
            binding.bottomBarLayout.setBackgroundColor(Color.parseColor("#CCFFFFFF"));
        }
    }

    interface ReplacementProvider { CharSequence getReplacement(Matcher m); }
    interface SpanProvider { Object[] getSpans(Matcher m); }

    class GlowingSpan extends CharacterStyle implements UpdateAppearance {
        private boolean isDim = false;
        private Handler handler = new Handler(Looper.getMainLooper());
        public GlowingSpan(int delay, TextView tv) {
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    isDim = !isDim;
                    tv.invalidate();
                    handler.postDelayed(this, delay);
                }
            };
            handler.postDelayed(runnable, delay);
        }
        @Override
        public void updateDrawState(TextPaint tp) {
            if (isDim) {
                tp.setAlpha(128);
                tp.setColor(Color.parseColor("#FFD700"));
            } else {
                tp.setAlpha(255);
                tp.setColor(Color.parseColor("#FF4500"));
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sliderManager != null) sliderManager.onPause();
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (sliderManager != null) sliderManager.onResume();
    }
}