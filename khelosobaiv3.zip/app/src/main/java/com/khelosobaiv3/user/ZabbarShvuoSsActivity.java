package com.khelosobaiv3.user;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZabbarShvuoSsActivity extends AppCompatActivity {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private ProgressBar progressBar;
    private Button btnCopyAll;
    private NoStateRecyclerView rvItems;

    private final ArrayList<ReportItem> items = new ArrayList<>();
    private ReportAdapter adapter;

    private long totalApkBytes = 0;
    private long totalZipUncompressed = 0;
    private long totalZipCompressed = 0;

    private String finalReportText = "";
    private boolean scanFinished = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        startScan();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        root.setSaveEnabled(false);
        root.setSaveFromParentEnabled(false);

        progressBar = new ProgressBar(this);
        progressBar.setSaveEnabled(false);
        progressBar.setSaveFromParentEnabled(false);

        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        pbLp.gravity = Gravity.CENTER_HORIZONTAL;
        pbLp.topMargin = dp(12);
        progressBar.setLayoutParams(pbLp);

        btnCopyAll = new Button(this);
        btnCopyAll.setText("Copy All");
        btnCopyAll.setEnabled(false);
        btnCopyAll.setSaveEnabled(false);
        btnCopyAll.setSaveFromParentEnabled(false);

        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        btnLp.gravity = Gravity.CENTER_HORIZONTAL;
        btnLp.topMargin = dp(8);
        btnCopyAll.setLayoutParams(btnLp);

        btnCopyAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyAllText();
            }
        });

        rvItems = new NoStateRecyclerView(this);
        rvItems.setLayoutManager(new LinearLayoutManager(this));
        rvItems.setItemAnimator(null);
        rvItems.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));
        rvItems.setSaveEnabled(false);
        rvItems.setSaveFromParentEnabled(false);
        rvItems.setNestedScrollingEnabled(true);

        adapter = new ReportAdapter(items);
        rvItems.setAdapter(adapter);

        root.addView(progressBar);
        root.addView(btnCopyAll);
        root.addView(rvItems);

        setContentView(root);
    }

    private void startScan() {
        progressBar.setVisibility(View.VISIBLE);
        btnCopyAll.setEnabled(false);
        scanFinished = false;

        executor.execute(new Runnable() {
            @Override
            public void run() {
                final long startTime = System.currentTimeMillis();
                final ArrayList<ReportItem> batch = new ArrayList<>();
                final ArrayList<String> apkNames = new ArrayList<>();
                final int[] entryCount = new int[]{0};

                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        items.clear();
                        adapter.notifyDataSetChanged();
                    }
                });

                totalApkBytes = 0;
                totalZipUncompressed = 0;
                totalZipCompressed = 0;

                totalApkBytes = scanInstalledApks(batch, apkNames, entryCount);
                flushBatch(batch);

                final long elapsed = System.currentTimeMillis() - startTime;
                final long totalApprox = totalApkBytes;

                finalReportText =
                        "APK files scanned: " + apkNames.size() + "\n" +
                        "APK names: " + joinNames(apkNames) + "\n" +
                        "APK size: " + formatBytes(totalApkBytes) + " (" + totalApkBytes + " bytes)\n" +
                        "APK entries count: " + entryCount[0] + "\n" +
                        "APK entries uncompressed total: " + formatBytes(totalZipUncompressed) + " (" + totalZipUncompressed + " bytes)\n" +
                        "APK entries compressed total: " + formatBytes(totalZipCompressed) + " (" + totalZipCompressed + " bytes)\n" +
                        "Approx total footprint: " + formatBytes(totalApprox) + " (" + totalApprox + " bytes)\n" +
                        "Scan time: " + elapsed + " ms";

                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.GONE);

                        ReportItem summaryItem = new ReportItem(
                                "summary",
                                "APP SUMMARY",
                                0,
                                finalReportText
                        );

                        items.add(0, summaryItem);
                        adapter.notifyItemInserted(0);

                        scanFinished = true;
                        btnCopyAll.setEnabled(true);
                        Toast.makeText(ZabbarShvuoSsActivity.this, "Scan complete", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private long scanInstalledApks(ArrayList<ReportItem> batch, ArrayList<String> apkNames, int[] entryCount) {
        long total = 0;

        try {
            File baseApk = new File(getApplicationInfo().sourceDir);
            if (baseApk.exists()) {
                apkNames.add(baseApk.getName());
                total += baseApk.length();
                scanZipApk(baseApk, batch, entryCount);
            }

            String[] splitPaths = getApplicationInfo().splitSourceDirs;
            if (splitPaths != null) {
                for (String apkPath : splitPaths) {
                    if (apkPath == null) continue;
                    File splitApk = new File(apkPath);
                    if (!splitApk.exists()) continue;

                    apkNames.add(splitApk.getName());
                    total += splitApk.length();
                    scanZipApk(splitApk, batch, entryCount);
                }
            }
        } catch (Exception e) {
            addBatchItem(batch, new ReportItem(
                    "error",
                    "APK scan error",
                    0,
                    String.valueOf(e.getMessage())
            ));
        }

        return total;
    }

    private void scanZipApk(File apkFile, ArrayList<ReportItem> batch, int[] entryCount) {
        ZipFile zipFile = null;
        try {
            zipFile = new ZipFile(apkFile);
            String apkName = apkFile.getName();

            for (ZipEntry ze : Collections.list(zipFile.entries())) {
                if (ze.isDirectory()) continue;

                long size = ze.getSize();
                long compressed = ze.getCompressedSize();

                if (size > 0) totalZipUncompressed += size;
                if (compressed > 0) totalZipCompressed += compressed;

                entryCount[0]++;

                String displayText =
                        "APK: " + apkName + "\n" +
                        "Entry: " + ze.getName() + "\n" +
                        "Size: " + (size >= 0 ? size : 0) + " bytes\n" +
                        "Compressed: " + (compressed >= 0 ? compressed : "unknown") + " bytes";

                addBatchItem(batch, new ReportItem(
                        "apk-entry",
                        ze.getName(),
                        size >= 0 ? size : 0,
                        displayText
                ));
            }
        } catch (Exception e) {
            addBatchItem(batch, new ReportItem(
                    "error",
                    "ZIP scan error",
                    0,
                    String.valueOf(e.getMessage())
            ));
        } finally {
            if (zipFile != null) {
                try {
                    zipFile.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private void addBatchItem(ArrayList<ReportItem> batch, ReportItem item) {
        batch.add(item);
        if (batch.size() >= 20) {
            flushBatch(batch);
        }
    }

    private void flushBatch(ArrayList<ReportItem> batch) {
        if (batch.isEmpty()) return;

        final ArrayList<ReportItem> copy = new ArrayList<>(batch);
        batch.clear();

        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                int start = items.size();
                items.addAll(copy);
                adapter.notifyItemRangeInserted(start, copy.size());
            }
        });
    }

    private void copyAllText() {
        String text = buildFullCopyText();
        if (text.length() == 0) {
            Toast.makeText(this, "Nothing to copy", Toast.LENGTH_SHORT).show();
            return;
        }

        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("APK Report", text));
            Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Clipboard not available", Toast.LENGTH_SHORT).show();
        }
    }

    private String buildFullCopyText() {
        StringBuilder sb = new StringBuilder();

        if (finalReportText != null && finalReportText.length() > 0) {
            sb.append(finalReportText).append("\n\n");
        }

        for (int i = 0; i < items.size(); i++) {
            ReportItem item = items.get(i);
            if (item == null) continue;

            if ("summary".equals(item.type)) {
                sb.append(item.copyText).append("\n\n");
            } else {
                sb.append("Type: ").append(item.type).append("\n");
                sb.append("Name: ").append(item.name).append("\n");
                sb.append("Size: ").append(item.sizeBytes).append(" bytes\n");
                sb.append("Extra: ").append(item.copyText).append("\n");
                sb.append("-----------------------------------\n");
            }
        }

        return sb.toString();
    }

    private String joinNames(ArrayList<String> names) {
        if (names == null || names.isEmpty()) return "none";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < names.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(names.get(i));
        }
        return sb.toString();
    }

    private String formatBytes(long bytes) {
        if (bytes < 0) return "Unknown";
        if (bytes < 1024) return bytes + " B";

        double kb = bytes / 1024.0;
        if (kb < 1024) return String.format(Locale.getDefault(), "%.2f KB", kb);

        double mb = kb / 1024.0;
        if (mb < 1024) return String.format(Locale.getDefault(), "%.2f MB", mb);

        double gb = mb / 1024.0;
        return String.format(Locale.getDefault(), "%.2f GB", gb);
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    private static class ReportItem {
        final String type;
        final String name;
        final long sizeBytes;
        final String copyText;

        ReportItem(String type, String name, long sizeBytes, String copyText) {
            this.type = type;
            this.name = name;
            this.sizeBytes = sizeBytes;
            this.copyText = copyText;
        }
    }

    private static class ReportAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int TYPE_SUMMARY = 0;
        private static final int TYPE_ITEM = 1;

        private final ArrayList<ReportItem> list;

        ReportAdapter(ArrayList<ReportItem> list) {
            this.list = list;
        }

        static class SummaryVH extends RecyclerView.ViewHolder {
            final TextView tv;
            SummaryVH(TextView itemView) {
                super(itemView);
                tv = itemView;
            }
        }

        static class ItemVH extends RecyclerView.ViewHolder {
            final TextView tv;
            ItemVH(TextView itemView) {
                super(itemView);
                tv = itemView;
            }
        }

        @Override
        public int getItemViewType(int position) {
            if (position >= 0 && position < list.size()) {
                ReportItem item = list.get(position);
                if (item != null && "summary".equals(item.type)) {
                    return TYPE_SUMMARY;
                }
            }
            return TYPE_ITEM;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            TextView tv = new TextView(parent.getContext());

            int pad = (int) (parent.getContext().getResources().getDisplayMetrics().density * 12);
            tv.setPadding(pad, pad, pad, pad);
            tv.setTextSize(14f);
            tv.setLayoutParams(new RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT,
                    RecyclerView.LayoutParams.WRAP_CONTENT
            ));

            tv.setSaveEnabled(false);
            tv.setSaveFromParentEnabled(false);
            tv.setFreezesText(false);
            tv.setTextIsSelectable(false);
            tv.setLongClickable(true);
            tv.setClickable(true);
            tv.setFocusable(true);

            if (viewType == TYPE_SUMMARY) {
                tv.setTextSize(15f);
                return new SummaryVH(tv);
            } else {
                return new ItemVH(tv);
            }
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (position < 0 || position >= list.size()) return;

            final ReportItem item = list.get(position);
            if (item == null) return;

            if (holder instanceof SummaryVH) {
                SummaryVH vh = (SummaryVH) holder;
                vh.tv.setText(item.copyText);
                vh.tv.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        copyToClipboard(v.getContext(), item.copyText);
                        return true;
                    }
                });
            } else if (holder instanceof ItemVH) {
                ItemVH vh = (ItemVH) holder;
                String text =
                        "Type: " + item.type + "\n" +
                        "Name: " + item.name + "\n" +
                        "Size: " + item.sizeBytes + " bytes\n" +
                        "Extra: " + item.copyText;

                vh.tv.setText(text);
                vh.tv.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        copyToClipboard(v.getContext(), text);
                        return true;
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        private void copyToClipboard(Context context, String text) {
            ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("item", text));
                Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private static class NoStateRecyclerView extends RecyclerView {
        public NoStateRecyclerView(Context context) {
            super(context);
            setSaveEnabled(false);
            setSaveFromParentEnabled(false);
        }

        @Override
        protected void dispatchSaveInstanceState(SparseArray<android.os.Parcelable> container) {
        }

        @Override
        protected void dispatchRestoreInstanceState(SparseArray<android.os.Parcelable> container) {
        }
    }
}