package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import androidx.core.content.ContextCompat;
import com.google.android.material.textfield.TextInputLayout;
import androidx.core.content.ContextCompat;
import com.google.android.material.tabs.TabLayout;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.PathShape;
import android.view.Menu;
import androidx.core.graphics.PathParser;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.Shape;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.card.MaterialCardView;
import android.graphics.Color;
import android.util.TypedValue;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class ZabbarWithdrawActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private ZabbarWithdrawBinding binding;
	private String Type_Withdraw = "";
	private String WD = "";
	private HashMap<String, Object> Shuvobro = new HashMap<>();
	private String trx = "";
	private HashMap<String, Object> onetime = new HashMap<>();
	private String wds = "";
	
	private SharedPreferences Api;
	private SharedPreferences Save_User_Status;
	private RequestNetwork Withdraw_Call;
	private RequestNetwork.RequestListener _Withdraw_Call_request_listener;
	private ProgressDialog prog;
	private TimerTask SHUVO_TIMER;
	private RequestNetwork Usersdata;
	private RequestNetwork.RequestListener _Usersdata_request_listener;
	private RequestNetwork wd;
	private RequestNetwork.RequestListener _wd_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ZabbarWithdrawBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		Api = getSharedPreferences("Api", Activity.MODE_PRIVATE);
		Save_User_Status = getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE);
		Withdraw_Call = new RequestNetwork(this);
		Usersdata = new RequestNetwork(this);
		wd = new RequestNetwork(this);
		
		binding.btnWithdrawNow.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
						if (Type_Withdraw.equals("")) {
								SketchwareUtil.showMessage(getApplicationContext(), "Please Select A Payment Method ");
						} else {
								if (binding.etAccountNumber.getText().toString().equals("")) {
										SketchwareUtil.showMessage(getApplicationContext(), "Please Fill All Fields ");
								} else {
										if (binding.etAmount.getText().toString().equals("")) {
												SketchwareUtil.showMessage(getApplicationContext(), "Please Fill All Fields ");
										} else {
												_Loading(true, "Proccessing Withdraw...");
												SHUVO_TIMER = new TimerTask() {
														@Override
														public void run() {
																runOnUiThread(new Runnable() {
																		@Override
																		public void run() {
																				if (Double.parseDouble(binding.etAmount.getText().toString().replace("৳", "")) < Double.parseDouble(WD)) {
																						_Loading(false, "Proccessing Withdraw...");
																						SketchwareUtil.showMessage(getApplicationContext(), "Minimum Withdraw Amount Is  ".concat(WD.concat("TK")));
																				} else {
																						if (binding.etAccountNumber.getText().toString().length() == 11) {
																								if ((Double.parseDouble(WD) - 1) < Double.parseDouble(binding.etAmount.getText().toString().replace("৳", ""))) {
																										trx = "KH".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(11), (int)(30)))).concat("AX".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(50), (int)(99)))))));
																										Shuvobro = new HashMap<>();
																										Shuvobro.put("type", "request");
																										Shuvobro.put("username", Save_User_Status.getString("Username", ""));
																										Shuvobro.put("email", Save_User_Status.getString("Email", ""));
																										Shuvobro.put("method", Type_Withdraw);
																										Shuvobro.put("number", binding.etAccountNumber.getText().toString());
																										Shuvobro.put("amount", binding.etAmount.getText().toString());
																										Shuvobro.put("trxid", trx);
																										Shuvobro.put("fcm", Save_User_Status.getString("Fcm", ""));
																										Withdraw_Call.setParams(Shuvobro, RequestNetworkController.REQUEST_PARAM);
																										Withdraw_Call.startRequestNetwork(RequestNetworkController.POST, Api.getString("Api", "").concat("withdraw.php"), "", _Withdraw_Call_request_listener);
																										Shuvobro.clear();
																										_Loading(false, "Proccessing Withdraw...");
																								} else {
																										_Loading(false, "Proccessing Withdraw...");
																										SketchwareUtil.showMessage(getApplicationContext(), "Minimum Withdraw Amount Is  ".concat(WD.concat("TK")));
																								}
																						} else {
																								_Loading(false, "Proccessing Withdraw...");
																								SketchwareUtil.showMessage(getApplicationContext(), "Invalid Number");
																						}
																				}
																		}
																});
														}
												};
												_timer.schedule(SHUVO_TIMER, (int)(SketchwareUtil.getRandom((int)(200), (int)(500))));
										}
								}
						}
				} catch (Exception e) {
						
				}
				
			}
		});
		
		_Withdraw_Call_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					    String response = _response.trim();
					
					    if (response.contains("Withdraw Request Successfully Submitted")) {
						
						        new PremiumDialog.Builder(ZabbarWithdrawActivity.this)
						                .setDialogType(true) 
						                .setCancelable(false)
						                .setBlurBackground(true)
						                .setLottie("success.json")
						                .setTitle("Success")
						                .setMessage("✅ Withdraw Request Successfully Submitted.\n\nআপনার Withdraw Request সফলভাবে জমা হয়েছে।")
						                .setPositiveButton("OK", "#2E7D32", dialog -> {
							                    dialog.dismiss();
							                    finish();
							                })
						                .show();
						
						    } else if (response.contains("Blocked")
					            || response.contains("Withdrawal Request Blocked")) {
						
						        new PremiumDialog.Builder(ZabbarWithdrawActivity.this)
						                .setDialogType(true)
						                .setCancelable(false)
						                .setBlurBackground(true)
						                .setLottie("withdraw_closed.json")
						                .setTitle("Withdraw Blocked")
						                .setMessage("❌ Withdrawal Request Blocked.\n\nবর্তমানে আপনার Withdraw Request বন্ধ রয়েছে।")
						                .setPositiveButton("OK", "#D32F2F", dialog -> {
							                    dialog.dismiss();
							                    finish();
							                })
						                .setNegativeButton("Exit", dialog -> {
							                    dialog.dismiss();
							                    finish();
							                })
						                .show();
						
						    } else if (response.contains("You already have a pending request")) {
						
						        new PremiumDialog.Builder(ZabbarWithdrawActivity.this)
						                .setDialogType(true)
						                .setCancelable(false)
						                .setBlurBackground(true)
						                .setLottie("error.json")
						                .setTitle("Pending Request")
						                .setMessage("⚠️ You already have a pending request.\n\nআগের Withdraw Request এখনো Processing এ রয়েছে।")
						                .setPositiveButton("OK", "#D32F2F", dialog -> {
							                    dialog.dismiss();
							                    finish();
							                })
						                .setNegativeButton("Exit", dialog -> {
							                    dialog.dismiss();
							                    finish();
							                })
						                .show();
						
						    } else {
						
						        
						        new PremiumDialog.Builder(ZabbarWithdrawActivity.this)
						                .setDialogType(true)
						                .setCancelable(false)
						                .setBlurBackground(true)
						                .setLottie("error.json")
						                .setTitle("Error")
						                .setMessage(response)
						                .setPositiveButton("OK", "#D32F2F", dialog -> {
							                    dialog.dismiss();
							                    finish();
							                })
						                .setNegativeButton("Exit", dialog -> {
							                    dialog.dismiss();
							                    finish();
							                })
						                .show();
						    }
					
				} catch (Exception e) {
					
					    new PremiumDialog.Builder(ZabbarWithdrawActivity.this)
					            .setDialogType(true)
					            .setCancelable(false)
					            .setBlurBackground(true)
					            .setLottie("error.json")
					            .setTitle("Error")
					            .setMessage(e.getMessage() == null ? "Unknown Error" : e.getMessage())
					            .setPositiveButton("OK", "#D32F2F", dialog -> {
						                dialog.dismiss();
						                finish();
						            })
					            .setNegativeButton("Exit", dialog -> {
						                dialog.dismiss();
						                finish();
						            })
					            .show();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Usersdata_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					    JSONObject obj = new JSONObject(_response);
					
					    wds = String.valueOf(obj.getInt("winning"));
					    binding.tvBalanceAmount.setText(wds);
					
				} catch (Exception e) {
					    SketchwareUtil.showMessage(getApplicationContext(), e.toString());
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_wd_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					    onetime = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>() {}.getType());
					
					    WD = String.valueOf(onetime.get("min_withdraw"));
					    String maxWithdraw = String.valueOf(onetime.get("maximumwd"));
					    String withdrawOpen = String.valueOf(onetime.get("withdraw_open"));
					    String blockTime = String.valueOf(onetime.get("withdraw_block_time"));
					    String dailyLimit = String.valueOf(onetime.get("daily_limit"));
					
					    binding.tvNoticeDetails.setText("• Minimum withdrawal amount is ".concat(WD.concat(" BDT.\n• Processing fee of 0~1% will be applied.\n• Withdrawals may take up to 24 hours to process.")));
					
					    String safeBlockTime = blockTime == null ? "" : blockTime.trim();
					
					    if (!safeBlockTime.isEmpty() && !"Off".equalsIgnoreCase(safeBlockTime)) {
						        try {
							            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy 'At' hh:mm a", Locale.ENGLISH);
							            Date unblockTime = sdf.parse(safeBlockTime);
							            Date currentTime = new Date();
							
							            if (unblockTime != null && currentTime.before(unblockTime)) {
								                new PremiumDialog.Builder(ZabbarWithdrawActivity.this)
								                        .setDialogType(true)
								                        .setCancelable(false)
								                        .setBlurBackground(true)
								                        .setLottie("withdraw_closed.json")
								                        .setTitle("Withdraw Temporarily Closed")
								                        .setMessage("Withdraw বর্তমানে বন্ধ রয়েছে।\n\n⏰ পুনরায় চালু হবে:\n" + safeBlockTime + "\n\n💰 Minimum Withdraw: ৳" + WD + "\n💵 Maximum Withdraw: ৳" + maxWithdraw + "\n📅 Daily Limit: " + dailyLimit + " বার")
								                        .setPositiveButton("OK", "#004F50", dialog -> {
									                            dialog.dismiss();
									                            finish();
									                        })
								                        .setNegativeButton("Exit", dialog -> {
									                            dialog.dismiss();
									                            finish();
									                        })
								                        .show();
								                return;
								            }
							        } catch (Exception e) {
							            new PremiumDialog.Builder(ZabbarWithdrawActivity.this)
							                    .setDialogType(true)
							                    .setCancelable(false)
							                    .setBlurBackground(true)
							                    .setLottie("withdraw_closed.json")
							                    .setTitle("Withdraw Closed")
							                    .setMessage("Withdraw বর্তমানে বন্ধ রয়েছে।\n\n⏰ সম্ভাব্য চালু হওয়ার সময়:\n" + safeBlockTime + "\n\n💰 Minimum Withdraw: ৳" + WD + "\n💵 Maximum Withdraw: ৳" + maxWithdraw + "\n📅 Daily Limit: " + dailyLimit + " বার")
							                    .setPositiveButton("OK", "#004F50", dialog -> {
								                        dialog.dismiss();
								                        finish();
								                    })
							                    .setNegativeButton("Exit", dialog -> {
								                        dialog.dismiss();
								                        finish();
								                    })
							                    .show();
							            return;
							        }
						    } else {
						        if (!"0".equals(withdrawOpen)) {
							            new PremiumDialog.Builder(ZabbarWithdrawActivity.this)
							                    .setDialogType(true)
							                    .setCancelable(false)
							                    .setBlurBackground(true)
							                    .setLottie("withdraw_closed.json")
							                    .setTitle("Withdraw Temporarily Closed")
							                    .setMessage("Withdraw সাময়িকভাবে বন্ধ আছে।\n\nঅনুগ্রহ করে কিছুক্ষণ পরে আবার চেষ্টা করুন।\n\n💰 Minimum Withdraw: ৳" + WD + "\n💵 Maximum Withdraw: ৳" + maxWithdraw + "\n📅 Daily Limit: " + dailyLimit + " বার")
							                    .setPositiveButton("OK", "#004F50", dialog -> {
								                        dialog.dismiss();
								                        finish();
								                    })
							                    .setNegativeButton("Exit", dialog -> {
								                        dialog.dismiss();
								                        finish();
								                    })
							                    .show();
							            return;
							        }
						    }
				} catch (Exception e) {
					    new PremiumDialog.Builder(ZabbarWithdrawActivity.this)
					            .setDialogType(true)
					            .setCancelable(true)
					            .setBlurBackground(true)
					            .setLottie("error.json")
					            .setTitle("Error")
					            .setMessage(e.getMessage() == null ? "Unknown Error" : e.getMessage())
					            .setPositiveButton("OK", "#D32F2F", dialog -> dialog.dismiss())
					            .show();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		ZabbarNavigation.INSTANCE.setup(this);
		BlurView blurView = binding.blurView;
		View rootView = getWindow().getDecorView().findViewById(android.R.id.content);
		Drawable windowBackground = getWindow().getDecorView().getBackground();
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
			    getWindow().setDecorFitsSystemWindows(false);
		} else {
			    getWindow().getDecorView().setSystemUiVisibility(
			        View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
			        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
			        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			    );
		}
		
		getWindow().setStatusBarColor(Color.TRANSPARENT);
		getWindow().setNavigationBarColor(Color.TRANSPARENT);
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
			    blurView.setupWith((ViewGroup) rootView, new RenderEffectBlur())
			        .setFrameClearDrawable(windowBackground)
			        .setBlurRadius(5f)
			        .setBlurAutoUpdate(true);
		} else {
			    blurView.setupWith((ViewGroup) rootView, new RenderScriptBlur(this))
			        .setFrameClearDrawable(windowBackground)
			        .setBlurRadius(5f)
			        .setBlurAutoUpdate(true);
		}
		
		setupWithdrawMethodSelection();
	}
	
	
	@Override
	public void onStart() {
		super.onStart();
		Shuvobro = new HashMap<>();
		Shuvobro.put("type", "1");
		Shuvobro.put("token", Save_User_Status.getString("Token", ""));
		Usersdata.setParams(Shuvobro, RequestNetworkController.REQUEST_PARAM);
		Usersdata.startRequestNetwork(RequestNetworkController.POST, Api.getString("Api", "").concat("XMapp_Us.js.php"), "", _Usersdata_request_listener);
		Shuvobro.clear();
		wd.startRequestNetwork(RequestNetworkController.POST, Api.getString("Api", "").concat("appinfo.php"), "", _wd_request_listener);
	}
	public void _Loading(final boolean _Show, final String _Title) {
		if (_Show) {
				if (prog == null) {
						prog = new ProgressDialog(this);
						prog.setMax(100);
						prog.setIndeterminate(true);
						prog.setCancelable(false);
						prog.setCanceledOnTouchOutside(false);
				}
				prog.setMessage(_Title);
				prog.show();
			
				try {
						int pbId = getResources().getIdentifier("progress", "id", "android");
						ProgressBar pb = (ProgressBar) prog.findViewById(pbId);
						if (pb != null) {
								pb.getIndeterminateDrawable().setColorFilter(
									Color.parseColor("#147368"),
									android.graphics.PorterDuff.Mode.SRC_IN
								);
						}
				} catch (Exception e) {}
			
				//Powered By SHUVO 69x
		} else {
				if (prog != null) {
						prog.dismiss();
				}
				//Powered By SHUVO 69x
		}
	}
	
	
	public void _Method() {
	}
	
	
	private void setupWithdrawMethodSelection() {
		    findViewById(R.id.cardBkash).setOnClickListener(v -> selectWithdrawMethod("bKash"));
		    findViewById(R.id.cardNagad).setOnClickListener(v -> selectWithdrawMethod("Nagad"));
		    findViewById(R.id.cardRocket).setOnClickListener(v -> selectWithdrawMethod("Rocket"));
		    findViewById(R.id.cardUpay).setOnClickListener(v -> selectWithdrawMethod("Upay"));
		    selectWithdrawMethod("bKash");
	}
	
	private void selectWithdrawMethod(String method) {
		    Type_Withdraw = method;
		    resetWithdrawCards();
		    applyWithdrawCardStyle(method);
		    updateWithdrawNotice(method);
	}
	
	private void resetWithdrawCards() {
		    int defaultStroke = dpToPx(2);
		    int defaultStrokeColor = Color.parseColor("#CAC4D0");
		    int defaultBg = Color.TRANSPARENT;
		    int defaultTextColor = Color.BLACK;
		
		    MaterialCardView cardBkash = findViewById(R.id.cardBkash);
		    MaterialCardView cardNagad = findViewById(R.id.cardNagad);
		    MaterialCardView cardRocket = findViewById(R.id.cardRocket);
		    MaterialCardView cardUpay = findViewById(R.id.cardUpay);
		    MaterialCardView[] cards = {cardBkash, cardNagad, cardRocket, cardUpay};
		
		    TextView tvBkash = findViewById(R.id.tvBkash);
		    TextView tvNagad = findViewById(R.id.tvNagad);
		    TextView tvRocket = findViewById(R.id.tvRocket);
		    TextView tvUpay = findViewById(R.id.tvUpay);
		    TextView[] labels = {tvBkash, tvNagad, tvRocket, tvUpay};
		
		    TextView subBkash = findViewById(R.id.textview5);
		    TextView subNagad = findViewById(R.id.textview6);
		    TextView subRocket = findViewById(R.id.textview7);
		    TextView subUpay = findViewById(R.id.textview8);
		    TextView[] subTexts = {subBkash, subNagad, subRocket, subUpay};
		
		    for (MaterialCardView card : cards) {
			        if (card != null) {
				            card.setStrokeWidth(defaultStroke);
				            card.setStrokeColor(defaultStrokeColor);
				            card.setCardBackgroundColor(defaultBg);
				        }
			    }
		    for (TextView tv : labels) {
			        if (tv != null) tv.setTextColor(defaultTextColor);
			    }
		    for (TextView sub : subTexts) {
			        if (sub != null) sub.setTextColor(Color.BLACK);
			    }
	}
	
	private void applyWithdrawCardStyle(String method) {
		    int selectedStroke = dpToPx(3);
		    int selectedStrokeColor = Color.parseColor("#004F50");
		    int selectedBg = Color.parseColor("#D9F2F2");
		    int selectedTextColor = Color.parseColor("#004F50");
		
		    switch (method) {
			        case "bKash":
			            setCardStyle(R.id.cardBkash, R.id.tvBkash, selectedStroke, selectedStrokeColor, selectedBg, selectedTextColor);
			            break;
			        case "Nagad":
			            setCardStyle(R.id.cardNagad, R.id.tvNagad, selectedStroke, selectedStrokeColor, selectedBg, selectedTextColor);
			            break;
			        case "Rocket":
			            setCardStyle(R.id.cardRocket, R.id.tvRocket, selectedStroke, selectedStrokeColor, selectedBg, selectedTextColor);
			            break;
			        case "Upay":
			            setCardStyle(R.id.cardUpay, R.id.tvUpay, selectedStroke, selectedStrokeColor, selectedBg, selectedTextColor);
			            break;
			    }
	}
	
	private void setCardStyle(int cardId, int textId, int strokeWidth, int strokeColor, int bgColor, int textColor) {
		    MaterialCardView card = findViewById(cardId);
		    TextView tv = findViewById(textId);
		    if (card != null) {
			        card.setStrokeWidth(strokeWidth);
			        card.setStrokeColor(strokeColor);
			        card.setCardBackgroundColor(bgColor);
			    }
		    if (tv != null) tv.setTextColor(textColor);
	}
	
	private void updateWithdrawNotice(String method) {
		    TextView tvNotice = findViewById(R.id.tvNoticeDetails);
		    if (tvNotice == null) return;
		    switch (method) {
			        case "bKash":
			            binding.tvNoticeDetails.setText("• Minimum withdrawal amount is ".concat(WD.concat(" BDT.\n• Processing fee of 0~1% will be applied.\n• Withdrawals may take up to 24 hours to process.")));
			            break;
			        case "Nagad":
			            binding.tvNoticeDetails.setText("• Minimum withdrawal amount is ".concat(WD.concat(" BDT.\n• Processing fee of 0~1% will be applied.\n• Withdrawals may take up to 24 hours to process.")));
			            break;
			        case "Rocket":
			            binding.tvNoticeDetails.setText("• Minimum withdrawal amount is ".concat(WD.concat(" BDT.\n• Processing fee of 0~1% will be applied.\n• Withdrawals may take up to 24 hours to process.")));
			            break;
			        case "Upay":
			            binding.tvNoticeDetails.setText("• Minimum withdrawal amount is ".concat(WD.concat(" BDT.\n• Processing fee of 0~1% will be applied.\n• Withdrawals may take up to 24 hours to process.")));
			            break;
			    }
	}
	
	private int dpToPx(int dp) {
		    return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics());
	}
	private void allowStoragePermission() {
		    if (ContextCompat.checkSelfPermission(
		            this,
		            Manifest.permission.READ_EXTERNAL_STORAGE)
		            != PackageManager.PERMISSION_GRANTED) {
			
			        ActivityCompat.requestPermissions(
			                this,
			                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
			                100
			        );
			    }
	}
	{
	}
	
	
	public void _LodLib() {
		
	}
	
}