package com.khelosobaiv3.user;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Minimal HTTP client for the live-chat PHP API.
 * BASE_URL: change to your real domain, e.g. "https://yourapp.com/api/"
 */
public class ChatApiClient {

    private static final String BASE_URL = "https://api.khelosobai20.live/ElitegoxUser/habib/";

    public interface MessagesCallback {
        void onSuccess(List<ChatMessage> messages);
        void onError(String error);
    }

    public interface StatusCallback {
        void onResult(boolean online);
    }

    public interface SendCallback {
        void onSuccess();
        void onError(String error);
    }

    /** Fetch messages newer than sinceId. Runs network on caller's thread - call from a background thread/executor. */
    public static void getMessages(String userToken, int sinceId, MessagesCallback cb) {
        try {
            HttpURLConnection conn = openConnection("get_messages.php?since_id=" + sinceId, "GET", userToken);
            JSONObject response = readResponse(conn);
            if (response.getBoolean("success")) {
                JSONArray arr = response.getJSONObject("data").getJSONArray("messages");
                List<ChatMessage> list = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject m = arr.getJSONObject(i);
                    list.add(new ChatMessage(
                            m.getInt("id"),
                            m.getString("sender_type"),
                            m.getString("message"),
                            m.getString("created_at")
                    ));
                }
                cb.onSuccess(list);
            } else {
                cb.onError(response.optString("message", "Unknown error"));
            }
        } catch (Exception e) {
            cb.onError(e.getMessage());
        }
    }

    public static void sendMessage(String userToken, String message, SendCallback cb) {
        try {
            HttpURLConnection conn = openConnection("send_message.php", "POST", userToken);
            JSONObject body = new JSONObject();
            body.put("message", message);
            writeBody(conn, body);
            JSONObject response = readResponse(conn);
            if (response.getBoolean("success")) {
                cb.onSuccess();
            } else {
                cb.onError(response.optString("message", "Unknown error"));
            }
        } catch (Exception e) {
            cb.onError(e.getMessage());
        }
    }

    public static void getAdminStatus(String userToken, StatusCallback cb) {
        try {
            HttpURLConnection conn = openConnection("get_admin_status.php", "GET", userToken);
            JSONObject response = readResponse(conn);
            boolean online = response.getBoolean("success")
                    && response.getJSONObject("data").getBoolean("online");
            cb.onResult(online);
        } catch (Exception e) {
            cb.onResult(false);
        }
    }

    // ---- internals ----

    private static HttpURLConnection openConnection(String path, String method, String token) throws IOException {
        URL url = new URL(BASE_URL + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod(method);
        conn.setRequestProperty("Authorization", "Bearer " + token);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        if (method.equals("POST")) conn.setDoOutput(true);
        return conn;
    }

    private static void writeBody(HttpURLConnection conn, JSONObject body) throws IOException {
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
    }

    private static JSONObject readResponse(HttpURLConnection conn) throws Exception {
        int code = conn.getResponseCode();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(),
                StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        return new JSONObject(sb.toString());
    }
}
