package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class ZabbarDeveloperActivity extends AppCompatActivity {
	
	private ZabbarDeveloperBinding binding;
	
	private Intent zabbar_int = new Intent();
	private Intent zabbar_web = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ZabbarDeveloperBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		binding.cardTelegram.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent intent;
				try {
					    intent = new Intent(Intent.ACTION_VIEW,
					            Uri.parse("tg://resolve?domain=unknown_439"));
					    startActivity(intent);
				} catch (Exception e) {
					    intent = new Intent(Intent.ACTION_VIEW,
					            Uri.parse("https://t.me/unknown_439"));
					    startActivity(intent);
				}
			}
		});
		
		binding.appIcon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		binding.imgNotification.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				zabbar_int.setClass(getApplicationContext(), ZabbarNotificationActivity.class);
				startActivity(zabbar_int);
			}
		});
	}
	
	private void initializeLogic() {
		Window window = getWindow();
		
		window.setDecorFitsSystemWindows(false);
		window.setStatusBarColor(Color.TRANSPARENT);
		window.setNavigationBarColor(Color.TRANSPARENT);
		
		BlurView blurView = findViewById(R.id.blurView);
		
		ViewGroup rootView =
		        (ViewGroup) window.getDecorView();
		
		Drawable windowBackground =
		        rootView.getBackground();
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
			
			    blurView.setupWith(rootView, new RenderEffectBlur())
			            .setFrameClearDrawable(windowBackground)
			            .setBlurRadius(8f)
			            .setBlurAutoUpdate(true);
			
		} else {
			
			    blurView.setupWith(rootView, new RenderScriptBlur(this))
			            .setFrameClearDrawable(windowBackground)
			            .setBlurRadius(8f)
			            .setBlurAutoUpdate(true);
		}
	}
	
}