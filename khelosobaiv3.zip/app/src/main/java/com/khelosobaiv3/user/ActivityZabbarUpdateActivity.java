package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class ActivityZabbarUpdateActivity extends AppCompatActivity {
	
	private ActivityZabbarUpdateBinding binding;
	private HashMap<String, Object> AJ_Or_Found_Null = new HashMap<>();
	private String link = "";
	private String version_code = "";
	
	private RequestNetwork KingOfUpdate;
	private RequestNetwork.RequestListener _KingOfUpdate_request_listener;
	private SharedPreferences Api;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ActivityZabbarUpdateBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		KingOfUpdate = new RequestNetwork(this);
		Api = getSharedPreferences("Api", Activity.MODE_PRIVATE);
		
		binding.btnDownload.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_KingOfUpdate_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try{
					AJ_Or_Found_Null = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					link = AJ_Or_Found_Null.get("update_link").toString();
					version_code = AJ_Or_Found_Null.get("version_code").toString();
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		KingOfUpdate.startRequestNetwork(RequestNetworkController.GET, Api.getString("Api", "").concat("appinfo.php"), "", _KingOfUpdate_request_listener);
	}
	
}