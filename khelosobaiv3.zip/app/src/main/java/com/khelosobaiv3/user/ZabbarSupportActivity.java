package com.khelosobaiv3.user;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.annotation.experimental.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.*;
import androidx.constraintlayout.widget.*;
import androidx.core.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.interpolator.*;
import androidx.lifecycle.runtime.*;
import androidx.profileinstaller.*;
import androidx.startup.*;
import androidx.swiperefreshlayout.*;
import androidx.tracing.*;
import androidx.versionedparcelable.*;
import com.android.volley.*;
import com.bumptech.glide.*;
import com.facebook.shimmer.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class ZabbarSupportActivity extends AppCompatActivity {
	
	private ZabbarSupportBinding binding;
	private HashMap<String, Object> zabbar9 = new HashMap<>();
	private String WhatsAppLink = "";
	private String TelegramLink = "";
	private String Email = "";
	private String add_money_link = "";
	private String join_match_link = "";
	private String collect_room_link = "";
	private String withdraw_link = "";
	
	private RequestNetwork ZabbarX;
	private RequestNetwork.RequestListener _ZabbarX_request_listener;
	private SharedPreferences Api;
	private Intent webLink_Zabbar = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ZabbarSupportBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		ZabbarX = new RequestNetwork(this);
		Api = getSharedPreferences("Api", Activity.MODE_PRIVATE);
		
		binding.btnBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		binding.linear83.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webLink_Zabbar.setClass(getApplicationContext(), ZabbarLiveChatActivity.class);
			}
		});
		
		binding.btnWhatsapp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ZabbarOpneLink(WhatsAppLink);
			}
		});
		
		binding.btnTelegram.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ZabbarOpneLink(TelegramLink);
			}
		});
		
		binding.btnEmail.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ZabbarOpneLink(Email);
			}
		});
		
		binding.faqAddMoney.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ZabbarOpneLink(add_money_link);
			}
		});
		
		binding.faqJoinMatch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ZabbarOpneLink(join_match_link);
			}
		});
		
		binding.faqJoinGame.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ZabbarOpneLink(collect_room_link);
			}
		});
		
		binding.faqWithdraw.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ZabbarOpneLink(withdraw_link);
			}
		});
		
		_ZabbarX_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				/*
zabbar9 = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
WhatsAppLink = zabbar9.get("WhatsAppLink").toString();
TelegramLink = zabbar9.get("TelegramLink").toString();
Email = zabbar9.get("Email").toString();
add_money_link = zabbar9.get("add_money_link").toString();
join_match_link = zabbar9.get("join_match_link").toString();
collect_room_link = zabbar9.get("collect_room_link").toString();
withdraw_link = zabbar9.get("withdraw_link").toString();
*/
				zabbar9 = new Gson().fromJson(_response,
				        new TypeToken<HashMap<String, Object>>(){}.getType());
				
				WhatsAppLink = zabbar9.get("WhatsAppLink") == null ? "" : zabbar9.get("WhatsAppLink").toString();
				TelegramLink = zabbar9.get("TelegramLink") == null ? "" : zabbar9.get("TelegramLink").toString();
				Email = zabbar9.get("Email") == null ? "" : zabbar9.get("Email").toString();
				
				add_money_link = zabbar9.get("add_money_link") == null ? "" : zabbar9.get("add_money_link").toString();
				join_match_link = zabbar9.get("join_match_link") == null ? "" : zabbar9.get("join_match_link").toString();
				collect_room_link = zabbar9.get("collect_room_link") == null ? "" : zabbar9.get("collect_room_link").toString();
				withdraw_link = zabbar9.get("withdraw_link") == null ? "" : zabbar9.get("withdraw_link").toString();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _message));
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			    Window window = getWindow();
			
			    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			
			    window.setStatusBarColor(Color.TRANSPARENT);
			    window.setNavigationBarColor(Color.TRANSPARENT);
		}
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			    getWindow().getDecorView().setSystemUiVisibility(
			            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			                    | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
			                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
			    );
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			    getWindow().getDecorView().setSystemUiVisibility(
			            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			                    | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
			    );
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		ZabbarX.startRequestNetwork(RequestNetworkController.GET, Api.getString("Api", "").concat("appinfo.php"), "Power By : ZabbarX", _ZabbarX_request_listener);
	}
	public void _ZabbarOpneLink(final String _link) {
		try{
			webLink_Zabbar.setData(Uri.parse(_link));
			webLink_Zabbar.setAction(Intent.ACTION_VIEW);
			startActivity(webLink_Zabbar);
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
		}
	}
	
}