package com.khelosobaiv3.user;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class BanChecker {

    private static volatile boolean isChecking = false; // একাধিক কল এড়াতে

    /**
     * ডিভাইস ব্যান চেক করে, ব্যান হলে UI থ্রেডে টোস্ট দেখিয়ে অ্যাপ কিল করে।
     * @param activity – যে অ্যাক্টিভিটি থেকে কল হচ্ছে (null হতে পারে)।
     *                   ব্যান থাকলে finishAffinity() কল করার জন্য দরকার।
     */
    public static void checkAndExitIfBanned(final Activity activity) {
        if (isChecking) {
            Log.d("BanChecker", "Already checking, skipping.");
            return;
        }
        isChecking = true;

        new Thread(() -> {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try {
                // ডিভাইস আইডি
                String deviceId = Settings.Secure.getString(
                        activity != null ? activity.getContentResolver() : null,
                        Settings.Secure.ANDROID_ID
                );
                if (deviceId == null) {
                    Log.e("BanChecker", "Android ID null, can't check ban.");
                    return;
                }

                URL url = new URL("https://api.khelosobai20.live/ElitegoxUser/check_device.php?device_id=" + deviceId);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);

                int code = connection.getResponseCode();
                if (code == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    JSONObject json = new JSONObject(response.toString());
                    boolean banned = json.optBoolean("banned", false);
                    String message = json.optString("message", "Device allowed");

                    if (banned) {
                        showToastAndExit(activity, message);
                    }
                } else {
                    Log.w("BanChecker", "Ban check failed, HTTP: " + code);
                }
            } catch (Exception e) {
                Log.e("BanChecker", "Error: " + e.getMessage());
            } finally {
                // clean up
                if (reader != null) {
                    try { reader.close(); } catch (Exception ignored) {}
                }
                if (connection != null) connection.disconnect();
                isChecking = false;
            }
        }).start();
    }

    private static void showToastAndExit(Activity activity, String message) {
        new Handler(Looper.getMainLooper()).post(() -> {
            // Toast (নিরাপদ)
            try {
                if (activity != null) {
                    Toast.makeText(activity, message, Toast.LENGTH_LONG).show();
                } else {
                    // Application context থেকে Toast দেখানো (ক্র্যাশ রোধ করতে try)
                    Toast.makeText(ZabbarX.getContext(), message, Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Log.w("BanChecker", "Toast failed: " + e.getMessage());
            }

            // Activity থাকলে সব শেষ করো
            if (activity != null) {
                activity.finishAffinity();
            }

            // 100% কিল
            Process.killProcess(Process.myPid());
            System.exit(0);
        });
    }
}