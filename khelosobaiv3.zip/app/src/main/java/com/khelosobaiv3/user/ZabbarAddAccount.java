package com.khelosobaiv3.user;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.switchmaterial.SwitchMaterial;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ZabbarAddAccount extends AppCompatActivity {

    private RelativeLayout mainLayout;
    private LinearLayout accountListContainer, emptyStateLayout;
    private final String BASE_URL = "https://api.khelosobai20.live/ElitegoxUser/";
    private String token = "", username = "";

    private final int C_BG = Color.parseColor("#F8FAFC");
    private final int C_SURF = Color.parseColor("#FFFFFF");
    private final int C_PRI = Color.parseColor("#4F46E5");
    private final int C_TXT_D = Color.parseColor("#0F172A");
    private final int C_TXT_M = Color.parseColor("#64748B");
    private final int C_RIPPLE = Color.parseColor("#E2E8F0");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        token = getSharedPreferences("Save_User_Status", Context.MODE_PRIVATE).getString("Token", "");

        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.setStatusBarColor(Color.TRANSPARENT);
            w.setNavigationBarColor(Color.WHITE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            w.getDecorView().setSystemUiVisibility(flags);
        }

        mainLayout = new RelativeLayout(this);
        mainLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        mainLayout.setBackgroundColor(C_BG);

        int sbHeight = 0;
        int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resId > 0) sbHeight = getResources().getDimensionPixelSize(resId);

        LinearLayout header = new LinearLayout(this);
        header.setId(View.generateViewId());
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(20), sbHeight + dp(12), dp(20), dp(16));
        mainLayout.addView(header, new RelativeLayout.LayoutParams(-1, -2));

        ImageView btnBack = new ImageView(this);
        btnBack.setImageResource(R.drawable.ic_back);
        btnBack.setColorFilter(C_TXT_D);
        btnBack.setPadding(dp(6), dp(6), dp(6), dp(6));
        btnBack.setBackground(createRipple(dp(20)));
        btnBack.setOnClickListener(v -> onBackPressed());
        header.addView(btnBack, llp(dp(36), dp(36)));

        TextView txtTitle = new TextView(this);
        txtTitle.setText("Game Accounts");
        txtTitle.setTextColor(C_TXT_D);
        txtTitle.setTextSize(22);
        txtTitle.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        LinearLayout.LayoutParams lpTitle = new LinearLayout.LayoutParams(0, -2, 1f);
        lpTitle.setMarginStart(dp(12));
        header.addView(txtTitle, lpTitle);

        MaterialButton btnAdd = new MaterialButton(this);
        btnAdd.setText("+ Add New");
        btnAdd.setTextColor(Color.WHITE);
        btnAdd.setTextSize(13);
        btnAdd.setInsetTop(0);
        btnAdd.setInsetBottom(0);
        btnAdd.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        btnAdd.setCornerRadius(dp(12));
        btnAdd.setBackgroundTintList(ColorStateList.valueOf(C_PRI));
        btnAdd.setElevation(dp(2));
        btnAdd.setPadding(dp(16), 0, dp(16), 0);
        header.addView(btnAdd, llp(-2, dp(38)));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        RelativeLayout.LayoutParams scrollParams = rlp(-1, -1);
        scrollParams.addRule(RelativeLayout.BELOW, header.getId());
        mainLayout.addView(scrollView, scrollParams);

        accountListContainer = new LinearLayout(this);
        accountListContainer.setOrientation(LinearLayout.VERTICAL);
        accountListContainer.setPadding(dp(20), dp(8), dp(20), dp(40));
        LayoutTransition transition = new LayoutTransition();
        transition.enableTransitionType(LayoutTransition.CHANGING);
        transition.setDuration(400);
        accountListContainer.setLayoutTransition(transition);
        scrollView.addView(accountListContainer, new ScrollView.LayoutParams(-1, -2));

        emptyStateLayout = new LinearLayout(this);
        emptyStateLayout.setOrientation(LinearLayout.VERTICAL);
        emptyStateLayout.setGravity(Gravity.CENTER);
        emptyStateLayout.setVisibility(View.GONE);
        RelativeLayout.LayoutParams lpEmpty = rlp(-1, -1);
        lpEmpty.addRule(RelativeLayout.BELOW, header.getId());
        mainLayout.addView(emptyStateLayout, lpEmpty);

        MaterialCardView emptyIconCard = new MaterialCardView(this);
        emptyIconCard.setRadius(dp(40));
        emptyIconCard.setCardBackgroundColor(Color.parseColor("#EEF2FF"));
        emptyIconCard.setCardElevation(0);
        emptyStateLayout.addView(emptyIconCard, llp(dp(80), dp(80)));

        ImageView imgEmpty = new ImageView(this);
        imgEmpty.setImageResource(R.drawable.ic_user);
        imgEmpty.setColorFilter(C_PRI);
        imgEmpty.setPadding(dp(20), dp(20), dp(20), dp(20));
        emptyIconCard.addView(imgEmpty, new ViewGroup.LayoutParams(-1, -1));

        TextView txtEmpty = new TextView(this);
        txtEmpty.setText("No Accounts Linked");
        txtEmpty.setTextColor(C_TXT_D);
        txtEmpty.setTextSize(18);
        txtEmpty.setGravity(Gravity.CENTER);
        txtEmpty.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        txtEmpty.setPadding(0, dp(20), 0, dp(8));
        emptyStateLayout.addView(txtEmpty);
        
        TextView txtEmptySub = new TextView(this);
        txtEmptySub.setText("Tap the + Add New button above\nto connect your game profiles");
        txtEmptySub.setTextColor(C_TXT_M);
        txtEmptySub.setTextSize(14);
        txtEmptySub.setGravity(Gravity.CENTER);
        emptyStateLayout.addView(txtEmptySub);

        setContentView(mainLayout);
        btnAdd.setOnClickListener(v -> showAddAccountDialog());
        fetchUserData();
    }

    private void apiRequest(String endPoint, String params, ApiCallback callback) {
        new Thread(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(BASE_URL + endPoint).openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("User-Agent", "EliteGOX/1.0");
                OutputStream os = conn.getOutputStream();
                os.write(params.getBytes("UTF-8"));
                os.flush(); os.close();
                if (conn.getResponseCode() == 200) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    JSONObject res = new JSONObject(sb.toString());
                    runOnUiThread(() -> callback.onResult(res));
                } else runOnUiThread(() -> callback.onResult(null));
                conn.disconnect();
            } catch (Exception e) {
                runOnUiThread(() -> callback.onResult(null));
            }
        }).start();
    }

    private interface ApiCallback { void onResult(JSONObject res); }

    private void fetchUserData() {
        apiRequest("XMapp_Us.js.php", "type=1&token=" + enc(token), res -> {
            if (res != null && res.has("username")) {
                username = res.optString("username");
                fetchGameAccounts();
            } else showSnackbar("Failed to get user data!");
        });
    }

    private void fetchGameAccounts() {
        apiRequest("get_game_accounts.php", "token=" + enc(token) + "&username=" + enc(username), res -> {
            accountListContainer.removeAllViews();
            if (res != null && "success".equals(res.optString("status"))) {
                JSONArray arr = res.optJSONArray("data");
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject obj = arr.optJSONObject(i);
                        if (obj != null) addNewCard(obj.optString("id"), obj.optString("ingame_name"), obj.optString("game_uid"), obj.optString("level"), "true".equals(obj.optString("is_default")));
                    }
                }
            }
            checkEmptyState();
        });
    }

    private void saveGameAccount(String name, String uid, String level, boolean isDef) {
        String data = "type=save&token=" + enc(token) + "&username=" + enc(username) + "&ingame_name=" + enc(name) + "&game_uid=" + enc(uid) + "&level=" + enc(level) + "&is_default=" + enc(isDef ? "true" : "false");
        apiRequest("save_game_account.php", data, res -> {
            if (res != null && "success".equals(res.optString("status"))) fetchGameAccounts();
            else showSnackbar(res != null ? res.optString("message", "Save Failed") : "Network Error");
        });
    }

    private void deleteGameAccount(String id, View card) {
        apiRequest("save_game_account.php", "type=delete&token=" + enc(token) + "&username=" + enc(username) + "&id=" + enc(id), res -> {
            if (res != null && "success".equals(res.optString("status"))) {
                accountListContainer.removeView(card);
                checkEmptyState();
            } else showSnackbar(res != null ? res.optString("message", "Delete Failed") : "Error");
        });
    }

    private void addNewCard(String id, String name, String uid, String level, boolean isDefault) {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardBackgroundColor(C_SURF);
        card.setRadius(dp(20));
        card.setCardElevation(0);
        card.setStrokeColor(Color.parseColor("#E2E8F0"));
        card.setStrokeWidth(dp(1));
        card.setClickable(true);
        card.setFocusable(true);
        card.setRippleColor(ColorStateList.valueOf(C_RIPPLE));
        LinearLayout.LayoutParams cp = llp(-1, -2);
        cp.setMargins(0, dp(6), 0, dp(10));
        card.setLayoutParams(cp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(16), dp(16), dp(16), dp(16));
        row.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(row);

        MaterialCardView avBox = new MaterialCardView(this);
        avBox.setRadius(dp(16));
        avBox.setCardElevation(0);
        avBox.setCardBackgroundColor(Color.parseColor(isDefault ? "#EEF2FF" : "#F1F5F9"));
        row.addView(avBox, llp(dp(54), dp(54)));

        ImageView imgUser = new ImageView(this);
        imgUser.setImageResource(R.drawable.ic_user);
        imgUser.setColorFilter(Color.parseColor(isDefault ? "#4F46E5" : "#64748B"));
        imgUser.setPadding(dp(12), dp(12), dp(12), dp(12));
        avBox.addView(imgUser, new ViewGroup.LayoutParams(-1, -1));

        LinearLayout infoCol = new LinearLayout(this);
        infoCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, -2, 1f);
        infoParams.setMarginStart(dp(16));
        row.addView(infoCol, infoParams);

        LinearLayout nbRow = new LinearLayout(this);
        nbRow.setOrientation(LinearLayout.HORIZONTAL);
        nbRow.setGravity(Gravity.CENTER_VERTICAL);
        infoCol.addView(nbRow);

        TextView txtName = new TextView(this);
        txtName.setText(name);
        txtName.setTextColor(C_TXT_D);
        txtName.setTextSize(17);
        txtName.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        txtName.setSingleLine(true);
        nbRow.addView(txtName);

        TextView badge = new TextView(this);
        badge.setTextSize(10);
        badge.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        badge.setPadding(dp(8), dp(4), dp(8), dp(4));
        
        GradientDrawable gdBadge = new GradientDrawable();
        gdBadge.setCornerRadius(dp(8));
        badge.setText(isDefault ? "Primary" : "Friend");
        badge.setTextColor(isDefault ? C_PRI : C_TXT_M);
        gdBadge.setColor(isDefault ? Color.parseColor("#EEF2FF") : Color.parseColor("#F1F5F9"));
        badge.setBackground(gdBadge);
        
        LinearLayout.LayoutParams lpBadge = llp(-2, -2);
        lpBadge.setMarginStart(dp(10));
        badge.setLayoutParams(lpBadge);
        nbRow.addView(badge);

        TextView txtUid = new TextView(this);
        txtUid.setText("UID: " + uid + "  •  Lvl " + level);
        txtUid.setTextColor(C_TXT_M);
        txtUid.setTextSize(13);
        LinearLayout.LayoutParams lpUid = llp(-2, -2);
        lpUid.setMargins(0, dp(4), 0, 0);
        infoCol.addView(txtUid, lpUid);

        ImageView imgDel = new ImageView(this);
        imgDel.setImageResource(R.drawable.ic_delete);
        imgDel.setColorFilter(Color.parseColor("#EF4444"));
        imgDel.setPadding(dp(10), dp(10), dp(10), dp(10));
        imgDel.setBackground(createRipple(dp(12)));
        
        LinearLayout.LayoutParams lpDel = llp(dp(44), dp(44));
        lpDel.setMarginStart(dp(16));
        row.addView(imgDel, lpDel);

        imgDel.setOnClickListener(v -> {
            if (id != null && !id.isEmpty()) deleteGameAccount(id, card);
            else { accountListContainer.removeView(card); checkEmptyState(); }
        });

        accountListContainer.addView(card, 0);
        checkEmptyState();
    }

    private void showAddAccountDialog() {
        BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.Theme_Design_BottomSheetDialog);
        
        BlurView blurView = new BlurView(this);
        blurView.setClickable(true);
        try {
            blurView.setupWith(mainLayout, new RenderScriptBlur(this)).setBlurRadius(12f);
            blurView.setOverlayColor(Color.parseColor("#33000000"));
        } catch (Exception ignored) {}
        blurView.setAlpha(0f);
        mainLayout.addView(blurView, new RelativeLayout.LayoutParams(-1, -1));
        blurView.animate().alpha(1f).setDuration(300).start();

        Window window = dialog.getWindow();
        if (window != null) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setNavigationBarColor(Color.WHITE);
            window.setStatusBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int flags = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
                window.getDecorView().setSystemUiVisibility(flags);
            }
        }

        dialog.setOnDismissListener(d -> blurView.animate().alpha(0f).setDuration(300).withEndAction(() -> mainLayout.removeView(blurView)).start());
        dialog.setOnShowListener(d -> {
            View internal = ((BottomSheetDialog) d).findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (internal != null) internal.setBackgroundColor(Color.TRANSPARENT);
        });

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bsBg = new GradientDrawable();
        bsBg.setColor(C_SURF);
        bsBg.setCornerRadii(new float[]{dp(32), dp(32), dp(32), dp(32), 0, 0, 0, 0});
        form.setBackground(bsBg);
        form.setPadding(dp(24), dp(16), dp(24), dp(32));

        RelativeLayout dHeader = new RelativeLayout(this);
        dHeader.setPadding(0, 0, 0, dp(24));
        form.addView(dHeader, llp(-1, -2));

        View handle = new View(this);
        GradientDrawable handleBg = new GradientDrawable();
        handleBg.setColor(C_RIPPLE);
        handleBg.setCornerRadius(dp(4));
        handle.setBackground(handleBg);
        RelativeLayout.LayoutParams lpHandle = rlp(dp(44), dp(5));
        lpHandle.addRule(RelativeLayout.CENTER_HORIZONTAL);
        dHeader.addView(handle, lpHandle);

        ImageView btnClose = new ImageView(this);
        btnClose.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        btnClose.setColorFilter(C_TXT_M);
        btnClose.setBackground(createRipple(dp(16)));
        btnClose.setPadding(dp(4), dp(4), dp(4), dp(4));
        btnClose.setOnClickListener(v -> dialog.dismiss());
        RelativeLayout.LayoutParams lpClose = rlp(dp(32), dp(32));
        lpClose.addRule(RelativeLayout.ALIGN_PARENT_END);
        lpClose.setMargins(0, dp(16), 0, 0);
        dHeader.addView(btnClose, lpClose);

        TextView title = new TextView(this);
        title.setText("Link New Account");
        title.setTextColor(C_TXT_D);
        title.setTextSize(24);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        RelativeLayout.LayoutParams lpTitle = rlp(-2, -2);
        lpTitle.addRule(RelativeLayout.BELOW, handle.getId());
        lpTitle.setMargins(0, dp(24), 0, 0);
        dHeader.addView(title, lpTitle);

        EditText[] etNameArr = new EditText[1];
        MaterialCardView inputName = createEnhancedInput("In-Game Name", R.drawable.ic_user, InputType.TYPE_CLASS_TEXT, etNameArr);
        etNameArr[0].setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});

        EditText[] etUidArr = new EditText[1];
        MaterialCardView inputUid = createEnhancedInput("Account UID", R.drawable.ic_check, InputType.TYPE_CLASS_NUMBER, etUidArr);

        EditText[] etLevelArr = new EditText[1];
        MaterialCardView inputLevel = createEnhancedInput("Account Level", R.drawable.ic_plus, InputType.TYPE_CLASS_NUMBER, etLevelArr);
        etLevelArr[0].setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});

        form.addView(inputName);
        form.addView(inputUid);
        form.addView(inputLevel);

        MaterialCardView switchCard = new MaterialCardView(this);
        switchCard.setRadius(dp(16));
        switchCard.setCardBackgroundColor(Color.parseColor("#F8FAFC"));
        switchCard.setCardElevation(0);
        switchCard.setStrokeWidth(dp(1));
        switchCard.setStrokeColor(Color.parseColor("#E2E8F0"));
        LinearLayout.LayoutParams lpSwitchCard = llp(-1, -2);
        lpSwitchCard.setMargins(0, dp(8), 0, dp(32));
        form.addView(switchCard, lpSwitchCard);

        RelativeLayout switchRow = new RelativeLayout(this);
        switchRow.setPadding(dp(16), dp(16), dp(16), dp(16));
        switchCard.addView(switchRow, new ViewGroup.LayoutParams(-1, -2));

        LinearLayout switchTextCol = new LinearLayout(this);
        switchTextCol.setOrientation(LinearLayout.VERTICAL);
        RelativeLayout.LayoutParams lpTextCol = rlp(-2, -2);
        lpTextCol.addRule(RelativeLayout.CENTER_VERTICAL);
        switchRow.addView(switchTextCol, lpTextCol);

        TextView labelDefault = new TextView(this);
        labelDefault.setText("Set as Primary Account");
        labelDefault.setTextColor(C_TXT_D);
        labelDefault.setTextSize(16);
        labelDefault.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        switchTextCol.addView(labelDefault);
        
        TextView labelDesc = new TextView(this);
        labelDesc.setText("Default account for joining matches");
        labelDesc.setTextColor(C_TXT_M);
        labelDesc.setTextSize(13);
        labelDesc.setPadding(0, dp(2), 0, 0);
        switchTextCol.addView(labelDesc);

        SwitchMaterial smDefault = new SwitchMaterial(this);
        smDefault.setThumbTintList(new ColorStateList(new int[][]{{-android.R.attr.state_checked}, {android.R.attr.state_checked}}, new int[]{C_SURF, C_PRI}));
        smDefault.setTrackTintList(new ColorStateList(new int[][]{{-android.R.attr.state_checked}, {android.R.attr.state_checked}}, new int[]{Color.parseColor("#CBD5E1"), Color.parseColor("#C7D2FE")}));
        RelativeLayout.LayoutParams lpSwitch = rlp(-2, -2);
        lpSwitch.addRule(RelativeLayout.ALIGN_PARENT_END);
        lpSwitch.addRule(RelativeLayout.CENTER_VERTICAL);
        switchRow.addView(smDefault, lpSwitch);

        MaterialButton btnSave = new MaterialButton(this);
        btnSave.setText("Save Account");
        btnSave.setTextColor(Color.WHITE);
        btnSave.setTextSize(16);
        btnSave.setInsetTop(0);
        btnSave.setInsetBottom(0);
        btnSave.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        btnSave.setCornerRadius(dp(16));
        btnSave.setBackgroundTintList(ColorStateList.valueOf(C_PRI));
        btnSave.setElevation(dp(4));
        form.addView(btnSave, llp(-1, dp(60)));

        btnSave.setOnClickListener(v -> {
            if (accountListContainer.getChildCount() >= 4) {
                showSnackbar("Maximum 4 accounts allowed");
                dialog.dismiss();
                return;
            }
            String n = etNameArr[0].getText().toString().trim().isEmpty() ? "Guest Player" : etNameArr[0].getText().toString().trim();
            String u = etUidArr[0].getText().toString().trim().isEmpty() ? "000000" : etUidArr[0].getText().toString().trim();
            String l = etLevelArr[0].getText().toString().trim().isEmpty() ? "1" : etLevelArr[0].getText().toString().trim();
            try { if (Integer.parseInt(l) > 100) l = "100"; } catch (Exception e) { l = "1"; }
            
            saveGameAccount(n, u, l, smDefault.isChecked());
            dialog.dismiss();
        });

        dialog.setContentView(form);
        try {
            BottomSheetBehavior.from((View) form.getParent()).setState(BottomSheetBehavior.STATE_EXPANDED);
        } catch (Exception ignored) {}
        dialog.show();
    }

    private MaterialCardView createEnhancedInput(String hint, int iconResId, int inputType, EditText[] outEt) {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardBackgroundColor(Color.parseColor("#F8FAFC"));
        card.setRadius(dp(16));
        card.setCardElevation(0);
        card.setStrokeWidth(dp(1));
        card.setStrokeColor(Color.parseColor("#E2E8F0"));
        
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(16));
        card.setLayoutParams(cp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(4), dp(16), dp(4));
        card.addView(row);

        ImageView ic = null;
        if (iconResId != 0) {
            ic = new ImageView(this);
            ic.setImageResource(iconResId);
            ic.setColorFilter(Color.parseColor("#94A3B8"));
            row.addView(ic, new LinearLayout.LayoutParams(dp(22), dp(22)));
        }

        EditText et = new EditText(this);
        et.setHint(hint);
        et.setHintTextColor(Color.parseColor("#94A3B8"));
        et.setTextColor(C_TXT_D);
        et.setTextSize(16);
        et.setBackground(null);
        et.setSingleLine(true);
        et.setInputType(inputType);
        et.setPadding(dp(12), dp(18), dp(12), dp(18));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, -2, 1f);
        row.addView(et, ep);

        final ImageView finalIc = ic;
        et.setOnFocusChangeListener((v, hasFocus) -> {
            card.setStrokeColor(hasFocus ? C_PRI : Color.parseColor("#E2E8F0"));
            card.setCardBackgroundColor(hasFocus ? Color.parseColor("#FFFFFF") : Color.parseColor("#F8FAFC"));
            if (finalIc != null) {
                finalIc.setColorFilter(hasFocus ? C_PRI : Color.parseColor("#94A3B8"));
            }
        });

        outEt[0] = et;
        return card;
    }

    private void checkEmptyState() {
        emptyStateLayout.setVisibility(accountListContainer.getChildCount() == 0 ? View.VISIBLE : View.GONE);
    }

    private void showSnackbar(String msg) {
        Snackbar s = Snackbar.make(findViewById(android.R.id.content), msg, 3000);
        s.setBackgroundTint(C_TXT_D);
        s.setTextColor(Color.WHITE);
        s.show();
    }

    private Drawable createRipple(int radius) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true);
        Drawable d = ContextCompat.getDrawable(this, tv.resourceId);
        return d;
    }

    private void addRippleEffect(View v) {
        v.setBackground(createRipple(dp(20)));
        v.setClickable(true);
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density); }
    private String enc(String v) { try { return URLEncoder.encode(v, "UTF-8"); } catch (Exception e) { return ""; } }
    private LinearLayout.LayoutParams llp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private RelativeLayout.LayoutParams rlp(int w, int h) { return new RelativeLayout.LayoutParams(w, h); }
}