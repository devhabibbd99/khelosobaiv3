package com.khelosobaiv3.user;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;

public class TopupBottomSheet {

    public interface OnTopupSubmitListener {
        void onSubmit(String uid, BottomSheetDialog dialog, ProgressBar progressBar, Button btnSubmit);
    }

    public static void showDialog(
            Activity activity,
            String lottieFileName,
            String title,
            String currentBalance,
            String regularAmount,
            String discountAmount,
            boolean isCancelable,
            OnTopupSubmitListener listener) {

        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(activity, R.style.TransparentBottomSheetDialogTheme);
        bottomSheetDialog.setCancelable(isCancelable);
        bottomSheetDialog.setCanceledOnTouchOutside(isCancelable);

        View view = LayoutInflater.from(activity).inflate(R.layout.bottom_sheet_topup, null);

        LinearLayout container = view.findViewById(R.id.bottom_sheet_container);
        View dragHandle = view.findViewById(R.id.drag_handle);
        TextView tvTitle = view.findViewById(R.id.tv_title);
        LinearLayout badgeBalance = view.findViewById(R.id.badge_balance);
        TextView tvBalance = view.findViewById(R.id.tv_balance);
        View divider = view.findViewById(R.id.divider);
        LottieAnimationView lottieAnim = view.findViewById(R.id.lottie_anim);
        LinearLayout cardPrice = view.findViewById(R.id.card_price);
        TextView tvRegularPrice = view.findViewById(R.id.tv_regular_price);
        TextView tvDiscountPrice = view.findViewById(R.id.tv_discount_price);
        EditText etUid = view.findViewById(R.id.et_uid);
        ProgressBar progressBar = view.findViewById(R.id.progress_bar);
        Button btnSubmit = view.findViewById(R.id.btn_submit);

        GradientDrawable bgContainer = new GradientDrawable();
        bgContainer.setColor(Color.parseColor("#FFFFFF"));
        bgContainer.setCornerRadii(new float[]{dpToPx(activity, 28), dpToPx(activity, 28), dpToPx(activity, 28), dpToPx(activity, 28), 0, 0, 0, 0});
        container.setBackground(bgContainer);

        GradientDrawable bgHandle = new GradientDrawable();
        bgHandle.setColor(Color.parseColor("#E2E8F0"));
        bgHandle.setCornerRadius(dpToPx(activity, 10));
        dragHandle.setBackground(bgHandle);

        GradientDrawable bgBadge = new GradientDrawable();
        bgBadge.setColor(Color.parseColor("#F0FDF4"));
        bgBadge.setCornerRadius(dpToPx(activity, 50));
        bgBadge.setStroke(dpToPx(activity, 1), Color.parseColor("#BBF7D0"));
        badgeBalance.setBackground(bgBadge);
        
        divider.setBackgroundColor(Color.parseColor("#F1F5F9"));

        GradientDrawable bgCard = new GradientDrawable();
        bgCard.setColor(Color.parseColor("#F8FAFC"));
        bgCard.setCornerRadius(dpToPx(activity, 14));
        bgCard.setStroke(dpToPx(activity, 1), Color.parseColor("#E2E8F0"));
        cardPrice.setBackground(bgCard);

        GradientDrawable bgInput = new GradientDrawable();
        bgInput.setColor(Color.parseColor("#FFFFFF"));
        bgInput.setCornerRadius(dpToPx(activity, 12));
        bgInput.setStroke(dpToPx(activity, 1), Color.parseColor("#CBD5E1"));
        etUid.setBackground(bgInput);

        etUid.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                bgInput.setStroke(dpToPx(activity, 2), Color.parseColor("#2563EB"));
                bgInput.setColor(Color.parseColor("#EFF6FF"));
            } else {
                bgInput.setStroke(dpToPx(activity, 1), Color.parseColor("#CBD5E1"));
                bgInput.setColor(Color.parseColor("#FFFFFF"));
            }
        });

        GradientDrawable bgButton = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor("#3B82F6"), Color.parseColor("#1D4ED8")}
        );
        bgButton.setCornerRadius(dpToPx(activity, 12));
        btnSubmit.setBackground(bgButton);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            btnSubmit.setElevation(dpToPx(activity, 4));
            progressBar.setIndeterminateTintList(ColorStateList.valueOf(Color.parseColor("#2563EB")));
        }

        tvTitle.setText(title);
        tvBalance.setText("৳ " + currentBalance);
        tvRegularPrice.setText(regularAmount);
        tvRegularPrice.setPaintFlags(tvRegularPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        tvDiscountPrice.setText(discountAmount);

        if (!TextUtils.isEmpty(lottieFileName)) {
            lottieAnim.setVisibility(View.VISIBLE);
            lottieAnim.setAnimation(lottieFileName);
        } else {
            lottieAnim.setVisibility(View.GONE);
        }

        btnSubmit.setOnClickListener(v -> {
            String uid = etUid.getText().toString().trim();

            if (uid.isEmpty()) {
                Toast.makeText(activity, "Player UID is required!", Toast.LENGTH_SHORT).show();
                return;
            }

            v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100).withEndAction(() -> {
                v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                
                progressBar.setVisibility(View.VISIBLE);
                btnSubmit.setText("Processing...");
                btnSubmit.setEnabled(false);
                etUid.setEnabled(false);

                if (listener != null) {
                    listener.onSubmit(uid, bottomSheetDialog, progressBar, btnSubmit);
                }
            }).start();
        });

        bottomSheetDialog.setContentView(view);

        View bottomSheetInternal = bottomSheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (bottomSheetInternal != null) {
            bottomSheetInternal.setBackgroundColor(Color.TRANSPARENT);
            BottomSheetBehavior.from(bottomSheetInternal).setState(BottomSheetBehavior.STATE_EXPANDED);
            BottomSheetBehavior.from(bottomSheetInternal).setSkipCollapsed(true);
        }
        if (bottomSheetDialog.getWindow() != null) {
            bottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        View decorView = activity.getWindow().getDecorView();
        bottomSheetDialog.setOnShowListener(dialog -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                decorView.setRenderEffect(RenderEffect.createBlurEffect(20f, 20f, Shader.TileMode.CLAMP));
            }
        });

        bottomSheetDialog.setOnDismissListener(dialog -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                decorView.setRenderEffect(null);
            }
        });

        bottomSheetDialog.show();
    }

    private static int dpToPx(Activity activity, int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, activity.getResources().getDisplayMetrics());
    }
}
