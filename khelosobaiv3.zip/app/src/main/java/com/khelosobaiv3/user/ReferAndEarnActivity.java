package com.khelosobaiv3.user;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ReferAndEarnActivity extends AppCompatActivity {

    private static final int ICON_BACK = 1;
    private static final int ICON_HERO_NETWORK = 2;
    private static final int ICON_EARNINGS = 3;
    private static final int ICON_USERS = 4;
    private static final int ICON_COPY = 5;
    private static final int ICON_STEP_1 = 6;
    private static final int ICON_STEP_2 = 7;
    private static final int ICON_STEP_3 = 8;

    private TextView tvReferralCode;
    private TextView tvTotalRefer;
    private TextView tvReferEran;

    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.parseColor("#F8FAFC"));

        setContentView(R.layout.activity_refer_earn);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        tvReferralCode = findViewById(R.id.tvReferralCode);
        tvTotalRefer = findViewById(R.id.total_refer);
        tvReferEran = findViewById(R.id.refer_eran);

        if (getIntent().hasExtra("refer_code")) {
            tvReferralCode.setText(getIntent().getStringExtra("refer_code"));
        }

        setupWindowInsets();
        setupCleanBackgrounds();
        setupBlurView();
        drawAndSetIcons();
        setupClickListeners();

        String username = tvReferralCode.getText().toString().trim();
        if (!TextUtils.isEmpty(username)) {
            fetchReferralData(username);
        } else {
            if (tvTotalRefer != null) tvTotalRefer.setText("0");
            if (tvReferEran != null) tvReferEran.setText("0");
        }
    }

    private void fetchReferralData(String username) {
        executorService.execute(() -> {
            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                String encodedUsername = URLEncoder.encode(username, "UTF-8");
                URL url = new URL("https://api.khelosobai20.live/ElitegoxUser/getRefer.php?username=" + encodedUsername);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.setDoInput(true);

                int responseCode = connection.getResponseCode();
                reader = new BufferedReader(new InputStreamReader(
                        responseCode >= 200 && responseCode < 400
                                ? connection.getInputStream()
                                : connection.getErrorStream()
                ));

                StringBuilder responseBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    responseBuilder.append(line);
                }

                String response = responseBuilder.toString();
                JSONObject rootObject = new JSONObject(response);

                JSONObject dataObject = rootObject.optJSONObject("data");
                if (dataObject == null) {
                    dataObject = rootObject;
                }

                String totalRefer = firstNonEmpty(dataObject,
                        "totalRefer",
                        "total_refer",
                        "totalrefer"
                );

                String totalEran = firstNonEmpty(dataObject,
                        "totalEran",
                        "total_eran",
                        "totalearn",
                        "totalEarn"
                );

                String finalTotalRefer = TextUtils.isEmpty(totalRefer) ? "0" : totalRefer;
                String finalTotalEran = TextUtils.isEmpty(totalEran) ? "0" : totalEran;

                mainHandler.post(() -> {
                    if (tvTotalRefer != null) tvTotalRefer.setText(finalTotalRefer);
                    if (tvReferEran != null) tvReferEran.setText(finalTotalEran);
                });

            } catch (Exception e) {
                mainHandler.post(() -> {
                    if (tvTotalRefer != null) tvTotalRefer.setText("0");
                    if (tvReferEran != null) tvReferEran.setText("0");
                    Toast.makeText(ReferAndEarnActivity.this, "Data load failed", Toast.LENGTH_SHORT).show();
                });
            } finally {
                try {
                    if (reader != null) reader.close();
                } catch (Exception ignored) {
                }
                if (connection != null) connection.disconnect();
            }
        });
    }

    private String firstNonEmpty(JSONObject object, String... keys) {
        if (object == null || keys == null) return "";
        for (String key : keys) {
            String value = object.optString(key, "").trim();
            if (!TextUtils.isEmpty(value) && !"null".equalsIgnoreCase(value)) {
                return value;
            }
        }
        return "";
    }

    private void setupBlurView() {
        BlurView blurView = findViewById(R.id.blurView);
        ViewGroup rootView = findViewById(R.id.mainLayout);

        if (blurView != null && rootView != null) {
            blurView.setupWith(rootView, new RenderScriptBlur(this))
                    .setFrameClearDrawable(rootView.getBackground())
                    .setBlurRadius(10f)
                    .setBlurAutoUpdate(true);
        }
    }

    private void setupWindowInsets() {
        ConstraintLayout mainLayout = findViewById(R.id.mainLayout);
        LinearLayout layoutHeader = findViewById(R.id.layoutHeader);
        ScrollView scrollView = findViewById(R.id.scrollView);

        ViewCompat.setOnApplyWindowInsetsListener(mainLayout, (v, insets) -> {
            int top = insets.getInsets(WindowInsetsCompat.Type.systemBars()).top;
            int bottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom;
            int padding = (int) (16 * getResources().getDisplayMetrics().density);

            layoutHeader.setPadding(padding, top + padding, padding, padding);

            layoutHeader.post(() -> {
                int headerHeight = layoutHeader.getHeight();
                scrollView.setPadding(0, headerHeight, 0, bottom + padding);
            });

            return insets;
        });
    }

    private void setupCleanBackgrounds() {
        LinearLayout layoutHeader = findViewById(R.id.layoutHeader);
        GradientDrawable headerBg = new GradientDrawable();
        headerBg.setColor(Color.parseColor("#80FFFFFF"));
        layoutHeader.setBackground(headerBg);

        TextView tvBadge = findViewById(R.id.tvBadge);
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.parseColor("#EEF2FF"));
        badgeBg.setCornerRadius(16f);
        tvBadge.setBackground(badgeBg);

        LinearLayout boxCode = findViewById(R.id.boxCode);
        GradientDrawable dashedBg = new GradientDrawable();
        dashedBg.setColor(Color.parseColor("#EEF2FF"));
        dashedBg.setCornerRadius(40f);
        dashedBg.setStroke(4, Color.parseColor("#818CF8"), 16f, 12f);
        boxCode.setBackground(dashedBg);

        LinearLayout btnCopy = findViewById(R.id.btnCopy);
        GradientDrawable copyBtnBg = new GradientDrawable();
        copyBtnBg.setColor(Color.parseColor("#E0E7FF"));
        copyBtnBg.setCornerRadius(24f);
        btnCopy.setBackground(copyBtnBg);

        AppCompatButton btnShare = findViewById(R.id.btnShare);
        GradientDrawable btnShareBg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor("#4361EE"), Color.parseColor("#3B82F6")}
        );
        btnShareBg.setCornerRadius(60f);
        btnShare.setBackground(btnShareBg);
    }

    private void drawAndSetIcons() {
        int backColor = Color.parseColor("#0F172A");
        int primaryBlue = Color.parseColor("#4361EE");
        int greenColor = Color.parseColor("#10B981");

        ((ImageView) findViewById(R.id.btnBack)).setImageBitmap(drawIcon(ICON_BACK, backColor));
        ((ImageView) findViewById(R.id.ivHeroGraphic)).setImageBitmap(drawIcon(ICON_HERO_NETWORK, primaryBlue));
        ((ImageView) findViewById(R.id.ivIconEarnings)).setImageBitmap(drawIcon(ICON_EARNINGS, greenColor));
        ((ImageView) findViewById(R.id.ivIconUsers)).setImageBitmap(drawIcon(ICON_USERS, primaryBlue));
        ((ImageView) findViewById(R.id.ivIconCopy)).setImageBitmap(drawIcon(ICON_COPY, primaryBlue));

        ((ImageView) findViewById(R.id.ivStep1)).setImageBitmap(drawIcon(ICON_STEP_1, primaryBlue));
        ((ImageView) findViewById(R.id.ivStep2)).setImageBitmap(drawIcon(ICON_STEP_2, primaryBlue));
        ((ImageView) findViewById(R.id.ivStep3)).setImageBitmap(drawIcon(ICON_STEP_3, primaryBlue));
    }

    private Bitmap drawIcon(int iconType, int color) {
        Bitmap bitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(12f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);

        Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        fillPaint.setColor(color);
        fillPaint.setStyle(Paint.Style.FILL);

        Path path = new Path();

        switch (iconType) {
            case ICON_BACK:
                path.moveTo(120, 40);
                path.lineTo(60, 100);
                path.lineTo(120, 160);
                canvas.drawPath(path, paint);
                break;

            case ICON_HERO_NETWORK:
                Paint dashedPaint = new Paint(paint);
                dashedPaint.setPathEffect(new DashPathEffect(new float[]{20f, 20f}, 0f));
                dashedPaint.setStrokeWidth(6f);
                dashedPaint.setColor(Color.parseColor("#93C5FD"));
                canvas.drawCircle(100, 100, 85, dashedPaint);

                paint.setStrokeWidth(8f);
                canvas.drawLine(100, 100, 100, 40, paint);
                canvas.drawLine(100, 100, 48, 130, paint);
                canvas.drawLine(100, 100, 152, 130, paint);

                canvas.drawCircle(100, 100, 24, fillPaint);

                fillPaint.setColor(Color.parseColor("#3B82F6"));
                canvas.drawCircle(100, 40, 16, fillPaint);
                canvas.drawCircle(48, 130, 16, fillPaint);
                canvas.drawCircle(152, 130, 16, fillPaint);
                break;

            case ICON_EARNINGS:
                canvas.drawCircle(100, 100, 80, paint);
                fillPaint.setTextSize(90f);
                fillPaint.setTypeface(Typeface.DEFAULT_BOLD);
                fillPaint.setTextAlign(Paint.Align.CENTER);
                float textY = 100 - ((fillPaint.descent() + fillPaint.ascent()) / 2);
                canvas.drawText("৳", 100, textY, fillPaint);
                break;

            case ICON_USERS:
                canvas.drawCircle(80, 70, 28, paint);
                path.moveTo(30, 170);
                path.quadTo(80, 120, 130, 170);
                canvas.drawPath(path, paint);

                paint.setStrokeWidth(10f);
                paint.setColor(Color.parseColor("#94A3B8"));
                canvas.drawCircle(145, 85, 20, paint);
                Path pathBg = new Path();
                pathBg.moveTo(125, 170);
                pathBg.quadTo(160, 135, 185, 170);
                canvas.drawPath(pathBg, paint);
                break;

            case ICON_COPY:
                canvas.drawRoundRect(new RectF(35, 35, 125, 125), 16, 16, paint);
                canvas.drawRoundRect(new RectF(75, 75, 165, 165), 16, 16, paint);
                break;

            case ICON_STEP_1:
            case ICON_STEP_2:
            case ICON_STEP_3:
                fillPaint.setColor(Color.parseColor("#EEF2FF"));
                canvas.drawCircle(100, 100, 90, fillPaint);

                fillPaint.setColor(color);
                fillPaint.setTextSize(90f);
                fillPaint.setTypeface(Typeface.DEFAULT_BOLD);
                fillPaint.setTextAlign(Paint.Align.CENTER);

                String stepNum = iconType == ICON_STEP_1 ? "1" : (iconType == ICON_STEP_2 ? "2" : "3");
                float numY = 100 - ((fillPaint.descent() + fillPaint.ascent()) / 2);
                canvas.drawText(stepNum, 100, numY, fillPaint);
                break;
        }

        return bitmap;
    }

    private void setupClickListeners() {
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        findViewById(R.id.btnCopy).setOnClickListener(v -> {
            TextView tvCode = findViewById(R.id.tvReferralCode);
            String code = tvCode.getText().toString();

            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("Referral Code", code);
            clipboard.setPrimaryClip(clip);

            Toast.makeText(ReferAndEarnActivity.this, "Code Copied!", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btnShare).setOnClickListener(v -> {
            TextView tvCode = findViewById(R.id.tvReferralCode);
            String code = tvCode.getText().toString();
            String shareMessage = "Join Khelo sobai 2.0 and use my referral code: " + code + " to get amazing rewards!\nDownload app from https://khelosobai20.live.";

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Khelo sobai 2.0 Referral");
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "Share Referral Code via"));
        });
    }
}