package com.khelosobaiv3.user

import android.app.Activity
import android.content.Intent
import android.view.View

object ZabbarNavigation {

    @JvmStatic
    fun setup(activity: Activity) {
        activity.findViewById<View?>(R.id.img_help)?.setOnClickListener {
            activity.startActivity(Intent(activity, ZabbarSupportActivity::class.java))
        }

        activity.findViewById<View?>(R.id.img_notification)?.setOnClickListener {
            activity.startActivity(Intent(activity, ZabbarNotificationActivity::class.java))
        }

        activity.findViewById<View?>(R.id.app_icon)?.setOnClickListener {
            activity.finish()
        }
    }
}