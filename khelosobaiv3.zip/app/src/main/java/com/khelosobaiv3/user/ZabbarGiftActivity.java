package com.khelosobaiv3.user;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;

import com.google.firebase.FirebaseApp;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;

public class ZabbarGiftActivity extends AppCompatActivity {

    private final boolean USE_USERNAME_AS_TOKEN = false;

    private LinearLayout boxDeposit, boxWinning, searchResultsContainer;
    private TextView labelDeposit, labelWinning, badgeDeposit, badgeWinning;
    private TextView textDepositBal, textWinningBal;
    private EditText amountInput, inputSearch;
    private TextView txtTransferAmount, txtPlatformFee, txtTotalDeducted;
    private BlurView blurToolbar, blurBottom, blurSearchToolbar;
    private RelativeLayout searchOverlay;
    private ScrollView searchScroll;
    private ImageView iconClear;
    private ProgressBar searchProgress;

    private TextView mainUserAvatar, mainUserName, mainUserId;

    private final double FLAT_FEE = 5.0;

    private int currentPage = 1;
    private final int perPage = 20;
    private boolean isLoading = false;
    private boolean hasMoreData = true;
    private String currentSearch = "";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private Runnable searchRunnable;

    private SharedPreferences Save_User_Status;
    private SharedPreferences Api;
    private String myToken = "";
    private String myUsername = "";
    private double myDepositBalance = 0.0;
    private double myWinningBalance = 0.0;

    private String receiverUid = "";
    private int selectedWalletType = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            FirebaseApp.initializeApp(this);
        } catch (Exception ignored) {
        }
        setContentView(R.layout.zabbar_gift);

        Save_User_Status = getSharedPreferences("Save_User_Status", MODE_PRIVATE);
        Api = getSharedPreferences("Api", MODE_PRIVATE);

        initializeLogic();
        fetchMyProfile();
    }

    private void initializeLogic() {
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                        View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        );
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        View mainContent = findViewById(R.id.main_content);
        mainContent.setPadding(dp(15), getStatusBarHeight() + dp(80), dp(15), dp(100));

        View searchContent = findViewById(R.id.search_content);
        searchContent.setPadding(dp(15), getStatusBarHeight() + dp(80), dp(15), dp(40));

        initViews();
        setupBlurViews();
        setupIcons();
        setupStyling();
        setupListeners();
        updateSummary(amountInput.getText().toString());
    }

    private void initViews() {
        boxDeposit = findViewById(R.id.box_deposit);
        boxWinning = findViewById(R.id.box_winning);
        labelDeposit = findViewById(R.id.label_deposit);
        labelWinning = findViewById(R.id.label_winning);
        badgeDeposit = findViewById(R.id.badge_deposit);
        badgeWinning = findViewById(R.id.badge_winning);
        textDepositBal = findViewById(R.id.textview146);
        textWinningBal = findViewById(R.id.textview147);

        amountInput = findViewById(R.id.amount_input);
        txtTransferAmount = findViewById(R.id.txt_transfer_amount);
        txtPlatformFee = findViewById(R.id.txt_platform_fee);
        txtTotalDeducted = findViewById(R.id.txt_total_deducted);
        blurToolbar = findViewById(R.id.blur_toolbar);
        blurBottom = findViewById(R.id.bottom_container);
        blurSearchToolbar = findViewById(R.id.blur_search_toolbar);
        searchOverlay = findViewById(R.id.search_overlay);
        searchScroll = findViewById(R.id.search_scroll);
        inputSearch = findViewById(R.id.input_search);
        iconClear = findViewById(R.id.icon_clear);
        searchResultsContainer = findViewById(R.id.search_results_container);
        searchProgress = findViewById(R.id.search_progress);

        mainUserAvatar = findViewById(R.id.user_avatar);
        mainUserName = findViewById(R.id.main_user_name);
        mainUserId = findViewById(R.id.main_user_id);
    }

    private void fetchMyProfile() {
        executor.execute(() -> {
            try {
                String tokenFromPref = Save_User_Status.getString("Token", "");
                String apiUrl = Api.getString("Api", "") + "XMapp_Us.js.php";

                URL url = new URL(apiUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(10000);

                String postData = "type=1&token=" + URLEncoder.encode(tokenFromPref, "UTF-8");

                OutputStream os = conn.getOutputStream();
                os.write(postData.getBytes("UTF-8"));
                os.flush();
                os.close();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONObject jsonObject = new JSONObject(response.toString());

                myDepositBalance = jsonObject.optDouble("balance", 0.0);
                myWinningBalance = jsonObject.optDouble("winning", 0.0);
                myUsername = jsonObject.optString("username", "");
                myToken = jsonObject.optString("token", tokenFromPref);

                uiHandler.post(() -> {
                    textDepositBal.setText(String.format("৳%.2f", myDepositBalance));
                    textWinningBal.setText(String.format("৳%.2f", myWinningBalance));
                });

            } catch (Exception e) {
                uiHandler.post(() -> showDialog("Error", "Failed to load balance", "error.json", "#F44336"));
            }
        });
    }

    private void sendGiftRequest() {
        if (receiverUid == null || receiverUid.trim().isEmpty() || receiverUid.equals("null")) {
            showDialog("Warning", "Please select a valid recipient first!", "error.json", "#F44336");
            return;
        }

        String amountStr = amountInput.getText().toString().trim();
        if (amountStr.isEmpty()) {
            showDialog("Warning", "Enter a valid amount!", "error.json", "#F44336");
            return;
        }

        double transferAmount = Double.parseDouble(amountStr);
        if (transferAmount <= 0) {
            showDialog("Warning", "Amount must be greater than 0", "error.json", "#F44336");
            return;
        }

        double fee = FLAT_FEE;
        double totalRequired = transferAmount + fee;

        if (selectedWalletType == 1 && myDepositBalance < totalRequired) {
            showDialog("Failed", "Insufficient Deposit Balance!", "faild.json", "#F44336");
            return;
        } else if (selectedWalletType == 2 && myWinningBalance < totalRequired) {
            showDialog("Failed", "Insufficient Winning Balance!", "faild.json", "#F44336");
            return;
        }

        final String requestToken = USE_USERNAME_AS_TOKEN ? myUsername : myToken;
        final String requestType = (selectedWalletType == 1) ? "balance" : "winning";

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing Transfer...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        executor.execute(() -> {
            try {
                String apiUrl = Api.getString("Api", "") + "send_gift_request.php";
                URL url = new URL(apiUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(10000);

                String postData = "token=" + URLEncoder.encode(requestToken, "UTF-8") +
                        "&uid=" + URLEncoder.encode(receiverUid, "UTF-8") +
                        "&amount=" + URLEncoder.encode(String.valueOf(transferAmount), "UTF-8") +
                        "&type=" + URLEncoder.encode(requestType, "UTF-8");

                OutputStream os = conn.getOutputStream();
                os.write(postData.getBytes("UTF-8"));
                os.flush();
                os.close();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONObject jsonObject = new JSONObject(response.toString());
                String status = jsonObject.optString("status");
                String message = jsonObject.optString("message");

                uiHandler.post(() -> {
                    progressDialog.dismiss();
                    if ("success".equals(status)) {
                        showDialog("Success", "Transfer Successful!", "success.json", "#4CAF50");
                        fetchMyProfile();
                        amountInput.setText("");
                    } else {
                        showDialog("Failed", "Error: " + message, "faild.json", "#F44336");
                    }
                });

            } catch (Exception e) {
                uiHandler.post(() -> {
                    progressDialog.dismiss();
                    showDialog("Network Error", "Network Error! Please try again.", "error.json", "#F44336");
                });
            }
        });
    }

    private void showDialog(String title, String message, String lottie, String color) {
        new PremiumDialog.Builder(this)
                .setDialogType(true)
                .setCancelable(false)
                .setBlurBackground(true)
                .setLottie(lottie)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Okay", color, Dialog::dismiss)
                .setNegativeButton("Close", Dialog::dismiss)
                .show();
    }

    private void setupBlurViews() {
        float radius = 5f;
        ViewGroup rootView = findViewById(R.id.root_layout);
        Drawable windowBackground = rootView.getBackground();

        blurToolbar.setupWith(rootView, new RenderScriptBlur(this))
                .setFrameClearDrawable(windowBackground)
                .setBlurRadius(radius);

        blurBottom.setupWith(rootView, new RenderScriptBlur(this))
                .setFrameClearDrawable(windowBackground)
                .setBlurRadius(radius);

        blurSearchToolbar.setupWith(rootView, new RenderScriptBlur(this))
                .setFrameClearDrawable(windowBackground)
                .setBlurRadius(radius);
    }

    private void setupIcons() {
        ImageView iconBackMain = findViewById(R.id.icon_back_main);
        ImageView iconCash = findViewById(R.id.icon_cash);
        ImageView iconTrophy = findViewById(R.id.icon_trophy);
        ImageView iconBackSearch = findViewById(R.id.icon_back_search);
        ImageView iconSearch = findViewById(R.id.icon_search);

        iconBackMain.setImageDrawable(new VectorIcon(1, Color.parseColor("#1E293B")));
        iconBackSearch.setImageDrawable(new VectorIcon(1, Color.parseColor("#1E293B")));
        iconSearch.setImageDrawable(new VectorIcon(2, Color.parseColor("#94A3B8")));
        iconClear.setImageDrawable(new VectorIcon(3, Color.parseColor("#94A3B8")));
        iconCash.setImageDrawable(new VectorIcon(4, Color.parseColor("#5C54F4")));
        iconTrophy.setImageDrawable(new VectorIcon(5, Color.parseColor("#F34770")));
    }

    private void setupStyling() {
        setBg(findViewById(R.id.btn_back_main), "#FFFFFF", "#C4D9FF", 20);
        setBg(mainUserAvatar, "#EDF4FF", null, 20);
        setBg(findViewById(R.id.btn_change), "#FFE5EC", null, 20);

        setBg(findViewById(R.id.card1), "#FFFFFF", "#C4D9FF", 16);
        setBg(findViewById(R.id.card2), "#FFFFFF", "#C4D9FF", 16);
        setBg(findViewById(R.id.card3), "#FFFFFF", "#C4D9FF", 16);
        setBg(findViewById(R.id.card4), "#FFFFFF", "#C4D9FF", 16);

        setBg(findViewById(R.id.user_container), "#F5F9FF", "#D0E0FF", 12);
        setBg(findViewById(R.id.input_container), "#F5F9FF", "#D0E0FF", 12);
        setBg(findViewById(R.id.info_box), "#EDF4FF", null, 10);

        setBg(findViewById(R.id.btn_50), "#F5F9FF", "#D0E0FF", 20);
        setBg(findViewById(R.id.btn_100), "#F5F9FF", "#D0E0FF", 20);
        setBg(findViewById(R.id.btn_500), "#F5F9FF", "#D0E0FF", 20);
        setBg(findViewById(R.id.btn_1000), "#F5F9FF", "#D0E0FF", 20);
        setBg(findViewById(R.id.btn_transfer), "#004F50", null, 12);

        setBg(findViewById(R.id.btn_back_search), "#FFFFFF", "#C4D9FF", 20);
        setBg(findViewById(R.id.search_card), "#FFFFFF", "#C4D9FF", 16);

        GradientDrawable symbolBg = new GradientDrawable();
        symbolBg.setColor(Color.parseColor("#EDF4FF"));
        symbolBg.setCornerRadii(new float[]{dp(12), dp(12), 0, 0, 0, 0, dp(12), dp(12)});
        findViewById(R.id.currency_symbol).setBackground(symbolBg);

        setBg(badgeDeposit, "#5C54F4", null, 8);
        setBg(badgeWinning, "#5C54F4", null, 8);

        selectBox(1);
    }

    private void setupListeners() {
        boxDeposit.setOnClickListener(v -> selectBox(1));
        boxWinning.setOnClickListener(v -> selectBox(2));

        findViewById(R.id.btn_50).setOnClickListener(v -> addAmount(50));
        findViewById(R.id.btn_100).setOnClickListener(v -> addAmount(100));
        findViewById(R.id.btn_500).setOnClickListener(v -> addAmount(500));
        findViewById(R.id.btn_1000).setOnClickListener(v -> addAmount(1000));

        findViewById(R.id.btn_change).setOnClickListener(v -> openSearchOverlay());
        findViewById(R.id.btn_back_search).setOnClickListener(v -> closeSearchOverlay());

        findViewById(R.id.btn_transfer).setOnClickListener(v -> sendGiftRequest());

        iconClear.setOnClickListener(v -> {
            inputSearch.setText("");
            searchResultsContainer.removeAllViews();
            currentSearch = "";
        });

        inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().length() > 0) {
                    iconClear.setVisibility(View.VISIBLE);
                } else {
                    iconClear.setVisibility(View.GONE);
                }

                if (searchRunnable != null) {
                    uiHandler.removeCallbacks(searchRunnable);
                }

                searchRunnable = () -> {
                    String query = s.toString().trim();
                    if (!query.equals(currentSearch)) {
                        currentSearch = query;
                        currentPage = 1;
                        hasMoreData = true;
                        searchResultsContainer.removeAllViews();
                        if (currentSearch.length() > 0) {
                            performSearch(currentSearch, currentPage);
                        }
                    }
                };
                uiHandler.postDelayed(searchRunnable, 600);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        searchScroll.getViewTreeObserver().addOnScrollChangedListener(() -> {
            View view = searchScroll.getChildAt(searchScroll.getChildCount() - 1);
            if (view != null) {
                int diff = (view.getBottom() - (searchScroll.getHeight() + searchScroll.getScrollY()));
                if (diff == 0 && !isLoading && currentSearch.length() > 0 && hasMoreData) {
                    currentPage++;
                    performSearch(currentSearch, currentPage);
                }
            }
        });

        amountInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateSummary(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        findViewById(R.id.btn_back_main).setOnClickListener(v -> finish());
    }

    private void performSearch(String query, int page) {
        isLoading = true;
        searchProgress.setVisibility(View.VISIBLE);

        executor.execute(() -> {
            try {
                String encodedQuery = URLEncoder.encode(query, "UTF-8");
                String urlString = "https://api.khelosobai20.live/ElitegoxUser/search.php?search=" + encodedQuery + "&page=" + page + "&per_page=" + perPage;
                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONObject jsonObject = new JSONObject(response.toString());
                JSONArray dataArray = jsonObject.getJSONArray("data");

                uiHandler.post(() -> {
                    renderResults(dataArray);
                    isLoading = false;
                    searchProgress.setVisibility(View.GONE);
                });

            } catch (Exception e) {
                uiHandler.post(() -> {
                    isLoading = false;
                    searchProgress.setVisibility(View.GONE);
                });
            }
        });
    }

    private void renderResults(JSONArray dataArray) {
        try {
            if (dataArray.length() < perPage) {
                hasMoreData = false;
            }

            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject userObj = dataArray.getJSONObject(i);

                String uid = userObj.has("uid") ? userObj.optString("uid", "") : userObj.optString("id", "");
                String username = userObj.optString("username", "").trim();

                if ("null".equals(uid)) {
                    uid = "";
                }

                if ("null".equals(username)) {
                    username = "";
                }

                final String finalUid = uid;
                final String finalUsername = username;

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.HORIZONTAL);
                card.setGravity(Gravity.CENTER_VERTICAL);
                card.setPadding(dp(15), dp(15), dp(15), dp(15));
                LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                cardParams.bottomMargin = dp(12);
                card.setLayoutParams(cardParams);
                setBg(card, "#F5F9FF", "#D0E0FF", 16);

                TextView avatar = new TextView(this);
                avatar.setGravity(Gravity.CENTER);
                String firstLetter = finalUsername.length() > 0 ? finalUsername.substring(0, 1).toUpperCase() : "U";
                avatar.setText(firstLetter);
                avatar.setTextSize(18);
                avatar.setTypeface(null, Typeface.BOLD);

                boolean isEven = (searchResultsContainer.getChildCount() % 2 == 0);
                String avatarBgColor = isEven ? "#EDF4FF" : "#FFE5EC";
                String avatarTextColor = isEven ? "#5C54F4" : "#F34770";

                avatar.setTextColor(Color.parseColor(avatarTextColor));
                LinearLayout.LayoutParams avatarParams = new LinearLayout.LayoutParams(dp(45), dp(45));
                avatarParams.rightMargin = dp(12);
                avatar.setLayoutParams(avatarParams);
                setBg(avatar, avatarBgColor, null, 22);

                LinearLayout infoBox = new LinearLayout(this);
                infoBox.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                infoBox.setLayoutParams(infoParams);

                TextView nameView = new TextView(this);
                nameView.setText("@" + finalUsername.replace("\n", ""));
                nameView.setTextSize(16);
                nameView.setTypeface(null, Typeface.BOLD);
                nameView.setTextColor(Color.parseColor("#1E293B"));

                TextView idView = new TextView(this);
                idView.setText("User ID: " + finalUid);
                idView.setTextSize(13);
                idView.setTextColor(Color.parseColor("#64748B"));
                LinearLayout.LayoutParams idParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                idParams.topMargin = dp(2);
                idView.setLayoutParams(idParams);

                infoBox.addView(nameView);
                infoBox.addView(idView);

                TextView btnSelect = new TextView(this);
                btnSelect.setText("Select");
                btnSelect.setTextSize(13);
                btnSelect.setTypeface(null, Typeface.BOLD);
                btnSelect.setTextColor(Color.WHITE);
                btnSelect.setPadding(dp(16), dp(8), dp(16), dp(8));
                setBg(btnSelect, "#5C54F4", null, 20);

                card.addView(avatar);
                card.addView(infoBox);
                card.addView(btnSelect);

                btnSelect.setOnClickListener(v -> selectUser(finalUsername, finalUid, firstLetter, avatarBgColor, avatarTextColor));

                searchResultsContainer.addView(card);
            }
        } catch (Exception ignored) {
        }
    }

    private void selectUser(String username, String uid, String letter, String bgColor, String textColor) {
        mainUserAvatar.setText(letter);
        mainUserAvatar.setTextColor(Color.parseColor(textColor));
        setBg(mainUserAvatar, bgColor, null, 20);
        mainUserName.setText("@" + username.replace("\n", ""));
        mainUserId.setText("User ID: " + uid);

        receiverUid = uid;

        closeSearchOverlay();
    }

    @Override
    public void onBackPressed() {
        if (searchOverlay != null && searchOverlay.getVisibility() == View.VISIBLE) {
            closeSearchOverlay();
        } else {
            super.onBackPressed();
        }
    }

    private void openSearchOverlay() {
        searchOverlay.setAlpha(0f);
        searchOverlay.setVisibility(View.VISIBLE);
        searchOverlay.animate().alpha(1f).setDuration(200).start();
    }

    private void closeSearchOverlay() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(inputSearch.getWindowToken(), 0);
        }
        searchOverlay.animate().alpha(0f).setDuration(200).withEndAction(() -> {
            searchOverlay.setVisibility(View.GONE);
            inputSearch.setText("");
            searchResultsContainer.removeAllViews();
            currentSearch = "";
        }).start();
    }

    private void selectBox(int type) {
        selectedWalletType = type;

        if (type == 1) {
            setBg(boxDeposit, "#EDF4FF", "#5C54F4", 12);
            labelDeposit.setTextColor(Color.parseColor("#5C54F4"));
            badgeDeposit.setVisibility(View.VISIBLE);

            setBg(boxWinning, "#FFFFFF", "#D0E0FF", 12);
            labelWinning.setTextColor(Color.parseColor("#64748B"));
            badgeWinning.setVisibility(View.GONE);
        } else {
            setBg(boxWinning, "#EDF4FF", "#5C54F4", 12);
            labelWinning.setTextColor(Color.parseColor("#5C54F4"));
            badgeWinning.setVisibility(View.VISIBLE);

            setBg(boxDeposit, "#FFFFFF", "#D0E0FF", 12);
            labelDeposit.setTextColor(Color.parseColor("#64748B"));
            badgeDeposit.setVisibility(View.GONE);
        }
    }

    private void addAmount(int value) {
        String currentStr = amountInput.getText().toString();
        int current = 0;
        if (!currentStr.isEmpty()) {
            try {
                current = Integer.parseInt(currentStr);
            } catch (Exception ignored) {
            }
        }
        amountInput.setText(String.valueOf(current + value));
        amountInput.setSelection(amountInput.getText().length());
    }

    private void updateSummary(String amountStr) {
        double amount = 0.0;
        if (!amountStr.isEmpty()) {
            try {
                amount = Double.parseDouble(amountStr);
            } catch (Exception ignored) {
            }
        }

        double platformFee = amount > 0 ? FLAT_FEE : 0.0;
        double total = amount > 0 ? amount + platformFee : 0.0;

        txtTransferAmount.setText(String.format("৳%.2f", amount));
        txtPlatformFee.setText(String.format("৳%.2f", platformFee));
        txtTotalDeducted.setText(String.format("৳%.2f", total));
    }

    private void setBg(View view, String bgColor, String strokeColor, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(bgColor));
        gd.setCornerRadius(dp(radiusDp));
        if (strokeColor != null) {
            gd.setStroke(dp(1), Color.parseColor(strokeColor));
        }
        view.setBackground(gd);
    }

    private int dp(float px) {
        return (int) (px * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int getStatusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    private static class VectorIcon extends Drawable {
        private final Paint paint;
        private final Path path;
        private final int type;

        public VectorIcon(int type, int color) {
            this.type = type;
            paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            path = new Path();
        }

        @Override
        public void draw(Canvas canvas) {
            int w = getBounds().width();
            int h = getBounds().height();
            float strokeWidth = w * 0.12f;
            paint.setStrokeWidth(strokeWidth);
            path.reset();

            if (type == 1) {
                path.moveTo(w * 0.60f, h * 0.25f);
                path.lineTo(w * 0.35f, h * 0.50f);
                path.lineTo(w * 0.60f, h * 0.75f);
                canvas.drawPath(path, paint);
            } else if (type == 2) {
                float cx = w * 0.45f;
                float cy = h * 0.45f;
                float r = w * 0.25f;
                canvas.drawCircle(cx, cy, r, paint);
                path.moveTo(cx + r * 0.707f, cy + r * 0.707f);
                path.lineTo(w * 0.85f, h * 0.85f);
                canvas.drawPath(path, paint);
            } else if (type == 3) {
                path.moveTo(w * 0.30f, h * 0.30f);
                path.lineTo(w * 0.70f, h * 0.70f);
                path.moveTo(w * 0.70f, h * 0.30f);
                path.lineTo(w * 0.30f, h * 0.70f);
                canvas.drawPath(path, paint);
            } else if (type == 4) {
                path.addRoundRect(w * 0.1f, h * 0.25f, w * 0.9f, h * 0.75f, w * 0.1f, w * 0.1f, Path.Direction.CW);
                canvas.drawPath(path, paint);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(w * 0.5f, h * 0.5f, w * 0.12f, paint);
            } else if (type == 5) {
                path.moveTo(w * 0.2f, h * 0.25f);
                path.lineTo(w * 0.8f, h * 0.25f);
                path.lineTo(w * 0.65f, h * 0.55f);
                path.lineTo(w * 0.35f, h * 0.55f);
                path.close();
                canvas.drawPath(path, paint);
                path.reset();
                path.moveTo(w * 0.5f, h * 0.55f);
                path.lineTo(w * 0.5f, h * 0.75f);
                canvas.drawPath(path, paint);
                path.reset();
                path.moveTo(w * 0.35f, h * 0.75f);
                path.lineTo(w * 0.65f, h * 0.75f);
                canvas.drawPath(path, paint);
            }
        }

        @Override
        public void setAlpha(int alpha) {
            paint.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter colorFilter) {
            paint.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }
}