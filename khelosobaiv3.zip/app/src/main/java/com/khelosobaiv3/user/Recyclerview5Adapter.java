package com.khelosobaiv3.user;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Recyclerview5Adapter extends RecyclerView.Adapter<Recyclerview5Adapter.ViewHolder> {

    private final ArrayList<HashMap<String, Object>> _data;

    public Recyclerview5Adapter(ArrayList<HashMap<String, Object>> _arr) {
        this._data = _arr;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.zabbarx_topup, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ZabbarxTopupBinding binding = ZabbarxTopupBinding.bind(holder.itemView);
        HashMap<String, Object> item = _data.get(position);

        String id1 = extractId(item, "id1", "product_id1");

        if (!id1.isEmpty()) {
            binding.cardview1.setVisibility(View.VISIBLE);
            binding.tvTitle1.setText(item.get("title1") != null ? item.get("title1").toString() : "");
            binding.tvAmount1.setText(item.get("amount1") != null ? item.get("amount1").toString() : "");
            binding.tvOriginalAmount1.setText(item.get("originalAmount1") != null ? item.get("originalAmount1").toString() : "");
            binding.tvOriginalAmount1.setPaintFlags(binding.tvOriginalAmount1.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

            if (item.get("photo1") != null) {
                Glide.with(holder.itemView.getContext())
                        .load(item.get("photo1").toString())
                        .into(binding.zabbarMt1);
            }

            binding.cardview1.setOnClickListener(v -> {
                Activity activity = (Activity) v.getContext();
                processTopup(activity, id1,
                        item.get("title1") != null ? item.get("title1").toString() : "",
                        item.get("originalAmount1") != null ? item.get("originalAmount1").toString() : "0",
                        item.get("amount1") != null ? item.get("amount1").toString() : "0");
            });
        } else {
            binding.cardview1.setVisibility(View.INVISIBLE);
        }

        String id2 = extractId(item, "id2", "product_id2");

        if (!id2.isEmpty() && item.get("photo2") != null && !item.get("photo2").toString().isEmpty()) {
            binding.cardview2.setVisibility(View.VISIBLE);
            binding.cardview2.setEnabled(true);

            binding.tvTitle2.setText(item.get("title2") != null ? item.get("title2").toString() : "");
            binding.tvAmount2.setText(item.get("amount2") != null ? item.get("amount2").toString() : "");
            binding.tvOriginalAmount2.setText(item.get("originalAmount2") != null ? item.get("originalAmount2").toString() : "");
            binding.tvOriginalAmount2.setPaintFlags(binding.tvOriginalAmount2.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

            Glide.with(holder.itemView.getContext())
                    .load(item.get("photo2").toString())
                    .into(binding.zabbarMt2);

            binding.cardview2.setOnClickListener(v -> {
                Activity activity = (Activity) v.getContext();
                processTopup(activity, id2,
                        item.get("title2") != null ? item.get("title2").toString() : "",
                        item.get("originalAmount2") != null ? item.get("originalAmount2").toString() : "0",
                        item.get("amount2") != null ? item.get("amount2").toString() : "0");
            });
        } else {
            binding.cardview2.setVisibility(View.GONE);
            binding.cardview2.setEnabled(false);
        }
    }

    private String extractId(HashMap<String, Object> item, String... keys) {
        for (String key : keys) {
            if (item.containsKey(key) && item.get(key) != null) {
                String val = item.get(key).toString().trim();
                if (val.endsWith(".0")) {
                    val = val.substring(0, val.indexOf(".0"));
                }
                if (!val.isEmpty() && !val.equals("null")) return val;
            }
        }
        return "";
    }

    private void processTopup(Activity activity, String productId, String title, String originalAmount, String discountAmount) {
        SharedPreferences saveUserStatus = activity.getSharedPreferences("Save_User_Status", Context.MODE_PRIVATE);
        String userToken = saveUserStatus.getString("token", "");
        String currentBalance = saveUserStatus.getString("balance", "0");

        if (userToken == null || userToken.trim().isEmpty()) {
            Toast.makeText(activity, "Authentication Error: User token is missing.", Toast.LENGTH_SHORT).show();
            return;
        }

        TopupBottomSheet.showDialog(
                activity,
                "lottie_topup.json",
                title,
                currentBalance,
                originalAmount,
                discountAmount,
                true,
                (uid, dialog, progressBar, btnSubmit) -> {
                    if (uid == null || uid.trim().isEmpty()) {
                        Toast.makeText(activity, "Please enter your UID", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    String url = "https://api.khelosobai20.live/ElitegoxUser/topuporder.php";

                    StringRequest request = new StringRequest(
                            Request.Method.POST,
                            url,
                            response -> {
                                progressBar.setVisibility(View.GONE);
                                btnSubmit.setText("Submit");
                                btnSubmit.setEnabled(true);

                                String serverResponse = response.trim();
                                if (serverResponse.equals("Order Placed Successfully")) {
                                    dialog.dismiss();
                                    Toast.makeText(activity, serverResponse, Toast.LENGTH_LONG).show();
                                } else {
                                    Toast.makeText(activity, serverResponse, Toast.LENGTH_LONG).show();
                                }
                            },
                            error -> {
                                progressBar.setVisibility(View.GONE);
                                btnSubmit.setText("Submit");
                                btnSubmit.setEnabled(true);
                                Toast.makeText(activity, "Network Error: Could not connect to server.", Toast.LENGTH_SHORT).show();
                            }
                    ) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<>();
                            params.put("product_id", productId);
                            params.put("user_token", userToken);
                            params.put("topup_uid", uid);
                            params.put("product_title", title);
                            params.put("product_price", originalAmount.replaceAll("[^0-9.]", ""));
                            params.put("discount_price", discountAmount.replaceAll("[^0-9.]", ""));
                            return params;
                        }
                    };

                    RequestQueue queue = Volley.newRequestQueue(activity);
                    queue.add(request);
                }
        );
    }

    @Override
    public int getItemCount() {
        return _data != null ? _data.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View v) {
            super(v);
        }
    }
}