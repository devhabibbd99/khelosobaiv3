package com.khelosobaiv3.user

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import androidx.core.view.WindowCompat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.TypedValue
import android.view.*
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.airbnb.lottie.LottieAnimationView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.tabs.TabLayout
import com.google.firebase.FirebaseApp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import eightbitlab.com.blurview.BlurView
import eightbitlab.com.blurview.RenderEffectBlur
import eightbitlab.com.blurview.RenderScriptBlur

class ZabbarClessHome(private val activity: ZabbarHomeActivity) {

    private var matchList = ArrayList<HashMap<String, Any>>()
    private var zabbarRefresh = ArrayList<HashMap<String, Any>>()
    private var categorys = ArrayList<HashMap<String, Any>>()
    private var statAll = ArrayList<HashMap<String, Any>>()
    private var statWinning = ArrayList<HashMap<String, Any>>()
    private var statRefunded = ArrayList<HashMap<String, Any>>()
    private var statParticipated = ArrayList<HashMap<String, Any>>()
    private var currentStatTab = "All"
    private var matchAdapter: Recyclerview4Adapter? = null
    private var sliderManager: SliderManager? = null
    private lateinit var binding: ZabbarHomeBinding
    private var shuvobro = java.util.HashMap<String, Any>()
    private lateinit var categoryReq: RequestNetwork
    private lateinit var usersDataReq: RequestNetwork
    private lateinit var categoryRequestListener: RequestNetwork.RequestListener
    private lateinit var usersDataRequestListener: RequestNetwork.RequestListener
    private lateinit var apiPrefs: SharedPreferences
    private lateinit var saveUserStatus: SharedPreferences
    private lateinit var imgExecutor: ExecutorService
    private lateinit var memoryCache: LruCache<String, Bitmap>
    private val mainHandler = Handler(Looper.getMainLooper())
    private var imagePickerLauncher: ActivityResultLauncher<PickVisualMediaRequest>

    init {
        imagePickerLauncher = activity.registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) {
                uploadProfileImage(uri)
            }
        }
    }

    fun onCreate(savedInstanceState: Bundle?) {
        binding = ZabbarHomeBinding.inflate(activity.layoutInflater)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            activity.window.statusBarColor = Color.TRANSPARENT
            activity.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        activity.setContentView(binding.root)
        activity.findViewById<TextView>(R.id.textview2)?.isSelected = true
        FirebaseApp.initializeApp(activity)
        initImageLoader()
        setupDynamicStyles()
        initialize()
        initializeLogic()
        setupImagePicker()
        loadUserDataAndRefresh()
    }

    fun onStart() {
        loadUserDataAndRefresh()
    }

    fun onResume() = updateAllZabbarBalances()

    fun onBackPressed() {
        PremiumDialog.Builder(activity)
            .setDialogType(true).setLottie("warning.json")
            .setTitle("Exit App").setMessage("Are you sure you want to exit?")
            .setPositiveButton("Exit", "#EF4444") { d -> d.dismiss(); activity.finishAffinity() }
            .setNegativeButton("Cancel") { d -> d.dismiss() }.show()
    }

    inner class SlideTimerView(c: Context, tv: TextView) : View(c) {
        var text = "00d 00h 00m 00s"; var old = "00d 00h 00m 00s"; var p = 1f
        var pt: Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tv.currentTextColor; textSize = tv.textSize; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        var an: ValueAnimator? = null
        init { layoutParams = tv.layoutParams }
        fun setTime(n: String) {
            if (n != text) {
                old = text; text = n; an?.cancel()
                an = ValueAnimator.ofFloat(0f, 1f).apply { duration = 300; addUpdateListener { a -> p = a.animatedValue as Float; invalidate() }; start() }
            }
        }
        private fun getTw(s: String) = s.sumOf { (if (it in '0'..'9') pt.measureText("0") else pt.measureText(it.toString())).toDouble() }.toFloat()
        override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(resolveSize(getTw(" 99d 23h 59m 59s ").toInt(), w), resolveSize((pt.descent() - pt.ascent()).toInt(), h))
        override fun onDraw(c: Canvas) {
            val y = height / 2f - (pt.descent() + pt.ascent()) / 2f
            var tStr = text; var oStr = old; val maxLen = maxOf(tStr.length, oStr.length)
            while (tStr.length < maxLen) tStr = " $tStr"
            while (oStr.length < maxLen) oStr = " $oStr"
            var x = (width - getTw(tStr)) / 2f
            for (i in 0 until maxLen) {
                val ch = tStr[i]; val o = oStr[i]; val cw = if (ch in '0'..'9') pt.measureText("0") else pt.measureText(ch.toString())
                if (ch == o) { pt.alpha = 255; c.drawText(ch.toString(), x, y, pt) } else {
                    pt.alpha = (p * 255).toInt(); c.drawText(ch.toString(), x, y - height * (1 - p), pt)
                    pt.alpha = ((1 - p) * 255).toInt(); c.drawText(o.toString(), x, y + height * p, pt)
                }
                x += cw
            }
        }
    }

    private fun initImageLoader() {
        memoryCache = object : LruCache<String, Bitmap>(((Runtime.getRuntime().maxMemory() / 1024) / 8).toInt()) { override fun sizeOf(k: String, b: Bitmap) = b.byteCount / 1024 }
        imgExecutor = Executors.newCachedThreadPool()
    }

    private fun setBg(v: View?, sh: Int, sc: Any, sw: Int, stc: Any?, r: Float) {
        v?.background = GradientDrawable().apply {
            shape = sh; setColor(when (sc) { is String -> Color.parseColor(sc); is Int -> sc; else -> Color.TRANSPARENT })
            if (sw > 0 && stc != null) setStroke(dpToPx(sw), when (stc) { is String -> Color.parseColor(stc); is Int -> stc; else -> Color.TRANSPARENT })
            if (r > 0) cornerRadius = dpToPx(r.toInt()).toFloat()
        }
    }

    private fun dpToPx(dp: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), activity.resources.displayMetrics).toInt()
    private fun str(m: HashMap<String, Any>, k: String, d: String = "") = if (m.containsKey(k) && m[k] != null) m[k].toString() else d

    private fun setupDynamicStyles() {
        binding.rootLayout?.setBackgroundColor(Color.parseColor("#DAE8FF"))
        setBg(binding.avatarOuterRing, 1, "#FFFFFF", 3, "#7B2CBF", 0f); setBg(binding.avatarInnerRing, 1, "#FFFFFF", 2, "#E0E0E0", 0f); setBg(binding.avatarCore, 1, "#7B2CBF", 0, null, 0f)
        setBg(binding.cameraBtn, 1, "#FFFFFF", 1, "#E0E0E0", 0f); setBg(binding.uidBadge, 0, "#EADDFF", 1, "#D0BCFF", 20f)
        setBg(binding.cardBalance, 0, "#FFFFFF", 1, "#E0E0E0", 16f); setBg(binding.cardWinning, 0, "#FFFFFF", 1, "#E0E0E0", 16f); setBg(binding.cardStats, 0, "#FFFFFF", 1, "#E0E0E0", 16f)
        setBg(binding.menuListContainer, 0, "#FFFFFF", 1, "#E0E0E0", 16f)
        setBg(binding.btnDeposit, 1, "#E8F5E9", 1, "#A5D6A7", 0f); setBg(binding.btnWithdraw, 1, "#FFEBEE", 1, "#EF9A9A", 0f); setBg(binding.btnGift, 1, "#F3E5F5", 1, "#CE93D8", 0f); setBg(binding.btnHistory, 1, "#E3F2FD", 1, "#90CAF9", 0f)
    }

    private fun setupImagePicker() {
        binding.cameraBtn.setOnClickListener {
            imagePickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
    }

    private fun uploadProfileImage(imageUri: Uri) {
        Toast.makeText(activity, "Uploading...", Toast.LENGTH_SHORT).show()
        val bitmap = try { 
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(activity.contentResolver, imageUri))
            } else {
                MediaStore.Images.Media.getBitmap(activity.contentResolver, imageUri)
            }
        } catch (e: Exception) { return Toast.makeText(activity, "Failed to read image", Toast.LENGTH_SHORT).show() } ?: return
        val baos = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.JPEG, 80, baos)
        val token = saveUserStatus.getString("token", "") ?: ""
        if (token.isEmpty()) return
        imgExecutor.execute {
            try {
                val bnd = "----WebKitFormBoundary${System.currentTimeMillis()}"; val le = "\r\n"; val th = "--"
                val bos = ByteArrayOutputStream().apply {
                    write((th + bnd + le).toByteArray()); write(("Content-Disposition: form-data; name=\"token\"$le").toByteArray()); write(("Content-Type: text/plain$le$le$token$le").toByteArray())
                    write((th + bnd + le).toByteArray()); write(("Content-Disposition: form-data; name=\"profile_image\"; filename=\"profile.jpg\"$le").toByteArray()); write(("Content-Type: image/jpeg$le$le").toByteArray()); write(baos.toByteArray()); write(le.toByteArray()); write((th + bnd + th + le).toByteArray())
                }
                val conn = URL("https://api.khelosobai20.live/ElitegoxUser/upload_profile_pic.php").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.doOutput = true; conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$bnd"); conn.setRequestProperty("Content-Length", bos.toByteArray().size.toString())
                DataOutputStream(conn.outputStream).apply { write(bos.toByteArray()); flush(); close() }
                val res = JSONObject(BufferedReader(InputStreamReader(if (conn.responseCode == HttpURLConnection.HTTP_OK) conn.inputStream else conn.errorStream)).use { it.readText() }); conn.disconnect()
                mainHandler.post { if (res.optBoolean("success", false)) { Toast.makeText(activity, "Profile updated!", Toast.LENGTH_SHORT).show(); updateProfileImage(res.optString("image_url", "")) } else Toast.makeText(activity, res.optString("message", "Upload failed"), Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) { mainHandler.post { Toast.makeText(activity, "Upload error", Toast.LENGTH_SHORT).show() } }
        }
    }

    private fun updateProfileImage(url: String) {
        binding.avatarCore?.visibility = View.GONE
        binding.avatarInnerRing?.parent?.let { p ->
            p as ViewGroup; var nav = p.findViewWithTag<ImageView>("avatar_img")
            if (nav == null) { nav = ImageView(activity).apply { tag = "avatar_img"; layoutParams = binding.avatarInnerRing.layoutParams; scaleType = ImageView.ScaleType.CENTER_CROP }; p.addView(nav, p.indexOfChild(binding.avatarInnerRing) + 1) }
            nav.visibility = View.VISIBLE; memoryCache.remove(url); loadCachedImage(url, nav, true)
        }
    }

    private fun loadCachedImage(url: String?, img: ImageView, isAvatar: Boolean) {
        val p = img.parent as? ViewGroup ?: return
        if (isAvatar && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { img.outlineProvider = object : android.view.ViewOutlineProvider() { override fun getOutline(v: View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) } }; img.clipToOutline = true }
        val tag = "pb_${img.hashCode()}"; var pb = if ("wrapper_frame" == p.tag) p.findViewWithTag<ProgressBar>(tag) else null
        if (pb == null) {
            pb = ProgressBar(img.context).apply { this.tag = tag; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) indeterminateTintList = ColorStateList.valueOf(Color.WHITE) }
            if ("wrapper_frame" == p.tag) p.addView(pb) else {
                val idx = p.indexOfChild(img); val prm = img.layoutParams; p.removeView(img)
                val wrp = FrameLayout(img.context).apply { layoutParams = prm; setBackgroundColor(Color.TRANSPARENT); this.tag = "wrapper_frame" }
                if (isAvatar && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) { wrp.outlineProvider = object : android.view.ViewOutlineProvider() { override fun getOutline(v: View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) } }; wrp.clipToOutline = true }
                img.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT); wrp.addView(img)
                pb.layoutParams = FrameLayout.LayoutParams(dpToPx(42), dpToPx(42), Gravity.CENTER); wrp.addView(pb); p.addView(wrp, idx)
            }
        }
        val fUrl = url?.trim()?.replace(" ", "%20") ?: ""
        if (fUrl.isBlank() || fUrl.equals("null", true)) { pb.visibility = View.GONE; if (isAvatar) { img.visibility = View.GONE; (img.parent as ViewGroup).visibility = View.GONE } else { img.setImageResource(R.drawable.zabbar_nodata_found); img.visibility = View.VISIBLE }; return }
        memoryCache.get(fUrl)?.let { img.setImageBitmap(it); pb.visibility = View.GONE; img.visibility = View.VISIBLE; if (isAvatar) (img.parent as ViewGroup).visibility = View.VISIBLE; return }
        img.visibility = View.INVISIBLE; pb.visibility = View.VISIBLE
        imgExecutor.execute {
            try {
                val f = File(img.context.cacheDir, "img_${fUrl.hashCode()}.png")
                if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.let { memoryCache.put(fUrl, it); mainHandler.post { img.setImageBitmap(it); pb.visibility = View.GONE; img.visibility = View.VISIBLE; if (isAvatar) (img.parent as ViewGroup).visibility = View.VISIBLE }; return@execute }
                val c = URL(fUrl).openConnection() as HttpURLConnection; c.connectTimeout = 3000; c.readTimeout = 5000
                val data = ByteArrayOutputStream().apply { c.inputStream.use { it.copyTo(this) } }.toByteArray(); c.disconnect()
                if (data.isNotEmpty()) {
                    BitmapFactory.decodeByteArray(data, 0, data.size)?.let { bmp ->
                        memoryCache.put(fUrl, bmp); FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        mainHandler.post { img.setImageBitmap(bmp); pb.visibility = View.GONE; img.visibility = View.VISIBLE; if (isAvatar) (img.parent as ViewGroup).visibility = View.VISIBLE }
                    }
                }
            } catch (e: Exception) { mainHandler.post { pb.visibility = View.GONE; if (!isAvatar) { img.setImageResource(R.drawable.zabbar_nodata_found); img.visibility = View.VISIBLE } } }
        }
    }

    private fun extractId(m: HashMap<String, Any>, vararg keys: String): String {
        for (k in keys) { if (m.containsKey(k) && m[k] != null) { val v = m[k].toString().trim().replace(".0", ""); if (v.isNotEmpty() && !v.equals("null", true)) return v } }
        return ""
    }

    private fun processTopup(productId: String, title: String, originalAmount: String, discountAmount: String) {
        val userToken = saveUserStatus.getString("token", "")
        if (userToken.isNullOrBlank()) { Toast.makeText(activity, "Authentication Error", Toast.LENGTH_SHORT).show(); return }
        
        val bal = saveUserStatus.getString("balance", "0")?.toDoubleOrNull() ?: 0.0
        val win = saveUserStatus.getString("winning", "0")?.toDoubleOrNull() ?: 0.0
        val totalBal = bal + win
        val currentBalance = if (totalBal % 1.0 == 0.0) totalBal.toInt().toString() else totalBal.toString()
        
        TopupBottomSheet.showDialog(activity, "lottie_topup.json", title, currentBalance, originalAmount, discountAmount, true) { uid, dialog, progressBar, btnSubmit ->
            if (uid.isNullOrBlank()) { Toast.makeText(activity, "Please enter your UID", Toast.LENGTH_SHORT).show(); return@showDialog }
            progressBar.visibility = View.VISIBLE; btnSubmit.text = "Processing..."; btnSubmit.isEnabled = false
            
            Volley.newRequestQueue(activity).add(object : StringRequest(Request.Method.POST, "https://api.khelosobai20.live/ElitegoxUser/topuporder.php", Response.Listener { r ->
                progressBar.visibility = View.GONE; btnSubmit.text = "Submit"; btnSubmit.isEnabled = true
                val msg = r.trim()
                dialog.dismiss()
                val isSuccess = msg.equals("Order Placed Successfully", true)
                PremiumDialog.Builder(activity)
                    .setDialogType(true)
                    .setLottie(if (isSuccess) "success.json" else "warning.json")
                    .setTitle(if (isSuccess) "Success!" else "Notice")
                    .setMessage(msg)
                    .setPositiveButton("OK", if (isSuccess) "#10B981" else "#EF4444") { d -> d.dismiss() }
                    .setNegativeButton("Close") { d -> d.dismiss() }
                    .show()
            }, Response.ErrorListener {
                progressBar.visibility = View.GONE; btnSubmit.text = "Submit"; btnSubmit.isEnabled = true
                dialog.dismiss()
                PremiumDialog.Builder(activity)
                    .setDialogType(true)
                    .setLottie("warning.json")
                    .setTitle("Error")
                    .setMessage("Network Error! Please check your connection.")
                    .setPositiveButton("OK", "#EF4444") { d -> d.dismiss() }
                    .setNegativeButton("Close") { d -> d.dismiss() }
                    .show()
            }) {
                override fun getParams() = hashMapOf("product_id" to productId, "user_token" to userToken, "topup_uid" to uid, "product_title" to title, "product_price" to originalAmount.replace("[^0-9.]".toRegex(), ""), "discount_price" to discountAmount.replace("[^0-9.]".toRegex(), ""))
            })
        }
    }

    private fun go(c: Class<*>) = activity.startActivity(Intent(activity, c))
    private fun goWithEx(c: Class<*>, txt: String) = activity.startActivity(Intent(activity, c).putExtra("refer_code", txt))

    private fun loadAppInfo() {
        Volley.newRequestQueue(activity).add(StringRequest(Request.Method.GET, "https://api.khelosobai20.live/ElitegoxUser/appinfo.php", { r ->
            try { val o = JSONObject(r); activity.findViewById<TextView>(R.id.textview2)?.let { if (o.has("home_notice") && o.optString("home_notice").isNotEmpty()) it.text = o.optString("home_notice") }; binding.linear23?.visibility = if (o.optString("zabbar_mored_game", "").equals("NO", true)) View.GONE else View.VISIBLE } catch (e: Exception) {}
        }, {}))
    }

    private fun initialize() {
        categoryReq = RequestNetwork(activity); apiPrefs = activity.getSharedPreferences("Api", Activity.MODE_PRIVATE); usersDataReq = RequestNetwork(activity); saveUserStatus = activity.getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE)
        activity.findViewById<SwipeRefreshLayout>(R.id.swipeRefresh)?.apply {
            setColorSchemeColors(Color.parseColor("#7B2CBF")); setProgressViewOffset(false, dpToPx(60), dpToPx(120))
            setOnRefreshListener {
                binding.recyclerview5.adapter = Recyclerview5Adapter(ArrayList()); binding.recyclerview7.adapter = Recyclerview7Adapter(ArrayList()); refreshShopTabs(); matchList.clear(); matchAdapter?.notifyDataSetChanged(); zabbarRefresh.clear(); binding.recyclerview1.adapter?.notifyDataSetChanged()
                loadUserDataAndRefresh()
                Handler(Looper.getMainLooper()).postDelayed({ isRefreshing = false }, 1500)
            }
        }
        binding.btnDeposit?.setOnClickListener { go(ZabbarAddWalletActivity::class.java) }; binding.btnWithdraw?.setOnClickListener { go(ZabbarWithdrawActivity::class.java) }; binding.btnGift?.setOnClickListener { go(ZabbarGiftActivity::class.java) }; binding.btnHistory?.setOnClickListener { go(ZabbarxHistoryActivity::class.java) }
        binding.menuEditProfile?.setOnClickListener { go(ZabbarProfileEditActivity::class.java) }; binding.menuGeniusBoard?.setOnClickListener { go(ZabbarLeaderboardActivity::class.java) }; binding.menuDeveloperProfile?.setOnClickListener { go(ZabbarDeveloperActivity::class.java) }
        binding.imgNotification?.setOnClickListener { go(ZabbarNotificationActivity::class.java) }; binding.menuReferEarn?.setOnClickListener { goWithEx(ReferAndEarnActivity::class.java, activity.findViewById<TextView>(R.id.username)?.text.toString()) }; binding.menuSupports?.setOnClickListener { goWithEx(ZabbarLiveChatActivity::class.java, binding.zabbarApplicationName?.text.toString()) }; binding.imgHelp?.setOnClickListener { goWithEx(ZabbarSupportActivity::class.java, binding.zabbarApplicationName?.text.toString()) }
        binding.linear23?.setOnClickListener { if (!arrayOf("com.khelosobaiv3.user.ZabbarWeb", "com.khelosobaiv3.user.ZabbarGame", "com.khelosobaiv3.user.ZabbargameActivity").any { n -> try { activity.startActivity(Intent(activity, Class.forName(n))); true } catch (e: Exception) { false } }) Toast.makeText(activity, "Game activity not found!", Toast.LENGTH_SHORT).show() }

        categoryRequestListener = object : RequestNetwork.RequestListener {
            override fun onResponse(p1: String, p2: String, p3: java.util.HashMap<String, Any>) {
                categorys = Gson().fromJson(p2, object : TypeToken<ArrayList<java.util.HashMap<String, Any>>>() {}.type)
                if (p2 == "[]") { binding.recyclerview2.visibility = View.GONE; binding.noFoundView.visibility = View.VISIBLE } else { binding.recyclerview2.visibility = View.VISIBLE; binding.noFoundView.visibility = View.GONE; binding.recyclerview2.adapter = Recyclerview2Adapter(categorys) }
            }
            override fun onErrorResponse(p1: String, p2: String) {}
        }
        
        usersDataRequestListener = object : RequestNetwork.RequestListener {
            override fun onResponse(p1: String, p2: String, p3: java.util.HashMap<String, Any>) {
                try {
                    shuvobro = Gson().fromJson(p2, object : TypeToken<java.util.HashMap<String, Any>>() {}.type)
                    if (shuvobro.isNotEmpty()) {
                        if (str(shuvobro, "status", "Unban").equals("ban", true)) {
                            PremiumDialog.Builder(activity).setDialogType(true).setCancelable(false).setLottie("warning.json").setTitle("Account Banned").setMessage(str(shuvobro, "ban_reason", "Banned by admin.")).setPositiveButton("Exit", "#EF4444") { d -> d.dismiss(); activity.finishAffinity() }.show()
                            return
                        }
                        
                        val rawUn = str(shuvobro, "username")
                        val rawEm = str(shuvobro, "email")
                        val verifyBadge = str(shuvobro, "verify_badge")
                        var un = rawUn
                        var uid = str(shuvobro, "uid")
                        var bal = str(shuvobro, "balance").replace(".0", "")
                        var win = str(shuvobro, "winning").replace(".0", "")

                        if (un.isBlank() || un.equals("null", true) || un.lowercase().contains("found_null")) un = "Loading..."
                        if (uid.isBlank() || uid.equals("null", true)) uid = "N/A"
                        if (bal.isBlank() || bal.equals("null", true)) bal = "0"
                        if (win.isBlank() || win.equals("null", true)) win = "0"
                        
                        activity.findViewById<TextView>(R.id.username)?.text = un
                        binding.uidBadge?.text = "UID: $uid"
                        binding.textview19?.text = str(shuvobro, "total_play").replace(".0", "").ifBlank { "0" }
                        binding.textview21?.text = str(shuvobro, "total_kill").replace(".0", "").ifBlank { "0" }
                        binding.textview23?.text = str(shuvobro, "total_refer").replace(".0", "").ifBlank { "0" }
                        
                        var lottieFile = ""
                        if (rawEm == "islammdshafiqul8127@gmail.com" || rawUn == "found_null" || verifyBadge.equals("dev", true)) {
                            lottieFile = "dev.json"
                        } else if (verifyBadge.equals("yes", true) || verifyBadge == "1") {
                            lottieFile = "verified.json"
                        }
                        
                        val badgeView = activity.findViewById<LottieAnimationView>(R.id.dynamic_badge)
                        if (lottieFile.isNotEmpty()) {
                            badgeView?.setAnimation(lottieFile)
                            badgeView?.visibility = View.VISIBLE
                            badgeView?.playAnimation()
                        } else {
                            badgeView?.visibility = View.GONE
                            badgeView?.cancelAnimation()
                        }

                        val pic = str(shuvobro, "profile_pic")
                        if (pic.isNotBlank() && !pic.equals("null", true)) {
                            updateProfileImage(pic)
                        } else {
                            binding.avatarCore?.apply { visibility = View.VISIBLE; text = if (un.isEmpty() || un == "Loading...") "?" else un.substring(0, 1).uppercase(); setTextColor(Color.WHITE) }
                            binding.rootLayout?.findViewWithTag<ImageView>("avatar_img")?.let { it.visibility = View.GONE; if (it.parent is ViewGroup && "wrapper_frame" == (it.parent as ViewGroup).tag) (it.parent as ViewGroup).visibility = View.GONE }
                        }
                        saveUserStatus.edit().apply { putString("Email", rawEm); putString("Fcm", str(shuvobro, "fcm_key")); putString("Username", un); putString("token", str(shuvobro, "token")); putString("balance", bal); putString("winning", win); apply() }
                        updateAllZabbarBalances()
                        refreshAllData()
                    }
                } catch (e: Exception) {}
            }
            override fun onErrorResponse(p1: String, p2: String) {}
        }
    }

    private fun updateStatButtonColors(cid: Int) {
        binding.button14?.setTextColor(if (cid == R.id.button14) Color.WHITE else Color.BLACK); binding.button17?.setTextColor(if (cid == R.id.button17) Color.WHITE else Color.BLACK)
        binding.button35?.setTextColor(if (cid == R.id.button35) Color.WHITE else Color.BLACK); binding.button34?.setTextColor(if (cid == R.id.button34) Color.WHITE else Color.BLACK)
        binding.button16?.setTextColor(if (cid == R.id.button16) Color.WHITE else Color.BLACK)
    }

    private fun initializeLogic() {
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("TopUp")); binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Products")); binding.tabLayout.getTabAt(0)?.select()
        createEmptyState(binding.recyclerview5.parent as? ViewGroup, "empty_state_topup", "No TopUp List Yet"); createEmptyState(binding.recyclerview7.parent as? ViewGroup, "empty_state_product", "No Products Found Yet")
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener { override fun onTabSelected(t: TabLayout.Tab) { refreshShopTabs() }; override fun onTabUnselected(t: TabLayout.Tab) {}; override fun onTabReselected(t: TabLayout.Tab) {} })
        PremiumBottomSheet(activity) {}.show()
        setupWindowAndBlur(); setupBottomNavigation()
        binding.btngrp.addOnButtonCheckedListener { _, cid, c -> if (c) { updateStatButtonColors(cid); currentStatTab = when (cid) { R.id.button17 -> "Winning"; R.id.button35 -> "Refunded"; R.id.button34 -> "Participated"; R.id.button16 -> "Others"; else -> "All" }; updateStatisticsList() } }
        binding.btngrp.check(R.id.button14); updateStatButtonColors(R.id.button14); binding.menuAccountList.setOnClickListener { go(ZabbarAddAccount::class.java) }
        binding.recyclerView4.layoutManager = LinearLayoutManager(activity); matchAdapter = Recyclerview4Adapter(matchList); binding.recyclerView4.adapter = matchAdapter
        activity.findViewById<View>(R.id.cardview1)?.let { sliderManager = SliderManager(activity, it as CardView) }
        binding.recyclerview1.apply { adapter = Recyclerview1Adapter(zabbarRefresh); layoutManager = LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false) }
        binding.recyclerview2.layoutManager = LinearLayoutManager(activity); binding.recyclerview5.layoutManager = LinearLayoutManager(activity); binding.recyclerview7.layoutManager = LinearLayoutManager(activity)
        binding.button16.visibility = View.GONE; binding.noFoundView.visibility = View.GONE
        binding.menuShareApp.setOnClickListener { activity.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "🎮 KHELO SOBAI 2.0-এ স্বাগতম!\n\n🏆 টুর্নামেন্ট খেলুন, জিতুন এবং প্রতিদিন পুরস্কার পান! 💰🔥\n\n📲 এখনই অ্যাপটি ডাউনলোড করুন:\nhttps://khelosobai20.live\n\n🚀 আজই যোগ দিন মেরামত করুন আপনার Gaming Journey!") }, "Share Khelo Sobai 2.0")) }
        
        binding.menuLogout.setOnClickListener {
            PremiumDialog.Builder(activity).setDialogType(true).setLottie("warning.json").setTitle("Logout").setMessage("Are you sure you want to logout?").setPositiveButton("Logout", "#EF4444") { d ->
                d.dismiss(); activity.getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE).edit().clear().apply(); activity.getSharedPreferences("Api", Activity.MODE_PRIVATE).edit().clear().apply()
                activity.startActivity(Intent(activity, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK }); activity.finishAffinity()
            }.setNegativeButton("Cancel") { d -> d.dismiss() }.show()
        }
        binding.menuDevProfile.setOnClickListener { go(ZabbarDeveloperActivity::class.java) }; binding.menuTerms.setOnClickListener { go(ZabbarTermsActivity::class.java) }; binding.menuSupports.setOnClickListener { go(ZabbarSupportActivity::class.java) }
    }

    private fun setupWindowAndBlur() {
        val w = activity.window; WindowCompat.setDecorFitsSystemWindows(w, false); w.navigationBarColor = Color.TRANSPARENT; val root = w.decorView as ViewGroup; val bg = root.background; val b2 = activity.findViewById<BlurView>(R.id.blurViewBottom)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { binding.blurView?.setupWith(root, RenderEffectBlur())?.setFrameClearDrawable(bg)?.setBlurRadius(5f)?.setBlurAutoUpdate(true); b2?.setupWith(root, RenderEffectBlur())?.setFrameClearDrawable(ColorDrawable(Color.TRANSPARENT))?.setBlurRadius(15f)?.setBlurAutoUpdate(true) }
        else { binding.blurView?.setupWith(root, RenderScriptBlur(activity))?.setFrameClearDrawable(bg)?.setBlurRadius(5f)?.setBlurAutoUpdate(true); b2?.setupWith(root, RenderScriptBlur(activity))?.setFrameClearDrawable(ColorDrawable(Color.TRANSPARENT))?.setBlurRadius(15f)?.setBlurAutoUpdate(true) }
    }

    private fun setupBottomNavigation() {
        val bn = activity.findViewById<BottomNavigationView>(R.id.bottomnavigation1) ?: return
        val csl = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf(-android.R.attr.state_checked)), intArrayOf(ContextCompat.getColor(activity, R.color.md_theme_onPrimaryFixedVariant), ContextCompat.getColor(activity, android.R.color.black)))
        bn.apply { itemIconTintList = csl; itemTextColor = csl; itemRippleColor = ColorStateList.valueOf(Color.TRANSPARENT) }
        if (bn.childCount > 0 && bn.getChildAt(0) is ViewGroup) { val vg = bn.getChildAt(0) as ViewGroup; for (i in 0 until vg.childCount) vg.getChildAt(i).findViewById<View>(com.google.android.material.R.id.navigation_bar_item_active_indicator_view)?.visibility = View.GONE }
        binding.bottomnavigation1.setOnItemSelectedListener { itm ->
            binding.bottomnavigation1.findViewById<View>(itm.itemId)?.findViewById<View>(com.google.android.material.R.id.navigation_bar_item_icon_view)?.apply { animate().scaleX(0.8f).scaleY(0.8f).setDuration(100).withEndAction { animate().scaleX(1f).scaleY(1f).setDuration(100).start() }.start() }
            binding.item1.visibility = View.GONE; binding.item2.visibility = View.GONE; binding.item3.visibility = View.GONE; binding.item4.visibility = View.GONE; binding.item5.visibility = View.GONE
            when (itm.itemId) { R.id.nav_home -> binding.item1.visibility = View.VISIBLE; R.id.nav_mymatch -> { binding.item2.visibility = View.VISIBLE; binding.zabbarLinear21.visibility = View.VISIBLE }; R.id.nav_shop -> binding.item3.visibility = View.VISIBLE; R.id.nav_profile -> binding.item4.visibility = View.VISIBLE }
            true
        }
        binding.bottomnavigation1.selectedItemId = R.id.nav_home
    }

    private fun createEmptyState(p: ViewGroup?, t: String, txt: String) {
        if (p == null || p.findViewWithTag<View>(t) != null) return
        val l = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; visibility = View.GONE; tag = t }
        l.addView(ImageView(activity).apply { setImageResource(R.drawable.zabbar_nodata_found) }, LinearLayout.LayoutParams(dpToPx(100), dpToPx(100)))
        l.addView(TextView(activity).apply { text = txt; gravity = Gravity.CENTER; textSize = 16f; setTextColor(Color.parseColor("#6C5F8B")) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.CENTER; topMargin = dpToPx(16) })
        p.addView(l, if (p is FrameLayout) FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(300), Gravity.CENTER) else if (p is LinearLayout) LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(300)).apply { gravity = Gravity.CENTER } else ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(300)))
    }

    private fun toggleEmptyState(t: String, s: Boolean) { activity.findViewById<View>(android.R.id.content).findViewWithTag<View>(t)?.visibility = if (s) View.VISIBLE else View.GONE }

    private fun refreshShopTabs() {
        val isTopUp = binding.tabLayout.selectedTabPosition == 0; val topCount = binding.recyclerview5.adapter?.itemCount ?: 0; val prodCount = binding.recyclerview7.adapter?.itemCount ?: 0
        if (isTopUp) { binding.recyclerview5.visibility = if (topCount > 0) View.VISIBLE else View.GONE; toggleEmptyState("empty_state_topup", topCount == 0); binding.recyclerview7.visibility = View.GONE; toggleEmptyState("empty_state_product", false) }
        else { binding.recyclerview7.visibility = if (prodCount > 0) View.VISIBLE else View.GONE; toggleEmptyState("empty_state_product", prodCount == 0); binding.recyclerview5.visibility = View.GONE; toggleEmptyState("empty_state_topup", false) }
    }

    private fun loadTopUpData() {
        Volley.newRequestQueue(activity).add(object : StringRequest(Request.Method.POST, "https://api.khelosobai20.live/ElitegoxUser/topuplist.php", Response.Listener { r ->
            try {
                val a = JSONArray(r); val l = ArrayList<HashMap<String, Any>>()
                for (i in 0 until a.length() step 2) {
                    val m = HashMap<String, Any>(); val j1 = a.getJSONObject(i)
                    m["id1"] = j1.optString("id", "0"); m["title1"] = j1.optString("title", ""); m["amount1"] = j1.optString("discount_price", ""); m["originalAmount1"] = j1.optString("real_price", ""); m["photo1"] = j1.optString("image_link", "")
                    if (i + 1 < a.length()) { val j2 = a.getJSONObject(i + 1); m["id2"] = j2.optString("id", "0"); m["title2"] = j2.optString("title", ""); m["amount2"] = j2.optString("discount_price", ""); m["originalAmount2"] = j2.optString("real_price", ""); m["photo2"] = j2.optString("image_link", "") } else { m["id2"] = ""; m["title2"] = ""; m["amount2"] = ""; m["originalAmount2"] = ""; m["photo2"] = "" }
                    l.add(m)
                }
                binding.recyclerview5.adapter = Recyclerview5Adapter(l); refreshShopTabs()
            } catch (e: Exception) { binding.recyclerview5.adapter = Recyclerview5Adapter(ArrayList()); refreshShopTabs() }
        }, Response.ErrorListener { binding.recyclerview5.adapter = Recyclerview5Adapter(ArrayList()); refreshShopTabs() }) { override fun getParams() = java.util.HashMap<String, String>() })
    }

    private fun loadProductData() {
        Volley.newRequestQueue(activity).add(StringRequest(Request.Method.GET, "https://api.khelosobai20.live/ElitegoxUser/get_products.php", { r ->
            try {
                val a = JSONObject(r).getJSONArray("products"); val ls = ArrayList<HashMap<String, Any>>()
                for (i in 0 until a.length() step 2) {
                    val m = HashMap<String, Any>(); val j1 = a.getJSONObject(i)
                    m["id1"] = j1.optString("id", "0"); m["title1"] = j1.optString("title", ""); m["amount1"] = j1.optString("discount", ""); m["originalAmount1"] = j1.optString("amount", ""); m["photo1"] = j1.optString("image_link", ""); m["desc1"] = j1.optString("description", ""); m["status1"] = j1.optString("stock_status", ""); m["sold1"] = j1.optString("sold", "0"); m["left1"] = j1.optString("left", "0")
                    if (i + 1 < a.length()) { val j2 = a.getJSONObject(i + 1); m["id2"] = j2.optString("id", "0"); m["title2"] = j2.optString("title", ""); m["amount2"] = j2.optString("discount", ""); m["originalAmount2"] = j2.optString("amount", ""); m["photo2"] = j2.optString("image_link", ""); m["desc2"] = j2.optString("description", ""); m["status2"] = j2.optString("stock_status", ""); m["sold2"] = j2.optString("sold", "0"); m["left2"] = j2.optString("left", "0") } else { m["id2"] = ""; m["title2"] = ""; m["amount2"] = ""; m["originalAmount2"] = ""; m["photo2"] = ""; m["desc2"] = ""; m["status2"] = ""; m["sold2"] = ""; m["left2"] = "" }
                    ls.add(m)
                }
                binding.recyclerview7.adapter = Recyclerview7Adapter(ls); refreshShopTabs()
            } catch (e: Exception) { binding.recyclerview7.adapter = Recyclerview7Adapter(ArrayList()); refreshShopTabs() }
        }, { binding.recyclerview7.adapter = Recyclerview7Adapter(ArrayList()); refreshShopTabs() }))
    }

    private fun loadStatistics() {
        val em = saveUserStatus.getString("Email", "")
        if (em.isNullOrEmpty()) return
        Volley.newRequestQueue(activity).add(object : StringRequest(Request.Method.POST, "https://api.khelosobai20.live/ElitegoxUser/get_statistics.php", Response.Listener { r ->
            try {
                val obj = JSONObject(r)
                if (obj.optBoolean("success")) {
                    statAll.clear(); statWinning.clear(); statRefunded.clear(); statParticipated.clear()
                    obj.optJSONArray("winnings")?.let { for (i in 0 until it.length()) statWinning.add(jsonToMap(it.getJSONObject(i))) }
                    obj.optJSONArray("refund")?.let { for (i in 0 until it.length()) statRefunded.add(jsonToMap(it.getJSONObject(i))) }
                    obj.optJSONArray("participate")?.let { for (i in 0 until it.length()) statParticipated.add(jsonToMap(it.getJSONObject(i))) }
                    statAll.addAll(statWinning); statAll.addAll(statRefunded); statAll.addAll(statParticipated); updateStatisticsList()
                }
            } catch (e: Exception) {}
        }, Response.ErrorListener {}) { override fun getParams() = hashMapOf("email" to em, "type" to "all") })
    }

    private fun jsonToMap(obj: JSONObject): java.util.HashMap<String, Any> { val map = java.util.HashMap<String, Any>(); val keys = obj.keys(); while (keys.hasNext()) { val k = keys.next(); map[k] = obj.optString(k) }; return map }

    private fun updateStatisticsList() {
        matchList.clear()
        when (currentStatTab) { "Winning" -> matchList.addAll(statWinning); "Refunded" -> matchList.addAll(statRefunded); "Participated" -> matchList.addAll(statParticipated); else -> matchList.addAll(statAll) }
        matchAdapter?.notifyDataSetChanged(); val p = binding.linear3; var ev = p.findViewWithTag<View>("stat_empty")
        if (matchList.isEmpty()) {
            if (ev == null) {
                ev = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; tag = "stat_empty" }.also { l ->
                    l.addView(ImageView(activity).apply { setImageResource(R.drawable.zabbar_nodata_found) }, LinearLayout.LayoutParams(dpToPx(100), dpToPx(100)))
                    l.addView(TextView(activity).apply { gravity = Gravity.CENTER; textSize = 16f; setTextColor(Color.parseColor("#6C5F8B")); tag = "stat_empty_text" }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.CENTER; topMargin = dpToPx(16) })
                    p.addView(l, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(300)).apply { gravity = Gravity.CENTER })
                }
            }
            ev.findViewWithTag<TextView>("stat_empty_text")?.text = "No Match Found.. ($currentStatTab)"; ev.visibility = View.VISIBLE; binding.recyclerView4.visibility = View.GONE; p.gravity = Gravity.CENTER
        } else { ev?.visibility = View.GONE; binding.recyclerView4.visibility = View.VISIBLE }
    }

    private fun loadRecentlyJoined() {
        val base = apiPrefs.getString("Api", ""); val em = saveUserStatus.getString("Email", "")
        if (base.isNullOrEmpty() || em.isNullOrEmpty()) return
        RequestNetwork(activity).apply {
            setParams(hashMapOf("email" to em), RequestNetworkController.REQUEST_PARAM)
            startRequestNetwork(RequestNetworkController.POST, base + (if (base.endsWith("/")) "" else "/") + "recently_joined.php", "tag", object : RequestNetwork.RequestListener {
                override fun onResponse(t: String, r: String, hdrs: java.util.HashMap<String, Any>) {
                    try {
                        val o = JSONObject(r); zabbarRefresh.clear()
                        if (o.optString("status") == "success") o.optJSONArray("matches")?.let { a ->
                            for (i in 0 until a.length()) { val m = a.getJSONObject(i); zabbarRefresh.add(hashMapOf("title" to m.optString("match_title", ""), "timer" to m.optString("timer", ""), "total_prize" to m.optString("total_prize", "0"), "per_kill" to m.optString("per_kill", "0"), "entry_fee" to m.optString("entry_fee", "0"), "type" to m.optString("entry_type", ""), "map" to m.optString("play_map", ""), "version" to m.optString("version", ""), "total_player" to m.optString("total_player", "0"), "joined_player" to m.optString("total_joiner", "0"), "image_link" to m.optString("image_link", ""))) }
                        }
                        binding.zabbarLinear7.visibility = if (zabbarRefresh.isEmpty()) View.GONE else View.VISIBLE; binding.recyclerview1.adapter?.notifyDataSetChanged()
                    } catch (e: Exception) { binding.zabbarLinear7.visibility = View.GONE }
                }
                override fun onErrorResponse(t: String, msg: String) { binding.zabbarLinear7.visibility = View.GONE }
            })
        }
    }

    inner class Recyclerview4Adapter(private val _data: ArrayList<HashMap<String, Any>>) : RecyclerView.Adapter<Recyclerview4Adapter.ViewHolder>() {
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.zabbar_access_match, p, false))
        override fun onBindViewHolder(h: ViewHolder, pos: Int) {
            val m = _data[pos]; val notice = str(m, "winaddmsg", ""); val fee = str(m, "paid", "0").ifBlank { "0" }; val win = str(m, "winnings", "0").ifBlank { "0" }; val refund = str(m, "refund_amount", "0").ifBlank { "0" }
            val rAmt = try { refund.toDouble() } catch (e: Exception) { 0.0 }; val hasNotice = notice.isNotBlank() && !notice.equals("null", true)
            h.v.findViewById<TextView>(R.id.tvMatchTitle)?.text = str(m, "match_title"); h.v.findViewById<TextView>(R.id.tvStatus)?.text = str(m, "type", "My Match"); h.v.findViewById<TextView>(R.id.tvTime)?.text = str(m, "played_on")
            h.v.findViewById<TextView>(R.id.tvFee)?.text = "৳ $fee"; h.v.findViewById<TextView>(R.id.tvWinAmount)?.text = "৳ $win"; h.v.findViewById<TextView>(R.id.tvRefundAmount)?.text = "৳ $refund"
            h.v.findViewById<View>(R.id.linear232)?.visibility = if (rAmt > 0) { h.v.findViewById<TextView>(R.id.tvRefundText)?.text = str(m, "refund_reason", ""); View.VISIBLE } else View.GONE
            h.v.findViewById<View>(R.id.linear234)?.visibility = if (hasNotice) { h.v.findViewById<TextView>(R.id.tvNoticeText)?.text = notice; View.VISIBLE } else View.GONE
            h.v.findViewById<View>(R.id.view233)?.visibility = if (rAmt > 0 && hasNotice) View.VISIBLE else View.GONE; h.v.findViewById<View>(R.id.linear231)?.visibility = if (rAmt > 0 || hasNotice) View.VISIBLE else View.GONE
        }
        override fun getItemCount() = _data.size
        inner class ViewHolder(val v: View) : RecyclerView.ViewHolder(v)
    }

    inner class Recyclerview5Adapter(private val _data: ArrayList<HashMap<String, Any>>) : RecyclerView.Adapter<Recyclerview5Adapter.ViewHolder>() {
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.zabbarx_topup, p, false))
        override fun onBindViewHolder(h: ViewHolder, pos: Int) {
            val b = h.b; val m = _data[pos]
            extractId(m, "id1", "product_id1").let { id1 ->
                if (id1.isNotEmpty()) { b.cardview1.visibility = View.VISIBLE; b.cardview1.isEnabled = true; b.tvTitle1.text = str(m, "title1"); b.tvAmount1.text = "৳" + str(m, "amount1"); b.tvOriginalAmount1.text = "৳" + str(m, "originalAmount1"); b.tvOriginalAmount1.paintFlags = b.tvOriginalAmount1.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG; loadCachedImage(str(m, "photo1"), b.zabbarMt1, false); b.cardview1.setOnClickListener { processTopup(id1, str(m, "title1"), str(m, "originalAmount1", "0"), str(m, "amount1", "0")) } } else { b.cardview1.visibility = View.INVISIBLE; b.cardview1.isEnabled = false }
            }
            extractId(m, "id2", "product_id2").let { id2 ->
                if (id2.isNotEmpty() && !m["photo2"].toString().isBlank() && !m["photo2"].toString().equals("null", true)) { b.cardview2.visibility = View.VISIBLE; b.cardview2.isEnabled = true; b.tvTitle2.text = str(m, "title2"); b.tvAmount2.text = "৳" + str(m, "amount2"); b.tvOriginalAmount2.text = "৳" + str(m, "originalAmount2"); b.tvOriginalAmount2.paintFlags = b.tvOriginalAmount2.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG; loadCachedImage(str(m, "photo2"), b.zabbarMt2, false); b.cardview2.setOnClickListener { processTopup(id2, str(m, "title2"), str(m, "originalAmount2", "0"), str(m, "amount2", "0")) } } else { b.cardview2.visibility = View.INVISIBLE; b.cardview2.isEnabled = false }
            }
        }
        override fun getItemCount() = _data.size
        inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) { val b = ZabbarxTopupBinding.bind(v) }
    }

    inner class Recyclerview7Adapter(private val _data: ArrayList<HashMap<String, Any>>) : RecyclerView.Adapter<Recyclerview7Adapter.ViewHolder>() {
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.zabbarx_topup, p, false))
        override fun onBindViewHolder(h: ViewHolder, pos: Int) {
            val b = h.b; val m = _data[pos]
            extractId(m, "id1").let { id1 ->
                if (id1.isNotEmpty()) { b.cardview1.visibility = View.VISIBLE; b.cardview1.isEnabled = true; b.tvTitle1.text = str(m, "title1"); b.tvAmount1.text = "৳" + str(m, "amount1"); b.tvOriginalAmount1.text = "৳" + str(m, "originalAmount1"); b.tvOriginalAmount1.paintFlags = b.tvOriginalAmount1.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG; loadCachedImage(str(m, "photo1"), b.zabbarMt1, false); b.cardview1.setOnClickListener { h.itemView.context.startActivity(Intent(h.itemView.context, ShopConfirmPageActivity::class.java).apply { putExtra("id", id1); putExtra("title", str(m, "title1")); putExtra("image_link", str(m, "photo1")); putExtra("discount_price", str(m, "amount1")); putExtra("real_price", str(m, "originalAmount1")); putExtra("description", str(m, "desc1")); putExtra("stock_status", str(m, "status1")); putExtra("sold", str(m, "sold1")); putExtra("left", str(m, "left1")) }) } } else { b.cardview1.visibility = View.INVISIBLE; b.cardview1.isEnabled = false }
            }
            extractId(m, "id2").let { id2 ->
                if (id2.isNotEmpty() && !m["photo2"].toString().isBlank() && !m["photo2"].toString().equals("null", true)) { b.cardview2.visibility = View.VISIBLE; b.cardview2.isEnabled = true; b.tvTitle2.text = str(m, "title2"); b.tvAmount2.text = "৳" + str(m, "amount2"); b.tvOriginalAmount2.text = "৳" + str(m, "originalAmount2"); b.tvOriginalAmount2.paintFlags = b.tvOriginalAmount2.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG; loadCachedImage(str(m, "photo2"), b.zabbarMt2, false); b.cardview2.setOnClickListener { h.itemView.context.startActivity(Intent(h.itemView.context, ShopConfirmPageActivity::class.java).apply { putExtra("id", id2); putExtra("title", str(m, "title2")); putExtra("image_link", str(m, "photo2")); putExtra("discount_price", str(m, "amount2")); putExtra("real_price", str(m, "originalAmount2")); putExtra("description", str(m, "desc2")); putExtra("stock_status", str(m, "status2")); putExtra("sold", str(m, "sold2")); putExtra("left", str(m, "left2")) }) } } else { b.cardview2.visibility = View.INVISIBLE; b.cardview2.isEnabled = false }
            }
        }
        override fun getItemCount() = _data.size
        inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) { val b = ZabbarxTopupBinding.bind(v) }
    }

    inner class Recyclerview1Adapter(private val _data: ArrayList<HashMap<String, Any>>) : RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder>() {
        private val handler = Handler(Looper.getMainLooper())
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = ViewHolder(activity.layoutInflater.inflate(R.layout.zabbar_recently_matches, p, false))
        override fun onBindViewHolder(h: ViewHolder, pos: Int) {
            val b = h.b; val m = _data[pos]
            setBg(b.zabbarMapLinear, 0, ContextCompat.getColor(b.root.context, R.color.md_theme_onPrimaryFixedVariant), 0, null, 100f); setBg(b.zabbarOpruter, 0, "#99000000", 1, "#FFBDBDBD", 100f)
            b.linear6.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xD9000000.toInt(), 0x66000000.toInt(), 0x00000000.toInt()))
            b.title.text = str(m, "title"); b.map.text = str(m, "map"); b.zabbarOprouterMobile.text = str(m, "version"); b.parize.text = "৳" + str(m, "total_prize", "0"); b.parKill.text = "৳" + str(m, "per_kill", "0"); b.fee.text = "৳" + str(m, "entry_fee", "0"); b.type.text = str(m, "type"); loadCachedImage(str(m, "image_link"), b.imageview1, false)
            val j = try { str(m, "joined_player", "0").toInt() } catch (e: Exception) { 0 }; val t = try { str(m, "total_player", "0").toInt() } catch (e: Exception) { 0 }
            b.zabbarPs.max = t; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) b.zabbarPs.setProgress(j, true) else b.zabbarPs.progress = j; b.textview7.text = "$j/$t"
            if (h.r != null) handler.removeCallbacks(h.r!!)
            val f = try { SimpleDateFormat("dd/MM/yyyy 'At' hh:mm a", Locale.ENGLISH).parse(str(m, "timer").replace(Regex("(?i)Time:?\\s*"), "").trim())?.time ?: 0L } catch (e: Exception) { 0L }
            h.r = object : Runnable {
                override fun run() {
                    val d = f - System.currentTimeMillis()
                    if (d > 0) { setBg(b.zabbarTimeLinear, 0, "#99000000", 1, "#FFBDBDBD", 100f); val dd = d / 86400000; val hh = (d / 3600000) % 24; val mm = (d / 60000) % 60; val ss = (d / 1000) % 60; h.stv.setTime(if (dd > 0) String.format(Locale.ENGLISH, "%02dd %02dh %02dm %02ds", dd, hh, mm, ss) else String.format(Locale.ENGLISH, "%02dh %02dm %02ds", hh, mm, ss)); handler.postDelayed(this, 1000) }
                    else { h.stv.setTime("Started"); setBg(b.zabbarTimeLinear, 0, "#4CAF50", 1, "#4CAF50", 100f) }
                }
            }; handler.post(h.r!!)
        }
        override fun getItemCount() = _data.size
        inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) { var stv: SlideTimerView; var r: java.lang.Runnable? = null; var b = ZabbarRecentlyMatchesBinding.bind(v); init { val pv = b.zabbarTime.parent as ViewGroup; stv = SlideTimerView(pv.context, b.zabbarTime); pv.addView(stv, pv.indexOfChild(b.zabbarTime) + 1); b.zabbarTime.visibility = View.GONE } }
    }

    inner class Recyclerview2Adapter(private val _data: ArrayList<HashMap<String, Any>>) : RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder>() {
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.zabbar_daily_match, p, false).apply { layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT) })
        override fun onBindViewHolder(h: ViewHolder, pos: Int) {
            val b = h.b; val p1 = (_data.size - 1) - (pos * 2); val p2 = p1 - 1; setBg(b.zabbarMatchBg, 0, Color.parseColor("#E5EFFF"), 1, "#FFE0E0E0", 15f); setBg(b.zabbarMatchBg2, 0, Color.parseColor("#E5EFFF"), 1, "#FFE0E0E0", 15f)
            if (p1 in 0 until _data.size) { b.linear2.visibility = View.VISIBLE; val t1 = str(_data[p1], "title"); loadCachedImage(str(_data[p1], "image_link"), b.imageview1, false); b.textview1.text = t1; b.textview4.text = "Match Found (${str(_data[p1], "match_found", "0").replace(".0", "")})"; b.linear2.setOnClickListener { b.root.context.startActivity(Intent(b.root.context, ZabbarMatchActivity::class.java).putExtra("Type", t1)) } } else b.linear2.visibility = View.GONE
            if (p2 in 0 until _data.size) { b.linear3.visibility = View.VISIBLE; val t2 = str(_data[p2], "title"); loadCachedImage(str(_data[p2], "image_link"), b.imageview2, false); b.textview2.text = t2; b.textview5.text = "Match Found (${str(_data[p2], "match_found", "0").replace(".0", "")})"; b.linear3.setOnClickListener { b.root.context.startActivity(Intent(b.root.context, ZabbarMatchActivity::class.java).putExtra("Type", t2)) } } else b.linear3.visibility = View.GONE
        }
        override fun getItemCount() = Math.ceil(_data.size / 2.0).toInt()
        inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) { val b = ZabbarDailyMatchBinding.bind(v) }
    }

    private fun updateAllZabbarBalances() {
        val sp = activity.getSharedPreferences("Save_User_Status", Context.MODE_PRIVATE)
        val bal = sp.getString("balance", "0") ?: "0"
        val win = sp.getString("winning", "0") ?: "0"

        // Header pill (next to the app name/bell/wallet icon) shows Main Balance +
        // Winning combined, not just Main Balance alone.
        val balNum = bal.toDoubleOrNull() ?: 0.0
        val winNum = win.toDoubleOrNull() ?: 0.0
        val totalNum = balNum + winNum
        val totalStr = if (totalNum % 1.0 == 0.0) totalNum.toInt().toString() else totalNum.toString()

        activity.findViewById<TextView>(R.id.top_balance_text)?.text = "৳$totalStr"
        activity.findViewById<TextView>(R.id.textview16)?.text = "৳$bal"
        activity.findViewById<TextView>(R.id.textview18)?.text = "৳$win"
        
        activity.findViewById<View>(R.id.zabbar_home_wallet)?.let { w -> 
            w.findViewById<TextView>(R.id.textview27)?.text = "৳$bal"
            w.findViewById<TextView>(R.id.textview28)?.text = "Winning: ৳$win"
            w.findViewById<View>(R.id.linear35)?.apply { isClickable = true; isFocusable = true; setOnClickListener { go(ZabbarAddWalletActivity::class.java) } }
            w.findViewById<View>(R.id.linear36)?.apply { isClickable = true; isFocusable = true; setOnClickListener { go(ZabbarWithdrawActivity::class.java) } }
        }
        activity.findViewById<View>(R.id.linear35)?.apply { isClickable = true; isFocusable = true; setOnClickListener { go(ZabbarAddWalletActivity::class.java) } }
        activity.findViewById<View>(R.id.linear36)?.apply { isClickable = true; isFocusable = true; setOnClickListener { go(ZabbarWithdrawActivity::class.java) } }
        activity.findViewById<View>(R.id.top_balance_box)?.setOnClickListener { go(ZabbarAddWalletActivity::class.java) }
    }
    
    private fun loadUserDataAndRefresh() {
        categoryReq.startRequestNetwork(RequestNetworkController.GET, apiPrefs.getString("Api", "") + "get_category.php", "", categoryRequestListener)
        loadTopUpData()
        loadProductData()
        loadAppInfo()
        sliderManager?.start()

        shuvobro.clear()
        shuvobro["type"] = "1"
        shuvobro["token"] = saveUserStatus.getString("Token", "") ?: ""
        usersDataReq.setParams(shuvobro, RequestNetworkController.REQUEST_PARAM)
        usersDataReq.startRequestNetwork(RequestNetworkController.POST, apiPrefs.getString("Api", "") + "XMapp_Us.js.php", "", usersDataRequestListener)
    }

    private fun refreshAllData() {
        categoryReq.startRequestNetwork(RequestNetworkController.GET, apiPrefs.getString("Api", "") + "get_category.php", "", categoryRequestListener)
        loadRecentlyJoined()
        loadStatistics()
        loadTopUpData()
        loadProductData()
        loadAppInfo()
        sliderManager?.start()
    }
}