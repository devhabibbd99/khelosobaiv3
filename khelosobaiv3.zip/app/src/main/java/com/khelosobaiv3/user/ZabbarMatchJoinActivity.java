package com.khelosobaiv3.user;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.FirebaseApp;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * New step-wizard "Scrim Join" screen.
 * Step 1 -> pick entry type (if match allows it) + pick a free slot
 * Step 2 -> enter player in-game names
 * Step 3 -> review everything
 * Step 4 -> read rules + confirm & join
 *
 * All wallet / account-selection / join-request / dialog logic below is carried
 * over as-is from the old ZabbarMatchJoinActivity so nothing that used to work
 * (balance check, saved game accounts, join API call, success/fail dialogs,
 * countdown timer) is lost - only the layout & navigation flow around it is new.
 */
public class ZabbarMatchJoinActivity extends AppCompatActivity {

    private ZabbarMatchJoinBinding binding;

    // ----- match / entry state (same meaning as old activity) -----
    private String zabbar = "solo";
    private HashMap<String, Object> Map1 = new HashMap<>();

    private RequestNetwork Join_Req;
    private RequestNetwork.RequestListener _Join_Req_request_listener;
    private SharedPreferences GET_API;
    private SharedPreferences Save_User_Status;

    private int baseEntryFee = 0;
    private String entryType = "";
    private String matchId = "";
    private String matchTitle = "";
    private String matchTimeStr = "";
    private String entryFeeStr = "0";
    private String perKillStr = "0";
    private String totalPrizeStr = "0";
    private String rulesExtra = "";
    private String matchTypeCategory = "";
    private int totalJoiner = 0;
    private int totalPlayer = 0;
    private int spotsLeft = 0;
    private boolean isLocked = false;

    private BottomSheetDialog loadingDialog;
    private boolean joinInProgress = false;
    private CountDownTimer countDownTimer;

    private final String BASE_URL = "https://api.khelosobai20.live/ElitegoxUser/";
    private String USER_TOKEN = "";
    private String USERNAME = "";
    private eightbitlab.com.blurview.BlurView blurViewOverlay;

    // ----- new wizard state -----
    private int currentStep = 1;
    private final List<Integer> selectedSlots = new ArrayList<>();
    // Real slot occupancy from get_match_slots.php - null until first fetched successfully.
    // While null, buildSlotGrid() falls back to the old TotalJoiner-count estimate.
    private java.util.Set<Integer> takenSlotsFromServer = null;
    private int totalSlots = 0;
    private int occupiedSlotsCount = 0;
    private final List<SlotHolder> slotHolders = new ArrayList<>();
    private final List<EditText> playerNameFields = new ArrayList<>();

    // ----- live slot polling (fixes "shows free but Already Taken on click") -----
    // Old behaviour only refetched taken slots on onCreate/onResume/failed-join, so a
    // user sitting on step 1 for a while kept looking at a stale grid while other
    // users took slots in the background. This loop keeps the grid fresh while the
    // user is actually on step 1, and is stopped everywhere else to save battery/data.
    private final Handler slotPollHandler = new Handler(Looper.getMainLooper());
    private static final long SLOT_POLL_INTERVAL_MS = 3000; // 3s refresh while picking a slot
    private boolean slotPollingActive = false;
    private final Runnable slotPollRunnable = new Runnable() {
        @Override
        public void run() {
            if (!slotPollingActive) return;
            fetchTakenSlots();
            slotPollHandler.postDelayed(this, SLOT_POLL_INTERVAL_MS);
        }
    };

    private void startSlotPolling() {
        if (slotPollingActive) return;
        slotPollingActive = true;
        slotPollHandler.postDelayed(slotPollRunnable, SLOT_POLL_INTERVAL_MS);
    }

    private void stopSlotPolling() {
        slotPollingActive = false;
        slotPollHandler.removeCallbacks(slotPollRunnable);
    }

    private static class SlotHolder {
        int number;
        boolean taken;
        MaterialCardView card;
        TextView label;
    }

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = ZabbarMatchJoinBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        FirebaseApp.initializeApp(this);
        initializeLogic();
        initialize();
        showStep(1);
        fetchLiveRules();
        fetchTakenSlots();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupZabbarWalletLogic();
        fetchTakenSlots();
        if (currentStep == 1) startSlotPolling();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Stop background polling when the screen isn't visible - no point burning
        // battery/data refreshing a grid the user isn't looking at.
        stopSlotPolling();
    }

    @Override
    public void onBackPressed() {
        if (currentStep > 1) {
            currentStep--;
            showStep(currentStep);
        } else {
            super.onBackPressed();
        }
    }

    // ============================================================
    //  SETUP
    // ============================================================

    private void initializeLogic() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.parseColor("#FFFFFF"));
            View decorView = window.getDecorView();
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            decorView.setSystemUiVisibility(flags);
        }
    }

    private void initialize() {
        Join_Req = new RequestNetwork(this);
        GET_API = getSharedPreferences("Api", Activity.MODE_PRIVATE);
        Save_User_Status = getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE);

        USER_TOKEN = Save_User_Status.getString("Token", "");
        USERNAME = Save_User_Status.getString("Username", "");

        matchId = safe(getIntent().getStringExtra("Id"));
        matchTitle = safe(getIntent().getStringExtra("Title"));
        entryFeeStr = safe(getIntent().getStringExtra("EntryFee"));
        perKillStr = safe(getIntent().getStringExtra("PerKill"));
        totalPrizeStr = safe(getIntent().getStringExtra("TotalPrize"));
        String totalJoinerStr = safe(getIntent().getStringExtra("TotalJoiner"));
        String totalPlayerStr = safe(getIntent().getStringExtra("TotalPlayer"));
        entryType = safe(getIntent().getStringExtra("EntryType"));
        String lockedStr = safe(getIntent().getStringExtra("locked"));
        isLocked = "true".equalsIgnoreCase(lockedStr);
        rulesExtra = safe(getIntent().getStringExtra("Rules"));

        // Same "match_type" extra + default that ShvuoRulesActivity uses for match_rule_get.php,
        // so the real, live rules show here instead of the generic hardcoded fallback text.
        matchTypeCategory = safe(getIntent().getStringExtra("match_type"));
        if (matchTypeCategory.isEmpty()) matchTypeCategory = "BR Match";

        String timeData = safe(getIntent().getStringExtra("match_time"));
        if (timeData.isEmpty()) timeData = safe(getIntent().getStringExtra("Time"));
        if (timeData.isEmpty()) timeData = safe(getIntent().getStringExtra("timer"));
        matchTimeStr = timeData;

        if (matchTitle.isEmpty()) matchTitle = "Match Details";
        if (entryFeeStr.isEmpty()) entryFeeStr = "0";
        if (perKillStr.isEmpty()) perKillStr = "0";
        if (totalPrizeStr.isEmpty()) totalPrizeStr = "0";
        if (entryType.isEmpty()) entryType = "Solo";

        try {
            if (!totalJoinerStr.isEmpty()) totalJoiner = Integer.parseInt(totalJoinerStr.trim());
            if (!totalPlayerStr.isEmpty()) totalPlayer = Integer.parseInt(totalPlayerStr.trim());
            if (!entryFeeStr.isEmpty()) baseEntryFee = Integer.parseInt(entryFeeStr.trim());
        } catch (Exception e) {
            baseEntryFee = 0;
        }

        spotsLeft = Math.max(0, totalPlayer - totalJoiner);

        binding.matchTitleText.setText(matchTitle);
        binding.feeBadgeText.setText("Fee: ৳" + entryFeeStr);
        binding.killBadgeText.setText("Per Kill: ৳" + perKillStr);
        binding.prizeBadgeText.setText("Prize: ৳" + totalPrizeStr);

        startCountdown();

        // entry type selector (solo/duo/squad) — only shown if match isn't locked to one type
        setupEntryTypeSelector();

        // back button (top bar)
        binding.backBtn.setOnClickListener(v -> onBackPressed());

        // wizard "Next / Confirm & Join" button
        binding.nextBtn.setOnClickListener(v -> onNextClicked());

        _Join_Req_request_listener = new RequestNetwork.RequestListener() {
            @Override
            public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
                hideLoadingDialog();
                joinInProgress = false;
                refreshNextButtonState();

                String response = _param2 != null ? _param2 : "";
                if (response.toLowerCase().contains("join successfully")) {
                    new PremiumDialog.Builder(ZabbarMatchJoinActivity.this)
                            .setDialogType(true)
                            .setCancelable(false)
                            .setBlurBackground(true)
                            .setLottie("success.json")
                            .setTitle("Match Joined!")
                            .setMessage("You have successfully joined the match. Best of luck!")
                            .setPositiveButton("Okay", "#10B981", dialog -> {
                                dialog.dismiss();
                                subscribeAfterJoin();
                            })
                            .setNegativeButton("Close", dialog -> {
                                dialog.dismiss();
                                subscribeAfterJoin();
                            })
                            .show();
                } else {
                    // Real-time fix: our slot grid might be stale (many users joining
                    // at once) - refetch exact taken slots right away instead of
                    // leaving the user stuck looking at outdated "available" slots.
                    fetchTakenSlots();

                    String msg = response.isEmpty() ? "Failed to join." : response;
                    if (response.toLowerCase().contains("slot") && response.toLowerCase().contains("taken")) {
                        // Server didn't tell us exactly which slot conflicted, so clear the
                        // whole selection - this also stops the fetchTakenSlots() call above
                        // from firing a second/duplicate dialog once its async result lands.
                        selectedSlots.clear();
                        currentStep = 1;
                        showStep(1);
                        showSlotConflictDialog();
                        return;
                    }
                    showErrorDialog(msg);
                }
            }

            @Override
            public void onErrorResponse(String _param1, String _param2) {
                hideLoadingDialog();
                joinInProgress = false;
                refreshNextButtonState();
                showErrorDialog("Something went wrong. Please try again.");
            }
        };

        if (spotsLeft <= 0) {
            binding.nextBtn.setEnabled(false);
        }
    }

    // ============================================================
    //  WALLET (kept from old activity — safe no-ops if a view is missing)
    // ============================================================

    private void setupZabbarWalletLogic() {
        if (Save_User_Status == null) {
            Save_User_Status = getSharedPreferences("Save_User_Status", Activity.MODE_PRIVATE);
        }
        // Cached value shown instantly so the UI isn't blank while the network call runs
        String cachedBalance = Save_User_Status.getString("Balance", "0");

        if (binding.balanceText != null) {
            binding.balanceText.setText("৳" + cachedBalance);
        }
        if (binding.requiredFeeText != null) {
            binding.requiredFeeText.setText("৳" + getCurrentTotalFee());
        }
        if (binding.balanceContainer != null) {
            applyRippleEffect(binding.balanceContainer);
            binding.balanceContainer.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(ZabbarMatchJoinActivity.this, Class.forName("com.khelosobaiv3.user.AddMoneyActivity")));
                } catch (Exception ignored) {
                }
            });
        }

        fetchLiveBalance();
    }

    /**
     * XMapp_Us.js.php (type=1) returns the RAW user row as JSON (no
     * {"status":...,"data":...} wrapper) - just token in, whole `users`
     * row out. We only need the "balance" field here, and we refresh the
     * local SharedPreferences cache too so other screens reading
     * "Balance" also stay in sync.
     */
    private void fetchLiveBalance() {
        if (USER_TOKEN == null || USER_TOKEN.isEmpty()) return;

        new Thread(() -> {
            try {
                URL url = new URL(BASE_URL + "XMapp_Us.js.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("User-Agent", "EliteGOX/1.0");

                String postData = "type=1&token=" + URLEncoder.encode(USER_TOKEN, "UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes("UTF-8"));
                }

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream is = conn.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    is.close();

                    JSONObject response = new JSONObject(sb.toString());
                    if (!response.has("error") && response.has("balance")) {
                        String liveBalance = response.optString("balance", "0");

                        Save_User_Status.edit().putString("Balance", liveBalance).apply();

                        runOnUiThread(() -> {
                            if (binding.balanceText != null) {
                                binding.balanceText.setText("৳" + liveBalance);
                            }
                        });
                    }
                }
            } catch (Exception ignored) {
                // Silent fail: cached balance already shown, no need to interrupt the join flow
            }
        }).start();
    }

    /**
     * match_rule_get.php - same endpoint ShvuoRulesActivity uses. Takes
     * `match_type` (category), returns {"status": bool, "rules": "..."}.
     * On success this REPLACES the generic hardcoded fallback text in
     * showStep(4) with the real rules, and refreshes the on-screen text
     * immediately if the user is already sitting on step 4 when it lands.
     */
    private void fetchLiveRules() {
        new Thread(() -> {
            try {
                URL url = new URL(BASE_URL + "match_rule_get.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("User-Agent", "EliteGOX/1.0");

                String postData = "match_type=" + URLEncoder.encode(matchTypeCategory, "UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes("UTF-8"));
                }

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream is = conn.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    is.close();

                    JSONObject response = new JSONObject(sb.toString());
                    if (response.optBoolean("status", false)) {
                        String liveRules = response.optString("rules", "");
                        if (!liveRules.isEmpty()) {
                            rulesExtra = liveRules;
                            runOnUiThread(() -> {
                                if (currentStep == 4 && binding.rulesText != null) {
                                    binding.rulesText.setText(rulesExtra);
                                }
                            });
                        }
                    }
                }
            } catch (Exception ignored) {
                // Silent fail: hardcoded default rules text stays shown as fallback
            }
        }).start();
    }

    private void applyRippleEffect(View view) {
        view.setClickable(true);
        view.setFocusable(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            TypedValue outValue = new TypedValue();
            getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
            view.setForeground(ContextCompat.getDrawable(this, outValue.resourceId));
        }
    }

    // ============================================================
    //  STEP NAVIGATION
    // ============================================================

    private void showStep(int step) {
        currentStep = step;

        binding.step1View.setVisibility(step == 1 ? View.VISIBLE : View.GONE);
        binding.step2View.setVisibility(step == 2 ? View.VISIBLE : View.GONE);
        binding.step3View.setVisibility(step == 3 ? View.VISIBLE : View.GONE);
        binding.step4View.setVisibility(step == 4 ? View.VISIBLE : View.GONE);
        binding.loadingView.setVisibility(View.GONE);

        styleStepDot(binding.step1, step >= 1);
        styleStepDot(binding.step2, step >= 2);
        styleStepDot(binding.step3, step >= 3);
        styleStepDot(binding.step4, step >= 4);
        binding.line1.setBackgroundColor(Color.parseColor(step >= 2 ? "#6D28D9" : "#E2E8F0"));
        binding.line2.setBackgroundColor(Color.parseColor(step >= 3 ? "#6D28D9" : "#E2E8F0"));
        binding.line3.setBackgroundColor(Color.parseColor(step >= 4 ? "#6D28D9" : "#E2E8F0"));

        binding.nextBtn.setText(step < 4 ? "Next" : "Confirm & Join");

        // Only poll the slot grid while it's actually on screen (step 1).
        if (step == 1) {
            fetchTakenSlots();
            startSlotPolling();
        } else {
            stopSlotPolling();
        }

        if (step == 2) {
            buildPlayerFields();
            setupZabbarWalletLogic();
        } else if (step == 3) {
            populateReviewStep();
        } else if (step == 4) {
            binding.rulesText.setText(
                    rulesExtra.isEmpty()
                            ? "1. Screenshots are mandatory after every match.\n"
                              + "2. Teaming / hacking will lead to a permanent ban.\n"
                              + "3. Entry fee is non-refundable once the slot is confirmed.\n"
                              + "4. Room ID & password will be shared 10 minutes before start.\n"
                              + "5. Prize money is credited within 24 hours of match end."
                            : rulesExtra
            );
        }

        refreshNextButtonState();
    }

    private void styleStepDot(TextView dot, boolean active) {
        dot.setBackgroundResource(active ? R.drawable.bg_step_active : R.drawable.bg_step_inactive);
        dot.setTextColor(active ? Color.WHITE : Color.parseColor("#94A3B8"));
    }

    private void onNextClicked() {
        if (joinInProgress) return;

        if (currentStep == 1) {
            if (selectedSlots.isEmpty()) {
                showErrorDialog("Please select at least one slot to continue.");
                return;
            }
            // Verify the picked slot(s) are still free right at the moment of leaving
            // step 1, instead of only finding out at the very last "Confirm & Join"
            // step - catches the case where someone else took the slot while this
            // user was still filling in step 1.
            showLoadingDialog("Checking slot availability...");
            verifySelectedSlotsStillFree(stillFree -> {
                hideLoadingDialog();
                if (!stillFree) {
                    selectedSlots.removeIf(takenSlotsFromServer::contains);
                    showStep(1);
                    showSlotConflictDialog();
                    return;
                }
                showStep(2);
            });
        } else if (currentStep == 2) {
            String err = validatePlayerNames();
            if (!TextUtils.isEmpty(err)) {
                showErrorDialog(err);
                return;
            }
            showStep(3);
        } else if (currentStep == 3) {
            showStep(4);
        } else if (currentStep == 4) {
            handleFinalJoin();
        }
    }

    private void refreshNextButtonState() {
        boolean matchFull = spotsLeft <= 0;
        binding.nextBtn.setEnabled(!matchFull && !joinInProgress);
        binding.nextBtn.setText(
                matchFull ? "Match Full" : (currentStep < 4 ? "Next" : "Confirm & Join")
        );
    }

    // ============================================================
    //  STEP 1 : ENTRY TYPE + SLOT GRID
    // ============================================================

    private void setupEntryTypeSelector() {
        if (isLocked) {
            binding.entrySoloCard.setVisibility(entryType.equalsIgnoreCase("Solo") ? View.VISIBLE : View.GONE);
            binding.entryDuoCard.setVisibility(entryType.equalsIgnoreCase("Duo") ? View.VISIBLE : View.GONE);
            binding.entrySquadCard.setVisibility(entryType.equalsIgnoreCase("Squad") ? View.VISIBLE : View.GONE);
        } else {
            binding.entrySoloCard.setVisibility(View.VISIBLE);
            binding.entryDuoCard.setVisibility(View.VISIBLE);
            binding.entrySquadCard.setVisibility(View.VISIBLE);
            binding.entrySoloCard.setOnClickListener(v -> setSelectionType("solo"));
            binding.entryDuoCard.setOnClickListener(v -> setSelectionType("duo"));
            binding.entrySquadCard.setOnClickListener(v -> setSelectionType("squad"));
        }

        String initialSelection = entryType.equalsIgnoreCase("Duo") ? "duo"
                : entryType.equalsIgnoreCase("Squad") ? "squad" : "solo";
        setSelectionType(initialSelection);
    }

    private void setSelectionType(String type) {
        zabbar = type;

        resetEntryCard(binding.entrySoloCard, binding.entrySoloText);
        resetEntryCard(binding.entryDuoCard, binding.entryDuoText);
        resetEntryCard(binding.entrySquadCard, binding.entrySquadText);

        if (type.equals("solo")) {
            highlightEntryCard(binding.entrySoloCard, binding.entrySoloText);
        } else if (type.equals("duo")) {
            highlightEntryCard(binding.entryDuoCard, binding.entryDuoText);
        } else {
            highlightEntryCard(binding.entrySquadCard, binding.entrySquadText);
        }

        buildSlotGrid();
    }

    private void resetEntryCard(androidx.cardview.widget.CardView card, TextView label) {
        card.setCardBackgroundColor(Color.parseColor("#F8FAFC"));
        label.setTextColor(Color.parseColor("#64748B"));
    }

    private void highlightEntryCard(androidx.cardview.widget.CardView card, TextView label) {
        card.setCardBackgroundColor(Color.parseColor("#F5F3FF"));
        label.setTextColor(Color.parseColor("#6D28D9"));
    }

    private int getSquadSize(String type) {
        if ("duo".equals(type)) return 2;
        if ("squad".equals(type)) return 4;
        return 1;
    }

    /**
     * Fee is now dynamic - based on how many INDIVIDUAL slots the user has
     * actually selected, not a fixed duo=2x / squad=4x amount. Selecting 1
     * slot in a duo match costs 1x the base fee, selecting both costs 2x.
     */
    private int getCurrentTotalFee() {
        int count = selectedSlots.isEmpty() ? 0 : selectedSlots.size();
        return baseEntryFee * count;
    }

    /**
     * Each slot here is now an INDIVIDUAL PLAYER POSITION (1..totalPlayer),
     * not a team-container. A duo/squad team is a group of `squadSize`
     * consecutive slot numbers - e.g. duo team 5 = slots 9 & 10
     * (team_no = ceil(slot / squadSize), matching the joingame.php logic).
     *
     * NOTE: there is currently no backend endpoint that returns which exact
     * individual slots are already taken, so "taken" state is still
     * estimated on the client from TotalJoiner (now a direct 1:1 count of
     * occupied slots since joingame.php increments total_joiner per
     * player, not per team). Swap the body of this method for a real API
     * call later (e.g. get_match_slots.php) without touching anything else
     * in this activity - toggleSlot()/buildPlayerFields()/
     * performJoinAction() will keep working the same way.
     */
    private void buildSlotGrid() {
        binding.slotsGrid.removeAllViews();
        slotHolders.clear();
        selectedSlots.clear();

        int squadSize = getSquadSize(zabbar);
        totalSlots = totalPlayer > 0 ? totalPlayer : 12;
        occupiedSlotsCount = Math.min(Math.max(totalJoiner, 0), totalSlots);

        if (squadSize <= 1) {
            // Solo: flat grid, one card per individual slot (unchanged)
            for (int i = 1; i <= totalSlots; i++) {
                SlotHolder holder = buildSlotCard(i, isSlotTaken(i));
                slotHolders.add(holder);
                binding.slotsGrid.addView(holder.card);
            }
        } else {
            // Duo/Squad: group slots into boxes of squadSize each (one box = one team's slots)
            int totalBoxes = (int) Math.ceil(totalSlots / (double) squadSize);
            for (int box = 1; box <= totalBoxes; box++) {
                int startSlot = (box - 1) * squadSize + 1;
                binding.slotsGrid.addView(buildSlotBox(box, startSlot, squadSize));
            }
        }

        refreshFeeDisplay();
        refreshNextButtonState();
    }

    /**
     * Prefer the REAL per-slot data from get_match_slots.php when we have
     * it; fall back to the old TotalJoiner-count estimate only if that
     * fetch hasn't landed yet (e.g. very first frame before the network
     * call returns).
     */
    private boolean isSlotTaken(int slotNumber) {
        if (takenSlotsFromServer != null) {
            return takenSlotsFromServer.contains(slotNumber);
        }
        return slotNumber <= occupiedSlotsCount;
    }

    /**
     * Real-time fix for the "shows 10 free slots but Join says Already
     * Taken" race condition: many users hitting the same match at once
     * means the client's cached/estimated slot state goes stale within
     * seconds. This fetches EXACTLY which individual slots are taken
     * right now and rebuilds the grid so it matches the server.
     * Called: on first load, on onResume (screen re-opened), and again
     * immediately after a "Slot Already Taken" join failure.
     */
    private void fetchTakenSlots() {
        new Thread(() -> {
            try {
                URL url = new URL(BASE_URL + "get_match_slots.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("User-Agent", "EliteGOX/1.0");

                String postData = "match_id=" + URLEncoder.encode(matchId, "UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes("UTF-8"));
                }

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream is = conn.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    is.close();

                    JSONObject response = new JSONObject(sb.toString());
                    if ("success".equals(response.optString("status", ""))) {
                        JSONArray arr = response.optJSONArray("taken_slots");
                        java.util.Set<Integer> fresh = new java.util.HashSet<>();
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) fresh.add(arr.optInt(i, -1));
                        }
                        takenSlotsFromServer = fresh;

                        runOnUiThread(() -> {
                            if (currentStep == 1) {
                                // A previously-selected slot may have just been taken by
                                // someone else - silently drop it and let the user know.
                                boolean droppedAny = selectedSlots.removeIf(fresh::contains);
                                buildSlotGrid();
                                if (droppedAny) {
                                    showSlotConflictDialog();
                                }
                            }
                        });
                    }
                }
            } catch (Exception ignored) {
                // Silent fail: keep showing whatever we had (estimate or last-known-good)
            }
        }).start();
    }

    /**
     * One "box" = one team's slots grouped visually (2 for duo, 4 for
     * squad). This is ONLY a visual grouping - tapping a slot inside still
     * calls toggleSlot() the same as before, and slots from DIFFERENT
     * boxes can still be selected together in one join (no restriction),
     * matching how joingame.php computes each slot's team_no independently.
     */
    private View buildSlotBox(int boxNumber, int startSlot, int squadSize) {
        MaterialCardView box = new MaterialCardView(this);
        GridLayout.LayoutParams boxLp = new GridLayout.LayoutParams();
        boxLp.width = 0;
        boxLp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        // slotsGrid has columnCount=4 - span 2 columns so 2 boxes sit per row,
        // giving each box enough width for its inner 2-column slot grid
        // (spanning only 1 column squeezed the inner buttons and clipped their text)
        boxLp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 2, 1f);
        boxLp.setMargins(dp(5), dp(5), dp(5), dp(5));
        box.setLayoutParams(boxLp);
        box.setRadius(dp(14));
        box.setCardElevation(0);
        box.setStrokeWidth(dp(1));
        box.setStrokeColor(Color.parseColor("#E2E8F0"));
        box.setCardBackgroundColor(Color.parseColor("#FFFFFF"));
        box.setUseCompatPadding(false);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(10), dp(10), dp(10), dp(10));

        TextView boxLabel = new TextView(this);
        boxLabel.setText(String.valueOf(boxNumber));
        boxLabel.setGravity(Gravity.CENTER);
        boxLabel.setTextSize(12);
        boxLabel.setTextColor(Color.parseColor("#94A3B8"));
        LinearLayout.LayoutParams boxLabelParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        boxLabelParams.bottomMargin = dp(8);
        boxLabel.setLayoutParams(boxLabelParams);
        outer.addView(boxLabel);

        // Nested GridLayout was unreliable here (columns didn't split width evenly,
        // which is what clipped/overlapped the "Slot N" text). LinearLayout rows
        // with weight=1 per item are predictable, so we use that instead:
        // squadSize=4 -> two rows of 2, squadSize=2 -> one row of 2.
        int remaining = squadSize;
        int slotCursor = startSlot;
        while (remaining > 0) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.topMargin = dp(3);
            row.setLayoutParams(rowLp);

            int inThisRow = Math.min(2, remaining);
            for (int c = 0; c < inThisRow; c++) {
                int slotNumber = slotCursor;
                if (slotNumber > totalSlots) break;

                boolean taken = isSlotTaken(slotNumber);
                SlotHolder holder = buildSlotCard(slotNumber, taken);
                slotHolders.add(holder);

                // buildSlotCard() sets layout params for the OUTER binding.slotsGrid
                // (a GridLayout); override here since this card now lives inside a
                // LinearLayout row instead.
                LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                itemLp.setMargins(dp(3), 0, dp(3), 0);
                holder.card.setLayoutParams(itemLp);

                row.addView(holder.card);
                slotCursor++;
            }
            outer.addView(row);
            remaining -= inThisRow;
        }

        box.addView(outer);

        return box;
    }

    private SlotHolder buildSlotCard(int number, boolean taken) {
        SlotHolder holder = new SlotHolder();
        holder.number = number;
        holder.taken = taken;

        MaterialCardView card = new MaterialCardView(this);
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        lp.setMargins(dp(5), dp(5), dp(5), dp(5));
        card.setLayoutParams(lp);
        card.setRadius(dp(14));
        card.setCardElevation(0);
        card.setStrokeWidth(dp(1));
        card.setUseCompatPadding(false);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setGravity(Gravity.CENTER);
        inner.setPadding(0, dp(14), 0, dp(14));

        TextView label = new TextView(this);
        label.setText("Slot " + number);
        label.setGravity(Gravity.CENTER);
        label.setTextSize(13);
        label.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        inner.addView(label);
        card.addView(inner);

        holder.card = card;
        holder.label = label;

        if (taken) {
            card.setCardBackgroundColor(Color.parseColor("#F1F5F9"));
            card.setStrokeColor(Color.parseColor("#E2E8F0"));
            label.setTextColor(Color.parseColor("#94A3B8"));

            TextView takenTag = new TextView(this);
            takenTag.setText("Taken");
            takenTag.setTextSize(10);
            takenTag.setTextColor(Color.parseColor("#94A3B8"));
            takenTag.setGravity(Gravity.CENTER);
            inner.addView(takenTag);

            card.setClickable(false);
        } else {
            styleSlotDefault(holder);
            card.setClickable(true);
            card.setFocusable(true);
            applyRippleEffect(card);
            card.setOnClickListener(v -> toggleSlot(holder));
        }

        return holder;
    }

    private void styleSlotDefault(SlotHolder holder) {
        holder.card.setCardBackgroundColor(Color.parseColor("#F8FAFC"));
        holder.card.setStrokeColor(Color.parseColor("#E2E8F0"));
        holder.card.setStrokeWidth(dp(1));
        holder.card.setCardElevation(0);
        holder.label.setTextColor(Color.parseColor("#0F172A"));
    }

    private void styleSlotSelected(SlotHolder holder) {
        // Solid, deep fill (not a pale tint) so a selected slot is unmistakable at a
        // glance instead of blending into the unselected cards.
        holder.card.setCardBackgroundColor(Color.parseColor("#6D28D9"));
        holder.card.setStrokeColor(Color.parseColor("#4C1D95"));
        holder.card.setStrokeWidth(dp(2));
        holder.card.setCardElevation(dp(3));
        holder.label.setTextColor(Color.parseColor("#FFFFFF"));
    }

    /**
     * Manual multi-select: user taps slots one by one to add/remove them.
     * Slots can be picked freely across DIFFERENT boxes/teams too (each
     * selected slot still gets its own team_no on the backend, computed
     * independently per slot in joingame.php - so picking from different
     * boxes just means this one join request lands in multiple teams,
     * which is fine). Only the total count is capped at squad size
     * (solo=1, duo=2, squad=4).
     */
    private void toggleSlot(SlotHolder tapped) {
        int squadSize = getSquadSize(zabbar);

        if (selectedSlots.contains(tapped.number)) {
            selectedSlots.remove((Integer) tapped.number);
            styleSlotDefault(tapped);
        } else {
            if (selectedSlots.size() >= squadSize) {
                showErrorDialog("You can select up to " + squadSize + " slot(s) for " + capitalize(zabbar) + ".");
                return;
            }

            selectedSlots.add(tapped.number);
            styleSlotSelected(tapped);
        }

        refreshFeeDisplay();
        refreshNextButtonState();
    }

    private void refreshFeeDisplay() {
        binding.totalFeeValueText.setText("৳" + getCurrentTotalFee());
        if (binding.requiredFeeText != null) {
            binding.requiredFeeText.setText("৳" + getCurrentTotalFee());
        }
    }

    // ============================================================
    //  STEP 2 : PLAYER NAME FIELDS
    // ============================================================

    private void buildPlayerFields() {
        binding.namesContainer.removeAllViews();
        playerNameFields.clear();

        // slots are sorted so field order lines up with the slot order sent to the backend
        List<Integer> sortedSlots = new ArrayList<>(selectedSlots);
        java.util.Collections.sort(sortedSlots);

        for (int slotNumber : sortedSlots) {
            playerNameFields.add(buildPlayerFieldRow(slotNumber));
        }

        fetchAndSetDefaultAccount();
    }

    private EditText buildPlayerFieldRow(int slotNumber) {
        MaterialCardView card = new MaterialCardView(this);
        card.setRadius(dp(16));
        card.setCardElevation(0);
        card.setStrokeWidth(dp(1));
        card.setStrokeColor(Color.parseColor("#E2E8F0"));
        card.setCardBackgroundColor(Color.parseColor("#F8FAFC"));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(cardParams);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(6), dp(10), dp(6));
        card.addView(row);

        TextView tag = new TextView(this);
        tag.setText("Slot " + slotNumber);
        tag.setTextColor(Color.parseColor("#6D28D9"));
        tag.setTextSize(12);
        tag.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        row.addView(tag, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        EditText input = new EditText(this);
        input.setHint("Player name for slot " + slotNumber);
        input.setTextColor(Color.parseColor("#0F172A"));
        input.setHintTextColor(Color.parseColor("#94A3B8"));
        input.setTextSize(14);
        input.setSingleLine(true);
        input.setBackground(null);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        inputParams.setMarginStart(dp(10));
        row.addView(input, inputParams);

        ImageView changeIcon = new ImageView(this);
        changeIcon.setImageResource(R.drawable.change);
        changeIcon.setColorFilter(Color.parseColor("#6D28D9"));
        changeIcon.setPadding(dp(8), dp(8), dp(8), dp(8));
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(36), dp(36));
        row.addView(changeIcon, iconParams);
        changeIcon.setOnClickListener(v -> showAccountSelectionDialog(input));

        binding.namesContainer.addView(card);
        return input;
    }

    private String getSafeText(View view) {
        if (view instanceof TextView) return ((TextView) view).getText().toString().trim();
        return "";
    }

    private String validatePlayerNames() {
        for (int i = 0; i < playerNameFields.size(); i++) {
            if (TextUtils.isEmpty(getSafeText(playerNameFields.get(i)))) {
                return "Player " + (i + 1) + " name is required.";
            }
        }
        return "";
    }

    private List<String> collectPlayerNames() {
        List<String> names = new ArrayList<>();
        for (EditText field : playerNameFields) {
            names.add(getSafeText(field));
        }
        return names;
    }

    // ============================================================
    //  STEP 3 : REVIEW
    // ============================================================

    private void populateReviewStep() {
        binding.regGameModeText.setText(capitalize(zabbar));
        binding.regSlotText.setText("Slot " + TextUtils.join(", ", getSortedSelectedSlots()));
        binding.regPlayersText.setText(TextUtils.join(", ", collectPlayerNames()));
        int totalFee = getCurrentTotalFee();
        binding.regPayableText.setText("৳" + totalFee);
        binding.totalFeeValueText.setText("৳" + totalFee);
    }

    private List<Integer> getSortedSelectedSlots() {
        List<Integer> sorted = new ArrayList<>(selectedSlots);
        java.util.Collections.sort(sorted);
        return sorted;
    }

    private String capitalize(String s) {
        if (TextUtils.isEmpty(s)) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    // ============================================================
    //  STEP 4 : CONFIRM & JOIN
    // ============================================================

    private void handleFinalJoin() {
        String baseUrl = GET_API.getString("Api", BASE_URL);
        if (!baseUrl.endsWith("/")) baseUrl = baseUrl + "/";

        String savedEmail = Save_User_Status.getString("Email", "");
        String savedFcm = Save_User_Status.getString("Fcm", "");

        if (TextUtils.isEmpty(savedEmail) || TextUtils.isEmpty(USERNAME)) {
            showErrorDialog("Error: Saved Profile Data is Empty!");
            return;
        }

        String validationError = validatePlayerNames();
        if (!TextUtils.isEmpty(validationError)) {
            showErrorDialog(validationError);
            return;
        }
        if (selectedSlots.isEmpty()) {
            showErrorDialog("Please select at least one slot to continue.");
            return;
        }

        int totalFee = getCurrentTotalFee();
        String slotList = TextUtils.join(", ", getSortedSelectedSlots());
        final String finalBaseUrl = baseUrl;

        // Last-moment race guard: right before we even show the confirm dialog, do one
        // fresh, synchronous check against the server for exactly the slots this user
        // picked. This is the tightest point we can close the "shows free but someone
        // else grabbed it" window at without a push/websocket backend - it collapses
        // the race down to a single network round trip instead of leaving it open for
        // as long as the user takes to read the confirm dialog.
        showLoadingDialog("Checking slot availability...");
        verifySelectedSlotsStillFree(stillFree -> {
            hideLoadingDialog();
            if (!stillFree) {
                // takenSlotsFromServer was refreshed by the check we just ran - drop
                // whichever of our picks got grabbed and rebuild the grid before showing
                // the dialog, so the user lands back on step 1 with an accurate view.
                selectedSlots.removeIf(takenSlotsFromServer::contains);
                currentStep = 1;
                showStep(1);
                showSlotConflictDialog();
                return;
            }

            new PremiumDialog.Builder(this)
                    .setDialogType(true)
                    .setCancelable(true)
                    .setBlurBackground(true)
                    .setLottie("Info.json")
                    .setTitle("Confirm Join")
                    .setMessage("Join Slot " + slotList + " with Entry Fee ৳" + totalFee + "?")
                    .setPositiveButton("Confirm", "#6D28D9", dialog -> {
                        dialog.dismiss();
                        performJoinAction(savedEmail, savedFcm, finalBaseUrl);
                    })
                    .setNegativeButton("Cancel", Dialog::dismiss)
                    .show();
        });
    }

    /**
     * Hits get_match_slots.php directly (bypassing the 3s poll cadence) and checks the
     * freshest possible taken-slot set against what this user currently has selected.
     * Calls back on the UI thread with true only if every selected slot is still free.
     * On any network failure we fail OPEN (treat as still-free) so a flaky connection
     * doesn't block a legitimate join - the backend's own uniqueness check on
     * joingame.php remains the final source of truth either way.
     */
    private interface SlotCheckCallback {
        void onResult(boolean stillFree);
    }

    private void verifySelectedSlotsStillFree(SlotCheckCallback callback) {
        final List<Integer> toCheck = new ArrayList<>(selectedSlots);
        new Thread(() -> {
            boolean stillFree = true;
            try {
                URL url = new URL(BASE_URL + "get_match_slots.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("User-Agent", "EliteGOX/1.0");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                String postData = "match_id=" + URLEncoder.encode(matchId, "UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes("UTF-8"));
                }

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream is = conn.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    is.close();

                    JSONObject response = new JSONObject(sb.toString());
                    if ("success".equals(response.optString("status", ""))) {
                        JSONArray arr = response.optJSONArray("taken_slots");
                        java.util.Set<Integer> fresh = new java.util.HashSet<>();
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) fresh.add(arr.optInt(i, -1));
                        }
                        takenSlotsFromServer = fresh;
                        for (int slot : toCheck) {
                            if (fresh.contains(slot)) {
                                stillFree = false;
                                break;
                            }
                        }
                    }
                }
                conn.disconnect();
            } catch (Exception ignored) {
                // fail open - see method doc
            }

            final boolean result = stillFree;
            runOnUiThread(() -> callback.onResult(result));
        }).start();
    }

    private void performJoinAction(String savedEmail, String savedFcm, String baseUrl) {
        Map1 = new HashMap<>();
        Map1.put("email", savedEmail);
        Map1.put("match_id", matchId);
        Map1.put("fcm_key", savedFcm);
        Map1.put("username", USERNAME);
        Map1.put("type", zabbar);

        // playerNameFields was built in the same order as getSortedSelectedSlots(),
        // so slots[i] always corresponds to names[i] - matches joingame.php's
        // parallel "slots"/"names" comma-list parsing.
        List<Integer> sortedSlots = getSortedSelectedSlots();
        List<String> names = collectPlayerNames();

        StringBuilder slotsCsv = new StringBuilder();
        StringBuilder namesCsv = new StringBuilder();
        for (int i = 0; i < sortedSlots.size(); i++) {
            if (i > 0) {
                slotsCsv.append(",");
                namesCsv.append(",");
            }
            slotsCsv.append(sortedSlots.get(i));
            namesCsv.append(i < names.size() ? names.get(i) : "");
        }

        Map1.put("slots", slotsCsv.toString());
        Map1.put("names", namesCsv.toString());

        joinInProgress = true;
        refreshNextButtonState();
        showLoadingDialog("Joining match...");

        Join_Req.setParams(Map1, RequestNetworkController.REQUEST_PARAM);
        Join_Req.startRequestNetwork(
                RequestNetworkController.POST,
                baseUrl.concat("joingame.php"),
                "",
                _Join_Req_request_listener
        );
    }

    private void subscribeAfterJoin() {
        String topic = buildMatchTopic();
        FCMManager.subscribe(topic, new FCMManager.FCMListener() {
            @Override
            public void onSuccess(String result) {
                completeJoinAndExit();
            }

            @Override
            public void onError(String error) {
                new PremiumDialog.Builder(ZabbarMatchJoinActivity.this)
                        .setDialogType(true)
                        .setCancelable(false)
                        .setBlurBackground(true)
                        .setLottie("error.json")
                        .setTitle("Notification Error")
                        .setMessage(error)
                        .setPositiveButton("Okay", "#EF4444", dialog -> {
                            dialog.dismiss();
                            completeJoinAndExit();
                        })
                        .setNegativeButton("Close", dialog -> {
                            dialog.dismiss();
                            completeJoinAndExit();
                        })
                        .show();
            }
        });
    }

    private void completeJoinAndExit() {
        try {
            sendBroadcast(new Intent(ZabbarMatchActivity.ACTION_REFRESH_MATCHES));
        } catch (Exception ignored) {
        }
        try {
            setResult(Activity.RESULT_OK);
        } catch (Exception ignored) {
        }
        finish();
    }

    private String buildMatchTopic() {
        String v = safe(matchId);
        if (v.isEmpty()) return "ttt";
        return "match_" + v;
    }

    // ============================================================
    //  ACCOUNT SELECTION BOTTOM SHEET (unchanged behaviour from old activity)
    // ============================================================

    private void showBlurBackground() {
        try {
            if (blurViewOverlay == null) {
                blurViewOverlay = new eightbitlab.com.blurview.BlurView(this);
                ViewGroup decorView = (ViewGroup) getWindow().getDecorView();
                ViewGroup rootView = decorView.findViewById(android.R.id.content);
                Drawable windowBackground = decorView.getBackground();

                blurViewOverlay.setupWith(rootView, new eightbitlab.com.blurview.RenderScriptBlur(this))
                        .setFrameClearDrawable(windowBackground)
                        .setBlurRadius(5f);

                blurViewOverlay.setOverlayColor(Color.parseColor("#33000000"));
                blurViewOverlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }

            ViewGroup content = findViewById(android.R.id.content);
            if (blurViewOverlay.getParent() == null) {
                content.addView(blurViewOverlay);
            }
            blurViewOverlay.setAlpha(0f);
            blurViewOverlay.animate().alpha(1f).setDuration(250).start();
        } catch (Exception e) {
        }
    }

    private void hideBlurBackground() {
        if (blurViewOverlay != null && blurViewOverlay.getParent() != null) {
            blurViewOverlay.animate().alpha(0f).setDuration(250).withEndAction(() -> {
                try {
                    ViewGroup content = findViewById(android.R.id.content);
                    content.removeView(blurViewOverlay);
                } catch (Exception ignored) {
                }
            }).start();
        }
    }

    private void applyBlurEffect(BottomSheetDialog dialog) {
        Window window = dialog.getWindow();
        if (window != null) {
            window.setDimAmount(0f);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                window.setNavigationBarColor(Color.parseColor("#FFFFFF"));
                View dev = window.getDecorView();
                dev.setSystemUiVisibility(dev.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            }
        }
        dialog.setOnShowListener(d -> {
            BottomSheetDialog bottomDialog = (BottomSheetDialog) d;
            View bottomSheetInternal = bottomDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (bottomSheetInternal != null) {
                bottomSheetInternal.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
            showBlurBackground();
        });
        dialog.setOnDismissListener(d -> hideBlurBackground());
        dialog.setOnCancelListener(d -> hideBlurBackground());
    }

    private void showAccountSelectionDialog(TextView targetTextView) {
        BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.Theme_Design_BottomSheetDialog);
        applyBlurEffect(dialog);

        LinearLayout formLayout = new LinearLayout(this);
        formLayout.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bsBg = new GradientDrawable();
        bsBg.setColor(Color.WHITE);
        bsBg.setCornerRadii(new float[]{dp(32), dp(32), dp(32), dp(32), 0, 0, 0, 0});
        formLayout.setBackground(bsBg);
        formLayout.setPadding(dp(24), dp(16), dp(24), dp(24));

        View handle = new View(this);
        GradientDrawable handleBg = new GradientDrawable();
        handleBg.setColor(Color.parseColor("#E2E8F0"));
        handleBg.setCornerRadius(dp(4));
        handle.setBackground(handleBg);
        LinearLayout.LayoutParams lpHandle = new LinearLayout.LayoutParams(dp(40), dp(5));
        lpHandle.gravity = Gravity.CENTER_HORIZONTAL;
        lpHandle.setMargins(0, dp(8), 0, dp(24));
        formLayout.addView(handle, lpHandle);

        TextView title = new TextView(this);
        title.setText("Select Game Account");
        title.setTextColor(Color.parseColor("#0F172A"));
        title.setTextSize(22);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setPadding(0, 0, 0, dp(20));
        formLayout.addView(title);

        ProgressBar progressBar = new ProgressBar(this);
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ((LinearLayout.LayoutParams) progressBar.getLayoutParams()).gravity = Gravity.CENTER_HORIZONTAL;

        TextView statusText = new TextView(this);
        statusText.setText("Loading your accounts...");
        statusText.setTextColor(Color.parseColor("#64748B"));
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(0, dp(12), 0, dp(16));
        statusText.setTextSize(15);

        TextView addAccountButton = new TextView(this);
        addAccountButton.setText("Add Account");
        addAccountButton.setTextColor(Color.WHITE);
        addAccountButton.setTextSize(15);
        addAccountButton.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        addAccountButton.setGravity(Gravity.CENTER);
        addAccountButton.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable addBg = new GradientDrawable();
        addBg.setColor(Color.parseColor("#6D28D9"));
        addBg.setCornerRadius(dp(14));
        addAccountButton.setBackground(addBg);
        LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        addParams.topMargin = dp(16);
        addAccountButton.setLayoutParams(addParams);
        addAccountButton.setVisibility(View.GONE);
        addAccountButton.setOnClickListener(v -> {
            dialog.dismiss();
            openAddAccountScreen();
        });

        formLayout.addView(progressBar);
        formLayout.addView(statusText);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout accountListContainer = new LinearLayout(this);
        accountListContainer.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(accountListContainer, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        formLayout.addView(scrollView);
        formLayout.addView(addAccountButton);

        dialog.setContentView(formLayout);
        dialog.show();

        new Thread(() -> {
            try {
                URL url = new URL(BASE_URL + "get_game_accounts.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("User-Agent", "EliteGOX/1.0");

                String postData = "token=" + URLEncoder.encode(USER_TOKEN, "UTF-8") + "&username=" + URLEncoder.encode(USERNAME, "UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes("UTF-8"));
                }

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream is = conn.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    is.close();

                    JSONObject response = new JSONObject(sb.toString());
                    if ("success".equalsIgnoreCase(response.optString("status", ""))) {
                        JSONArray array = response.optJSONArray("data");
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            if (array == null || array.length() == 0) {
                                statusText.setText("No Accounts Linked.\nPlease add an account first.");
                                addAccountButton.setVisibility(View.VISIBLE);
                            } else {
                                statusText.setVisibility(View.GONE);
                                addAccountButton.setVisibility(View.GONE);

                                for (int i = 0; i < array.length(); i++) {
                                    try {
                                        JSONObject obj = array.getJSONObject(i);
                                        String name = obj.optString("ingame_name", "");
                                        String uid = obj.optString("game_uid", "");
                                        String lvl = obj.optString("level", "");
                                        boolean isDefault = "true".equalsIgnoreCase(obj.optString("is_default", "false"));

                                        MaterialCardView card = new MaterialCardView(ZabbarMatchJoinActivity.this);
                                        card.setCardBackgroundColor(Color.parseColor("#F8FAFC"));
                                        card.setRadius(dp(16));
                                        card.setCardElevation(0);
                                        card.setStrokeColor(Color.parseColor("#E2E8F0"));
                                        card.setStrokeWidth(dp(1));
                                        card.setRippleColor(ColorStateList.valueOf(Color.parseColor("#CBD5E1")));

                                        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                                        cardParams.setMargins(0, 0, 0, dp(14));
                                        card.setLayoutParams(cardParams);

                                        LinearLayout rowLayout = new LinearLayout(ZabbarMatchJoinActivity.this);
                                        rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                                        rowLayout.setPadding(dp(16), dp(16), dp(16), dp(16));
                                        rowLayout.setGravity(Gravity.CENTER_VERTICAL);
                                        card.addView(rowLayout);

                                        MaterialCardView avatarBox = new MaterialCardView(ZabbarMatchJoinActivity.this);
                                        avatarBox.setRadius(dp(24));
                                        avatarBox.setCardElevation(0);
                                        avatarBox.setCardBackgroundColor(Color.parseColor("#EEF2FF"));
                                        rowLayout.addView(avatarBox, new LinearLayout.LayoutParams(dp(48), dp(48)));

                                        ImageView imgUser = new ImageView(ZabbarMatchJoinActivity.this);
                                        imgUser.setImageResource(R.drawable.icon_person_3_round);
                                        imgUser.setColorFilter(Color.parseColor("#6D28D9"));
                                        imgUser.setPadding(dp(12), dp(12), dp(12), dp(12));
                                        avatarBox.addView(imgUser, new MaterialCardView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                                        LinearLayout infoCol = new LinearLayout(ZabbarMatchJoinActivity.this);
                                        infoCol.setOrientation(LinearLayout.VERTICAL);
                                        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                                        infoParams.setMarginStart(dp(16));
                                        rowLayout.addView(infoCol, infoParams);

                                        LinearLayout nameBadgeRow = new LinearLayout(ZabbarMatchJoinActivity.this);
                                        nameBadgeRow.setOrientation(LinearLayout.HORIZONTAL);
                                        nameBadgeRow.setGravity(Gravity.CENTER_VERTICAL);
                                        infoCol.addView(nameBadgeRow);

                                        TextView txtName = new TextView(ZabbarMatchJoinActivity.this);
                                        txtName.setText(name);
                                        txtName.setTextColor(Color.parseColor("#0F172A"));
                                        txtName.setTextSize(17);
                                        txtName.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                                        nameBadgeRow.addView(txtName);

                                        if (isDefault) {
                                            TextView badge = new TextView(ZabbarMatchJoinActivity.this);
                                            badge.setText("Default");
                                            badge.setTextColor(Color.parseColor("#6D28D9"));
                                            badge.setTextSize(10);
                                            badge.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
                                            badge.setPadding(dp(8), dp(4), dp(8), dp(4));
                                            GradientDrawable gdBadge = new GradientDrawable();
                                            gdBadge.setCornerRadius(dp(8));
                                            gdBadge.setColor(Color.parseColor("#EDE9FE"));
                                            badge.setBackground(gdBadge);
                                            LinearLayout.LayoutParams lpBadge = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                                            lpBadge.setMarginStart(dp(10));
                                            nameBadgeRow.addView(badge, lpBadge);
                                        }

                                        TextView txtUid = new TextView(ZabbarMatchJoinActivity.this);
                                        txtUid.setText("UID: " + uid + " • Lv: " + lvl);
                                        txtUid.setTextColor(Color.parseColor("#64748B"));
                                        txtUid.setTextSize(13);
                                        LinearLayout.LayoutParams lpUid = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                                        lpUid.setMargins(0, dp(6), 0, 0);
                                        infoCol.addView(txtUid, lpUid);

                                        card.setOnClickListener(v -> {
                                            targetTextView.setText(name);
                                            dialog.dismiss();
                                        });

                                        accountListContainer.addView(card);
                                    } catch (Exception ignored) {
                                    }
                                }
                            }
                        });
                    } else {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            statusText.setText("Failed to retrieve accounts.");
                            addAccountButton.setVisibility(View.VISIBLE);
                        });
                    }
                } else {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        statusText.setText("Failed to retrieve accounts.");
                        addAccountButton.setVisibility(View.VISIBLE);
                    });
                }
                conn.disconnect();
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    statusText.setText("Network error. Please try again.");
                    addAccountButton.setVisibility(View.VISIBLE);
                });
            }
        }).start();
    }

    private void openAddAccountScreen() {
        String[] candidates = {
                "com.khelosobaiv3.user.ZabbarAddAccount",
                "com.khelosobaiv3.user.AddGameAccountActivity",
                "com.khelosobaiv3.user.ZabbarGameAccountActivity",
                "com.khelosobaiv3.user.GameAccountActivity"
        };

        for (String name : candidates) {
            try {
                Class<?> cls = Class.forName(name);
                Intent intent = new Intent(this, cls);
                startActivity(intent);
                return;
            } catch (Exception ignored) {
            }
        }

        new PremiumDialog.Builder(this)
                .setDialogType(true)
                .setCancelable(false)
                .setBlurBackground(true)
                .setLottie("error.json")
                .setTitle("Error")
                .setMessage("Add account screen not found")
                .setPositiveButton("Okay", "#EF4444", Dialog::dismiss)
                .setNegativeButton("Close", Dialog::dismiss)
                .show();
    }

    private void fetchAndSetDefaultAccount() {
        if (playerNameFields.isEmpty()) return;
        final EditText firstField = playerNameFields.get(0);

        new Thread(() -> {
            try {
                URL url = new URL(BASE_URL + "get_game_accounts.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("User-Agent", "EliteGOX/1.0");

                String postData = "token=" + URLEncoder.encode(USER_TOKEN, "UTF-8") + "&username=" + URLEncoder.encode(USERNAME, "UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(postData.getBytes("UTF-8"));
                }

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream is = conn.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    is.close();

                    JSONObject response = new JSONObject(sb.toString());
                    if ("success".equalsIgnoreCase(response.optString("status", ""))) {
                        JSONArray array = response.optJSONArray("data");
                        if (array != null) {
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                boolean isDefault = "true".equalsIgnoreCase(obj.optString("is_default", "false"));
                                if (isDefault) {
                                    String name = obj.optString("ingame_name", "");
                                    runOnUiThread(() -> firstField.setText(name));
                                    break;
                                }
                            }
                        }
                    }
                }
                conn.disconnect();
            } catch (Exception e) {
            }
        }).start();
    }

    // ============================================================
    //  COUNTDOWN
    // ============================================================

    private long parseDateToMillis(String rawStr) {
        if (rawStr == null || rawStr.isEmpty()) return 0;
        String cleanStr = rawStr.replaceAll("(?i)(timer|time|start\\s*in\\s*time)\\s*:", "")
                .replaceAll("(?i)\\bat\\b", "")
                .replaceAll("\\s+", " ")
                .trim()
                .replace("-", "/");

        String[] patterns = {
                "dd/MM/yyyy hh:mm a",
                "dd/MM/yyyy HH:mm:ss",
                "yyyy/MM/dd HH:mm:ss",
                "dd/MM/yyyy HH:mm",
                "dd-MM-yyyy hh:mm a"
        };

        for (String pattern : patterns) {
            try {
                Date date = new SimpleDateFormat(pattern, Locale.ENGLISH).parse(cleanStr);
                if (date != null) return date.getTime();
            } catch (Exception ignored) {
            }
        }

        try {
            return Long.parseLong(rawStr.trim());
        } catch (Exception ignored) {
        }
        return 0;
    }

    private void startCountdown() {
        if (countDownTimer != null) countDownTimer.cancel();
        long targetMillis = parseDateToMillis(matchTimeStr);
        long timeToWait = targetMillis - System.currentTimeMillis();

        if (timeToWait <= 0) {
            binding.countdownMainText.setText("MATCH START");
            binding.countdownMainText.setTextColor(Color.parseColor("#EF4444"));
            binding.countdownSecText.setVisibility(View.GONE);
            return;
        }

        countDownTimer = new CountDownTimer(timeToWait, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long d = millisUntilFinished / 86400000;
                long h = (millisUntilFinished % 86400000) / 3600000;
                long m = (millisUntilFinished % 3600000) / 60000;
                long s = (millisUntilFinished % 60000) / 1000;

                StringBuilder sb1 = new StringBuilder();
                if (d > 0) sb1.append(String.format(Locale.ENGLISH, "%02d", d)).append("d : ");
                if (h > 0 || d > 0) sb1.append(String.format(Locale.ENGLISH, "%02d", h)).append("h : ");
                sb1.append(String.format(Locale.ENGLISH, "%02d", m)).append("m :");

                binding.countdownMainText.setText(sb1.toString());
                binding.countdownMainText.setTextColor(Color.parseColor("#0F172A"));
                binding.countdownSecText.setText(String.format(Locale.ENGLISH, "%02d", s) + "s");
                binding.countdownSecText.setVisibility(View.VISIBLE);
                binding.countdownSecText.setTextColor(Color.parseColor("#E11D48"));
            }

            @Override
            public void onFinish() {
                binding.countdownMainText.setText("MATCH START");
                binding.countdownMainText.setTextColor(Color.parseColor("#EF4444"));
                binding.countdownSecText.setVisibility(View.GONE);
            }
        }.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) countDownTimer.cancel();
        stopSlotPolling();
    }

    // ============================================================
    //  DIALOGS / MISC
    // ============================================================

    private void showErrorDialog(String message) {
        new PremiumDialog.Builder(this)
                .setDialogType(true)
                .setCancelable(false)
                .setBlurBackground(true)
                .setLottie("faild.json")
                .setTitle("Failed")
                .setMessage(message)
                .setPositiveButton("Okay", "#EF4444", Dialog::dismiss)
                .setNegativeButton("Close", Dialog::dismiss)
                .show();
    }

    /**
     * Shown whenever we detect (via polling, the pre-confirm check, or the server's
     * own "Slot Already Taken" response) that a slot the user had selected got taken
     * by someone else in the meantime. Always resets back to step 1 with the taken
     * slot(s) already removed from selection before this shows, so both actions just
     * need to dismiss - "Refresh" also forces one more fetch in case even more slots
     * were taken while this dialog was on screen.
     */
    private void showSlotConflictDialog() {
    if (isFinishing() || isDestroyed()) {
        return;
    }

    runOnUiThread(() -> {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        new PremiumDialog.Builder(this)
                .setDialogType(true)
                .setCancelable(false)
                .setBlurBackground(true)
                .setLottie("faild.json")
                .setTitle("স্লট নেওয়া হয়ে গেছে")
                .setMessage("এই স্লট অন্য প্লেয়ার জয়েন করছে! রিফ্রেশ করে আবার চেষ্টা করুন অথবা অন্য স্লট বুক করুন।")
                .setPositiveButton("রিফ্রেশ করুন", "#6D28D9", dialog -> {
                    dialog.dismiss();

                    if (!isFinishing() && !isDestroyed()) {
                        fetchTakenSlots();
                    }
                })
                .setNegativeButton("অন্য স্লট বুক করুন", dialog -> {
                    dialog.dismiss();
                })
                .show();
    });
}

    private void showLoadingDialog(String message) {
        hideLoadingDialog();
        loadingDialog = new BottomSheetDialog(this, R.style.Theme_Design_BottomSheetDialog);
        applyBlurEffect(loadingDialog);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(16), dp(24), dp(32));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadii(new float[]{dp(32), dp(32), dp(32), dp(32), 0, 0, 0, 0});
        root.setBackground(bg);

        View handle = new View(this);
        GradientDrawable handleBg = new GradientDrawable();
        handleBg.setColor(Color.parseColor("#E2E8F0"));
        handleBg.setCornerRadius(dp(4));
        handle.setBackground(handleBg);
        LinearLayout.LayoutParams handleParams = new LinearLayout.LayoutParams(dp(44), dp(5));
        handleParams.gravity = Gravity.CENTER_HORIZONTAL;
        handleParams.bottomMargin = dp(16);
        handle.setLayoutParams(handleParams);

        TextView title = new TextView(this);
        title.setText("Please wait");
        title.setTextSize(20f);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setTextColor(Color.parseColor("#0F172A"));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(20), 0, dp(8));
        row.setGravity(Gravity.CENTER_VERTICAL);

        ProgressBar progressBar = new ProgressBar(this);
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(dp(32), dp(32)));

        TextView msg = new TextView(this);
        msg.setText(message);
        msg.setTextSize(16f);
        msg.setTextColor(Color.parseColor("#475569"));
        LinearLayout.LayoutParams msgParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        msgParams.leftMargin = dp(16);
        msg.setLayoutParams(msgParams);

        row.addView(progressBar);
        row.addView(msg);
        root.addView(handle);
        root.addView(title);
        root.addView(row);

        loadingDialog.setContentView(root);
        loadingDialog.setCancelable(false);
        loadingDialog.setCanceledOnTouchOutside(false);
        loadingDialog.show();
    }

    private void hideLoadingDialog() {
        try {
            if (loadingDialog != null && loadingDialog.isShowing()) loadingDialog.dismiss();
        } catch (Exception ignored) {
        }
        loadingDialog = null;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private String safe(String s) {
        return s == null ? "" : s.trim();
    }
}