package com.khelosobaiv3.user;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class CustomBottomSheet {

    public interface OnButtonClickListener {
        void onClick(BottomSheetDialog dialog);
    }

    public static void show(Activity activity, String title, String message, String lottieFileName,
                            String buttonText, String buttonColor, String buttonTextColor,
                            boolean isBlur, boolean isCancelable, OnButtonClickListener listener) {

        BottomSheetDialog dialog = new BottomSheetDialog(activity, R.style.TransparentBottomSheetDialogTheme);
        View view = activity.getLayoutInflater().inflate(R.layout.layout_bottom_sheet, null);
        dialog.setContentView(view);

        dialog.setCancelable(isCancelable);
        dialog.setCanceledOnTouchOutside(isCancelable);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);

            if (isBlur) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                
                ViewGroup decorView = (ViewGroup) window.getDecorView();
                BlurView blurView = new BlurView(activity);
                decorView.addView(blurView, 0, new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 
                        ViewGroup.LayoutParams.MATCH_PARENT
                ));

                ViewGroup activityRoot = activity.findViewById(android.R.id.content);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    blurView.setupWith(activityRoot, new RenderEffectBlur())
                            .setFrameClearDrawable(new ColorDrawable(Color.TRANSPARENT))
                            .setBlurRadius(2f); 
                } else {
                    blurView.setupWith(activityRoot, new RenderScriptBlur(activity))
                            .setFrameClearDrawable(new ColorDrawable(Color.TRANSPARENT))
                            .setBlurRadius(2f); 
                }
                
               
                blurView.setOverlayColor(Color.TRANSPARENT); 

            } else {
                window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                window.setDimAmount(0.6f);
            }
        }

        View bottomSheetParent = (View) view.getParent();
        if (bottomSheetParent != null) {
            bottomSheetParent.setBackgroundColor(Color.TRANSPARENT);
        }

        LinearLayout root = view.findViewById(R.id.bottom_sheet_root);
        View dragHandle = view.findViewById(R.id.drag_handle);
        LottieAnimationView lottieView = view.findViewById(R.id.lottie_view);
        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvMessage = view.findViewById(R.id.tv_message);
        MaterialButton btnAction = view.findViewById(R.id.btn_action);

        GradientDrawable rootBackground = new GradientDrawable();
        rootBackground.setColor(Color.parseColor("#FFFFFF"));
        rootBackground.setCornerRadii(new float[]{80f, 80f, 80f, 80f, 0f, 0f, 0f, 0f});
        root.setBackground(rootBackground);

        GradientDrawable handleBackground = new GradientDrawable();
        handleBackground.setColor(Color.parseColor("#E5E7EB"));
        handleBackground.setCornerRadius(20f);
        dragHandle.setBackground(handleBackground);

        btnAction.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(buttonColor)));

        lottieView.setAnimation(lottieFileName);
        tvTitle.setText(title);
        tvMessage.setText(message);

        btnAction.setText(buttonText);
        btnAction.setTextColor(Color.parseColor(buttonTextColor));

        btnAction.setOnClickListener(v -> {
            if (listener != null) {
                listener.onClick(dialog);
            } else {
                dialog.dismiss();
            }
        });

        dialog.show();
    }
}
