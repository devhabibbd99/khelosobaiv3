package com.khelosobaiv3.user;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderEffectBlur;
import eightbitlab.com.blurview.RenderScriptBlur;

public class CheckoutHelper {

    public static boolean SHOW_PHONE_NUMBER = true;
    public static boolean REQUIRE_PHONE_NUMBER = true;
    public static boolean SHOW_LOCAL_LOCATION = true;
    public static boolean HIDE_DISTRICT_UPAZILA = false;
    public static boolean REQUIRE_LOCAL_LOCATION = false;

    private static final List<GeoItem> divisionsList = new ArrayList<>();
    private static final Map<String, List<GeoItem>> districtsMap = new HashMap<>();
    private static final Map<String, List<GeoItem>> upazilasMap = new HashMap<>();
    private static final Map<String, List<GeoItem>> unionsMap = new HashMap<>();
    private static boolean isDataLoaded = false;

    static class GeoItem {
        String id, parentId, nameEn, nameBn;

        GeoItem(String id, String parentId, String nameEn, String nameBn) {
            this.id = id;
            this.parentId = parentId;
            this.nameEn = nameEn;
            this.nameBn = nameBn;
        }

        @Override
        public String toString() {
            return nameBn;
        }
    }

    private static String loadJSONFromAsset(Context context, String fileName) {
        String json = null;
        try {
            InputStream is = context.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return json;
    }

    private static JSONArray getTableData(String json) throws Exception {
        if (json == null) return new JSONArray();
        JSONArray root = new JSONArray(json);
        for (int i = 0; i < root.length(); i++) {
            JSONObject item = root.getJSONObject(i);
            if (item.has("type") && "table".equals(item.getString("type")) && item.has("data")) {
                return item.getJSONArray("data");
            }
        }
        return new JSONArray();
    }

    private static void loadGeoData(Context context, Runnable onComplete) {
        if (isDataLoaded) {
            new Handler(Looper.getMainLooper()).post(onComplete);
            return;
        }

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                if (!isDataLoaded) {
                    divisionsList.clear();
                    districtsMap.clear();
                    upazilasMap.clear();
                    unionsMap.clear();

                    JSONArray divArr = getTableData(loadJSONFromAsset(context, "divisions.json"));
                    for (int i = 0; i < divArr.length(); i++) {
                        JSONObject obj = divArr.getJSONObject(i);
                        divisionsList.add(new GeoItem(obj.getString("id"), "", obj.getString("name"), obj.getString("bn_name")));
                    }

                    JSONArray distArr = getTableData(loadJSONFromAsset(context, "districts.json"));
                    for (int i = 0; i < distArr.length(); i++) {
                        JSONObject obj = distArr.getJSONObject(i);
                        String divId = obj.getString("division_id");
                        if (!districtsMap.containsKey(divId)) districtsMap.put(divId, new ArrayList<>());
                        districtsMap.get(divId).add(new GeoItem(obj.getString("id"), divId, obj.getString("name"), obj.getString("bn_name")));
                    }

                    JSONArray upzArr = getTableData(loadJSONFromAsset(context, "upazilas.json"));
                    for (int i = 0; i < upzArr.length(); i++) {
                        JSONObject obj = upzArr.getJSONObject(i);
                        String distId = obj.getString("district_id");
                        if (!upazilasMap.containsKey(distId)) upazilasMap.put(distId, new ArrayList<>());
                        upazilasMap.get(distId).add(new GeoItem(obj.getString("id"), distId, obj.getString("name"), obj.getString("bn_name")));
                    }

                    JSONArray unArr = getTableData(loadJSONFromAsset(context, "unions.json"));
                    for (int i = 0; i < unArr.length(); i++) {
                        JSONObject obj = unArr.getJSONObject(i);
                        String upzId = obj.getString("upazilla_id");
                        if (!unionsMap.containsKey(upzId)) unionsMap.put(upzId, new ArrayList<>());
                        unionsMap.get(upzId).add(new GeoItem(obj.getString("id"), upzId, obj.getString("name"), obj.getString("bn_name")));
                    }
                    isDataLoaded = true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            new Handler(Looper.getMainLooper()).post(onComplete);
        });
    }

    public static void showCheckoutBottomSheet(Activity activity, String productId, String userToken, String productName, String productImageUrl, double unitPrice, int quantity, double deliveryFee, boolean isHomeDelivery) {
        try {
            View view = LayoutInflater.from(activity).inflate(R.layout.bottom_sheet_checkout, null);
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(activity, com.google.android.material.R.style.Theme_Design_BottomSheetDialog);
            bottomSheetDialog.setContentView(view);
            bottomSheetDialog.setOnShowListener(dialog -> {
                BottomSheetDialog d = (BottomSheetDialog) dialog;
                View bottomSheetInternal = d.findViewById(com.google.android.material.R.id.design_bottom_sheet);
                if (bottomSheetInternal != null)
                    bottomSheetInternal.setBackgroundColor(Color.TRANSPARENT);
            });

            BlurView blurView = view.findViewById(R.id.blurView);
            if (blurView != null) {
                ViewGroup decorView = (ViewGroup) activity.getWindow().getDecorView();
                Drawable windowBackground = decorView.getBackground();
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        blurView.setupWith(decorView, new RenderEffectBlur()).setFrameClearDrawable(windowBackground).setBlurRadius(20f);
                    } else {
                        blurView.setupWith(decorView, new RenderScriptBlur(activity)).setFrameClearDrawable(windowBackground).setBlurRadius(20f);
                    }
                } catch (Exception e) {
                    blurView.setBackgroundColor(Color.parseColor("#CCFFFFFF"));
                }
            }

            double orderAmount = unitPrice * quantity;
            double totalAmount = orderAmount + deliveryFee;

            ImageView ivProductImage = view.findViewById(R.id.ivProductImage);
            ProgressBar pbImageLoading = view.findViewById(R.id.pbImageLoading);
            TextView tvProductName = view.findViewById(R.id.tvProductName);
            TextView tvProductPriceTop = view.findViewById(R.id.tvProductPriceTop);
            TextView tvProductQuantity = view.findViewById(R.id.tvProductQuantity);

            if (tvProductName != null) tvProductName.setText(productName);
            if (tvProductPriceTop != null) tvProductPriceTop.setText("৳ " + unitPrice);
            if (tvProductQuantity != null)
                tvProductQuantity.setText("Quantity: " + quantity + " Item(s)");

            if (ivProductImage != null && productImageUrl != null && !productImageUrl.isEmpty()) {
                ivProductImage.setImageBitmap(null);
                if (pbImageLoading != null) pbImageLoading.setVisibility(View.VISIBLE);

                Executors.newSingleThreadExecutor().execute(() -> {
                    try {
                        URL url = new URL(productImageUrl);
                        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                        connection.setDoInput(true);
                        connection.setConnectTimeout(8000);
                        connection.setReadTimeout(8000);
                        connection.connect();
                        InputStream input = connection.getInputStream();
                        final Bitmap bitmap = BitmapFactory.decodeStream(input);
                        input.close();

                        new Handler(Looper.getMainLooper()).post(() -> {
                            if (bitmap != null) {
                                ivProductImage.setImageBitmap(bitmap);
                            }
                            if (pbImageLoading != null) pbImageLoading.setVisibility(View.GONE);
                        });
                    } catch (Exception e) {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            if (pbImageLoading != null) pbImageLoading.setVisibility(View.GONE);
                        });
                    }
                });
            }

            TextInputLayout layoutDivision = view.findViewById(R.id.layoutDivision);
            TextInputLayout layoutDistrict = view.findViewById(R.id.layoutDistrict);
            TextInputLayout layoutUpazila = view.findViewById(R.id.layoutUpazila);
            TextInputLayout layoutUnion = view.findViewById(R.id.layoutUnion);
            TextInputLayout layoutPhoneNumber = view.findViewById(R.id.layoutPhoneNumber);
            TextInputLayout layoutLocalLocation = view.findViewById(R.id.layoutLocalLocation);

            AutoCompleteTextView autoCompleteDivision = view.findViewById(R.id.autoCompleteDivision);
            AutoCompleteTextView autoCompleteDistrict = view.findViewById(R.id.autoCompleteDistrict);
            AutoCompleteTextView autoCompleteUpazila = view.findViewById(R.id.autoCompleteUpazila);
            AutoCompleteTextView autoCompleteUnion = view.findViewById(R.id.autoCompleteUnion);

            TextInputEditText etPhoneNumber = view.findViewById(R.id.etPhoneNumber);
            TextInputEditText etLocalLocation = view.findViewById(R.id.etLocalLocation);

            TextView tvAmount = view.findViewById(R.id.tvAmount);
            TextView tvDeliveryFee = view.findViewById(R.id.tvDeliveryFee);
            TextView tvTotalAmount = view.findViewById(R.id.tvTotalAmount);
            RadioGroup radioGroupPayment = view.findViewById(R.id.radioGroupPayment);
            MaterialCardView layoutDeliveryInfo = view.findViewById(R.id.layoutDeliveryInfo);
            TextView tvDeliveryInfoText = view.findViewById(R.id.tvDeliveryInfoText);
            MaterialButton btnConfirmOrder = view.findViewById(R.id.btnConfirmOrder);
            RadioButton rbCashMoney = view.findViewById(R.id.rbCashMoney);
            RadioButton rbAppWallet = view.findViewById(R.id.rbAppWallet);

            if (layoutPhoneNumber != null) {
                layoutPhoneNumber.setVisibility(SHOW_PHONE_NUMBER ? View.VISIBLE : View.GONE);
            }

            if (layoutLocalLocation != null) {
                layoutLocalLocation.setVisibility(SHOW_LOCAL_LOCATION ? View.VISIBLE : View.GONE);
            }

            if (HIDE_DISTRICT_UPAZILA) {
                if (layoutDivision != null) layoutDivision.setVisibility(View.GONE);
                if (layoutDistrict != null) layoutDistrict.setVisibility(View.GONE);
                if (layoutUpazila != null) layoutUpazila.setVisibility(View.GONE);
                if (layoutUnion != null) layoutUnion.setVisibility(View.GONE);
            } else {
                if (layoutDivision != null) layoutDivision.setVisibility(View.VISIBLE);
            }

            if (tvAmount != null)
                tvAmount.setText("৳ " + orderAmount + " (৳" + unitPrice + " x " + quantity + ")");
            if (tvDeliveryFee != null)
                tvDeliveryFee.setText(deliveryFee == 0 ? "Free" : "৳ " + deliveryFee);
            if (tvTotalAmount != null) tvTotalAmount.setText("৳ " + totalAmount);
            if (tvDeliveryInfoText != null)
                tvDeliveryInfoText.setText("পণ্যের টাকা (৳" + totalAmount + ") ডেলিভারির সময় নেওয়া হবে।\nProduct amount collected on delivery.");

            if (radioGroupPayment != null && layoutDeliveryInfo != null) {
                radioGroupPayment.setOnCheckedChangeListener((group, checkedId) -> {
                    if (checkedId == R.id.rbCashMoney && isHomeDelivery)
                        layoutDeliveryInfo.setVisibility(View.VISIBLE);
                    else layoutDeliveryInfo.setVisibility(View.GONE);
                });
            }

            if (!isHomeDelivery) {
                if (layoutDeliveryInfo != null) layoutDeliveryInfo.setVisibility(View.GONE);
                if (rbCashMoney != null) rbCashMoney.setVisibility(View.GONE);
                if (radioGroupPayment != null && rbAppWallet != null)
                    radioGroupPayment.check(R.id.rbAppWallet);
            }

            final GeoItem[] selectedLocation = new GeoItem[4];

            if (!HIDE_DISTRICT_UPAZILA && autoCompleteDivision != null) {
                autoCompleteDivision.setEnabled(false);
                autoCompleteDivision.setText("Loading Data...", false);

                loadGeoData(activity, () -> {
                    autoCompleteDivision.setText("", false);
                    autoCompleteDivision.setEnabled(true);
                    ArrayAdapter<GeoItem> divisionAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_dropdown_item_1line, divisionsList);
                    autoCompleteDivision.setAdapter(divisionAdapter);
                });

                autoCompleteDivision.setOnItemClickListener((parent, view1, position, id) -> {
                    GeoItem div = (GeoItem) parent.getItemAtPosition(position);
                    selectedLocation[0] = div;
                    selectedLocation[1] = null;
                    selectedLocation[2] = null;
                    selectedLocation[3] = null;

                    if (autoCompleteDistrict != null) autoCompleteDistrict.setText("", false);
                    if (autoCompleteUpazila != null) autoCompleteUpazila.setText("", false);
                    if (autoCompleteUnion != null) autoCompleteUnion.setText("", false);

                    if (layoutDistrict != null) layoutDistrict.setVisibility(View.VISIBLE);
                    if (layoutUpazila != null) layoutUpazila.setVisibility(View.GONE);
                    if (layoutUnion != null) layoutUnion.setVisibility(View.GONE);

                    List<GeoItem> districts = districtsMap.get(div.id);
                    if (districts != null && autoCompleteDistrict != null) {
                        ArrayAdapter<GeoItem> districtAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_dropdown_item_1line, districts);
                        autoCompleteDistrict.setAdapter(districtAdapter);
                    }
                });
            }

            if (!HIDE_DISTRICT_UPAZILA && autoCompleteDistrict != null) {
                autoCompleteDistrict.setOnItemClickListener((parent, view12, position, id) -> {
                    GeoItem dist = (GeoItem) parent.getItemAtPosition(position);
                    selectedLocation[1] = dist;
                    selectedLocation[2] = null;
                    selectedLocation[3] = null;

                    if (autoCompleteUpazila != null) autoCompleteUpazila.setText("", false);
                    if (autoCompleteUnion != null) autoCompleteUnion.setText("", false);

                    if (layoutUpazila != null) layoutUpazila.setVisibility(View.VISIBLE);
                    if (layoutUnion != null) layoutUnion.setVisibility(View.GONE);

                    List<GeoItem> upazilas = upazilasMap.get(dist.id);
                    if (upazilas != null && autoCompleteUpazila != null) {
                        ArrayAdapter<GeoItem> upazilaAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_dropdown_item_1line, upazilas);
                        autoCompleteUpazila.setAdapter(upazilaAdapter);
                    }
                });
            }

            if (!HIDE_DISTRICT_UPAZILA && autoCompleteUpazila != null) {
                autoCompleteUpazila.setOnItemClickListener((parent, view13, position, id) -> {
                    GeoItem upz = (GeoItem) parent.getItemAtPosition(position);
                    selectedLocation[2] = upz;
                    selectedLocation[3] = null;

                    if (autoCompleteUnion != null) autoCompleteUnion.setText("", false);
                    if (layoutUnion != null) layoutUnion.setVisibility(View.VISIBLE);

                    List<GeoItem> unions = unionsMap.get(upz.id);
                    if (unions != null && autoCompleteUnion != null) {
                        ArrayAdapter<GeoItem> unionAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_dropdown_item_1line, unions);
                        autoCompleteUnion.setAdapter(unionAdapter);
                    } else if (autoCompleteUnion != null) {
                        autoCompleteUnion.setAdapter(null);
                    }
                });
            }

            if (!HIDE_DISTRICT_UPAZILA && autoCompleteUnion != null) {
                autoCompleteUnion.setOnItemClickListener((parent, view14, position, id) -> {
                    selectedLocation[3] = (GeoItem) parent.getItemAtPosition(position);
                });
            }

            if (btnConfirmOrder != null) {
                btnConfirmOrder.setOnClickListener(v -> {
                    String phoneNumberStr = "";
                    if (etPhoneNumber != null && etPhoneNumber.getText() != null) {
                        phoneNumberStr = etPhoneNumber.getText().toString().trim();
                    }

                    String localLocationStr = "";
                    if (etLocalLocation != null && etLocalLocation.getText() != null) {
                        localLocationStr = etLocalLocation.getText().toString().trim();
                    }

                    if (SHOW_PHONE_NUMBER && REQUIRE_PHONE_NUMBER) {
                        if (phoneNumberStr.isEmpty()) {
                            if (layoutPhoneNumber != null) layoutPhoneNumber.setError("Phone number is required");
                            Toast.makeText(activity, "Phone number is required!", Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            if (layoutPhoneNumber != null) layoutPhoneNumber.setError(null);
                        }
                    }

                    if (SHOW_LOCAL_LOCATION && REQUIRE_LOCAL_LOCATION) {
                        if (localLocationStr.isEmpty()) {
                            if (layoutLocalLocation != null) layoutLocalLocation.setError("Local location is required");
                            Toast.makeText(activity, "Local location is required!", Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            if (layoutLocalLocation != null) layoutLocalLocation.setError(null);
                        }
                    }

                    if (!HIDE_DISTRICT_UPAZILA) {
                        if (selectedLocation[0] == null || selectedLocation[1] == null || selectedLocation[2] == null || selectedLocation[3] == null) {
                            Toast.makeText(activity, "দয়া করে সম্পূর্ণ ঠিকানা (ইউনিয়ন সহ) প্রদান করুন!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }

                    String finalAddressToSave = "";

                    if (!HIDE_DISTRICT_UPAZILA && selectedLocation[0] != null && selectedLocation[1] != null && selectedLocation[2] != null && selectedLocation[3] != null) {
                        finalAddressToSave = selectedLocation[3].nameBn + ", " + selectedLocation[2].nameBn + ", " + selectedLocation[1].nameBn + ", " + selectedLocation[0].nameBn;
                    }

                    if (SHOW_LOCAL_LOCATION && !localLocationStr.isEmpty()) {
                        if (!finalAddressToSave.isEmpty()) {
                            finalAddressToSave += " | Local Location: ";
                        } else {
                            finalAddressToSave = "Local Location: ";
                        }
                        finalAddressToSave += localLocationStr;
                    }

                    if (finalAddressToSave.isEmpty()) {
                        finalAddressToSave = "N/A";
                    }

                    if (userToken == null || userToken.isEmpty() || productId == null || productId.isEmpty() || productId.equals("0")) {
                        Toast.makeText(activity, "Authentication Error: Login and select product again.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int selectedPaymentId = (radioGroupPayment != null) ? radioGroupPayment.getCheckedRadioButtonId() : -1;
                    String paymentMethod = (selectedPaymentId == R.id.rbAppWallet) ? "App Wallet" : "Cash On Delivery";

                    JSONObject extraJson = new JSONObject();
                    try {
                        extraJson.put("quantity", quantity);
                        extraJson.put("unit_price", unitPrice);
                        extraJson.put("delivery_fee", deliveryFee);
                        extraJson.put("total_amount", totalAmount);
                        extraJson.put("payment_method", paymentMethod);
                        if (SHOW_PHONE_NUMBER && !phoneNumberStr.isEmpty()) {
                            extraJson.put("phone_number", phoneNumberStr);
                        }
                        if (SHOW_LOCAL_LOCATION && !localLocationStr.isEmpty()) {
                            extraJson.put("local_location", localLocationStr);
                        }
                    } catch (Exception e) {
                    }

                    btnConfirmOrder.setEnabled(false);
                    btnConfirmOrder.setText("Processing...");

                    String url = "https://api.khelosobai20.live/ElitegoxUser/orderproducts.php";
                    String finalAddressParams = finalAddressToSave;

                    StringRequest request = new StringRequest(Request.Method.POST, url,
                            response -> {
                                btnConfirmOrder.setEnabled(true);
                                btnConfirmOrder.setText("Confirm Order");
                                String res = response.trim();
                                if (res.equals("Order Successfully")) {
                                    bottomSheetDialog.dismiss();
                                    new com.khelosobaiv3.user.PremiumDialog.Builder(activity)
                                            .setDialogType(true)
                                            .setLottie("success.json")
                                            .setTitle("Success!")
                                            .setMessage("Order Placed Successfully")
                                            .setPositiveButton("OK", "#10B981", d -> {
                                                d.dismiss();
                                                activity.finish();
                                            })
                                            .setCancelable(false)
                                            .show();
                                } else {
                                    Toast.makeText(activity, res, Toast.LENGTH_LONG).show();
                                }
                            },
                            error -> {
                                btnConfirmOrder.setEnabled(true);
                                btnConfirmOrder.setText("Confirm Order");
                                Toast.makeText(activity, "Network error occurred", Toast.LENGTH_SHORT).show();
                            }
                    ) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<>();
                            params.put("token", userToken);
                            params.put("product_id", productId);
                            params.put("address", finalAddressParams);
                            params.put("extra_json", extraJson.toString());
                            return params;
                        }
                    };
                    Volley.newRequestQueue(activity).add(request);
                });
            }

            if (!activity.isFinishing()) {
                bottomSheetDialog.show();
            }

        } catch (Exception e) {
            Toast.makeText(activity, "Error Loading Checkout: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}