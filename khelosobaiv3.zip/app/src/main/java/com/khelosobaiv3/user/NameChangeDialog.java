package com.khelosobaiv3.user;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NameChangeDialog {

    private final Activity activity;
    private String title = "Change Player Name";
    private String subtitle = "Update the display name for this slot.";
    private boolean useBlur = false;
    private String hintText = "e.g. Alex Hunter";
    private String defaultText = "";
    private String buttonText = "Save changes";
    private String feeNoticeText = null; // ফি সংক্রান্ত মেসেজ

    private FrameLayout dialogRoot;
    private View overlay;
    private ImageView blurOverlay;
    private LinearLayout dialogContainer;
    private EditText editTextBox;

    private OnNameChangeAction actionListener;

    // Material 3 Light Theme Colors (Google Standard)
    private final int M3_PRIMARY = 0xFF6750A4;
    private final int M3_PRIMARY_CONTAINER = 0xFFEADDFF;
    private final int M3_SURFACE = 0xFFFEF7FF;
    private final int M3_ON_SURFACE = 0xFF1D1B20;
    private final int M3_ON_SURFACE_VARIANT = 0xFF49454F;
    private final int M3_OUTLINE = 0xFF79747E;
    private final int M3_OUTLINE_VARIANT = 0xFFCAC4D0;
    private final int M3_INFO_BG = 0xFFFFF3E0;   // হালকা অ্যাম্বার ব্যাকগ্রাউন্ড (নোটিশের জন্য)
    private final int M3_INFO_TEXT = 0xFFB45309; // গাঢ় অ্যাম্বার টেক্সট

    public interface OnNameChangeAction {
        void onAction(String name);
    }

    public NameChangeDialog(Activity activity) {
        this.activity = activity;
    }

    public NameChangeDialog setTitle(String title) {
        this.title = title;
        return this;
    }

    public NameChangeDialog setSubtitle(String subtitle) {
        this.subtitle = subtitle;
        return this;
    }

    public NameChangeDialog setBlurOverlay(boolean blur) {
        this.useBlur = blur;
        return this;
    }

    public NameChangeDialog setField(String hint, String defaultText) {
        this.hintText = hint;
        this.defaultText = defaultText;
        return this;
    }

    public NameChangeDialog setButtonText(String text) {
        this.buttonText = text;
        return this;
    }

    /**
     * নোটিশ মেসেজ সেট করুন (যেমন: ফি বা সতর্কতা)।
     * null দিলে নোটিশ দেখানো হবে না।
     */
    public NameChangeDialog setFeeNotice(String notice) {
        this.feeNoticeText = notice;
        return this;
    }

    public NameChangeDialog setActionListener(OnNameChangeAction listener) {
        this.actionListener = listener;
        return this;
    }

    public void show() {
        ViewGroup contentRoot = activity.findViewById(android.R.id.content);
        dialogRoot = new FrameLayout(activity);
        dialogRoot.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));

        createBlurAndOverlay(contentRoot);
        createBottomSheet();

        contentRoot.addView(dialogRoot);
        animateIn();
    }

    private void createBlurAndOverlay(ViewGroup contentRoot) {
        if (useBlur) {
            Bitmap blurred = getBlurredScreen(contentRoot);
            if (blurred != null) {
                blurOverlay = new ImageView(activity);
                blurOverlay.setImageBitmap(blurred);
                blurOverlay.setScaleType(ImageView.ScaleType.CENTER_CROP);
                blurOverlay.setAlpha(0f);
                dialogRoot.addView(blurOverlay, new FrameLayout.LayoutParams(-1, -1));
            }
        }

        overlay = new View(activity);
        overlay.setBackgroundColor(0x66000000);
        overlay.setAlpha(0f);
        overlay.setOnClickListener(v -> animateOut());
        dialogRoot.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
    }

    @SuppressLint("ClickableViewAccessibility")
    private void createBottomSheet() {
        dialogContainer = new LinearLayout(activity);
        dialogContainer.setOrientation(LinearLayout.VERTICAL);
        dialogContainer.setPadding(dp(24), dp(16), dp(24), dp(48));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(M3_SURFACE);
        float r = dp(28);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        dialogContainer.setBackground(bg);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            dialogContainer.setElevation(dp(16));
        }

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-1, -2);
        params.gravity = Gravity.BOTTOM;
        dialogContainer.setLayoutParams(params);

        // Drag Handle
        View dragHandle = new View(activity);
        GradientDrawable handleBg = new GradientDrawable();
        handleBg.setColor(M3_OUTLINE_VARIANT);
        handleBg.setCornerRadius(dp(10));
        dragHandle.setBackground(handleBg);
        LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(dp(32), dp(4));
        handleLp.gravity = Gravity.CENTER_HORIZONTAL;
        handleLp.bottomMargin = dp(24);
        dragHandle.setLayoutParams(handleLp);
        dialogContainer.addView(dragHandle);

        // Title
        TextView tvTitle = new TextView(activity);
        tvTitle.setText(title);
        tvTitle.setTextColor(M3_ON_SURFACE);
        tvTitle.setTextSize(22);
        tvTitle.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        dialogContainer.addView(tvTitle);

        // Subtitle
        TextView tvSub = new TextView(activity);
        tvSub.setText(subtitle);
        tvSub.setTextColor(M3_ON_SURFACE_VARIANT);
        tvSub.setTextSize(14);
        tvSub.setPadding(0, dp(4), 0, dp(16));
        tvSub.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        dialogContainer.addView(tvSub);

        // ========== ফি নোটিশ (শুধুমাত্র মেসেজ থাকলে দেখাবে) ==========
        if (feeNoticeText != null && !feeNoticeText.isEmpty()) {
            dialogContainer.addView(createFeeNoticeCard());
        }

        // Input Field (Player name)
        LinearLayout inputOuterWrapper = new LinearLayout(activity);
        inputOuterWrapper.setOrientation(LinearLayout.HORIZONTAL);
        inputOuterWrapper.setGravity(Gravity.CENTER_VERTICAL);
        inputOuterWrapper.setBackground(createM3InputBg(false));
        inputOuterWrapper.setPadding(dp(16), dp(8), dp(16), dp(8));
        inputOuterWrapper.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        // Left Icon
        SimpleUserIcon userIcon = new SimpleUserIcon(activity, dp(24), M3_ON_SURFACE_VARIANT);
        inputOuterWrapper.addView(userIcon);

        // Inner Vertical Layout for Label + Input
        LinearLayout textWrapper = new LinearLayout(activity);
        textWrapper.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams twLp = new LinearLayout.LayoutParams(0, -2, 1f);
        twLp.leftMargin = dp(16);
        textWrapper.setLayoutParams(twLp);

        // Inner Label
        TextView innerLabel = new TextView(activity);
        innerLabel.setText("Player name");
        innerLabel.setTextColor(M3_ON_SURFACE_VARIANT);
        innerLabel.setTextSize(12);
        innerLabel.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textWrapper.addView(innerLabel);

        // The Actual EditText
        editTextBox = new EditText(activity);
        editTextBox.setHint(hintText);
        editTextBox.setText(defaultText);
        editTextBox.setBackgroundColor(Color.TRANSPARENT);
        editTextBox.setHintTextColor(M3_OUTLINE);
        editTextBox.setTextColor(M3_ON_SURFACE);
        editTextBox.setTextSize(16);
        editTextBox.setPadding(0, dp(2), 0, dp(2));
        editTextBox.setSingleLine(true);
        editTextBox.setInputType(InputType.TYPE_CLASS_TEXT);
        editTextBox.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        textWrapper.addView(editTextBox);

        // Focus State
        editTextBox.setOnFocusChangeListener((v, hasFocus) -> {
            inputOuterWrapper.setBackground(createM3InputBg(hasFocus));
            innerLabel.setTextColor(hasFocus ? M3_PRIMARY : M3_ON_SURFACE_VARIANT);
            userIcon.setColor(hasFocus ? M3_PRIMARY : M3_ON_SURFACE_VARIANT);
        });

        inputOuterWrapper.addView(textWrapper);
        dialogContainer.addView(inputOuterWrapper);

        // Spacing
        dialogContainer.addView(createSpace(dp(32)));

        // Save Button (Filled, Pill Shape)
        LinearLayout finalBtn = new LinearLayout(activity);
        finalBtn.setGravity(Gravity.CENTER);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(M3_PRIMARY);
        btnBg.setCornerRadius(dp(100));
        finalBtn.setBackground(btnBg);
        finalBtn.setPadding(0, dp(14), 0, dp(14));
        finalBtn.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        TextView btnTv = new TextView(activity);
        btnTv.setText(buttonText);
        btnTv.setTextColor(Color.WHITE);
        btnTv.setTextSize(15);
        btnTv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        finalBtn.addView(btnTv);

        finalBtn.setOnTouchListener(new BouncyTouchListener(() -> {
            hideKeyboard();
            if (actionListener != null) {
                actionListener.onAction(editTextBox.getText().toString().trim());
            }
            animateOut();
        }));

        dialogContainer.addView(finalBtn);

        // Initial Position
        dialogContainer.setTranslationY(2000f);
        dialogRoot.addView(dialogContainer);
    }

    /**
     * ফি নোটিশ কার্ড তৈরি করে (আইকন + টেক্সট)।
     */
    private View createFeeNoticeCard() {
        // Outer horizontal LinearLayout with rounded background
        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(12), dp(16), dp(12));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(M3_INFO_BG);
        cardBg.setCornerRadius(dp(16));
        card.setBackground(cardBg);

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.bottomMargin = dp(24); // নিচে ইনপুট ফিল্ড থেকে গ্যাপ
        card.setLayoutParams(cardParams);

        // ইনফো আইকন (ছোট গোলাকার ভিউ)
        InfoIconView infoIcon = new InfoIconView(activity, dp(20), M3_INFO_TEXT);
        card.addView(infoIcon);

        // টেক্সট
        TextView tvFee = new TextView(activity);
        tvFee.setText(feeNoticeText);
        tvFee.setTextColor(M3_INFO_TEXT);
        tvFee.setTextSize(14);
        tvFee.setPadding(dp(8), 0, 0, 0);
        tvFee.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        card.addView(tvFee);

        return card;
    }

    // --- Dynamic Background for M3 Outlined TextField ---
    private GradientDrawable createM3InputBg(boolean focused) {
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(dp(16));
        if (focused) {
            gd.setColor(M3_PRIMARY_CONTAINER);
            gd.setStroke(dp(2), M3_PRIMARY);
        } else {
            gd.setColor(Color.WHITE);
            gd.setStroke(dp(1), M3_OUTLINE);
        }
        return gd;
    }

    private void animateIn() {
        overlay.animate().alpha(1f).setDuration(300).start();
        if (blurOverlay != null) blurOverlay.animate().alpha(1f).setDuration(300).start();

        dialogContainer.post(() -> {
            dialogContainer.setTranslationY(dialogContainer.getHeight());
            dialogContainer.animate()
                    .translationY(0)
                    .setDuration(350)
                    .setInterpolator(new DecelerateInterpolator(1.5f))
                    .withEndAction(this::showKeyboard)
                    .start();
        });
    }

    private void animateOut() {
        hideKeyboard();
        overlay.animate().alpha(0f).setDuration(250).start();
        if (blurOverlay != null) blurOverlay.animate().alpha(0f).setDuration(250).start();

        dialogContainer.animate()
                .translationY(dialogContainer.getHeight())
                .setDuration(300)
                .setInterpolator(new AccelerateInterpolator(1.2f))
                .withEndAction(() -> {
                    ViewGroup contentRoot = activity.findViewById(android.R.id.content);
                    contentRoot.removeView(dialogRoot);
                }).start();
    }

    private void showKeyboard() {
        editTextBox.requestFocus();
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(editTextBox, InputMethodManager.SHOW_IMPLICIT);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(editTextBox.getWindowToken(), 0);
    }

    private Bitmap getBlurredScreen(View view) {
        if(view.getWidth() == 0 || view.getHeight() == 0) return null;
        Bitmap cache = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(cache);
        view.draw(c);

        int scale = 8;
        Bitmap b = Bitmap.createScaledBitmap(cache, cache.getWidth() / scale, cache.getHeight() / scale, false);
        int w = b.getWidth(), h = b.getHeight();
        int[] pix = new int[w * h];
        b.getPixels(pix, 0, w, 0, 0, w, h);
        int radius = 4;

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = 0, g = 0, bl = 0, cnt = 0;
                for (int dy = -radius; dy <= radius; dy++) {
                    for (int dx = -radius; dx <= radius; dx++) {
                        int nx = x + dx, ny = y + dy;
                        if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
                            int p = pix[ny * w + nx];
                            r += (p >> 16) & 0xFF;
                            g += (p >> 8) & 0xFF;
                            bl += p & 0xFF;
                            cnt++;
                        }
                    }
                }
                pix[y * w + x] = (0xFF000000) | ((r / cnt) << 16) | ((g / cnt) << 8) | (bl / cnt);
            }
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(pix, 0, w, 0, 0, w, h);
        return out;
    }

    private int dp(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, activity.getResources().getDisplayMetrics());
    }

    private View createSpace(int h) {
        View v = new View(activity);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, h));
        return v;
    }

    // M3 Clean Vector Style Icon
    public static class SimpleUserIcon extends View {
        private Paint paint;
        public SimpleUserIcon(Context context, int size, int color) {
            super(context);
            setLayoutParams(new LinearLayout.LayoutParams(size, size));
            paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(size / 10f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
        }
        public void setColor(int color) {
            paint.setColor(color);
            invalidate();
        }
        @Override
        protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            float w = getWidth(), h = getHeight();
            cv.scale(w / 100f, h / 100f);
            Path path = new Path();
            path.addCircle(50, 35, 20, Path.Direction.CW);
            path.moveTo(20, 90);
            path.cubicTo(20, 60, 80, 60, 80, 90);
            cv.drawPath(path, paint);
        }
    }

    // ইনফো আইকন (i) – বৃত্তে “i”
    public static class InfoIconView extends View {
        private Paint circlePaint, textPaint;
        private int color;

        public InfoIconView(Context context, int size, int color) {
            super(context);
            this.color = color;
            setLayoutParams(new LinearLayout.LayoutParams(size, size));

            circlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            circlePaint.setStyle(Paint.Style.STROKE);
            circlePaint.setStrokeWidth(dpRaw(context, 2));
            circlePaint.setColor(color);

            textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(color);
            textPaint.setTextSize(size * 0.6f);
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setTextAlign(Paint.Align.CENTER);
        }

        private static int dpRaw(Context context, float dp) {
            return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float radius = Math.min(cx, cy) - dpRaw(getContext(), 2);
            canvas.drawCircle(cx, cy, radius, circlePaint);

            // টেক্সট “i” বসানো
            float textY = cy - ((textPaint.descent() + textPaint.ascent()) / 2f);
            canvas.drawText("i", cx, textY, textPaint);
        }
    }

    public static class BouncyTouchListener implements View.OnTouchListener {
        Runnable action;
        public BouncyTouchListener(Runnable action){
            this.action = action;
        }
        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch(e.getAction()){
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(100).start();
                    break;
                case MotionEvent.ACTION_UP:
                    v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    v.animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(new OvershootInterpolator(1.5f)).start();
                    if(action != null) action.run();
                    break;
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
                    break;
            }
            return true;
        }
    }
}