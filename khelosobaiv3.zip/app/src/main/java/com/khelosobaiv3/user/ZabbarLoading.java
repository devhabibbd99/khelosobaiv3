package com.khelosobaiv3.user;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.app.AlertDialog;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class ZabbarLoading {

    private final Activity activity;
    private AlertDialog dialog;

    public ZabbarLoading(Activity activity) {
        this.activity = activity;
    }

    public void show() {
        if (dialog != null && dialog.isShowing()) return;

        View view = LayoutInflater.from(activity)
                .inflate(R.layout.zabbar_loading_layout, null);

        dialog = new MaterialAlertDialogBuilder(activity)
                .setView(view)
                .setCancelable(false)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(
                    new ColorDrawable(Color.TRANSPARENT));
        }

        dialog.show();
    }

    public void dismiss() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    public boolean isShowing() {
        return dialog != null && dialog.isShowing();
    }
}