# =========================================================
# ProGuard / R8 Rules
# Package: com.devshuvo.skmesports
# Goal: stable build, keep important Android/Firebase entry points
# =========================================================

# ---------------------------------------------------------
# General keep attributes
# ---------------------------------------------------------
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes Exceptions
-keepattributes InnerClasses
-keepattributes EnclosingMethod
-keepattributes SourceFile,LineNumberTable
-keepattributes RuntimeVisibleAnnotations
-keepattributes RuntimeInvisibleAnnotations
-keepattributes RuntimeVisibleParameterAnnotations
-keepattributes RuntimeInvisibleParameterAnnotations

# ---------------------------------------------------------
# Do not warn for common libraries
# ---------------------------------------------------------
-dontwarn javax.annotation.**
-dontwarn org.codehaus.mojo.animal_sniffer.**
-dontwarn org.checkerframework.**
-dontwarn com.google.errorprone.**
-dontwarn kotlin.**
-dontwarn kotlin.jvm.**
-dontwarn kotlin.coroutines.**
-dontwarn kotlinx.**
-dontwarn org.jetbrains.annotations.**
-dontwarn android.support.**
-dontwarn androidx.**
-dontwarn com.squareup.okhttp3.**
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-dontwarn com.google.gson.**
-dontwarn com.bumptech.glide.**
-dontwarn com.facebook.**
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**

# ---------------------------------------------------------
# Keep Android component entry points
# ---------------------------------------------------------
-keep public class * extends android.app.Activity
-keep public class * extends androidx.appcompat.app.AppCompatActivity
-keep public class * extends androidx.fragment.app.Fragment
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider
-keep public class * extends android.app.job.JobService
-keep public class * extends android.preference.PreferenceActivity
-keep public class * extends androidx.lifecycle.ViewModel

# ---------------------------------------------------------
# Keep your app classes that are referenced by manifest
# ---------------------------------------------------------
-keep class com.devshuvo.skmesports.** { *; }

# If you want slightly more obfuscation later, replace the line above with
# only the required entry points. For now this keeps the app safest.

# ---------------------------------------------------------
# Keep Firebase Messaging / Services / Receivers
# ---------------------------------------------------------
-keep class com.devshuvo.skmesports.MyFirebaseMessagingService { *; }
-keep class com.devshuvo.skmesports.NotificationActionReceiver { *; }
-keep class com.google.firebase.messaging.FirebaseMessagingService { *; }
-keep class com.google.firebase.iid.FirebaseInstanceIdReceiver { *; }

-keep class * extends com.google.firebase.messaging.FirebaseMessagingService { *; }
-keep class * extends android.content.BroadcastReceiver { *; }

# Firebase component discovery
-keep class com.google.firebase.components.** { *; }
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# ---------------------------------------------------------
# Keep Application class
# ---------------------------------------------------------
-keep class com.devshuvo.skmesports.ZabbarX { *; }
-keep class * extends android.app.Application { *; }

# ---------------------------------------------------------
# Keep Activities used in manifest
# ---------------------------------------------------------
-keep class com.devshuvo.skmesports.MainActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarSignupActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarHomeActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarxActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarMatchActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarProfileEditActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarDeveloperActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarAddWalletActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarWithdrawActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarxHistoryActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarLeaderboardActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarMatchJoinActivity { *; }
-keep class com.devshuvo.skmesports.ShvuoRulesActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarLiveChatActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarNotificationActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarParticipantsActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarGiftActivity { *; }
-keep class com.devshuvo.skmesports.ShopConfirmPageActivity { *; }
-keep class com.devshuvo.skmesports.ShuvobroRegisterpageActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarShvuoSsActivity { *; }
-keep class com.devshuvo.skmesports.ActivityReferEarnActivity { *; }
-keep class com.devshuvo.skmesports.ActivityZabbarUpdateActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarSupportActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarTermsActivity { *; }
-keep class com.devshuvo.skmesports.ZabbargameActivity { *; }
-keep class com.devshuvo.skmesports.DebugActivity { *; }
-keep class com.devshuvo.skmesports.ReferAndEarnActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarUpdateActivity { *; }
-keep class com.devshuvo.skmesports.ZabbarAddAccount { *; }

# ---------------------------------------------------------
# Keep manifest-declared external package classes
# ---------------------------------------------------------
-keep class com.google.android.gms.auth.api.signin.internal.SignInHubActivity { *; }
-keep class com.google.android.gms.auth.api.signin.RevocationBoundService { *; }

# ---------------------------------------------------------
# Keep Parcelable / Serializable models
# ---------------------------------------------------------
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
}
-keepclassmembers class ** implements java.io.Serializable { *; }

# Keep parcelable creators
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ---------------------------------------------------------
# Gson rules
# ---------------------------------------------------------
-keep class com.google.gson.** { *; }
-keep class com.google.gson.reflect.** { *; }
-keep class com.google.gson.annotations.** { *; }
-keepattributes *Annotation*

# Keep fields annotated with SerializedName
-keepclassmembers,allowobfuscation class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Keep all model classes if needed
-keep class com.devshuvo.skmesports.model.** { *; }
-keep class com.devshuvo.skmesports.models.** { *; }
-keep class com.devshuvo.skmesports.pojo.** { *; }

# ---------------------------------------------------------
# Retrofit rules
# ---------------------------------------------------------
-dontwarn retrofit2.Platform$Java8
-dontwarn retrofit2.**
-dontwarn org.codehaus.mojo.animal_sniffer.**

-keepattributes Exceptions,Signature,InnerClasses,EnclosingMethod

# Keep Retrofit interfaces
-keep interface com.devshuvo.skmesports.api.** { *; }
-keep interface com.devshuvo.skmesports.network.** { *; }
-keep interface com.devshuvo.skmesports.retrofit.** { *; }

# Keep retrofit annotations
-keepclassmembers interface * {
    @retrofit2.http.* <methods>;
}

# ---------------------------------------------------------
# OkHttp / Okio rules
# ---------------------------------------------------------
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep class okio.** { *; }

# ---------------------------------------------------------
# Glide rules
# ---------------------------------------------------------
-dontwarn com.bumptech.glide.**
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep public class * extends com.bumptech.glide.module.AppGlideModule
-keep class com.bumptech.glide.** { *; }
-keep class * extends com.bumptech.glide.module.AppGlideModule { *; }
-keep class * implements com.bumptech.glide.module.LibraryGlideModule { *; }

# Generated Glide API
-keep class com.bumptech.glide.GeneratedAppGlideModuleImpl { *; }

# ---------------------------------------------------------
# Picasso rules
# ---------------------------------------------------------
-dontwarn com.squareup.picasso.**
-keep class com.squareup.picasso.** { *; }

# ---------------------------------------------------------
# ViewBinding / DataBinding
# ---------------------------------------------------------
-keep class androidx.databinding.** { *; }
-keep class * extends androidx.databinding.ViewDataBinding { *; }
-keep class * extends androidx.viewbinding.ViewBinding { *; }

# ---------------------------------------------------------
# Kotlin rules
# ---------------------------------------------------------
-keep class kotlin.Metadata { *; }
-dontwarn kotlin.Metadata
-keep class kotlin.coroutines.** { *; }
-keepclassmembers class kotlin.Metadata { *; }

# Keep lambdas / synthetic classes
-keepclassmembers class ** {
    ** lambda$*($*); 
}

# ---------------------------------------------------------
# LiveData / ViewModel / Lifecycle
# ---------------------------------------------------------
-keep class androidx.lifecycle.** { *; }
-keep class * extends androidx.lifecycle.ViewModel { *; }
-keep class * extends androidx.lifecycle.AndroidViewModel { *; }
-keep class * implements androidx.lifecycle.LifecycleObserver { *; }

# ---------------------------------------------------------
# WorkManager / JobScheduler
# ---------------------------------------------------------
-keep class androidx.work.** { *; }
-dontwarn androidx.work.**

# ---------------------------------------------------------
# Room database
# ---------------------------------------------------------
-keep class androidx.room.** { *; }
-dontwarn androidx.room.**
-keep @androidx.room.Dao class * { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Database class * { *; }

# ---------------------------------------------------------
# WebView / JavaScript interface
# ---------------------------------------------------------
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ---------------------------------------------------------
# Reflection used classes
# ---------------------------------------------------------
-keep class * {
    public <init>(...);
}

# Keep enum values
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ---------------------------------------------------------
# Keep annotations
# ---------------------------------------------------------
-keep @interface android.support.annotation.Keep
-keep @interface androidx.annotation.Keep

# ---------------------------------------------------------
# Keep app-specific helper classes if used by reflection
# ---------------------------------------------------------
-keep class com.devshuvo.skmesports.ZabbarX** { *; }
-keep class com.devshuvo.skmesports.Zabbar** { *; }
-keep class com.devshuvo.skmesports.Shvuo** { *; }
-keep class com.devshuvo.skmesports.Activity** { *; }

# ---------------------------------------------------------
# Keep Firebase token / messaging helper classes
# ---------------------------------------------------------
-keep class * implements com.google.firebase.iid.internal.FirebaseInstanceIdInternal { *; }
-keep class * implements com.google.firebase.components.ComponentRegistrar { *; }

# ---------------------------------------------------------
# Keep string resources / generated class references
# ---------------------------------------------------------
-keep class **.R
-keep class **.R$*
-dontwarn **.R
-dontwarn **.R$*

# ---------------------------------------------------------
# Keep your package public API stable
# ---------------------------------------------------------
-keep public class com.devshuvo.skmesports.** { public *; }

# If you face runtime reflection issues, uncomment this line:
# -keep class com.devshuvo.skmesports.** { *; }

# ---------------------------------------------------------
# Suppress common AndroidX warnings
# ---------------------------------------------------------
-dontwarn androidx.annotation.**
-dontwarn androidx.core.**
-dontwarn androidx.appcompat.**
-dontwarn androidx.fragment.**
-dontwarn androidx.recyclerview.**
-dontwarn androidx.cardview.**
-dontwarn androidx.constraintlayout.**
-dontwarn androidx.lifecycle.**
-dontwarn androidx.startup.**
-dontwarn androidx.emoji2.**

# ---------------------------------------------------------
# Suppress common Google/Firebase warnings
# ---------------------------------------------------------
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.tasks.**
-dontwarn com.google.android.gms.common.**
-dontwarn com.google.android.gms.common.internal.**
-dontwarn com.google.android.gms.measurement.**
-dontwarn com.google.android.gms.auth.**
-dontwarn com.google.android.gms.auth.api.**

# ---------------------------------------------------------
# Logging
# ---------------------------------------------------------
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
    public static int wtf(...);
}

# ---------------------------------------------------------
# Strip debug info from release only if needed
# ---------------------------------------------------------
# -renamesourcefileattribute SourceFile
# -keepattributes SourceFile,LineNumberTable

# ---------------------------------------------------------
# HTTP / networking helpers
# ---------------------------------------------------------
-dontwarn org.apache.http.**
-keep class org.apache.http.** { *; }

# ---------------------------------------------------------
# JSON helpers
# ---------------------------------------------------------
-keep class org.json.** { *; }
-dontwarn org.json.**

# ---------------------------------------------------------
# Common collection / util classes
# ---------------------------------------------------------
-dontwarn java.lang.invoke.**
-dontwarn sun.misc.**
-dontwarn jdk.internal.**

# ---------------------------------------------------------
# App-specific activities that use reflection/navigation
# ---------------------------------------------------------
-keep class com.devshuvo.skmesports.NotificationActionReceiver { *; }
-keep class com.devshuvo.skmesports.MyFirebaseMessagingService { *; }

# ---------------------------------------------------------
# Final safety rules
# ---------------------------------------------------------
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keepclasseswithmembers class * {
    public static void main(java.lang.String[]);
}

# End of file
# =========================================================

# StringFog
-dontwarn com.github.megatronking.stringfog.**
-keep class com.github.megatronking.stringfog.** { *; }
-keep class com.github.megatronking.stringfog.xor.StringFogImpl { *; }